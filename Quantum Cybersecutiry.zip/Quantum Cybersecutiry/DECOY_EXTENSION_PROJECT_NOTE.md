# Decoy Extension Project Note

Date: 2026-07-13

## Repository inspection

- Active paper source: `report/main.tex`; active bibliography: `report/references.bib`; current compiled PDF: `report/main.pdf`.
- Existing companion decoy notes: `decoy_notes.tex` and `decoy_notes.pdf`.
- Existing numerical artifacts are under `results_01_finite-key`, `results_02_rigorous`, `results_03_reconciliation`, `results_04_theorem-wrapper`, `results_05_publication-ready`, and the `results_ldpc*` folders.
- Existing LDPC code and outputs are present (`ldpc_reconciliation.py`, `run_ldpc_simulation.py`, `generate_ldpc_figures.py`, `results_ldpc*`). LDPC remains exploratory; no large LDPC grid will be launched.
- Local primary literature inspected/extracted: `literature/0411004v4.pdf`, `literature/0806.0120v1.pdf`, `literature/2405.16578v3.pdf`, and `literature/ncomms1631.pdf`.

## Implementation plan

1. Preserve the current ideal single-photon BB84 theorem and empirical Cascade/LDPC sections.
2. Add finite-block Hamming-ball lemmas and one validation figure.
3. Add deterministic weak-coherent-pulse and vacuum-plus-weak decoy calculations.
4. Use Lo--Ma--Chen / Ma--Qi--Zhao--Lo style formulas for the asymptotic vacuum-plus-weak validation.
5. Use Wiesemann et al. (2024/2026 accepted), Appendix A.2 and Eq. (137), as the finite-count source-faithful two-decoy/vacuum-plus-weak proof convention:
   - Eq. (127): lower vacuum events.
   - Eq. (132): lower single-photon events.
   - Eq. (134): upper single-photon errors.
   - Eq. (117): upper single-photon QBER.
   - Eq. (73): Serfling phase sampling correction.
   - Eq. (137): simplified two-decoy secure-key length.
6. Generate expected-count planning results only. The report will state that a real run must insert observed integer counts into the same formulas.
7. Use analytical reconciliation leakage for decoy results: `ceil(f_EC n_Z h2(E_Z))`, with a default and sensitivity band. Do not present this as measured LDPC or Cascade performance.
8. Treat the exact Hamming-ball decoy refinement as conditional unless the source proof supplies the required absolute count structure in a way compatible with the Hamming-ball substitution.

## Expected artifacts

- New code under `code/qkd/` plus runner scripts under `code/`.
- Tests under `tests/`.
- Reproducible decoy outputs under `results/decoy/`.
- New decoy figures and generated tables copied into `report/figures/` and `report/tables/`.
- Rebuilt `report/main.pdf`.
