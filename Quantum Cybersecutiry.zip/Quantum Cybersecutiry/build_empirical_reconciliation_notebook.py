import json
import sys
from pathlib import Path
from textwrap import dedent


cells = []


def add_cell(kind, text):
    source = dedent(text).strip() + "\n"
    cell = {
        "cell_type": kind,
        "id": f"cell-{len(cells) + 1:03d}",
        "metadata": {},
        "source": source.splitlines(True),
    }
    if kind == "code":
        cell.update({"execution_count": None, "outputs": []})
    cells.append(cell)


def md(text):
    add_cell("markdown", text)


def code(text):
    add_cell("code", text)


md(r"""
# Empirical Short-Block Reconciliation Leakage for 256-bit Finite-Key QKD

Notebook 01 explored many possible directions for short-key finite-key QKD. Notebook 02 studied the minimum transmitted signal budget

$$
N_{\min}(Q,\varepsilon_{\mathrm{total}})
=
\min\{N:\ell(N,Q,\varepsilon_{\mathrm{total}})\ge256\}
$$

under several parameter-estimation bounds and artificial error-correction leakage models.

The strongest next step is to replace artificial leakage models with measured leakage from an actual reconciliation protocol. Finite-key formulas subtract public error-correction leakage:

$$
\ell_{\mathrm{toy}}
=
n[1-h_2(Q_{\mathrm{upper}})]
-
\mathrm{leak}_{EC}
-
t_{\mathrm{ver}}
-
2\log_2(1/\varepsilon_{\mathrm{PA}}).
$$

In Notebook 02, $\mathrm{leak}_{EC}$ was modelled by formulas such as

$$
f_{\mathrm{EC}} n h_2(Q)
$$

or by short-block stress tests. In this notebook we simulate reconciliation and measure:

- parity or syndrome leakage,
- effective EC efficiency,
- residual mismatch probability,
- operational reconciliation success probability,
- effect on $N_{\min}$.

**Scientific caution.** This is still not a complete QKD security proof. It is an empirical protocol-level reconciliation study that gives a more realistic leakage input for a finite-key planning model.
""")

md(r"""
## Information Reconciliation in QKD

Alice has a raw key $X$. Bob has a noisy raw key $Y$, where

$$
Y=X\oplus E,
$$

and each bit is flipped with probability approximately equal to the observed QBER $Q$.

The purpose of information reconciliation is for Bob to correct $Y$ so that it equals $X$, using public communication. That public communication leaks information to Eve, so finite-key formulas subtract it.

The ideal Shannon-style leakage model is

$$
\mathrm{leak}_{EC}^{\mathrm{ideal}}
=
f_{\mathrm{EC}} n h_2(Q).
$$

Here $n$ is the raw key block length entering reconciliation, $Q$ is the bit error rate, $h_2(Q)$ is the binary entropy, and $f_{\mathrm{EC}}$ is the reconciliation inefficiency factor. For long blocks, good codes may approach $f_{\mathrm{EC}}\approx 1$. For short blocks, fixed overheads and inefficient correction can make the real leakage much larger.

The central question is: for short QKD blocks producing only a 256-bit final key, how much worse is actual reconciliation leakage compared with $f_{\mathrm{EC}} n h_2(Q)$?
""")

md(r"""
## Cascade Reconciliation

Cascade is an interactive reconciliation protocol.

Basic idea:

1. Alice and Bob split their strings into blocks.
2. Alice reveals the parity of each block.
3. Bob compares that public parity with his local parity.
4. If parities disagree, the block contains an odd number of errors.
5. They binary-search inside the block using parities of sub-blocks.
6. Once an error is located, Bob flips that bit.
7. The correction can change parities of blocks from earlier passes, so Cascade revisits affected blocks.
8. Multiple passes use different random permutations and larger block sizes to catch errors that were hidden in even-error blocks.

Every revealed parity bit is public and must be counted as leakage. The permutation can be public if it is independent of the key, so it does not reveal key values. In this notebook, the primary leakage metric is the number of public parity values revealed. We also track protocol counters, but the finite-key input uses parity leakage only.

Cascade may fail if residual errors remain. In QKD, a later verification hash detects remaining mismatch with high probability. This notebook measures reconciliation failure probability separately; it does not treat an empirical failure rate as a theorem-level correctness bound.
""")

md(r"""
## Simple Hamming-Family Syndrome Baseline

Implementing full BCH or LDPC reconciliation from scratch is large. To keep the notebook self-contained, we implement a simple syndrome-code baseline based on binary Hamming codes.

Binary Hamming codes are single-error-correcting linear block codes and can be viewed as a simple BCH-family baseline with designed distance 3. They are not competitive with modern LDPC or Cascade at all parameter regimes, but they are useful because:

- leakage is exactly syndrome length,
- failure probability can be measured,
- short-block behavior is easy to see,
- they provide a non-interactive comparison to Cascade.

For a Hamming parameter $r$, the block length is $2^r-1$ and the syndrome length is $r$. Examples include $r=4$ with length 15, $r=5$ with length 31, $r=6$ with length 63, and $r=7$ with length 127.

For each block, Alice reveals $HX$, Bob computes $HY$, and the difference syndrome identifies a single-bit error if the block has exactly one error. If the block has two or more errors, single-error correction can fail. Leftover bits that do not fill a full Hamming block are revealed completely in this self-contained baseline; the leakage is counted as the leftover length.

This is not a full BCH or LDPC implementation. It is a clean syndrome-code baseline. The main reconciliation model in this notebook is Cascade.
""")

md("## Imports and Setup")

code(r'''
import itertools
import json
import math
import random
import sys
import time
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy.stats import hypergeom
import matplotlib
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore", category=RuntimeWarning)

START_TIME = time.time()
TARGET_KEY_LENGTH = 256
DEFAULT_EPS_TOTAL = 1e-9
DEFAULT_P_SIFT = 0.5
DEFAULT_F_EC = 1.1
RNG_SEED = 12345

results_dir = Path("results_03_reconciliation")
fig_dir = results_dir / "figures"
res_dir = results_dir / "tables"
fig_dir.mkdir(parents=True, exist_ok=True)
res_dir.mkdir(parents=True, exist_ok=True)

np.random.seed(RNG_SEED)
random.seed(RNG_SEED)

plt.rcParams.update({
    "figure.figsize": (8.8, 5.3),
    "axes.grid": True,
    "grid.alpha": 0.25,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "font.size": 11,
})

OPTIONAL_LIBRARY_STATUS = {}
for optional_name in ["galois", "ldpc"]:
    try:
        __import__(optional_name)
        OPTIONAL_LIBRARY_STATUS[optional_name] = "available"
    except Exception:
        OPTIONAL_LIBRARY_STATUS[optional_name] = "not available"


def save_figure(name):
    """Save the active matplotlib figure into the reconciliation figures folder."""
    path = fig_dir / name
    plt.tight_layout()
    plt.savefig(path, dpi=180, bbox_inches="tight")
    return path


print(f"Figures directory: {fig_dir.resolve()}")
print(f"Results directory: {res_dir.resolve()}")
print("Optional libraries:", OPTIONAL_LIBRARY_STATUS)
''')

md("## Basic Utilities")

code(r'''
def binary_entropy(q):
    """Return the binary entropy h2(q) for scalars or numpy arrays."""
    arr = np.asarray(q, dtype=float)
    safe = np.clip(arr, 1e-15, 1.0 - 1e-15)
    h = -(safe * np.log2(safe) + (1.0 - safe) * np.log2(1.0 - safe))
    h = np.where((arr <= 0.0) | (arr >= 1.0), 0.0, h)
    if np.isscalar(q):
        return float(h)
    return h


def generate_correlated_keys(n, qber, rng):
    """Generate Alice and Bob raw keys with independent Bernoulli(qber) flips."""
    alice = rng.integers(0, 2, size=int(n), dtype=np.uint8)
    error_mask = rng.random(int(n)) < float(qber)
    bob = alice.copy()
    bob[error_mask] ^= np.uint8(1)
    return alice, bob, error_mask.astype(bool)


def count_mismatches(a, b):
    """Return the number of positions where two bit arrays differ."""
    return int(np.sum(np.asarray(a) != np.asarray(b)))


def ideal_leakage(n, qber, f_ec=1.1):
    """Return f_ec * n * h2(qber)."""
    return float(f_ec * int(n) * binary_entropy(float(qber)))
''')

md("## Cascade Implementation")

code(r'''
def parity(bits):
    """Return parity bit as int 0 or 1."""
    arr = np.asarray(bits, dtype=np.uint8)
    if arr.size == 0:
        return 0
    return int(np.bitwise_xor.reduce(arr) & np.uint8(1))


def make_blocks(indices, block_size):
    """Split an array of indices into consecutive numpy-array blocks."""
    indices = np.asarray(indices, dtype=np.int64)
    block_size = max(1, int(block_size))
    return [indices[start:start + block_size] for start in range(0, len(indices), block_size)]


def locate_single_error_by_binary_search(alice, bob, block_indices, leakage_counter):
    """Locate one odd-parity error using public half-block parities and flip Bob's bit.

    The caller is responsible for counting the public parity that detected this
    block mismatch. This function counts exactly one additional leakage bit for
    each Alice half-block parity revealed during binary search.
    """
    active = np.asarray(block_indices, dtype=np.int64)
    public_parity_queries = 0
    while len(active) > 1:
        mid = len(active) // 2
        left = active[:mid]
        right = active[mid:]
        alice_left_parity = parity(alice[left])
        bob_left_parity = parity(bob[left])
        leakage_counter += 1
        public_parity_queries += 1
        if alice_left_parity != bob_left_parity:
            active = left
        else:
            active = right
    corrected_index = int(active[0])
    bob[corrected_index] ^= np.uint8(1)
    return corrected_index, leakage_counter, public_parity_queries


def _cascade_block_schedule(n, qber_estimate, num_passes, first_block_factor):
    """Return Cascade block sizes for a block of length n."""
    if n <= 0:
        return []
    if qber_estimate > 0:
        k1 = max(4, int(math.ceil(float(first_block_factor) / float(qber_estimate))))
    else:
        k1 = n
    return [min(n, max(1, int(k1 * (2 ** pass_idx)))) for pass_idx in range(int(num_passes))]


def cascade_reconcile(
    alice,
    bob,
    qber_estimate,
    num_passes=4,
    first_block_factor=0.73,
    shuffle_seed=None,
    enable_backtracking=True,
):
    """Run a simplified but real Cascade reconciliation simulation.

    Leakage accounting:
    - one bit for every public block parity revealed,
    - one bit for every public half-block parity revealed in binary search,
    - no verification hash leakage is counted here, because the finite-key
      formula subtracts t_ver separately.
    """
    alice = np.asarray(alice, dtype=np.uint8)
    corrected_bob = np.asarray(bob, dtype=np.uint8).copy()
    n = len(alice)
    rng = np.random.default_rng(shuffle_seed)
    initial_errors = count_mismatches(alice, corrected_bob)

    leakage_bits = 0
    parity_checks = 0
    binary_searches = 0
    binary_search_parity_queries = 0
    corrections = 0
    backtracking_checks = 0
    backtracking_limit_hit = False

    block_sizes = _cascade_block_schedule(n, qber_estimate, num_passes, first_block_factor)
    pass_metadata = []
    max_backtracking_ops = max(1000, 20 * max(1, n))

    def enqueue_affected_blocks(queue, corrected_index, max_pass_inclusive):
        for old_pass_idx in range(max_pass_inclusive + 1):
            metadata = pass_metadata[old_pass_idx]
            block_idx = int(metadata["position_to_block"][corrected_index])
            if block_idx >= 0:
                queue.append((old_pass_idx, block_idx))

    def process_backtracking(queue):
        nonlocal leakage_bits, parity_checks, binary_searches, corrections
        nonlocal binary_search_parity_queries
        nonlocal backtracking_checks, backtracking_limit_hit
        ops = 0
        while queue:
            if ops >= max_backtracking_ops:
                backtracking_limit_hit = True
                break
            pass_idx, block_idx = queue.pop(0)
            block = pass_metadata[pass_idx]["blocks"][block_idx]
            leakage_bits += 1
            parity_checks += 1
            backtracking_checks += 1
            ops += 1
            if parity(alice[block]) != parity(corrected_bob[block]):
                corrected_index, leakage_bits, queries = locate_single_error_by_binary_search(
                    alice, corrected_bob, block, leakage_bits
                )
                binary_searches += 1
                binary_search_parity_queries += queries
                corrections += 1
                if enable_backtracking:
                    enqueue_affected_blocks(queue, corrected_index, pass_idx)

    for pass_idx, block_size in enumerate(block_sizes):
        permutation = rng.permutation(n)
        blocks = make_blocks(permutation, block_size)
        position_to_block = np.full(n, -1, dtype=np.int64)
        for block_idx, block in enumerate(blocks):
            position_to_block[block] = block_idx
        pass_metadata.append({
            "block_size": block_size,
            "blocks": blocks,
            "position_to_block": position_to_block,
        })

        for block_idx, block in enumerate(blocks):
            leakage_bits += 1
            parity_checks += 1
            if parity(alice[block]) != parity(corrected_bob[block]):
                corrected_index, leakage_bits, queries = locate_single_error_by_binary_search(
                    alice, corrected_bob, block, leakage_bits
                )
                binary_searches += 1
                binary_search_parity_queries += queries
                corrections += 1
                if enable_backtracking and pass_idx > 0:
                    queue = []
                    enqueue_affected_blocks(queue, corrected_index, pass_idx - 1)
                    process_backtracking(queue)

    final_errors = count_mismatches(alice, corrected_bob)
    return {
        "corrected_bob": corrected_bob,
        "leakage_bits": int(leakage_bits),
        "initial_errors": int(initial_errors),
        "final_errors": int(final_errors),
        "success": bool(final_errors == 0),
        "num_passes": int(num_passes),
        "block_sizes": [int(x) for x in block_sizes],
        "parity_checks": int(parity_checks),
        "binary_searches": int(binary_searches),
        "binary_search_parity_queries": int(binary_search_parity_queries),
        "corrections": int(corrections),
        "backtracking_checks": int(backtracking_checks),
        "backtracking_limit_hit": bool(backtracking_limit_hit),
    }
''')

md("## Hamming Syndrome-Code Baseline")

code(r'''
def hamming_parity_check_matrix(r):
    """Return H of shape (r, 2^r - 1) with binary columns 1..2^r-1."""
    r = int(r)
    n = 2 ** r - 1
    H = np.zeros((r, n), dtype=np.uint8)
    for position in range(1, n + 1):
        for bit in range(r):
            H[bit, position - 1] = (position >> bit) & 1
    return H


def syndrome(bits, H):
    """Compute H @ bits mod 2."""
    bits = np.asarray(bits, dtype=np.uint8)
    H = np.asarray(H, dtype=np.uint8)
    return ((H @ bits) % 2).astype(np.uint8)


def _syndrome_to_position(diff):
    """Convert a binary syndrome vector to a 1-based Hamming position."""
    value = 0
    for bit, entry in enumerate(np.asarray(diff, dtype=np.uint8)):
        value |= int(entry) << bit
    return value


def hamming_reconcile_block(alice_block, bob_block, H):
    """Reconcile one Hamming block using Alice's public syndrome."""
    corrected = np.asarray(bob_block, dtype=np.uint8).copy()
    alice_syndrome = syndrome(alice_block, H)
    bob_syndrome = syndrome(corrected, H)
    diff = (alice_syndrome ^ bob_syndrome).astype(np.uint8)
    position = _syndrome_to_position(diff)
    if 1 <= position <= len(corrected):
        corrected[position - 1] ^= np.uint8(1)
    leakage_bits = int(H.shape[0])
    success_for_block = count_mismatches(alice_block, corrected) == 0
    return corrected, leakage_bits, bool(success_for_block)


def hamming_reconcile_full(alice, bob, r=6):
    """Apply Hamming syndrome reconciliation blockwise.

    Leftover bits smaller than a full Hamming block are revealed completely and
    copied from Alice to Bob. Their leakage is counted as the leftover length.
    """
    alice = np.asarray(alice, dtype=np.uint8)
    corrected_bob = np.asarray(bob, dtype=np.uint8).copy()
    initial_errors = count_mismatches(alice, corrected_bob)
    H = hamming_parity_check_matrix(r)
    block_length = H.shape[1]
    leakage_bits = 0
    corrected_blocks = 0
    failed_blocks = 0

    for start in range(0, len(alice), block_length):
        stop = min(start + block_length, len(alice))
        if stop - start == block_length:
            corrected, leak, success = hamming_reconcile_block(
                alice[start:stop], corrected_bob[start:stop], H
            )
            corrected_bob[start:stop] = corrected
            leakage_bits += leak
            corrected_blocks += int(success)
            failed_blocks += int(not success)
        else:
            leftover = stop - start
            corrected_bob[start:stop] = alice[start:stop]
            leakage_bits += leftover

    final_errors = count_mismatches(alice, corrected_bob)
    return {
        "corrected_bob": corrected_bob,
        "leakage_bits": int(leakage_bits),
        "initial_errors": int(initial_errors),
        "final_errors": int(final_errors),
        "success": bool(final_errors == 0),
        "r": int(r),
        "block_length": int(block_length),
        "corrected_blocks": int(corrected_blocks),
        "failed_blocks": int(failed_blocks),
    }
''')

md(r"""
## Simulation Design

We simulate many independent raw-key blocks. For each block length $n$, QBER $Q$, and reconciliation protocol, we measure:

- initial number of errors,
- final number of errors,
- success indicator,
- leakage bits,
- effective leakage efficiency

$$
f_{\mathrm{eff}}
=
\frac{\mathrm{leakage}}{n h_2(Q)}
$$

when $Q>0$, and residual error rate.
""")

code(r'''
def simulate_reconciliation(
    protocol,
    n,
    qber,
    trials=200,
    rng_seed=0,
    **protocol_kwargs,
):
    """Run repeated reconciliation simulations and return one row per trial."""
    rng = np.random.default_rng(rng_seed)
    rows = []
    for trial in range(int(trials)):
        alice, bob, _ = generate_correlated_keys(n, qber, rng)
        if protocol == "cascade":
            result = cascade_reconcile(
                alice,
                bob,
                qber_estimate=qber,
                shuffle_seed=int(rng.integers(0, 2**32 - 1)),
                **protocol_kwargs,
            )
            protocol_label = "cascade"
        elif protocol == "hamming":
            r = int(protocol_kwargs.get("r", 6))
            result = hamming_reconcile_full(alice, bob, r=r)
            protocol_label = f"hamming_r{r}"
        else:
            raise ValueError(f"Unknown protocol: {protocol}")

        leakage = float(result["leakage_bits"])
        shannon = float(n * binary_entropy(qber))
        ideal_1_1 = ideal_leakage(n, qber, DEFAULT_F_EC)
        rows.append({
            "protocol": protocol_label,
            "n": int(n),
            "qber": float(qber),
            "trial": int(trial),
            "initial_errors": int(result["initial_errors"]),
            "final_errors": int(result["final_errors"]),
            "success": bool(result["success"]),
            "leakage_bits": leakage,
            "ideal_leakage_fec_1": shannon,
            "ideal_leakage_fec_1_1": ideal_1_1,
            "f_eff_vs_shannon": leakage / shannon if shannon > 0 else np.nan,
            "f_eff_vs_fec_1_1": leakage / ideal_1_1 if ideal_1_1 > 0 else np.nan,
            "residual_qber": float(result["final_errors"] / n),
            "parity_checks": int(result.get("parity_checks", 0)),
            "binary_searches": int(result.get("binary_searches", 0)),
            "binary_search_parity_queries": int(result.get("binary_search_parity_queries", 0)),
            "corrections": int(result.get("corrections", 0)),
            "backtracking_checks": int(result.get("backtracking_checks", 0)),
            "backtracking_limit_hit": bool(result.get("backtracking_limit_hit", False)),
        })
    return pd.DataFrame(rows)


def summarize_reconciliation_trials(df):
    """Summarize trial-level reconciliation results by protocol, n, and QBER."""
    grouped = df.groupby(["protocol", "n", "qber"], as_index=False)
    summary = grouped.agg(
        trials=("trial", "count"),
        mean_leakage=("leakage_bits", "mean"),
        median_leakage=("leakage_bits", "median"),
        p90_leakage=("leakage_bits", lambda x: float(np.quantile(x, 0.90))),
        p95_leakage=("leakage_bits", lambda x: float(np.quantile(x, 0.95))),
        p99_leakage=("leakage_bits", lambda x: float(np.quantile(x, 0.99))),
        max_leakage=("leakage_bits", "max"),
        failure_rate=("success", lambda x: float(1.0 - np.mean(x.astype(float)))),
        mean_initial_errors=("initial_errors", "mean"),
        mean_final_errors=("final_errors", "mean"),
        mean_f_eff=("f_eff_vs_shannon", "mean"),
        p95_f_eff=("f_eff_vs_shannon", lambda x: float(np.nanquantile(x, 0.95))),
        p99_f_eff=("f_eff_vs_shannon", lambda x: float(np.nanquantile(x, 0.99))),
        mean_residual_qber=("residual_qber", "mean"),
        mean_parity_checks=("parity_checks", "mean"),
        mean_binary_searches=("binary_searches", "mean"),
        mean_binary_search_parity_queries=("binary_search_parity_queries", "mean"),
        any_backtracking_limit_hit=("backtracking_limit_hit", "max"),
    )
    return summary
''')

md(r"""
## Run Empirical Leakage Simulations

The grid below is deliberately moderate so that the notebook remains runnable from top to bottom while still showing short-block behavior across relevant QBERs.
""")

code(r'''
n_values = [256, 512, 1024, 2048, 4096, 8192]
qber_values = [0.005, 0.01, 0.02, 0.03, 0.05, 0.08]
trials_per_point = 200
cascade_passes = 4
hamming_r_values = [5, 6, 7]
main_hamming_r = 6

all_trial_tables = []
total_jobs = len(n_values) * len(qber_values) * 2
job = 0

for n, qber in itertools.product(n_values, qber_values):
    job += 1
    print(f"[{job:02d}/{total_jobs}] Cascade n={n}, QBER={qber:.3f}")
    all_trial_tables.append(simulate_reconciliation(
        "cascade",
        n=n,
        qber=qber,
        trials=trials_per_point,
        rng_seed=RNG_SEED + 100000 + 1000 * n + int(qber * 1_000_000),
        num_passes=cascade_passes,
        first_block_factor=0.73,
        enable_backtracking=True,
    ))

for n, qber in itertools.product(n_values, qber_values):
    job += 1
    print(f"[{job:02d}/{total_jobs}] Hamming r={main_hamming_r} n={n}, QBER={qber:.3f}")
    all_trial_tables.append(simulate_reconciliation(
        "hamming",
        n=n,
        qber=qber,
        trials=trials_per_point,
        rng_seed=RNG_SEED + 200000 + 1000 * n + int(qber * 1_000_000),
        r=main_hamming_r,
    ))

df_trials = pd.concat(all_trial_tables, ignore_index=True)
df_summary = summarize_reconciliation_trials(df_trials)

df_trials.to_csv(res_dir / "reconciliation_trials.csv", index=False)
df_summary.to_csv(res_dir / "reconciliation_summary.csv", index=False)

display(df_summary)
''')

md("### Leakage-Counting Sanity Check")

code(r'''
cascade_trials = df_trials[df_trials["protocol"] == "cascade"].copy()
cascade_trials["leakage_consistency_error"] = (
    cascade_trials["leakage_bits"]
    - cascade_trials["parity_checks"]
    - cascade_trials["binary_search_parity_queries"]
)
max_abs_leakage_error = float(np.max(np.abs(cascade_trials["leakage_consistency_error"])))
print("Cascade leakage consistency max absolute error:", max_abs_leakage_error)
print("Backtracking limit hit in any trial:", bool(cascade_trials["backtracking_limit_hit"].max()))
assert max_abs_leakage_error == 0.0
assert not bool(cascade_trials["backtracking_limit_hit"].max())
''')

md("## Plots: Empirical Leakage Behavior")

code(r'''
cascade_summary = df_summary[df_summary["protocol"] == "cascade"].copy()
hamming_summary = df_summary[df_summary["protocol"] == f"hamming_r{main_hamming_r}"].copy()

plt.figure(figsize=(9, 5.4))
for qber, sub in cascade_summary.groupby("qber"):
    sub = sub.sort_values("n")
    plt.plot(sub["n"], sub["mean_leakage"], marker="o", label=f"Q={100*qber:.1f}%")
plt.xscale("log", base=2)
plt.xlabel("Raw reconciliation block length n")
plt.ylabel("Mean leakage bits")
plt.title("Cascade mean leakage vs n")
plt.legend(title="QBER", fontsize=8)
save_figure("cascade_mean_leakage_vs_n.png")
plt.show()

plt.figure(figsize=(9, 5.4))
for qber, sub in cascade_summary.groupby("qber"):
    sub = sub.sort_values("n")
    plt.plot(sub["n"], sub["mean_f_eff"], marker="o", label=f"Q={100*qber:.1f}%")
plt.axhline(1.0, color="black", linestyle="--", linewidth=1, label="Shannon limit")
plt.axhline(DEFAULT_F_EC, color="gray", linestyle=":", linewidth=1, label="f_EC=1.1")
plt.xscale("log", base=2)
plt.xlabel("Raw reconciliation block length n")
plt.ylabel("Effective leakage efficiency")
plt.title("Cascade effective leakage efficiency vs n")
plt.legend(fontsize=8)
save_figure("cascade_f_eff_vs_n.png")
plt.show()

plt.figure(figsize=(9, 5.4))
for qber, sub in cascade_summary.groupby("qber"):
    sub = sub.sort_values("n")
    plt.plot(sub["n"], sub["failure_rate"], marker="o", label=f"Q={100*qber:.1f}%")
plt.xscale("log", base=2)
plt.yscale("symlog", linthresh=1e-3)
plt.xlabel("Raw reconciliation block length n")
plt.ylabel("Failure rate")
plt.title("Cascade reconciliation failure rate vs n")
plt.legend(title="QBER", fontsize=8)
save_figure("cascade_failure_rate_vs_n.png")
plt.show()

selected_plot_qbers = [0.01, 0.03, 0.05]
fig, axes = plt.subplots(1, len(selected_plot_qbers), figsize=(14, 4.7), sharey=False)
for ax, qber in zip(axes, selected_plot_qbers):
    cas = cascade_summary[np.isclose(cascade_summary["qber"], qber)].sort_values("n")
    ham = hamming_summary[np.isclose(hamming_summary["qber"], qber)].sort_values("n")
    ideal = [ideal_leakage(n, qber, DEFAULT_F_EC) for n in cas["n"]]
    ax.plot(cas["n"], ideal, marker="o", label="ideal 1.1 n h2(Q)")
    ax.plot(cas["n"], cas["p95_leakage"], marker="o", label="Cascade p95")
    ax.plot(ham["n"], ham["mean_leakage"], marker="o", label=f"Hamming r={main_hamming_r} mean")
    ax.set_xscale("log", base=2)
    ax.set_title(f"QBER={100*qber:.0f}%")
    ax.set_xlabel("n")
    ax.set_ylabel("Leakage bits")
axes[0].legend(fontsize=8)
save_figure("leakage_models_comparison_empirical.png")
plt.show()

pivot = cascade_summary.pivot(index="qber", columns="n", values="p95_f_eff").sort_index()
plt.figure(figsize=(9.2, 5.2))
im = plt.imshow(pivot.values, aspect="auto", origin="lower")
plt.colorbar(im, label="Cascade p95 f_eff")
plt.xticks(range(len(pivot.columns)), [str(c) for c in pivot.columns], rotation=45)
plt.yticks(range(len(pivot.index)), [f"{100*q:.1f}%" for q in pivot.index])
plt.xlabel("n")
plt.ylabel("QBER")
plt.title("Cascade p95 leakage efficiency heatmap")
save_figure("cascade_p95_f_eff_heatmap.png")
plt.show()
''')

md(r"""
### Leakage Behavior Analysis

Cascade leakage grows with block length and QBER because more errors require more public parity queries. The effective efficiency is worst for the shortest blocks, where block parities and interactive searches are large compared with the Shannon term. Larger blocks often move closer to a stable efficiency, but finite block size and backtracking still prevent the empirical leakage from behaving like a smooth asymptotic formula.

The failure rate is separate from leakage. Leakage reduces the secret key length; residual mismatch affects correctness and operational abort probability. In this notebook, verification leakage is not included in reconciliation leakage because $t_{\mathrm{ver}}$ is subtracted separately in the finite-key calculation.
""")

md("## Build Empirical Leakage Table")

code(r'''
def build_empirical_leakage_table(summary_df, protocol="cascade"):
    """Build a finite-key lookup table from reconciliation summaries."""
    table = summary_df[summary_df["protocol"] == protocol].copy()
    if table.empty:
        raise ValueError(f"No rows found for protocol={protocol!r}")
    denom = table["n"].astype(float) * table["qber"].map(binary_entropy).astype(float)
    denom = denom.replace(0.0, np.nan)
    for stat in ["mean", "median", "p90", "p95", "p99", "max"]:
        leakage_col = f"{stat}_leakage" if stat != "mean" else "mean_leakage"
        if leakage_col in table.columns:
            table[f"{stat}_f_eff"] = table[leakage_col] / denom
    return table.sort_values(["protocol", "qber", "n"]).reset_index(drop=True)


cascade_leakage_table = build_empirical_leakage_table(df_summary, protocol="cascade")
hamming_leakage_table = build_empirical_leakage_table(df_summary, protocol=f"hamming_r{main_hamming_r}")
empirical_leakage_table = pd.concat([cascade_leakage_table, hamming_leakage_table], ignore_index=True)
empirical_leakage_table.to_csv(res_dir / "empirical_leakage_table.csv", index=False)
display(empirical_leakage_table)


def _nearest_values(values, target):
    """Return lower and upper neighboring values from a sorted numeric array."""
    values = np.asarray(sorted(np.unique(values)), dtype=float)
    target = float(target)
    if target <= values[0]:
        return values[0], values[0]
    if target >= values[-1]:
        return values[-1], values[-1]
    upper_idx = int(np.searchsorted(values, target, side="left"))
    return values[upper_idx - 1], values[upper_idx]


def empirical_leakage_lookup(
    n,
    qber,
    table,
    protocol="cascade",
    statistic="p95_leakage",
    return_info=False,
):
    """Return interpolated empirical leakage for (n, qber).

    The lookup uses bilinear interpolation inside the simulated grid. Outside
    the simulated grid, it clamps to the nearest boundary. For n outside the
    grid, it uses the boundary effective efficiency and scales by n h2(Q);
    this is marked as extrapolated.
    """
    sub = table[table["protocol"] == protocol].copy()
    if sub.empty:
        raise ValueError(f"No empirical leakage table rows for protocol={protocol!r}")
    if statistic not in sub.columns:
        raise ValueError(f"Statistic {statistic!r} is not in the empirical leakage table.")

    n = int(max(1, round(n)))
    qber = float(qber)
    n_values_table = np.asarray(sorted(sub["n"].unique()), dtype=float)
    q_values_table = np.asarray(sorted(sub["qber"].unique()), dtype=float)
    n_low, n_high = _nearest_values(n_values_table, n)
    q_low, q_high = _nearest_values(q_values_table, qber)
    clamped_n = float(np.clip(n, n_values_table[0], n_values_table[-1]))
    clamped_q = float(np.clip(qber, q_values_table[0], q_values_table[-1]))
    extrapolated = bool(n < n_values_table[0] or n > n_values_table[-1] or qber < q_values_table[0] or qber > q_values_table[-1])

    pivot = sub.pivot(index="qber", columns="n", values=statistic)

    def value_at(q, nn):
        return float(pivot.loc[float(q), int(nn)])

    if n_low == n_high and q_low == q_high:
        boundary_value = value_at(q_low, n_low)
    elif n_low == n_high:
        v0 = value_at(q_low, n_low)
        v1 = value_at(q_high, n_low)
        t = 0.0 if q_high == q_low else (clamped_q - q_low) / (q_high - q_low)
        boundary_value = (1.0 - t) * v0 + t * v1
    elif q_low == q_high:
        v0 = value_at(q_low, n_low)
        v1 = value_at(q_low, n_high)
        t = 0.0 if n_high == n_low else (clamped_n - n_low) / (n_high - n_low)
        boundary_value = (1.0 - t) * v0 + t * v1
    else:
        q_t = (clamped_q - q_low) / (q_high - q_low)
        n_t = (clamped_n - n_low) / (n_high - n_low)
        v00 = value_at(q_low, n_low)
        v01 = value_at(q_low, n_high)
        v10 = value_at(q_high, n_low)
        v11 = value_at(q_high, n_high)
        boundary_value = (
            (1.0 - q_t) * (1.0 - n_t) * v00
            + (1.0 - q_t) * n_t * v01
            + q_t * (1.0 - n_t) * v10
            + q_t * n_t * v11
        )

    leakage = float(boundary_value)
    if n != int(clamped_n):
        boundary_denom = max(float(clamped_n) * binary_entropy(clamped_q), 1e-12)
        efficiency = boundary_value / boundary_denom
        leakage = efficiency * n * binary_entropy(qber)

    info = {
        "leakage": float(leakage),
        "extrapolated": extrapolated,
        "source_n": int(clamped_n),
        "source_qber": float(clamped_q),
        "statistic": statistic,
        "protocol": protocol,
    }
    return info if return_info else float(leakage)


def empirical_metric_lookup(n, qber, table, protocol="cascade", metric="failure_rate"):
    """Lookup a non-leakage empirical metric by nearest boundary."""
    sub = table[table["protocol"] == protocol].copy()
    q_values_table = np.asarray(sorted(sub["qber"].unique()), dtype=float)
    n_values_table = np.asarray(sorted(sub["n"].unique()), dtype=float)
    nearest_q = float(q_values_table[np.argmin(np.abs(q_values_table - float(qber)))])
    nearest_n = int(n_values_table[np.argmin(np.abs(n_values_table - int(n)))])
    row = sub[(np.isclose(sub["qber"], nearest_q)) & (sub["n"] == nearest_n)].iloc[0]
    return float(row[metric])
''')

md(r"""
## Finite-Key Planning Model With Empirical EC

We now feed empirical leakage into the same planning formula:

$$
\ell_{\mathrm{toy}}
=
n[1-h_2(Q_{\mathrm{upper}})]
-
\mathrm{leak}_{EC}(n,Q)
-
t_{\mathrm{ver}}
-
2\log_2(1/\varepsilon_{\mathrm{PA}}).
$$

The only change is that $\mathrm{leak}_{EC}$ is measured from reconciliation simulations instead of assumed as $f_{\mathrm{EC}}nh_2(Q)$.

For parameter estimation, this notebook uses Serfling as the default conservative method and includes a corrected hypergeometric key-block helper for future comparisons. The finite-key code below is self-contained and does not import Notebook 02.
""")

code(r'''
HYPERGEOM_EXACT_MAX_S = 200_000
OPTIMIZER_M_GRID = 120


def verification_tag_length(eps_cor):
    """Return ceil(log2(1 / eps_cor))."""
    return int(np.ceil(np.log2(1.0 / float(eps_cor))))


def privacy_amplification_penalty(eps_pa):
    """Return the toy privacy amplification penalty 2 log2(1 / eps_pa)."""
    return float(2.0 * np.log2(1.0 / float(eps_pa)))


def split_epsilons(eps_total):
    """Split the toy security budget into PE, PA, and correctness parts."""
    eps_total = float(eps_total)
    return eps_total / 3.0, eps_total / 3.0, eps_total / 3.0


def q_upper_serfling(q_hat, m, s, eps_pe):
    """Simplified Serfling-style upper bound for sampling without replacement."""
    if m <= 0 or s <= 0 or m >= s:
        return 0.5
    q_hat = float(np.clip(q_hat, 0.0, 0.5))
    delta = math.sqrt(((s - m + 1.0) * math.log(1.0 / eps_pe)) / (2.0 * m * s))
    return float(np.clip(q_hat + delta, 0.0, 0.5))


def q_upper_hypergeom_exact_key_block(k_errors, m, s, eps_pe):
    """Exact hypergeometric inversion returning an unrevealed key-block rate."""
    k_errors = int(np.clip(k_errors, 0, m))
    m = int(m)
    s = int(s)
    eps_pe = float(eps_pe)
    if m <= 0 or s <= 0 or m >= s:
        return 0.5
    if s > HYPERGEOM_EXACT_MAX_S:
        return q_upper_serfling(k_errors / m, m, s, eps_pe)
    low = max(k_errors, 0)
    high = s
    best_K = low
    while low <= high:
        mid_K = (low + high) // 2
        cdf = float(hypergeom.cdf(k_errors, s, mid_K, m))
        if not np.isfinite(cdf):
            return q_upper_serfling(k_errors / m, m, s, eps_pe)
        if cdf >= eps_pe:
            best_K = mid_K
            low = mid_K + 1
        else:
            high = mid_K - 1
    remaining_errors_upper = max(0, best_K - k_errors)
    return float(np.clip(remaining_errors_upper / (s - m), 0.0, 0.5))


def q_upper_bound(qber, m, s, eps_pe, method="serfling"):
    """Return a PE upper bound dictionary."""
    k_errors = int(np.clip(round(float(qber) * int(m)), 0, int(m)))
    q_hat = k_errors / int(m)
    if method == "serfling":
        q_upper = q_upper_serfling(q_hat, m, s, eps_pe)
        used_method = "serfling"
        fallback = False
    elif method == "hypergeom_exact":
        fallback = int(s) > HYPERGEOM_EXACT_MAX_S
        q_upper = q_upper_hypergeom_exact_key_block(k_errors, m, s, eps_pe)
        used_method = "serfling_fallback" if fallback else "hypergeom_exact"
    else:
        raise ValueError(f"Unknown PE method: {method}")
    return {
        "q_upper": float(q_upper),
        "q_hat_discrete": float(q_hat),
        "k_errors": int(k_errors),
        "used_method": used_method,
        "hypergeom_fallback": bool(fallback),
    }


def empirical_model_config(ec_model):
    """Map finite-key EC model names to empirical table settings."""
    mapping = {
        "cascade_mean": ("cascade", "mean_leakage"),
        "cascade_p95": ("cascade", "p95_leakage"),
        "cascade_p99": ("cascade", "p99_leakage"),
        "hamming_mean": (f"hamming_r{main_hamming_r}", "mean_leakage"),
        "hamming_p95": (f"hamming_r{main_hamming_r}", "p95_leakage"),
    }
    return mapping[ec_model]


def ec_leakage_for_model(n, qber, ec_model, table):
    """Return EC leakage and extrapolation metadata for a finite-key model."""
    if ec_model == "ideal_fec_1_1":
        return {
            "leakage": ideal_leakage(n, qber, DEFAULT_F_EC),
            "extrapolated": False,
            "source_n": int(n),
            "source_qber": float(qber),
        }
    protocol, statistic = empirical_model_config(ec_model)
    return empirical_leakage_lookup(
        n,
        qber,
        table,
        protocol=protocol,
        statistic=statistic,
        return_info=True,
    )


def toy_key_length_empirical_ec(
    N,
    qber,
    m,
    eps_total=DEFAULT_EPS_TOTAL,
    p_sift=DEFAULT_P_SIFT,
    pe_method="serfling",
    ec_model="ideal_fec_1_1",
    leakage_table=None,
):
    """Compute the toy finite-key length using ideal or empirical EC leakage."""
    s = int(math.floor(float(p_sift) * int(N)))
    m = int(m)
    if leakage_table is None:
        leakage_table = empirical_leakage_table
    if s <= 1 or m <= 0 or m >= s:
        return {
            "ell": -np.inf,
            "status": "invalid",
            "N": int(N),
            "s": int(s),
            "m": int(m),
            "n": max(0, s - m),
            "extrapolated": False,
        }

    n_key = s - m
    eps_pe, eps_pa, eps_cor = split_epsilons(eps_total)
    pe = q_upper_bound(qber, m, s, eps_pe, method=pe_method)
    q_upper = pe["q_upper"]
    entropy_term = n_key * (1.0 - binary_entropy(q_upper))
    leakage_info = ec_leakage_for_model(n_key, qber, ec_model, leakage_table)
    ec_leakage = float(leakage_info["leakage"])
    t_ver = verification_tag_length(eps_cor)
    pa_penalty = privacy_amplification_penalty(eps_pa)
    ell = entropy_term - ec_leakage - t_ver - pa_penalty
    return {
        "ell": float(ell),
        "status": "ok" if ell >= TARGET_KEY_LENGTH else "short",
        "N": int(N),
        "s": int(s),
        "m": int(m),
        "n": int(n_key),
        "qber": float(qber),
        "q_upper": float(q_upper),
        "q_hat_discrete": pe["q_hat_discrete"],
        "pe_method": pe_method,
        "used_pe_method": pe["used_method"],
        "hypergeom_fallback": pe["hypergeom_fallback"],
        "ec_model": ec_model,
        "entropy_term": float(entropy_term),
        "ec_leakage": float(ec_leakage),
        "t_ver": int(t_ver),
        "pa_penalty": float(pa_penalty),
        "extrapolated": bool(leakage_info["extrapolated"]),
        "leakage_source_n": int(leakage_info["source_n"]),
        "leakage_source_qber": float(leakage_info["source_qber"]),
    }


def candidate_m_values(s, grid=OPTIMIZER_M_GRID):
    """Return candidate PE sample sizes for a sifted block of size s."""
    s = int(s)
    if s <= 2:
        return []
    fractions = np.linspace(0.03, 0.55, int(grid))
    fixed = [8, 16, 32, 64, 128, 256, 512, 1024]
    candidates = set(int(round(f * s)) for f in fractions)
    candidates.update(x for x in fixed if x < s)
    candidates = [m for m in candidates if 1 <= m < s]
    return sorted(candidates)


def optimize_m_for_N(
    N,
    qber,
    eps_total=DEFAULT_EPS_TOTAL,
    p_sift=DEFAULT_P_SIFT,
    pe_method="serfling",
    ec_model="ideal_fec_1_1",
    leakage_table=None,
):
    """Find the best PE sample size m for a fixed N."""
    s = int(math.floor(float(p_sift) * int(N)))
    best = None
    for m in candidate_m_values(s):
        result = toy_key_length_empirical_ec(
            N,
            qber,
            m,
            eps_total=eps_total,
            p_sift=p_sift,
            pe_method=pe_method,
            ec_model=ec_model,
            leakage_table=leakage_table,
        )
        if best is None or result["ell"] > best["ell"]:
            best = result
    if best is None:
        return {
            "ell": -np.inf,
            "status": "invalid",
            "N": int(N),
            "qber": float(qber),
            "ec_model": ec_model,
        }
    return best


def find_minimum_N(
    qber,
    eps_total=DEFAULT_EPS_TOTAL,
    p_sift=DEFAULT_P_SIFT,
    pe_method="serfling",
    ec_model="ideal_fec_1_1",
    leakage_table=None,
    target=TARGET_KEY_LENGTH,
    max_N=2_000_000,
):
    """Find the smallest N whose optimized key length reaches target bits."""
    low = 2
    high = 2048
    best_high = None
    while high <= max_N:
        result = optimize_m_for_N(
            high,
            qber,
            eps_total=eps_total,
            p_sift=p_sift,
            pe_method=pe_method,
            ec_model=ec_model,
            leakage_table=leakage_table,
        )
        if result["ell"] >= target:
            best_high = result
            break
        low = high + 1
        high *= 2

    if best_high is None:
        result["status"] = "not_found"
        result["N_min"] = np.inf
        return result

    answer = best_high
    left, right = low, high
    while left <= right:
        mid = (left + right) // 2
        result = optimize_m_for_N(
            mid,
            qber,
            eps_total=eps_total,
            p_sift=p_sift,
            pe_method=pe_method,
            ec_model=ec_model,
            leakage_table=leakage_table,
        )
        if result["ell"] >= target:
            answer = result
            right = mid - 1
        else:
            left = mid + 1

    answer["N_min"] = int(answer["N"])
    answer["optimal_m"] = int(answer["m"])
    answer["status"] = "ok"
    return answer
''')

md("## Compute N_min Using Empirical Reconciliation Leakage")

code(r'''
qber_values_nmin = [0.005, 0.01, 0.02, 0.03, 0.05, 0.08]
ec_models_nmin = [
    "ideal_fec_1_1",
    "cascade_mean",
    "cascade_p95",
    "cascade_p99",
    "hamming_mean",
    "hamming_p95",
]

nmin_rows = []
for qber, ec_model in itertools.product(qber_values_nmin, ec_models_nmin):
    print(f"N_min search: QBER={qber:.3f}, EC={ec_model}")
    result = find_minimum_N(
        qber,
        eps_total=DEFAULT_EPS_TOTAL,
        p_sift=DEFAULT_P_SIFT,
        pe_method="serfling",
        ec_model=ec_model,
        leakage_table=empirical_leakage_table,
    )
    nmin_rows.append(result)

df_nmin = pd.DataFrame(nmin_rows)
df_nmin.to_csv(res_dir / "nmin_empirical_reconciliation.csv", index=False)
display(df_nmin[[
    "qber", "ec_model", "N_min", "optimal_m", "s", "n", "q_upper",
    "ec_leakage", "ell", "extrapolated", "status"
]])

pivot = df_nmin.replace([np.inf, -np.inf], np.nan).pivot(index="qber", columns="ec_model", values="N_min")
ax = pivot.plot(kind="bar", figsize=(11.5, 5.8), width=0.82)
ax.set_xlabel("Observed QBER")
ax.set_ylabel("Minimum transmitted signals N_min")
ax.set_title("N_min with empirical reconciliation leakage")
ax.set_yscale("log")
ax.legend(title="EC model", fontsize=8)
save_figure("nmin_empirical_reconciliation.png")
plt.show()
''')

md("## Percentage Increase Over Ideal Leakage")

code(r'''
ideal = df_nmin[df_nmin["ec_model"] == "ideal_fec_1_1"][["qber", "N_min"]].rename(columns={"N_min": "N_min_ideal"})
df_increase = df_nmin.merge(ideal, on="qber", how="left")
df_increase["percent_increase_over_ideal"] = 100.0 * (
    df_increase["N_min"] - df_increase["N_min_ideal"]
) / df_increase["N_min_ideal"]
df_increase = df_increase[df_increase["ec_model"] != "ideal_fec_1_1"].copy()
df_increase.to_csv(res_dir / "nmin_percent_increase_over_ideal.csv", index=False)
display(df_increase[["qber", "ec_model", "N_min", "N_min_ideal", "percent_increase_over_ideal"]])

plt.figure(figsize=(10, 5.5))
for ec_model, sub in df_increase.groupby("ec_model"):
    sub = sub.sort_values("qber")
    plt.plot(100 * sub["qber"], sub["percent_increase_over_ideal"], marker="o", label=ec_model)
plt.axhline(0.0, color="black", linewidth=1)
plt.xlabel("Observed QBER (%)")
plt.ylabel("Increase over ideal N_min (%)")
plt.title("N_min increase from empirical reconciliation leakage")
plt.legend(fontsize=8)
save_figure("percent_increase_over_ideal.png")
plt.show()
''')

md(r"""
### Main Publishable Comparison

At low QBER, fixed and interactive overheads may dominate because the Shannon term $nh_2(Q)$ is small. At moderate QBER, empirical leakage can significantly increase the required signal budget. If Cascade p95 or p99 is much larger than the ideal model, this supports the claim that ideal asymptotic EC leakage is too optimistic for short-key QKD. The Hamming baseline is expected to perform badly at higher QBER because single-error-correcting blocks are not well matched to random multi-error QKD blocks.

If Hamming shows a small leakage-only $N_{\min}$ at moderate or high QBER, it should not be interpreted as a better reconciliation method. Its syndrome transcript is short, but its measured failure rate is often large. The operational success adjustment below is the place where that failure becomes visible.
""")

md(r"""
## Reconciliation Failure and Operational Abort Probability

A reconciliation protocol can leave residual errors. In QKD, error verification should detect mismatches with high probability and cause abort rather than output a wrong key. The finite-key correctness parameter is handled by verification, but a high reconciliation failure rate still hurts operational efficiency because sessions may abort.

Define

$$
P_{\mathrm{succ,rec}} = 1-P_{\mathrm{fail,rec}}.
$$

An operational approximation to the transmitted signals per successful reconciled key is

$$
N_{\mathrm{expected}}
=
\frac{N_{\min}}{P_{\mathrm{succ,rec}}}.
$$

This is not a composable security theorem. It is an operational metric.
""")

code(r'''
failure_rows = []
for _, row in df_nmin.iterrows():
    ec_model = row["ec_model"]
    if ec_model == "ideal_fec_1_1":
        protocol = "cascade"
    elif ec_model.startswith("cascade"):
        protocol = "cascade"
    elif ec_model.startswith("hamming"):
        protocol = f"hamming_r{main_hamming_r}"
    else:
        protocol = "cascade"
    failure_rate = empirical_metric_lookup(
        row["n"], row["qber"], empirical_leakage_table, protocol=protocol, metric="failure_rate"
    )
    p_success = max(1.0 - failure_rate, 1e-12)
    failure_rows.append({
        **row.to_dict(),
        "protocol_for_failure": protocol,
        "failure_rate": failure_rate,
        "p_success_rec": p_success,
        "N_expected": float(row["N_min"]) / p_success if np.isfinite(row["N_min"]) else np.inf,
    })

df_operational = pd.DataFrame(failure_rows)
df_operational.to_csv(res_dir / "operational_success_adjusted_N.csv", index=False)
display(df_operational[["qber", "ec_model", "N_min", "failure_rate", "p_success_rec", "N_expected"]])

plt.figure(figsize=(10, 5.5))
for ec_model in ["cascade_mean", "cascade_p95", "cascade_p99"]:
    sub = df_operational[df_operational["ec_model"] == ec_model].sort_values("qber")
    plt.plot(100 * sub["qber"], sub["N_expected"], marker="o", label=ec_model)
plt.yscale("log")
plt.xlabel("Observed QBER (%)")
plt.ylabel("Expected transmitted signals per successful reconciliation")
plt.title("Operational success adjusted N")
plt.legend(fontsize=8)
save_figure("operational_success_adjusted_N.png")
plt.show()
''')

md(r"""
### Failure vs Leakage

Leakage affects secrecy and key length. Failure affects correctness and abort probability. Verification detects residual mismatch and should cause abort with high probability. Both matter for practical short-key generation, but verification leakage is not double-counted here: reconciliation leakage counts public parity or syndrome values, while $t_{\mathrm{ver}}$ is subtracted separately.
""")

md("## Bit-Budget Decomposition With Empirical EC")

code(r'''
selected_qbers = [0.01, 0.03, 0.05]
selected_models = ["ideal_fec_1_1", "cascade_p95", "cascade_p99"]
df_budget_empirical = df_nmin[
    df_nmin["qber"].isin(selected_qbers) & df_nmin["ec_model"].isin(selected_models)
].copy()
df_budget_empirical.to_csv(res_dir / "bit_budget_empirical_ec.csv", index=False)
display(df_budget_empirical[[
    "qber", "ec_model", "N_min", "s", "m", "n", "entropy_term",
    "ec_leakage", "t_ver", "pa_penalty", "ell"
]])

plot_df = df_budget_empirical.copy()
plot_df["case"] = plot_df.apply(lambda r: f"Q={100*r['qber']:.0f}%, {r['ec_model']}", axis=1)
terms = ["entropy_term", "ec_leakage", "t_ver", "pa_penalty", "ell"]
ax = plot_df.set_index("case")[terms].plot(kind="bar", figsize=(12, 5.8), width=0.78)
ax.set_ylabel("Bits")
ax.set_title("Bit-budget decomposition with empirical EC")
ax.legend(title="Term", fontsize=8)
save_figure("bit_budget_empirical_ec.png")
plt.show()
''')

md(r"""
### Bit-Budget Analysis

The bit-budget view shows whether empirical EC leakage is now the dominant loss term. When the empirical Cascade p95 or p99 leakage approaches the entropy term, the optimizer must increase $N$ to leave enough room for verification, privacy amplification, and the 256-bit target.
""")

md("## Comparison With Notebook 02 Artificial Models")

code(r'''
nb02_path = Path("results_02_rigorous") / "tables" / "ec_models_comparison.csv"
if nb02_path.exists():
    df_nb02 = pd.read_csv(nb02_path)
    df_nb02_plot = df_nb02[df_nb02["ec_model"].isin(["ideal", "short_block_penalty", "pessimistic_short_block"])].copy()
    df_nb03_plot = df_nmin[df_nmin["ec_model"].isin(["ideal_fec_1_1", "cascade_p95", "cascade_p99"])].copy()

    plt.figure(figsize=(10.5, 5.8))
    for ec_model, sub in df_nb02_plot.groupby("ec_model"):
        sub = sub.sort_values("qber")
        plt.plot(100 * sub["qber"], sub["N_min"], marker="o", linestyle="--", label=f"NB02 {ec_model}")
    for ec_model, sub in df_nb03_plot.groupby("ec_model"):
        sub = sub.sort_values("qber")
        plt.plot(100 * sub["qber"], sub["N_min"], marker="s", label=f"NB03 {ec_model}")
    plt.yscale("log")
    plt.xlabel("Observed QBER (%)")
    plt.ylabel("N_min")
    plt.title("Notebook 02 artificial EC vs Notebook 03 empirical EC")
    plt.legend(fontsize=8)
    save_figure("notebook02_vs_notebook03_ec_models.png")
    plt.show()

    comparison_rows = []
    for qber in sorted(set(df_nb03_plot["qber"]).intersection(set(df_nb02_plot["qber"]))):
        artificial = df_nb02_plot[np.isclose(df_nb02_plot["qber"], qber)]
        empirical = df_nb03_plot[np.isclose(df_nb03_plot["qber"], qber)]
        comparison_rows.append({
            "qber": qber,
            "nb02_min": float(artificial["N_min"].min()),
            "nb02_max": float(artificial["N_min"].max()),
            "nb03_cascade_p95": float(empirical[empirical["ec_model"] == "cascade_p95"]["N_min"].iloc[0]),
            "nb03_cascade_p99": float(empirical[empirical["ec_model"] == "cascade_p99"]["N_min"].iloc[0]),
        })
    df_nb02_nb03_comparison = pd.DataFrame(comparison_rows)
    display(df_nb02_nb03_comparison)
else:
    print(f"Notebook 02 comparison file not found: {nb02_path}. Skipping comparison plot.")
''')

md(r"""
### Notebook 02 vs Notebook 03 Analysis

Notebook 02 used artificial models: ideal, rounded syndrome, fixed overhead, short-block penalty, and pessimistic short-block. Notebook 03 measures Cascade and Hamming leakage directly. The comparison above indicates whether the artificial stress tests were too optimistic, too pessimistic, or roughly aligned with measured Cascade leakage for this simulation model.
""")

md(r"""
## Main Result Summary

This notebook implemented:

1. Cascade reconciliation simulation.
2. Hamming syndrome-code baseline.
3. Empirical leakage table.
4. Finite-key $N_{\min}$ calculation using empirical leakage.

It measured leakage bits, effective $f_{\mathrm{eff}}$, residual failure probability, $N_{\min}$, and percent increase over ideal EC leakage.

Main interpretation:

- ideal $f_{\mathrm{EC}}nh_2(Q)$ can underestimate short-block leakage,
- empirical Cascade leakage gives a stronger basis for the finite-key resource calculation,
- reconciliation details can materially change the number of quantum signals needed for one 256-bit key.

Scientific caution:

- the Cascade implementation is a simulation model,
- empirical p95/p99 leakage is not a theorem-level leakage bound,
- more trials and theorem-level reconciliation analysis are needed for publication,
- real QKD would also need authentication, decoy states, device modelling, and exact finite-key theorem constants.
""")

md(r"""
## Limitations

1. Cascade implementation is simplified and should be checked against standard Cascade descriptions.
2. Leakage is counted mainly as public parity values; full transcript accounting may require additional care.
3. Hamming baseline is simple and not a competitive modern QKD reconciliation method.
4. Empirical leakage quantiles are not rigorous worst-case bounds.
5. Failure probability estimates require many more trials for very small target correctness errors.
6. The finite-key formula is still a planning formula, not a complete composable security theorem.
7. Parameter estimation is simplified.
8. Decoy-state source modelling is not included.
9. Real hardware side channels are not included.
""")

md(r"""
## Future Work Toward a Stronger Paper

1. Validate Cascade implementation against known examples or an external implementation.
2. Increase simulation trials and add confidence intervals on leakage and failure estimates.
3. Implement or import real LDPC reconciliation.
4. Implement BCH reconciliation if a reliable library is available.
5. Use theorem-level leakage bounds rather than empirical quantiles.
6. Combine empirical reconciliation with the corrected hypergeometric PE bound from Notebook 02.
7. Add abort-probability modelling.
8. Replace the toy finite-key formula with a theorem-level expression from a specific finite-key QKD paper.
9. Produce paper-ready plots and tables.
10. State the final claim as: "Measured short-block reconciliation leakage increases $N_{\min}$ by X% relative to ideal leakage under this model."
""")

md("## Reproducibility")

code(r'''
total_runtime = time.time() - START_TIME
print("Python:", sys.version.split()[0])
print("numpy:", np.__version__)
print("pandas:", pd.__version__)
print("scipy:", scipy.__version__)
print("matplotlib:", matplotlib.__version__)
print("total runtime seconds:", round(total_runtime, 2))
print("optional libraries:", json.dumps(OPTIONAL_LIBRARY_STATUS, indent=2))
print()
print("Results saved in:", res_dir.resolve())
for path in sorted(res_dir.glob("*.csv")):
    print(" -", path.as_posix())
print()
print("Figures saved in:", fig_dir.resolve())
for path in sorted(fig_dir.glob("*.png")):
    print(" -", path.as_posix())
''')


notebook = {
    "cells": cells,
    "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {
            "name": "python",
            "version": sys.version.split()[0],
            "mimetype": "text/x-python",
            "codemirror_mode": {"name": "ipython", "version": 3},
            "pygments_lexer": "ipython3",
            "nbconvert_exporter": "python",
            "file_extension": ".py",
        },
    },
    "nbformat": 4,
    "nbformat_minor": 5,
}


path = Path("03_empirical_reconciliation_leakage.ipynb")
path.write_text(json.dumps(notebook, indent=1), encoding="utf-8")
print(f"wrote {path.resolve()} with {len(cells)} cells")
