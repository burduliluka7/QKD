import json
import sys
from pathlib import Path
from textwrap import dedent


cells = []


def add_cell(kind, text):
    source = dedent(text).strip() + "\n"
    cell = {
        "cell_type": kind,
        "id": f"cell-{len(cells) + 1:03d}",
        "metadata": {},
        "source": source.splitlines(True),
    }
    if kind == "code":
        cell.update({"execution_count": None, "outputs": []})
    cells.append(cell)


def md(text):
    add_cell("markdown", text)


def code(text):
    add_cell("code", text)


md(r"""
# Finite-Key and Short-Key QKD: Minimum Signal Budget for a 256-bit Key

Quantum key distribution (QKD) generates a shared secret key between Alice and Bob using quantum signals plus an authenticated public classical channel. In finite-key analysis, Alice and Bob only send a finite number of quantum signals, so statistical fluctuations, error-correction leakage, verification tags, and privacy-amplification overheads must be counted explicitly.

This notebook studies the ultra-short-key regime where the final key length is only 256 bits, suitable as an AES-256 key. The central planning question is

$$
N_{\min}(Q,\varepsilon_{\text{total}})
= \min\{N : \ell(N,Q,\varepsilon_{\text{total}}) \ge 256\}.
$$

This differs from asymptotic QKD, where the main object is usually the key rate as $N \to \infty$. Here the aim is not to maximize asymptotic rate, but to find how few transmitted signals are enough to obtain one short final key.

**Scientific caution.** This notebook is a toy/protocol-level finite-key exploration and planning model. It is not a complete QKD security proof, not a decoy-state proof, and not an implementation-security proof for real devices. Every simplified formula below should be read as a toy model or planning model to explore optimization structure before replacing it with a theorem-level finite-key expression.
""")

md(r"""
## Relation to the Provided Notes and Papers

The local notes define the main goal as short-key finite-key analysis: produce a 256-bit final key from as few quantum signals as possible by optimizing parameter estimation, error correction, privacy amplification, and security-parameter allocation.

The four provided papers already cover the heavy security-proof material, so this notebook does **not** repeat their theorem derivations:

- Scarani and Renner, *Security Bounds for Quantum Cryptography with Finite Resources* (arXiv:0806.0120), motivates composable finite-resource security and shows why finite parameter estimation, privacy amplification, and error-correction leakage change asymptotic rates.
- Tomamichel, Lim, Gisin, and Renner, *Tight finite-key analysis for quantum cryptography* (Nature Communications, 2012), gives tight finite-key methods using smooth-entropy uncertainty relations.
- Wiesemann et al., *A consolidated and accessible security proof for finite-size decoy-state QKD* (arXiv:2405.16578v3, accepted in Quantum 2026), consolidates modern finite-size decoy-state BB84 proof structure, including acceptance conditioning and operational secure-key length expressions.
- The *Finite-Key Security Bounds in QKD* overview summarizes the standard modular structure: smooth min-entropy, error-correction leakage, privacy amplification, statistical confidence intervals, and composable failure budgets.

The contribution attempted here is narrower: a self-contained numerical planning notebook for the 256-bit short-key optimization problem. The notebook uses simplified BB84-like formulas, compares optimization directions, and produces tables/figures that can guide which theorem-level formula should be implemented next.
""")

md(r"""
## Main Formula and Bit Budget

We use the following simplified finite-key key-length planning model:

$$
\ell_{\text{toy}}
= n\left[1-h_2(Q_{\text{upper}})\right]
- f_{\text{EC}} n h_2(\hat Q)
- t_{\text{ver}}
- 2\log_2(1/\varepsilon_{\text{PA}}).
$$

Definitions:

- $N$: number of transmitted quantum signals.
- $s$: sifted bits, approximately $s = p_{\text{sift}}N$.
- $m$: parameter-estimation sample size.
- $n=s-m$: raw bits kept for key generation.
- $\hat Q$: observed QBER.
- $Q_{\text{upper}}$: conservative upper bound on the true or phase error rate.
- $h_2(q)$: binary entropy.
- $f_{\text{EC}}$: error-correction inefficiency.
- $t_{\text{ver}}$: verification hash length.
- $\varepsilon_{\text{PA}}$: privacy-amplification failure parameter.
- target: $\ell_{\text{toy}} \ge 256$.

Increasing $m$ improves the QBER estimate but leaves fewer bits for the key. Increasing QBER reduces the secret fraction. Short keys are sensitive to fixed overheads like verification and privacy amplification. The aim is to minimize $N$, not maximize asymptotic rate.
""")

md("## Imports and Numerical Utilities")

code(r'''
import itertools
import math
import os
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy import stats
import matplotlib
import matplotlib.pyplot as plt

try:
    from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import mean_absolute_error, r2_score
    SKLEARN_AVAILABLE = True
except Exception as exc:
    SKLEARN_AVAILABLE = False
    SKLEARN_IMPORT_ERROR = exc

warnings.filterwarnings("ignore", category=RuntimeWarning)

plt.rcParams.update({
    "figure.figsize": (8, 5),
    "axes.grid": True,
    "grid.alpha": 0.25,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "font.size": 11,
})

RESULTS_DIR = Path("results_01_finite-key")
FIGURES_DIR = RESULTS_DIR / "figures"
TABLES_DIR = RESULTS_DIR / "tables"
FIGURES_DIR.mkdir(parents=True, exist_ok=True)
TABLES_DIR.mkdir(parents=True, exist_ok=True)
TARGET_KEY_LENGTH = 256.0
METHODS = ["hoeffding", "serfling", "normal"]


def clamp_probability(q, lower=1e-15, upper=1 - 1e-15):
    """Clip probabilities into a numerically safe interval."""
    clipped = np.clip(q, lower, upper)
    if np.isscalar(q):
        return float(clipped)
    return clipped


def binary_entropy(q):
    """Binary entropy h2(q), evaluated safely for scalars or arrays."""
    q_safe = clamp_probability(np.asarray(q, dtype=float))
    h = -(q_safe * np.log2(q_safe) + (1.0 - q_safe) * np.log2(1.0 - q_safe))
    h = np.minimum(h, 1.0)
    if np.isscalar(q):
        return float(h)
    return h


def verification_tag_length(eps_cor):
    """Return ceil(log2(1/eps_cor)) for universal-hash error verification."""
    if eps_cor <= 0 or eps_cor >= 1:
        raise ValueError("eps_cor must be in (0, 1).")
    return int(math.ceil(math.log2(1.0 / eps_cor)))


def pa_penalty(eps_pa):
    """Return the toy privacy-amplification penalty 2 log2(1/eps_pa)."""
    if eps_pa <= 0 or eps_pa >= 1:
        raise ValueError("eps_pa must be in (0, 1).")
    return float(2.0 * math.log2(1.0 / eps_pa))


def save_figure(name):
    """Save the current matplotlib figure into the figures directory."""
    path = FIGURES_DIR / name
    plt.tight_layout()
    plt.savefig(path, dpi=180, bbox_inches="tight")
    return path


print(f"scikit-learn available: {SKLEARN_AVAILABLE}")
print(f"Figures will be saved under: {FIGURES_DIR.resolve()}")
''')

md(r"""
## Parameter-Estimation Bounds

Parameter estimation converts the observed QBER $\hat Q$ from $m$ revealed bits into a conservative upper bound $Q_{\text{upper}}$. This notebook compares several simplified numerical bounds. These are **toy model** confidence bounds for exploration; constants and conditioning details vary across rigorous finite-key theorems.
""")

code(r'''
def q_upper_hoeffding(q_hat, m, eps_pe):
    """Hoeffding-style one-sided upper confidence bound for a Bernoulli error rate."""
    if m <= 0:
        return 0.5
    q_hat = clamp_probability(q_hat, 0.0, 0.5)
    delta = math.sqrt(math.log(1.0 / eps_pe) / (2.0 * m))
    return float(np.clip(q_hat + delta, 0.0, 0.5))


def q_upper_serfling(q_hat, m, s, eps_pe):
    """Serfling-style finite-population comparison bound.

    Constants vary across formulations. This version is used only as a
    comparison/planning model for sampling without replacement.
    """
    if m <= 0 or s <= 0 or m >= s:
        return 0.5
    q_hat = clamp_probability(q_hat, 0.0, 0.5)
    delta = math.sqrt(((s - m + 1.0) * math.log(1.0 / eps_pe)) / (2.0 * m * s))
    return float(np.clip(q_hat + delta, 0.0, 0.5))


def q_upper_normal_approx(q_hat, m, eps_pe):
    """One-sided normal-approximation upper confidence bound.

    This is a heuristic comparison bound and can be too optimistic in the
    small-sample or zero-error regime.
    """
    if m <= 0:
        return 0.5
    q_hat = clamp_probability(q_hat, 0.0, 0.5)
    z = stats.norm.ppf(1.0 - eps_pe)
    std = math.sqrt(max(q_hat * (1.0 - q_hat), 0.0) / m)
    return float(np.clip(q_hat + z * std, 0.0, 0.5))


def q_upper_bound(q_hat, m, s, eps_pe, method="hoeffding"):
    """Dispatch to one of the simplified QBER upper-bound methods."""
    method = method.lower()
    if method == "hoeffding":
        return q_upper_hoeffding(q_hat, m, eps_pe)
    if method == "serfling":
        return q_upper_serfling(q_hat, m, s, eps_pe)
    if method == "normal":
        return q_upper_normal_approx(q_hat, m, eps_pe)
    raise ValueError(f"Unknown parameter-estimation method: {method}")
''')

md(r"""
## Toy Key-Length Function

The function below implements the planning formula. It deliberately omits theorem-level details: smoothing terms beyond the displayed PA penalty, decoy-state photon statistics, abort conditioning, authentication-key consumption, and implementation imperfections. It is useful for exploratory optimization, not for making a final composable-security claim.
""")

code(r'''
def toy_key_length(
    N,
    qber,
    m,
    eps_pe=1e-10,
    eps_pa=1e-10,
    eps_cor=1e-10,
    f_ec=1.1,
    p_sift=0.5,
    pe_method="hoeffding",
    extra_ec_leakage=0.0,
    return_details=False,
):
    """Compute the simplified BB84-like finite-key length.

    This is a toy/planning model, not a theorem-level finite-key proof.
    """
    s = int(math.floor(p_sift * N))
    if m <= 0 or m >= s:
        details = {
            "N": int(N), "s": s, "m": int(m), "n": max(s - int(m), 0),
            "qber": qber, "q_upper": np.nan, "entropy_term": -np.inf,
            "ec_leakage": np.inf, "t_ver": np.nan, "pa_penalty": np.nan,
            "ell": -np.inf, "passes_256": False,
        }
        return details if return_details else -np.inf

    qber = clamp_probability(qber, 0.0, 0.5)
    n = s - int(m)
    q_upper = q_upper_bound(qber, int(m), s, eps_pe, method=pe_method)
    entropy_term = n * (1.0 - binary_entropy(q_upper))
    ec_leakage = f_ec * n * binary_entropy(qber) + float(extra_ec_leakage)
    t_ver = verification_tag_length(eps_cor)
    pa = pa_penalty(eps_pa)
    ell = entropy_term - ec_leakage - t_ver - pa

    if return_details:
        return {
            "N": int(N), "s": s, "m": int(m), "n": int(n),
            "qber": float(qber), "q_upper": float(q_upper),
            "entropy_term": float(entropy_term),
            "ec_leakage": float(ec_leakage), "t_ver": int(t_ver),
            "pa_penalty": float(pa), "ell": float(ell),
            "passes_256": bool(ell >= TARGET_KEY_LENGTH),
        }
    return float(ell)


def ec_leakage_model(n, qber, model="constant_f", f_ec=1.1):
    """Toy error-correction leakage models for short-block sensitivity studies."""
    n = np.asarray(n, dtype=float)
    qber = clamp_probability(qber, 0.0, 0.5)
    hq = binary_entropy(qber)
    n_safe = np.maximum(n, 1.0)
    if model == "constant_f":
        leakage = f_ec * n * hq
    elif model == "short_block_penalty":
        leakage = (f_ec + 5.0 / np.sqrt(n_safe)) * n * hq
    elif model == "fixed_overhead":
        leakage = f_ec * n * hq + 64.0
    elif model == "pessimistic_short_block":
        leakage = (f_ec + 10.0 / np.sqrt(n_safe) + 500.0 / n_safe) * n * hq
    else:
        raise ValueError(f"Unknown EC leakage model: {model}")
    if leakage.shape == ():
        return float(leakage)
    return leakage


def _q_upper_array(qber, m_values, s, eps_pe, method):
    """Vectorized QBER upper bounds for optimizer internals."""
    m_values = np.asarray(m_values, dtype=float)
    qber = clamp_probability(qber, 0.0, 0.5)
    log_term = math.log(1.0 / eps_pe)
    method = method.lower()
    if method == "hoeffding":
        q_upper = qber + np.sqrt(log_term / (2.0 * m_values))
    elif method == "serfling":
        q_upper = qber + np.sqrt(((s - m_values + 1.0) * log_term) / (2.0 * m_values * s))
    elif method == "normal":
        z = stats.norm.ppf(1.0 - eps_pe)
        q_upper = qber + z * np.sqrt(max(qber * (1.0 - qber), 0.0) / m_values)
    else:
        raise ValueError(f"Unknown parameter-estimation method: {method}")
    return np.clip(q_upper, 0.0, 0.5)


def _toy_key_lengths_for_m_values(
    N, qber, m_values, eps_pe=1e-10, eps_pa=1e-10, eps_cor=1e-10,
    f_ec=1.1, p_sift=0.5, pe_method="hoeffding", ec_model="constant_f",
):
    """Vectorized key lengths over candidate m values."""
    s = int(math.floor(p_sift * N))
    m_values = np.asarray(m_values, dtype=int)
    n_values = s - m_values
    valid = (m_values > 0) & (m_values < s) & (n_values > 0)
    ell = np.full_like(m_values, fill_value=-np.inf, dtype=float)
    if not np.any(valid):
        return ell
    mv = m_values[valid]
    nv = n_values[valid].astype(float)
    q_upper = _q_upper_array(qber, mv, s, eps_pe, pe_method)
    entropy_term = nv * (1.0 - binary_entropy(q_upper))
    ec_leakage = ec_leakage_model(nv, qber, model=ec_model, f_ec=f_ec)
    ell[valid] = entropy_term - ec_leakage - verification_tag_length(eps_cor) - pa_penalty(eps_pa)
    return ell
''')

md(r"""
## Baseline Experiment: Key Length Versus $N$

For several QBER values, compute $\ell_{\text{toy}}$ as a function of $N$ using a fixed parameter-estimation fraction $m=0.2s$. This is intentionally not optimized yet; it shows the basic shape of the overhead problem.
""")

code(r'''
qber_values = [0.00, 0.01, 0.03, 0.05, 0.08, 0.10]
N_values = np.unique(np.logspace(np.log10(500), np.log10(100_000), 180).astype(int))

baseline_rows = []
plt.figure(figsize=(9, 5.5))
for qber in qber_values:
    ell_values = []
    for N in N_values:
        s = int(math.floor(0.5 * N))
        m = int(max(10, min(s - 1, round(0.2 * s))))
        ell = toy_key_length(N, qber, m, pe_method="hoeffding")
        ell_values.append(ell)
        baseline_rows.append({"N": N, "qber": qber, "m": m, "ell": ell})
    plt.plot(N_values, ell_values, label=f"QBER={100*qber:.0f}%")

plt.axhline(TARGET_KEY_LENGTH, color="black", linestyle="--", linewidth=1.2, label="256-bit target")
plt.xscale("log")
plt.xlabel("Transmitted quantum signals N")
plt.ylabel("Toy final key length ell (bits)")
plt.title("Baseline toy key length with fixed m = 0.2s")
plt.legend(ncol=2)
save_figure("baseline_key_length_vs_N.png")
plt.show()

baseline_curve_df = pd.DataFrame(baseline_rows)
baseline_crossings_df = pd.DataFrame([
    {
        "qber": qber,
        "first_grid_N_reaching_256": (
            int(sub["N"].iloc[0]) if len(sub := baseline_curve_df[(baseline_curve_df["qber"] == qber) & (baseline_curve_df["ell"] >= TARGET_KEY_LENGTH)]) else np.nan
        ),
    }
    for qber in qber_values
])
display(baseline_crossings_df)
''')

md(r"""
### Baseline Observations

Lower QBER reaches 256 bits with fewer signals, while high QBER requires many more signals. Near the BB84-like threshold, the secret fraction becomes small and fixed overheads dominate. Because this section fixes $m=0.2s$, it is only a starting point; the next section optimizes $m$ directly.
""")

md(r"""
## Optimize Parameter-Estimation Sample Size $m$

Small $m$ gives a poor QBER confidence interval; large $m$ leaves fewer key-generation bits. The optimum is often interior, especially in the short-key regime.
""")

code(r'''
def _candidate_m_values(N, p_sift=0.5, m_grid_size=200):
    """Build a unique grid of candidate PE sample sizes from 10 to s-10."""
    s = int(math.floor(p_sift * N))
    if s <= 20:
        return np.array([], dtype=int)
    grid_size = int(max(2, min(m_grid_size, s - 19)))
    return np.unique(np.linspace(10, s - 10, grid_size).round().astype(int))


def _best_m_for_N(
    N, qber, eps_pe=1e-10, eps_pa=1e-10, eps_cor=1e-10, f_ec=1.1,
    p_sift=0.5, pe_method="hoeffding", m_grid_size=200, ec_model="constant_f",
):
    """Fast internal optimizer over m for a fixed N."""
    m_values = _candidate_m_values(N, p_sift=p_sift, m_grid_size=m_grid_size)
    if len(m_values) == 0:
        return None, -np.inf, m_values, np.array([], dtype=float)
    ell_values = _toy_key_lengths_for_m_values(
        N, qber, m_values, eps_pe=eps_pe, eps_pa=eps_pa, eps_cor=eps_cor,
        f_ec=f_ec, p_sift=p_sift, pe_method=pe_method, ec_model=ec_model,
    )
    idx = int(np.nanargmax(ell_values))
    return int(m_values[idx]), float(ell_values[idx]), m_values, ell_values


def optimize_m_for_N(
    N, qber, eps_pe=1e-10, eps_pa=1e-10, eps_cor=1e-10, f_ec=1.1,
    p_sift=0.5, pe_method="hoeffding", m_grid_size=200,
):
    """Search over possible m values from 10 to s-10 for a fixed N."""
    best_m, best_ell, m_values, ell_values = _best_m_for_N(
        N, qber, eps_pe=eps_pe, eps_pa=eps_pa, eps_cor=eps_cor, f_ec=f_ec,
        p_sift=p_sift, pe_method=pe_method, m_grid_size=m_grid_size,
    )
    s = int(math.floor(p_sift * N))
    df = pd.DataFrame({
        "m": m_values,
        "m_fraction_of_s": m_values / s if s else np.nan,
        "n": s - m_values,
        "ell": ell_values,
    })
    return best_m, best_ell, df


best_m, best_ell, m_scan_df = optimize_m_for_N(10_000, 0.03, m_grid_size=250)
plt.figure(figsize=(8.5, 5))
plt.plot(m_scan_df["m"], m_scan_df["ell"], color="tab:blue")
plt.scatter([best_m], [best_ell], color="tab:red", zorder=3, label=f"best m={best_m}")
plt.axhline(TARGET_KEY_LENGTH, color="black", linestyle="--", linewidth=1.1, label="256-bit target")
plt.xlabel("Parameter-estimation sample size m")
plt.ylabel("Toy final key length ell (bits)")
plt.title("Optimizing m for N=10,000 and QBER=3%")
plt.legend()
save_figure("optimize_m_example.png")
plt.show()

print(f"Best m={best_m}, best ell={best_ell:.2f} bits")
display(m_scan_df.sort_values("ell", ascending=False).head(8))
''')

code(r'''
def _default_eps_split(eps_total):
    """Default equal-ish allocation used by the planning model."""
    return {
        "eps_pe": eps_total / 4.0,
        "eps_pa": eps_total / 4.0,
        "eps_cor": eps_total / 4.0,
        "eps_smooth": eps_total / 4.0,
    }


def find_minimum_N(
    qber, eps_total=1e-9, eps_split=None, f_ec=1.1, p_sift=0.5,
    pe_method="hoeffding", N_min=500, N_max=5_000_000, m_grid_size=140,
    target_key_length=TARGET_KEY_LENGTH, ec_model="constant_f",
):
    """Binary search for the smallest N whose optimized toy key length reaches target."""
    if eps_split is None:
        eps_split = _default_eps_split(eps_total)
    eps_pe = eps_split["eps_pe"]
    eps_pa = eps_split["eps_pa"]
    eps_cor = eps_split["eps_cor"]
    eps_smooth = eps_split.get("eps_smooth", max(eps_total - eps_pe - eps_pa - eps_cor, 0.0))

    def eval_N(N):
        return _best_m_for_N(
            N, qber, eps_pe=eps_pe, eps_pa=eps_pa, eps_cor=eps_cor, f_ec=f_ec,
            p_sift=p_sift, pe_method=pe_method, m_grid_size=m_grid_size,
            ec_model=ec_model,
        )[:2]

    high_m, high_ell = eval_N(N_max)
    if not np.isfinite(high_ell) or high_ell < target_key_length:
        return {
            "qber": qber, "N_min": np.nan, "optimal_m": high_m,
            "optimal_ell": high_ell, "eps_pe": eps_pe, "eps_pa": eps_pa,
            "eps_cor": eps_cor, "eps_smooth": eps_smooth, "eps_total": eps_total,
            "f_ec": f_ec, "p_sift": p_sift, "pe_method": pe_method,
            "ec_model": ec_model, "status": "not_found_within_N_max",
        }

    lo, hi = int(N_min), int(N_max)
    while lo < hi:
        mid = (lo + hi) // 2
        _, mid_ell = eval_N(mid)
        if np.isfinite(mid_ell) and mid_ell >= target_key_length:
            hi = mid
        else:
            lo = mid + 1

    best_N = lo
    best_m, best_ell = eval_N(best_N)
    for candidate_N in range(max(int(N_min), best_N - 250), best_N + 1):
        cand_m, cand_ell = eval_N(candidate_N)
        if np.isfinite(cand_ell) and cand_ell >= target_key_length:
            best_N, best_m, best_ell = candidate_N, cand_m, cand_ell
            break

    return {
        "qber": qber, "N_min": int(best_N), "optimal_m": int(best_m),
        "optimal_ell": float(best_ell), "eps_pe": eps_pe, "eps_pa": eps_pa,
        "eps_cor": eps_cor, "eps_smooth": eps_smooth, "eps_total": eps_total,
        "f_ec": f_ec, "p_sift": p_sift, "pe_method": pe_method,
        "ec_model": ec_model, "status": "ok",
    }


baseline_nmin_df = pd.DataFrame([
    find_minimum_N(qber, eps_total=1e-9, pe_method="hoeffding", m_grid_size=140)
    for qber in qber_values
])
baseline_nmin_df.to_csv(TABLES_DIR / "results_baseline_nmin.csv", index=False)
display(baseline_nmin_df)

plt.figure(figsize=(8, 5))
plt.plot(100 * baseline_nmin_df["qber"], baseline_nmin_df["N_min"], marker="o")
plt.yscale("log")
plt.xlabel("QBER (%)")
plt.ylabel("Minimum transmitted signals N_min")
plt.title("Optimized minimum signal budget versus QBER")
save_figure("baseline_Nmin_vs_QBER.png")
plt.show()
''')

md(r"""
## Direction 1: Compare Statistical Bounds

This direction explores how the choice of statistical confidence bound changes the minimum signal budget. A tighter parameter-estimation bound can reduce $N_{\min}$ because it lowers $Q_{\text{upper}}$ and therefore reduces the privacy-amplification compression required by the toy model.
""")

code(r'''
stat_bounds_df = pd.DataFrame([
    find_minimum_N(qber, eps_total=1e-9, pe_method=method, m_grid_size=120)
    for qber, method in itertools.product([0.01, 0.03, 0.05, 0.08], METHODS)
])
stat_bounds_df.to_csv(TABLES_DIR / "results_statistical_bounds.csv", index=False)
display(stat_bounds_df[["qber", "pe_method", "N_min", "optimal_m", "optimal_ell", "status"]])

pivot = stat_bounds_df.pivot(index="qber", columns="pe_method", values="N_min")
ax = pivot.plot(kind="bar", figsize=(8.5, 5.2))
ax.set_xlabel("QBER")
ax.set_ylabel("Minimum transmitted signals N_min")
ax.set_title("N_min by parameter-estimation bound")
ax.set_yscale("log")
ax.legend(title="Bound")
save_figure("statistical_bounds_grouped_bar.png")
plt.show()
''')

md(r"""
### Statistical-Bound Analysis

In this planning model, the normal approximation often gives the smallest $N_{\min}$, but it can be too optimistic for very small samples or zero observed errors. Hoeffding is usually more conservative. The Serfling-style finite-population correction can improve on Hoeffding when sampling without replacement matters. In the short-key regime, these differences can be large because a small change in $Q_{\text{upper}}$ changes the entropy term across the whole kept block.
""")

md(r"""
## Direction 2: Security-Parameter Allocation Optimization

The total security budget is split between parameter estimation, privacy amplification, correctness verification, and smoothing. Equal splitting is simple, but it is not necessarily optimal because the epsilons enter the toy formula differently. Parameter estimation affects $Q_{\text{upper}}$ and therefore the entropy term, while privacy amplification and verification enter as logarithmic fixed costs.
""")

code(r'''
def random_epsilon_allocations(eps_total, num_samples=1000, seed=0):
    """Generate random positive epsilon allocations with a Dirichlet distribution."""
    rng = np.random.default_rng(seed)
    weights = rng.dirichlet(np.ones(4), size=num_samples)
    return pd.DataFrame(weights * eps_total, columns=["eps_pe", "eps_pa", "eps_cor", "eps_smooth"])


def optimize_epsilon_allocation(
    qber, eps_total=1e-9, f_ec=1.1, pe_method="hoeffding", num_allocations=200,
):
    """Random-search optimizer for the epsilon allocation."""
    allocations = random_epsilon_allocations(eps_total, num_samples=num_allocations, seed=int(10_000 * qber) + 7)
    rows = []
    for _, allocation in allocations.iterrows():
        eps_split = allocation.to_dict()
        result = find_minimum_N(
            qber, eps_total=eps_total, eps_split=eps_split, f_ec=f_ec,
            pe_method=pe_method, m_grid_size=85,
        )
        rows.append({**eps_split, **result})
    results_df = pd.DataFrame(rows)
    ok = results_df[results_df["status"] == "ok"].copy()
    best = ok.sort_values("N_min").iloc[0].to_dict() if len(ok) else None
    return best, results_df


allocation_compare_rows = []
epsilon_allocation_full = []
for qber in [0.01, 0.03, 0.05]:
    equal_result = find_minimum_N(qber, eps_total=1e-9, pe_method="hoeffding", m_grid_size=100)
    best_alloc, full_df = optimize_epsilon_allocation(qber, eps_total=1e-9, num_allocations=200)
    epsilon_allocation_full.append(full_df.assign(search_qber=qber))
    allocation_compare_rows.append({
        "qber": qber, "allocation": "equal", "N_min": equal_result["N_min"],
        "optimal_m": equal_result["optimal_m"], "eps_pe": equal_result["eps_pe"],
        "eps_pa": equal_result["eps_pa"], "eps_cor": equal_result["eps_cor"],
        "eps_smooth": equal_result["eps_smooth"],
    })
    if best_alloc is not None:
        allocation_compare_rows.append({
            "qber": qber, "allocation": "optimized_random", "N_min": best_alloc["N_min"],
            "optimal_m": best_alloc["optimal_m"], "eps_pe": best_alloc["eps_pe"],
            "eps_pa": best_alloc["eps_pa"], "eps_cor": best_alloc["eps_cor"],
            "eps_smooth": best_alloc["eps_smooth"],
        })

epsilon_allocation_df = pd.DataFrame(allocation_compare_rows)
epsilon_allocation_search_df = pd.concat(epsilon_allocation_full, ignore_index=True)
epsilon_allocation_df.to_csv(TABLES_DIR / "results_epsilon_allocation.csv", index=False)
display(epsilon_allocation_df)

pivot = epsilon_allocation_df.pivot(index="qber", columns="allocation", values="N_min")
ax = pivot.plot(kind="bar", figsize=(8, 5))
ax.set_xlabel("QBER")
ax.set_ylabel("Minimum transmitted signals N_min")
ax.set_title("Equal versus optimized epsilon allocation")
ax.set_yscale("log")
ax.legend(title="Allocation")
save_figure("epsilon_allocation_comparison.png")
plt.show()
''')

md(r"""
### Epsilon-Allocation Analysis

Random allocation can help when it gives more budget to parameter estimation, because $\varepsilon_{\text{PE}}$ changes the confidence interval and therefore changes the entropy term on many bits. Privacy amplification and verification also matter, but in this toy formula they mainly enter through logarithmic overheads. These results should be treated as optimizer diagnostics, not as proof-level epsilon choices.
""")

md(r"""
## Direction 3: Error-Correction Leakage Models

The simple model uses $f_{\text{EC}}nh_2(Q)$, but real short-block error correction can leak more information. This direction studies how sensitive $N_{\min}$ is to the error-correction model.
""")

code(r'''
ec_models = ["constant_f", "short_block_penalty", "fixed_overhead", "pessimistic_short_block"]
ec_models_df = pd.DataFrame([
    find_minimum_N(qber, eps_total=1e-9, pe_method="hoeffding", m_grid_size=110, ec_model=model)
    for qber, model in itertools.product([0.01, 0.03, 0.05], ec_models)
])
ec_models_df.to_csv(TABLES_DIR / "results_ec_models.csv", index=False)
display(ec_models_df[["qber", "ec_model", "N_min", "optimal_m", "optimal_ell", "status"]])

pivot = ec_models_df.pivot(index="qber", columns="ec_model", values="N_min")
ax = pivot.plot(kind="bar", figsize=(9, 5.5))
ax.set_xlabel("QBER")
ax.set_ylabel("Minimum transmitted signals N_min")
ax.set_title("Sensitivity to short-block EC leakage model")
ax.set_yscale("log")
ax.legend(title="EC model", fontsize=9)
save_figure("ec_models_Nmin.png")
plt.show()
''')

md(r"""
### Error-Correction Analysis

Short-block EC leakage can dominate the 256-bit regime. A fixed 64-bit overhead is already a large fraction of the target final key, and pessimistic short-block inefficiency can move $N_{\min}$ substantially. This is one of the most promising publishable directions because it connects the finite-key optimizer to concrete short-block reconciliation performance rather than only asymptotic leakage formulas.
""")

md("## Direction 4: Sensitivity Analysis")

code(r'''
sensitivity_rows = []
for qber in np.linspace(0.0, 0.10, 11):
    sensitivity_rows.append({"sweep": "qber", "value": qber, **find_minimum_N(float(qber), m_grid_size=90)})
for f_ec in np.linspace(1.0, 1.5, 8):
    sensitivity_rows.append({"sweep": "f_ec", "value": f_ec, **find_minimum_N(0.03, f_ec=float(f_ec), m_grid_size=90)})
for eps_total in np.logspace(-6, -12, 7):
    sensitivity_rows.append({"sweep": "eps_total", "value": eps_total, **find_minimum_N(0.03, eps_total=float(eps_total), m_grid_size=90)})
for p_sift in np.linspace(0.45, 0.90, 10):
    sensitivity_rows.append({"sweep": "p_sift", "value": p_sift, **find_minimum_N(0.03, p_sift=float(p_sift), m_grid_size=90)})

sensitivity_df = pd.DataFrame(sensitivity_rows)
sensitivity_df.to_csv(TABLES_DIR / "results_sensitivity.csv", index=False)
display(sensitivity_df[["sweep", "value", "qber", "N_min", "optimal_m", "status"]].head(20))

fig, axes = plt.subplots(2, 2, figsize=(11, 8))
sub = sensitivity_df[sensitivity_df["sweep"] == "qber"]
axes[0, 0].plot(100 * sub["value"], sub["N_min"], marker="o")
axes[0, 0].set(xlabel="QBER (%)", ylabel="N_min", title="N_min vs QBER")
axes[0, 0].set_yscale("log")
sub = sensitivity_df[sensitivity_df["sweep"] == "f_ec"]
axes[0, 1].plot(sub["value"], sub["N_min"], marker="o", color="tab:orange")
axes[0, 1].set(xlabel="f_ec", ylabel="N_min", title="N_min vs EC inefficiency")
axes[0, 1].set_yscale("log")
sub = sensitivity_df[sensitivity_df["sweep"] == "eps_total"]
axes[1, 0].plot(sub["value"], sub["N_min"], marker="o", color="tab:green")
axes[1, 0].set_xscale("log")
axes[1, 0].invert_xaxis()
axes[1, 0].set(xlabel="epsilon_total", ylabel="N_min", title="N_min vs security level")
axes[1, 0].set_yscale("log")
sub = sensitivity_df[sensitivity_df["sweep"] == "p_sift"]
axes[1, 1].plot(sub["value"], sub["N_min"], marker="o", color="tab:red")
axes[1, 1].set(xlabel="p_sift", ylabel="N_min", title="N_min vs sift fraction")
axes[1, 1].set_yscale("log")
save_figure("sensitivity_analysis.png")
plt.show()
''')

md(r"""
### Sensitivity Summary

QBER likely has the strongest effect because it affects both the entropy term and error-correction leakage. Error-correction inefficiency matters strongly. The security level affects fixed overheads and confidence intervals, while biased basis choice or a larger sift fraction can help by leaving more usable bits per transmitted signal.
""")

md(r"""
## Direction 5: Pareto-Front Exploration

Instead of optimizing only $N$, this section studies trade-offs between $N$, final key length, verification cost, PA cost, and parameter-estimation sample size. Pareto plots help choose robust parameters rather than only the smallest possible $N$.
""")

code(r'''
rng = np.random.default_rng(1234)
pareto_rows = []
for _ in range(2500):
    N = int(10 ** rng.uniform(math.log10(1_000), math.log10(250_000)))
    p_sift = float(rng.uniform(0.45, 0.9))
    s = int(math.floor(p_sift * N))
    if s <= 30:
        continue
    m = int(np.clip(round(rng.uniform(0.02, 0.65) * s), 10, s - 10))
    weights = rng.dirichlet(np.ones(4))
    eps_pe, eps_pa, eps_cor, eps_smooth = weights * 1e-9
    f_ec = float(rng.uniform(1.0, 1.35))
    method = str(rng.choice(METHODS))
    details = toy_key_length(
        N, 0.03, m, eps_pe=eps_pe, eps_pa=eps_pa, eps_cor=eps_cor,
        f_ec=f_ec, p_sift=p_sift, pe_method=method, return_details=True,
    )
    pareto_rows.append({
        **details, "m_fraction_of_s": m / s, "eps_pe": eps_pe, "eps_pa": eps_pa,
        "eps_cor": eps_cor, "eps_smooth": eps_smooth, "f_ec": f_ec,
        "p_sift": p_sift, "pe_method": method,
    })

pareto_df = pd.DataFrame(pareto_rows)
passing_df = pareto_df[pareto_df["passes_256"]].copy().sort_values("N")
best_seen_ell = -np.inf
flags = []
for _, row in passing_df.iterrows():
    is_pareto = row["ell"] > best_seen_ell
    flags.append(is_pareto)
    best_seen_ell = max(best_seen_ell, row["ell"])
passing_df["pareto_efficient"] = flags
pareto_front_df = passing_df[passing_df["pareto_efficient"]].copy()

plt.figure(figsize=(8.5, 5.5))
plt.scatter(pareto_df["N"], pareto_df["ell"], s=12, alpha=0.2, label="sampled configs")
if len(passing_df):
    plt.scatter(passing_df["N"], passing_df["ell"], s=16, alpha=0.35, label="passing configs")
if len(pareto_front_df):
    plt.scatter(pareto_front_df["N"], pareto_front_df["ell"], s=35, color="tab:red", label="Pareto efficient")
plt.axhline(TARGET_KEY_LENGTH, color="black", linestyle="--", linewidth=1.1)
plt.xscale("log")
plt.xlabel("Transmitted quantum signals N")
plt.ylabel("Toy final key length ell (bits)")
plt.title("Pareto exploration: minimize N, maximize ell")
plt.legend()
save_figure("pareto_front_exploration.png")
plt.show()

print(f"Sampled configs: {len(pareto_df)}")
print(f"Passing configs: {len(passing_df)}")
print(f"Pareto-efficient passing configs: {len(pareto_front_df)}")
display(pareto_front_df.head(10))
''')

md(r"""
### Pareto Analysis

The Pareto front shows that the minimum-$N$ configuration is not the only useful configuration. Slightly larger blocks can produce more margin above 256 bits, use less aggressive epsilon allocation, or reduce sensitivity to the chosen parameter-estimation bound.
""")

md(r"""
## Direction 6: ML Surrogate Model for $N_{\min}$

Machine learning does not replace the security proof. Here it is only a surrogate model to approximate the output of the finite-key optimizer and to understand sensitivity. Any ML prediction must be verified by the finite-key formula before use.
""")

code(r'''
ml_results_df = pd.DataFrame()
ml_metrics = {}

if SKLEARN_AVAILABLE:
    rng = np.random.default_rng(2026)
    method_to_code = {method: idx for idx, method in enumerate(METHODS)}
    rows = []
    for _ in range(100):
        qber = float(rng.uniform(0.001, 0.08))
        log10_eps_total = float(rng.uniform(-12, -6))
        eps_total = 10 ** log10_eps_total
        f_ec = float(rng.uniform(1.0, 1.4))
        p_sift = float(rng.uniform(0.45, 0.9))
        method = str(rng.choice(METHODS))
        result = find_minimum_N(
            qber, eps_total=eps_total, f_ec=f_ec, p_sift=p_sift,
            pe_method=method, N_max=3_000_000, m_grid_size=55,
        )
        if result["status"] == "ok" and np.isfinite(result["N_min"]):
            rows.append({
                "qber": qber, "log10_eps_total": log10_eps_total, "f_ec": f_ec,
                "p_sift": p_sift, "method": method, "method_code": method_to_code[method],
                "N_min": result["N_min"], "log10_N_min": math.log10(result["N_min"]),
            })

    ml_results_df = pd.DataFrame(rows)
    if len(ml_results_df) >= 30:
        feature_cols = ["qber", "log10_eps_total", "f_ec", "p_sift", "method_code"]
        X = ml_results_df[feature_cols]
        y = ml_results_df["log10_N_min"]
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42)
        model = RandomForestRegressor(n_estimators=180, random_state=42, min_samples_leaf=2)
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        ml_metrics = {
            "mae_log10": float(mean_absolute_error(y_test, predictions)),
            "r2": float(r2_score(y_test, predictions)),
            "num_rows": int(len(ml_results_df)),
        }
        print("ML surrogate metrics:", ml_metrics)
        ml_results_df["predicted_log10_N_min"] = model.predict(X)
        ml_results_df.to_csv(TABLES_DIR / "results_ml_surrogate.csv", index=False)

        fig, axes = plt.subplots(1, 2, figsize=(12, 4.8))
        axes[0].scatter(y_test, predictions, alpha=0.75)
        lo = min(y_test.min(), predictions.min())
        hi = max(y_test.max(), predictions.max())
        axes[0].plot([lo, hi], [lo, hi], color="black", linestyle="--", linewidth=1)
        axes[0].set(xlabel="True log10(N_min)", ylabel="Predicted log10(N_min)", title="Predicted vs true")
        importances = pd.Series(model.feature_importances_, index=feature_cols).sort_values()
        axes[1].barh(importances.index, importances.values)
        axes[1].set(xlabel="Random forest feature importance", title="Surrogate sensitivity")
        save_figure("ml_surrogate_results.png")
        plt.show()
        display(ml_results_df.head())
    else:
        print(f"Only {len(ml_results_df)} successful ML rows; skipping model training.")
else:
    print("scikit-learn is unavailable; ML surrogate section skipped.")
''')

md(r"""
### ML Surrogate Analysis

If the ML section ran, the surrogate approximates the optimizer in log-space and feature importances provide a rough sensitivity diagnostic. The model is only an accelerator for exploration. Its predictions are not security claims and should always be checked with the toy formula or, later, the theorem-level finite-key formula.
""")

md(r"""
## Direction 7: Bayesian/Random Optimization for Protocol Parameters

A full grid search can become expensive when the theorem-level formula has many nested optimizations. This section compares coarse grid search, random search, and a simple ML-assisted search idea for maximizing $\ell$ at fixed $N$ and QBER. The final parameters must still be checked with the exact formula.
""")

code(r'''
def _evaluate_protocol_search_point(N, qber, m_fraction, weights, f_ec=1.1, p_sift=0.5, pe_method="hoeffding", eps_total=1e-9):
    """Evaluate one search point for fixed N and qber."""
    s = int(math.floor(p_sift * N))
    m = int(np.clip(round(m_fraction * s), 10, max(11, s - 10)))
    weights = np.asarray(weights, dtype=float)
    weights = np.maximum(weights, 1e-12)
    weights = weights / weights.sum()
    eps_pe, eps_pa, eps_cor, eps_smooth = weights * eps_total
    return toy_key_length(N, qber, m, eps_pe=eps_pe, eps_pa=eps_pa, eps_cor=eps_cor, f_ec=f_ec, p_sift=p_sift, pe_method=pe_method)


qber_for_search = 0.03
base_row = baseline_nmin_df[np.isclose(baseline_nmin_df["qber"], qber_for_search)].iloc[0]
search_N = int(1.15 * base_row["N_min"])
eps_patterns = np.array([[1, 1, 1, 1], [4, 1, 1, 1], [1, 4, 1, 1], [1, 1, 4, 1], [2, 1, 1, 2]], dtype=float)

coarse_values = [
    _evaluate_protocol_search_point(search_N, qber_for_search, m_fraction, weights)
    for m_fraction, weights in itertools.product(np.linspace(0.03, 0.65, 25), eps_patterns)
]
coarse_best = np.maximum.accumulate(coarse_values)

rng = np.random.default_rng(314)
random_values = [
    _evaluate_protocol_search_point(search_N, qber_for_search, float(rng.uniform(0.03, 0.65)), rng.dirichlet(np.ones(4)))
    for _ in range(160)
]
random_best = np.maximum.accumulate(random_values)

search_curves = pd.DataFrame({"evaluation": np.arange(1, max(len(coarse_best), len(random_best)) + 1)})
search_curves["coarse_grid"] = pd.Series(coarse_best)
search_curves["random_search"] = pd.Series(random_best)

if SKLEARN_AVAILABLE:
    try:
        from sklearn.gaussian_process import GaussianProcessRegressor
        from sklearn.gaussian_process.kernels import RBF, WhiteKernel, ConstantKernel

        observed_X, observed_y = [], []
        for _ in range(24):
            m_fraction = float(rng.uniform(0.03, 0.65))
            weights = rng.dirichlet(np.ones(4))
            observed_X.append(np.r_[m_fraction, weights[:3]])
            observed_y.append(_evaluate_protocol_search_point(search_N, qber_for_search, m_fraction, weights))
        gp_best_values = list(np.maximum.accumulate(observed_y))
        kernel = ConstantKernel(1.0) * RBF(length_scale=np.ones(4)) + WhiteKernel(noise_level=1e-3)
        for _ in range(96):
            gp = GaussianProcessRegressor(kernel=kernel, random_state=42, normalize_y=True, n_restarts_optimizer=0)
            gp.fit(np.asarray(observed_X), np.asarray(observed_y))
            candidate_m = rng.uniform(0.03, 0.65, size=600)
            candidate_weights = rng.dirichlet(np.ones(4), size=600)
            candidate_X = np.column_stack([candidate_m, candidate_weights[:, :3]])
            mean, std = gp.predict(candidate_X, return_std=True)
            idx = int(np.argmax(mean + 0.25 * std))
            y_val = _evaluate_protocol_search_point(search_N, qber_for_search, float(candidate_m[idx]), candidate_weights[idx])
            observed_X.append(candidate_X[idx])
            observed_y.append(y_val)
            gp_best_values.append(max(gp_best_values[-1], y_val))
        search_curves["gp_assisted"] = pd.Series(gp_best_values)
    except Exception as exc:
        print("GP-assisted search skipped:", exc)
else:
    print("scikit-learn unavailable; GP-assisted search skipped.")

plt.figure(figsize=(8.5, 5))
for col in ["coarse_grid", "random_search", "gp_assisted"]:
    if col in search_curves:
        plt.plot(search_curves["evaluation"], search_curves[col], label=col.replace("_", " "))
plt.axhline(TARGET_KEY_LENGTH, color="black", linestyle="--", linewidth=1.1)
plt.xlabel("Number of evaluations")
plt.ylabel("Best ell found so far (bits)")
plt.title(f"Search efficiency at fixed N={search_N}, QBER=3%")
plt.legend()
save_figure("search_efficiency.png")
plt.show()
display(search_curves.tail())
''')

md(r"""
### Search-Method Analysis

Random and ML-assisted search can find good parameters without enumerating a dense grid. This becomes more valuable once the toy formula is replaced by a full finite-key theorem with expensive decoy bounds, exact hypergeometric tails, or code-specific error-correction simulations.
""")

md(r"""
## Summary of Findings

- This notebook explored a simplified short-key BB84-like planning model for producing one 256-bit key.
- The most important optimization target is $N_{\min}(Q,\varepsilon_{\text{total}})$, not asymptotic key rate.
- QBER strongly affects the answer because it reduces raw entropy and increases error-correction leakage.
- The choice of statistical confidence bound can substantially change the short-key signal budget.
- Epsilon allocation can help because parameter-estimation failure probability affects the entropy term through $Q_{\text{upper}}$.
- Short-block error-correction leakage is a major uncertainty and a promising direction for more serious work.
- Pareto plots expose margin and robustness trade-offs that a single minimum-$N$ number hides.
- ML surrogate models can approximate the optimizer and diagnose sensitivity, but they do not replace the finite-key calculation.
- What remains incomplete is the actual theorem-level security proof: decoy-state statistics, exact constants, smoothing, abort conditioning, authentication costs, and implementation assumptions are not proved here.

## Future Work

1. Replace the toy BB84 formula with a theorem-level finite-key expression from a specific paper.
2. Include exact hypergeometric or Serfling bounds with carefully checked constants.
3. Implement or benchmark real short-block reconciliation codes.
4. Add decoy-state analysis for weak coherent pulse sources.
5. Study acceptance conditioning and abort probability more rigorously.
6. Turn the notebook into a paper-style reproducible experiment.
7. Release code and figures.
""")

md(r"""
## Reproducibility and Output Files

The final cell prints package versions and saves the main result tables under `results_01_finite-key/tables/`. Figures are saved under `results_01_finite-key/figures/`.
""")

code(r'''
print("Python:", sys.version.split()[0])
print("numpy:", np.__version__)
print("pandas:", pd.__version__)
print("scipy:", scipy.__version__)
print("matplotlib:", matplotlib.__version__)
if SKLEARN_AVAILABLE:
    import sklearn
    print("sklearn:", sklearn.__version__)
else:
    print("sklearn: unavailable")

tables_to_save = {
    "results_baseline_nmin.csv": baseline_nmin_df,
    "results_statistical_bounds.csv": stat_bounds_df,
    "results_epsilon_allocation.csv": epsilon_allocation_df,
    "results_ec_models.csv": ec_models_df,
    "results_sensitivity.csv": sensitivity_df,
}
if SKLEARN_AVAILABLE and isinstance(ml_results_df, pd.DataFrame) and len(ml_results_df) > 0:
    tables_to_save["results_ml_surrogate.csv"] = ml_results_df

for filename, table in tables_to_save.items():
    path = TABLES_DIR / filename
    table.to_csv(path, index=False)
    print(f"saved {path}: {len(table)} rows")

print("Saved figures:")
for path in sorted(FIGURES_DIR.glob("*.png")):
    print("-", path.as_posix())
''')


notebook = {
    "cells": cells,
    "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {
            "name": "python",
            "version": sys.version.split()[0],
            "mimetype": "text/x-python",
            "codemirror_mode": {"name": "ipython", "version": 3},
            "pygments_lexer": "ipython3",
            "nbconvert_exporter": "python",
            "file_extension": ".py",
        },
    },
    "nbformat": 4,
    "nbformat_minor": 5,
}

path = Path("finite_key_short_key_qkd_study.ipynb")
path.write_text(json.dumps(notebook, indent=1), encoding="utf-8")
print(f"wrote {path.resolve()} with {len(cells)} cells")
