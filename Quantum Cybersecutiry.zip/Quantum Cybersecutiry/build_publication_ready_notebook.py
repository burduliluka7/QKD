import json
import sys
from pathlib import Path
from textwrap import dedent


cells = []


def add_cell(kind, text):
    source = dedent(text).strip() + "\n"
    cell = {
        "cell_type": kind,
        "id": f"cell-{len(cells) + 1:03d}",
        "metadata": {},
        "source": source.splitlines(True),
    }
    if kind == "code":
        cell.update({"execution_count": None, "outputs": []})
    cells.append(cell)


def md(text):
    add_cell("markdown", text)


def code(text):
    add_cell("code", text)


md(r"""
# 05 — Publication-Ready Analysis for Leakage-Capped 256-bit Finite-Key BB84

This notebook turns the previous theory and reconciliation analysis into paper-ready numerical evidence.  The cleaned proof text is treated as fixed: the numerical task here is to implement the theorem-level quantities consistently, generate the figures and tables needed for the paper, and keep security accounting separate from operational acceptance estimates.

The notebook uses the theorem-level key-length condition

$$
\ell
=
\left\lfloor
n-\log_2 B(n,t_{\mathrm{ph}}^U)
- L_{\max}
- t_{\mathrm{ver}}
- 2\log_2(1/\varepsilon_{\mathrm{PA}})
\right\rfloor,
$$

where

$$
B(n,t)=\sum_{i=0}^{t}\binom{n}{i}.
$$

The target quantity is

$$
N_{\min}(Q_{\mathrm{tol}},\varepsilon_{\mathrm{tot}})
=
\min\{N:\ell(N,Q_{\mathrm{tol}},\varepsilon_{\mathrm{tot}})\ge256\}.
$$

Empirical reconciliation data is used only to choose deterministic leakage caps $L_{\max}$.  The security calculation itself subtracts the cap.  If the actual reconciliation transcript exceeds the declared cap, the protocol aborts.
""")

md(r"""
## 1. Security theorem used in this notebook

The proof file used by this notebook is `cleaned_security_proof_theory.txt` when available locally, or `/mnt/data/cleaned_security_proof_theory.txt` in a hosted environment.  The theorem structure is modular:

1. Parameter estimation bounds the number of phase errors in the unrevealed raw-key block.
2. The phase-error count gives a smooth-min-entropy lower bound through the finite Hamming-ball term.
3. Public reconciliation leakage and verification leakage are subtracted.
4. Two-universal privacy amplification extracts the final key.

The parameter-estimation event is

$$
\Pr[t_{\mathrm{ph}}>t_{\mathrm{ph}}^U \wedge \mathrm{accept}]
\le
\varepsilon_{\mathrm{PE}}.
$$

The exact Hamming-ball entropy lower bound is

$$
H_{\min}^{\varepsilon_s}(X^n|E,\mathrm{pub}_{\mathrm{preEC}})
\ge
n-\log_2 B(n,t_{\mathrm{ph}}^U).
$$

Leakage and verification subtraction give

$$
H_{\min}^{\varepsilon_s}(X^n|E,\mathrm{pub}_{\mathrm{preEC}},C,V)
\ge
n-\log_2 B(n,t_{\mathrm{ph}}^U)
- L_{\max}
- t_{\mathrm{ver}}.
$$

The verification tag length is

$$
t_{\mathrm{ver}}
=
\left\lceil
\log_2(1/\varepsilon_{\mathrm{cor}})
\right\rceil.
$$

The privacy-amplification penalty is

$$
2\log_2(1/\varepsilon_{\mathrm{PA}}).
$$

The final key-length condition is

$$
\ell
\le
n-\log_2 B(n,t_{\mathrm{ph}}^U)
- L_{\max}
- t_{\mathrm{ver}}
- 2\log_2(1/\varepsilon_{\mathrm{PA}}).
$$

The composable security budget is

$$
\varepsilon_{\mathrm{tot}}
=
\varepsilon_{\mathrm{cor}}
+
\varepsilon_{\mathrm{PE}}
+
2\varepsilon_s
+
\varepsilon_{\mathrm{PA}}.
$$

The balanced split used by default is

$$
\varepsilon_{\mathrm{cor}}
=
\varepsilon_{\mathrm{PE}}
=
\varepsilon_s
=
\varepsilon_{\mathrm{PA}}
=
\varepsilon_{\mathrm{tot}}/5.
$$

The familiar binary-entropy expression

$$
n[1-h_2(Q_{\mathrm{ph}}^U)]
$$

is shown only as a conservative comparison.  The main finite-key calculation uses the exact Hamming-ball term from the proof.
""")

code(r'''
import itertools
import json
import math
import platform
import random
import sys
import time
import warnings
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy


START_TIME = time.time()
random.seed(12345)
np.random.seed(12345)

output_dir = Path("results_05_publication-ready")
results_dir = output_dir / "data"
figures_dir = output_dir / "figures"
tables_dir = output_dir / "tables"
for directory in [results_dir, figures_dir, tables_dir]:
    directory.mkdir(parents=True, exist_ok=True)

TARGET_KEY_LENGTH = 256
DEFAULT_EPS_TOTAL = 1e-9
DEFAULT_P_SIFT = 0.5
DEFAULT_F_EC = 1.1
DEFAULT_QTOL_GRID = [0.005, 0.01, 0.02, 0.03, 0.05]

EXACT_S_LIMIT = 200_000
MAIN_M_FRACTION_GRID = np.linspace(0.06, 0.44, 20)
DIAGNOSTIC_M_FRACTION_GRID = np.linspace(0.08, 0.40, 13)

plt.rcParams.update({
    "figure.figsize": (8.0, 4.8),
    "axes.grid": True,
    "grid.alpha": 0.25,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "font.size": 10,
    "axes.titlesize": 12,
    "axes.labelsize": 10,
    "legend.frameon": False,
})

environment_summary = {
    "python_version": sys.version,
    "numpy_version": np.__version__,
    "pandas_version": pd.__version__,
    "scipy_version": scipy.__version__,
    "matplotlib_version": matplotlib.__version__,
    "platform": platform.platform(),
    "timestamp": time.strftime("%Y-%m-%d %H:%M:%S %Z"),
}
(results_dir / "environment_summary.json").write_text(json.dumps(environment_summary, indent=2), encoding="utf-8")
environment_summary
''')

md("### Load the cleaned theory text")

code(r'''
def load_theory_text():
    """Load the cleaned proof/theory text if it is available."""
    candidates = [
        Path("/mnt/data/cleaned_security_proof_theory.txt"),
        Path("cleaned_security_proof_theory.txt"),
    ]
    for path in candidates:
        if path.exists():
            return path, path.read_text(encoding="utf-8", errors="replace")
    return None, ""


THEORY_PATH, THEORY_TEXT = load_theory_text()
if THEORY_PATH is None:
    warnings.warn("cleaned_security_proof_theory.txt was not found; formulas are still implemented from the prompt.")
else:
    print("Loaded theory text:", THEORY_PATH)
print(THEORY_TEXT[:900] if THEORY_TEXT else "No theory file loaded.")
''')

md("## Utility functions")

code(r'''
def binary_entropy(q):
    """Return binary entropy h2(q) in bits, with strict domain checking."""
    arr = np.asarray(q, dtype=float)
    tol = 1e-15
    if np.any(arr < -tol) or np.any(arr > 1.0 + tol):
        raise ValueError("binary_entropy expects q in [0, 1].")
    clipped = np.clip(arr, 0.0, 1.0)
    out = np.zeros_like(clipped, dtype=float)
    mask = (clipped > 0.0) & (clipped < 1.0)
    out[mask] = (
        -clipped[mask] * np.log2(clipped[mask])
        - (1.0 - clipped[mask]) * np.log2(1.0 - clipped[mask])
    )
    if out.shape == ():
        return float(out)
    return out


def log2_binom(n, k):
    """Return log2(binomial(n, k)) using scipy.special.gammaln."""
    n = int(n)
    k = int(k)
    if k < 0 or k > n:
        return float("-inf")
    return float((scipy.special.gammaln(n + 1) - scipy.special.gammaln(k + 1) - scipy.special.gammaln(n - k + 1)) / math.log(2.0))


_HAMMING_CACHE = {}


def log2_hamming_ball(n, t):
    """Return log2(sum_{i=0}^t binom(n, i)) using stable log-sum-exp.

    The Hamming ball is not symmetric in t: B(n,t) != B(n,n-t). For t > n/2,
    compute the complement tail 2^n - sum_{i=t+1}^n binom(n,i) rather than
    using a symmetry shortcut.
    """
    n = int(n)
    t = int(math.floor(t))
    if n < 0:
        raise ValueError("n must be nonnegative.")
    if t < 0:
        return float("-inf")
    if t == 0:
        return 0.0
    if t >= n:
        return float(n)
    key = (n, t)
    if key in _HAMMING_CACHE:
        return _HAMMING_CACHE[key]
    if t <= n // 2:
        ks = np.arange(0, t + 1, dtype=float)
        logs = scipy.special.gammaln(n + 1) - scipy.special.gammaln(ks + 1) - scipy.special.gammaln(n - ks + 1)
        value = float(scipy.special.logsumexp(logs) / math.log(2.0))
    else:
        ks = np.arange(t + 1, n + 1, dtype=float)
        tail_logs = scipy.special.gammaln(n + 1) - scipy.special.gammaln(ks + 1) - scipy.special.gammaln(n - ks + 1)
        log_tail = float(scipy.special.logsumexp(tail_logs))
        log_total = n * math.log(2.0)
        ratio = math.exp(log_tail - log_total) if log_tail - log_total > -745 else 0.0
        value = float(n + math.log1p(-ratio) / math.log(2.0))
    _HAMMING_CACHE[key] = value
    return value


def verification_tag_length(eps_cor):
    """Return ceil(log2(1/eps_cor))."""
    eps_cor = float(eps_cor)
    if eps_cor <= 0.0:
        raise ValueError("eps_cor must be positive.")
    return int(math.ceil(math.log2(1.0 / eps_cor)))


def pa_penalty(eps_pa):
    """Return the two-universal privacy amplification penalty."""
    eps_pa = float(eps_pa)
    if eps_pa <= 0.0:
        raise ValueError("eps_pa must be positive.")
    return float(2.0 * math.log2(1.0 / eps_pa))


def split_security_budget(eps_total, mode="balanced"):
    """Split eps_total with eps_cor + eps_pe + 2 eps_smooth + eps_pa <= eps_total."""
    eps_total = float(eps_total)
    if eps_total <= 0.0:
        raise ValueError("eps_total must be positive.")
    mode = str(mode).lower()
    weights = {
        "balanced": {"eps_cor": 1.0, "eps_pe": 1.0, "eps_smooth": 1.0, "eps_pa": 1.0},
        "pe_heavy": {"eps_cor": 1.0, "eps_pe": 5.0, "eps_smooth": 1.0, "eps_pa": 1.0},
        "pa_heavy": {"eps_cor": 1.0, "eps_pe": 1.0, "eps_smooth": 1.0, "eps_pa": 5.0},
        "cor_heavy": {"eps_cor": 5.0, "eps_pe": 1.0, "eps_smooth": 1.0, "eps_pa": 1.0},
        "smoothing_heavy": {"eps_cor": 1.0, "eps_pe": 1.0, "eps_smooth": 5.0, "eps_pa": 1.0},
    }
    if mode not in weights:
        raise ValueError(f"Unknown security-budget split: {mode}")
    w = weights[mode]
    weighted_total = w["eps_cor"] + w["eps_pe"] + 2.0 * w["eps_smooth"] + w["eps_pa"]
    out = {name: eps_total * value / weighted_total for name, value in w.items()}
    out["eps_total_implied"] = out["eps_cor"] + out["eps_pe"] + 2.0 * out["eps_smooth"] + out["eps_pa"]
    out["eps_total_target"] = eps_total
    out["eps_mode"] = mode
    return out


def save_figure(fig, stem):
    """Save a matplotlib figure as PNG and PDF and return both paths."""
    png_path = figures_dir / f"{stem}.png"
    pdf_path = figures_dir / f"{stem}.pdf"
    fig.tight_layout()
    fig.savefig(png_path, dpi=220)
    fig.savefig(pdf_path)
    return png_path, pdf_path


budget_preview = pd.DataFrame([split_security_budget(DEFAULT_EPS_TOTAL, mode) for mode in [
    "balanced", "pe_heavy", "pa_heavy", "cor_heavy", "smoothing_heavy"
]])
budget_preview
''')

md("## 2. Sanity checks for theorem-level quantities")

code(r'''
def check_row(name, passed, value, expected):
    """Return a standardized sanity-check row."""
    return {"check": name, "passed": bool(passed), "value": value, "expected": expected}


checks = []
checks.append(check_row("binary_entropy(0)=0", np.isclose(binary_entropy(0), 0.0), binary_entropy(0), "0"))
checks.append(check_row("binary_entropy(0.5)=1", np.isclose(binary_entropy(0.5), 1.0), binary_entropy(0.5), "1"))
checks.append(check_row("binary_entropy(1)=0", np.isclose(binary_entropy(1), 0.0), binary_entropy(1), "0"))
checks.append(check_row("log2_hamming_ball(n,0)=0", np.isclose(log2_hamming_ball(100, 0), 0.0), log2_hamming_ball(100, 0), "0"))
checks.append(check_row("log2_hamming_ball(n,n)=n", np.isclose(log2_hamming_ball(100, 100), 100.0), log2_hamming_ball(100, 100), "100"))
checks.append(check_row(
    "Hamming ball is not incorrectly symmetrized",
    log2_hamming_ball(10, 7) > log2_hamming_ball(10, 3),
    f"log2 B(10,7)={log2_hamming_ball(10, 7):.6f}, log2 B(10,3)={log2_hamming_ball(10, 3):.6f}",
    "B(10,7) > B(10,3)",
))

for n in [64, 256, 1000]:
    for q in [0.01, 0.03, 0.08, 0.12]:
        t = int(math.floor(n * q))
        lhs = log2_hamming_ball(n, t)
        rhs = n * binary_entropy(t / n if n else 0.0)
        checks.append(check_row(
            f"log2 B({n}, floor(n*{q})) <= n h2(floor(nq)/n)",
            lhs <= rhs + 1e-8,
            f"{lhs:.6f} <= {rhs:.6f}",
            "True",
        ))

eps = split_security_budget(DEFAULT_EPS_TOTAL, "balanced")
t_ver_demo = verification_tag_length(eps["eps_cor"])
checks.append(check_row(
    "2^-t_ver <= eps_cor",
    2.0 ** (-t_ver_demo) <= eps["eps_cor"],
    f"2^-{t_ver_demo}={2.0 ** (-t_ver_demo):.3e}, eps_cor={eps['eps_cor']:.3e}",
    "True",
))
checks.append(check_row(
    "balanced epsilon split sums to target",
    np.isclose(eps["eps_total_implied"], DEFAULT_EPS_TOTAL, rtol=0.0, atol=DEFAULT_EPS_TOTAL * 1e-12),
    f"{eps['eps_total_implied']:.3e}",
    f"{DEFAULT_EPS_TOTAL:.3e}",
))

sanity_checks = pd.DataFrame(checks)
sanity_checks.to_csv(results_dir / "theory_sanity_checks.csv", index=False)
display(sanity_checks)
if not sanity_checks["passed"].all():
    raise RuntimeError("One or more theory sanity checks failed.")
print("All theory sanity checks passed.")
''')

md(r"""
## 3. Threshold-based parameter estimation

This notebook uses an accept/abort threshold rather than expected errors.  The protocol accepts the parameter-estimation sample only when

$$
e_{\mathrm{obs}}\le e_{\mathrm{tol}},
$$

where

$$
e_{\mathrm{tol}}=\lfloor Q_{\mathrm{tol}}m\rfloor.
$$

For every accepted observation, the key-length formula must remain valid.  Therefore the phase-error count used below is

$$
t_{\mathrm{ph}}^U
=
\max_{0\le e\le e_{\mathrm{tol}}}
\left(K^U(e)-e\right).
$$

Here $K^U(e)$ is the largest total sifted-block error count still compatible with observing at most $e$ errors in the test sample, at failure probability $\varepsilon_{\mathrm{PE}}$. Under the natural coupling from $K$ to $K+1$ population errors, the sample count rises by at most one; consequently $K^U(e)-e$ is nondecreasing and the exact maximum is attained at $e=e_{\mathrm{tol}}$. The implementation checks this endpoint reduction against brute-force enumeration on representative parameter sets.
""")

code(r'''
_PE_CACHE = {}


def accepted_error_threshold(q_tol, m):
    """Return floor(q_tol * m), the accepted sample-error threshold."""
    return int(np.floor(float(q_tol) * int(m)))


def hypergeom_K_upper(e, S, m, eps_pe):
    """Return largest K with P_K[E_sample <= e] >= eps_pe for Hypergeom(S,K,m)."""
    e = int(e)
    S = int(S)
    m = int(m)
    eps_pe = float(eps_pe)
    if m <= 0 or S <= 0 or m >= S:
        return S
    low = 0
    high = S
    best = 0
    while low <= high:
        mid = (low + high) // 2
        cdf = scipy.stats.hypergeom.cdf(e, S, mid, m)
        if np.isfinite(cdf) and float(cdf) >= eps_pe:
            best = mid
            low = mid + 1
        else:
            high = mid - 1
    return int(best)


def phase_error_upper_count_threshold(q_tol, m, s, eps_pe):
    """Compute exact threshold PE t_ph^U by worst case over accepted e values."""
    q_tol = float(q_tol)
    m = int(m)
    s = int(s)
    eps_pe = float(eps_pe)
    n = s - m
    e_tol = accepted_error_threshold(q_tol, m)
    if m <= 0 or n <= 0:
        return {
            "s": s, "m": m, "n": max(0, n), "q_tol": q_tol, "e_tol": e_tol,
            "t_ph_upper": max(0, n), "q_ph_upper": 1.0, "worst_e": np.nan,
            "K_upper_at_worst_e": np.nan, "eps_pe": eps_pe, "valid": False,
            "pe_method": "hypergeom", "pe_fallback_used": False,
        }
    # Under the natural coupling from K to K + 1 population errors, the sample
    # error count can increase by at most one. Hence K_upper(e + 1) is at least
    # K_upper(e) + 1, so K_upper(e) - e is nondecreasing. The exact maximum over
    # all accepted e is therefore attained at the endpoint e_tol.
    worst_e = int(e_tol)
    worst_K = int(hypergeom_K_upper(worst_e, s, m, eps_pe))
    t_ph = int(np.clip(worst_K - worst_e, 0, n))
    return {
        "s": s,
        "m": m,
        "n": n,
        "q_tol": q_tol,
        "e_tol": e_tol,
        "t_ph_upper": t_ph,
        "q_ph_upper": float(np.clip(t_ph / max(n, 1), 0.0, 1.0)),
        "worst_e": int(worst_e),
        "K_upper_at_worst_e": int(worst_K),
        "eps_pe": eps_pe,
        "valid": True,
        "pe_method": "hypergeom",
        "pe_fallback_used": False,
    }


def verify_endpoint_phase_error_inversion():
    """Cross-check the endpoint maximum against brute force over accepted e."""
    checks = []
    for q_tol, m, s, eps_pe in [
        (0.01, 127, 700, 1e-7),
        (0.03, 211, 1000, 2.5e-10),
        (0.05, 319, 1400, 1e-9),
    ]:
        endpoint = phase_error_upper_count_threshold(q_tol, m, s, eps_pe)
        e_tol = accepted_error_threshold(q_tol, m)
        scalar_candidates = []
        for e in range(e_tol + 1):
            K_upper = hypergeom_K_upper(e, s, m, eps_pe)
            scalar_candidates.append((K_upper - e, e, K_upper))
        scalar = max(scalar_candidates, key=lambda x: x[0])
        scalar_t_ph = int(np.clip(scalar[0], 0, s - m))
        checks.append({
            "q_tol": q_tol,
            "m": m,
            "s": s,
            "endpoint_t_ph": int(endpoint["t_ph_upper"]),
            "scalar_t_ph": scalar_t_ph,
            "passed": int(endpoint["t_ph_upper"]) == scalar_t_ph,
        })
    checks = pd.DataFrame(checks)
    if not bool(checks["passed"].all()):
        raise AssertionError("Endpoint phase-error inversion disagrees with brute-force reference")
    return checks


phase_error_endpoint_checks = verify_endpoint_phase_error_inversion()
phase_error_endpoint_checks.to_csv(results_dir / "phase_error_endpoint_checks.csv", index=False)


def phase_error_upper_count_serfling(q_tol, m, s, eps_pe):
    """Return a Serfling fallback upper count for the unrevealed key block."""
    q_tol = float(q_tol)
    m = int(m)
    s = int(s)
    eps_pe = float(eps_pe)
    n = s - m
    e_tol = accepted_error_threshold(q_tol, m)
    if m <= 0 or n <= 0:
        q_upper = 1.0
    else:
        q_hat = e_tol / m
        delta = math.sqrt(((s - m + 1.0) * math.log(1.0 / eps_pe)) / (2.0 * m * s))
        q_upper = float(np.clip(q_hat + delta, 0.0, 1.0))
    t_ph = int(np.clip(math.ceil(q_upper * max(n, 0)), 0, max(n, 0)))
    return {
        "s": s,
        "m": m,
        "n": max(n, 0),
        "q_tol": q_tol,
        "e_tol": e_tol,
        "t_ph_upper": t_ph,
        "q_ph_upper": float(np.clip(t_ph / max(n, 1), 0.0, 1.0)),
        "worst_e": int(e_tol),
        "K_upper_at_worst_e": np.nan,
        "eps_pe": eps_pe,
        "valid": n > 0,
        "pe_method": "serfling",
        "pe_fallback_used": True,
    }


def phase_error_upper_count(q_tol, m, s, eps_pe, method="hypergeom", exact_s_limit=200_000):
    """Dispatch exact hypergeometric PE when feasible, otherwise Serfling fallback."""
    key = (round(float(q_tol), 12), int(m), int(s), round(float(eps_pe), 24), str(method), int(exact_s_limit))
    if key in _PE_CACHE:
        return dict(_PE_CACHE[key])
    if str(method).lower() == "hypergeom" and int(s) <= int(exact_s_limit):
        result = phase_error_upper_count_threshold(q_tol, m, s, eps_pe)
    elif str(method).lower() in ["serfling", "hypergeom"]:
        result = phase_error_upper_count_serfling(q_tol, m, s, eps_pe)
    else:
        raise ValueError(f"Unknown PE method: {method}")
    _PE_CACHE[key] = dict(result)
    return result


pe_diag_rows = []
eps_pe_diag = split_security_budget(DEFAULT_EPS_TOTAL, "balanced")["eps_pe"]
for q_tol, s, frac in itertools.product(DEFAULT_QTOL_GRID, [1000, 2500, 5000, 10000], [0.1, 0.2, 0.35]):
    m = max(1, int(math.floor(frac * s)))
    row = phase_error_upper_count(q_tol, m, s, eps_pe_diag)
    row["m_fraction"] = frac
    pe_diag_rows.append(row)
pe_diagnostics = pd.DataFrame(pe_diag_rows)
pe_diagnostics.to_csv(results_dir / "parameter_estimation_diagnostics.csv", index=False)
display(pe_diagnostics.head(12))
''')

md("## Plot 1 -- Hamming-ball entropy vs binary-entropy approximation")

code(r'''
n_values = [256, 512, 1000, 5000]
q_values = np.linspace(0.0, 0.12, 80)

fig, ax = plt.subplots(figsize=(8, 5))
entropy_comparison_rows = []
for n in n_values:
    exact_values = []
    binary_values = []
    for q in q_values:
        t = int(math.floor(n * q))
        exact_entropy = n - log2_hamming_ball(n, t)
        binary_entropy_term = n * (1.0 - binary_entropy(t / n if n else 0.0))
        exact_values.append(exact_entropy)
        binary_values.append(binary_entropy_term)
        entropy_comparison_rows.append({
            "n": n, "q": q, "t": t,
            "entropy_exact": exact_entropy,
            "entropy_binary": binary_entropy_term,
            "exact_minus_binary": exact_entropy - binary_entropy_term,
        })
    ax.plot(q_values, exact_values, label=f"exact n={n}")
    ax.plot(q_values, binary_values, linestyle="--", alpha=0.65, label=f"binary n={n}")
ax.set_xlabel(r"Phase-error fraction $q=t/n$")
ax.set_ylabel("Raw-key entropy lower bound (bits)")
ax.set_title("Exact Hamming-ball entropy vs binary-entropy approximation")
ax.legend(ncol=2, fontsize=8)
save_figure(fig, "01_entropy_exact_vs_binary")
plt.show()

pd.DataFrame(entropy_comparison_rows).to_csv(results_dir / "entropy_exact_vs_binary_grid.csv", index=False)
''')

md(r"""
The plot compares the exact theorem term $n-\log_2 B(n,t)$ with the simpler binary-entropy expression $n[1-h_2(t/n)]$.  The exact Hamming-ball term is the main result because it is the finite-size expression used by the cleaned proof.  The binary-entropy expression is a conservative approximation and can hide short-block finite-size structure, which matters for 256-bit final keys.
""")

md("## Plot 2 -- Phase-error upper bound vs block size")

code(r'''
phase_rows = []
N_values_phase = np.unique(np.round(np.logspace(math.log10(1200), math.log10(60000), 24)).astype(int))
m_fraction_phase = 0.2
eps_pe_phase = split_security_budget(DEFAULT_EPS_TOTAL, "balanced")["eps_pe"]
for q_tol, N in itertools.product(DEFAULT_QTOL_GRID, N_values_phase):
    s = int(math.floor(DEFAULT_P_SIFT * int(N)))
    m = max(1, int(math.floor(m_fraction_phase * s)))
    pe = phase_error_upper_count(q_tol, m, s, eps_pe_phase)
    row = dict(pe)
    row["N"] = int(N)
    row["m_fraction"] = m_fraction_phase
    phase_rows.append(row)
phase_vs_N = pd.DataFrame(phase_rows)
phase_vs_N.to_csv(results_dir / "phase_error_upper_vs_N.csv", index=False)

fig, ax = plt.subplots(figsize=(8, 5))
for q_tol in DEFAULT_QTOL_GRID:
    sub = phase_vs_N[np.isclose(phase_vs_N["q_tol"], q_tol)].sort_values("N")
    ax.plot(sub["N"], sub["q_ph_upper"], marker="o", markersize=3, label=f"Qtol={q_tol:.3f}")
ax.set_xscale("log")
ax.set_xlabel(r"Transmitted signals $N$")
ax.set_ylabel(r"Phase-error upper rate $Q_{\mathrm{ph}}^{U}$")
ax.set_title("Finite-size phase-error upper bound vs N")
ax.legend()
save_figure(fig, "02_phase_error_upper_vs_N")
plt.show()
''')

md(r"""
Parameter estimation adds finite-size statistical overhead.  Smaller blocks produce larger $Q_{\mathrm{ph}}^U$, which directly reduces the Hamming-ball entropy term.  The plotted curves use a fixed diagnostic sample fraction $m/s=0.2$; the main $N_{\min}$ calculations later optimize this fraction.
""")

md("## 4. Loading reconciliation leakage caps")

code(r'''
def normalize_columns(df):
    """Normalize CSV column names and protocol labels."""
    out = df.copy()
    out.columns = [str(c).strip().lower().replace(" ", "_").replace("-", "_") for c in out.columns]
    aliases = {
        "q": "qber",
        "q_obs": "qber",
        "block_length": "n",
        "protocol_name": "protocol",
        "mean": "mean_leakage",
        "p95": "p95_leakage",
        "p99": "p99_leakage",
        "max": "max_leakage",
        "leakage": "leakage_bits",
    }
    out = out.rename(columns={old: new for old, new in aliases.items() if old in out.columns})
    if "protocol" in out.columns:
        out["protocol"] = out["protocol"].astype(str).str.lower().str.strip()
    for col in out.columns:
        if col != "protocol":
            converted = pd.to_numeric(out[col], errors="coerce")
            if converted.notna().sum() > 0:
                out[col] = converted
    return out


def load_first_existing(paths):
    """Load the first existing CSV from paths."""
    loaded = []
    for path in paths:
        path = Path(path)
        if path.exists():
            return normalize_columns(pd.read_csv(path)), str(path), loaded + [str(path)]
        loaded.append(str(path))
    return None, None, loaded


leakage_candidates = [
    "results_03_reconciliation/tables/empirical_leakage_table.csv",
    "results_03_reconciliation/tables/reconciliation_summary.csv",
    "/mnt/data/results_03_reconciliation/tables/empirical_leakage_table.csv",
    "/mnt/data/results_03_reconciliation/tables/reconciliation_summary.csv",
]
leakage_table, leakage_path, leakage_paths_checked = load_first_existing(leakage_candidates)

if leakage_table is None:
    USING_FALLBACK_DATA = True
    fallback_rows = []
    for n, qber in itertools.product([256, 512, 1024, 2048, 4096, 8192], DEFAULT_QTOL_GRID):
        ideal = DEFAULT_F_EC * n * binary_entropy(qber)
        fallback_rows.append({
            "protocol": "cascade",
            "n": n,
            "qber": qber,
            "trials": 0,
            "mean_leakage": math.ceil(1.15 * ideal + 16),
            "p95_leakage": math.ceil(1.25 * ideal + 32),
            "p99_leakage": math.ceil(1.40 * ideal + 64),
            "max_leakage": math.ceil(1.60 * ideal + 96),
            "failure_rate": np.nan,
            "fallback_demonstration_only": True,
        })
    leakage_table = pd.DataFrame(fallback_rows)
    leakage_path = "synthetic_fallback_demonstration_only"
else:
    USING_FALLBACK_DATA = False
    leakage_table["fallback_demonstration_only"] = False

if "protocol" in leakage_table.columns:
    cascade_leakage_table = leakage_table[leakage_table["protocol"].astype(str).str.contains("cascade", na=False)].copy()
else:
    leakage_table["protocol"] = "cascade"
    cascade_leakage_table = leakage_table.copy()

cascade_leakage_table.to_csv(results_dir / "cleaned_reconciliation_leakage_table.csv", index=False)
print("Using fallback data:", USING_FALLBACK_DATA)
print("Leakage path:", leakage_path)
display(cascade_leakage_table.head())

theorem_wrapper_candidates = [
    "results_04_theorem-wrapper/tables/nmin_theorem_locked_leakage_caps.csv",
    "results_04_theorem-wrapper/tables/percent_increase_theorem_locked.csv",
]
previous_theorem_paths_loaded = [path for path in theorem_wrapper_candidates if Path(path).exists()]
print("Previous theorem-wrapper CSVs available:", previous_theorem_paths_loaded)
''')

md("### Load LDPC leakage table (when available)")

code(r'''
ldpc_leakage_candidates = [
    "results_ldpc/tables/ldpc_leakage_table.csv",
    "results_ldpc/tables/ldpc_selected_codes.csv",
]
ldpc_leakage_raw, ldpc_leakage_path, _ = load_first_existing(ldpc_leakage_candidates)

if ldpc_leakage_raw is not None:
    USING_LDPC_DATA = True
    # normalize: the leakage table has columns protocol/n/qber/mean_leakage/...
    # selected_codes table has n/Q/beta/selected_r/leakage_bits
    if "Q" in ldpc_leakage_raw.columns and "protocol" not in ldpc_leakage_raw.columns:
        # It's the selected_codes CSV; build leakage rows manually
        rows = []
        for _, r in ldpc_leakage_raw.iterrows():
            if str(r.get("status", "ok")) != "ok" or r.get("selected_r") is None:
                continue
            beta_str = f"ldpc_beta{int(float(r['beta']) * 100):02d}"
            rv = float(r["selected_r"])
            rows.append({
                "protocol": beta_str,
                "n": int(r["n"]),
                "qber": float(r["Q"]),
                "mean_leakage": rv,
                "p95_leakage": rv,
                "p99_leakage": rv,
                "max_leakage": rv,
                "failure_rate": r.get("eval_failure_rate", float("nan")),
                "selected_r": rv,
                "fallback_demonstration_only": False,
            })
        ldpc_leakage_table = pd.DataFrame(rows)
    else:
        ldpc_leakage_table = ldpc_leakage_raw.copy()
        if "fallback_demonstration_only" not in ldpc_leakage_table.columns:
            ldpc_leakage_table["fallback_demonstration_only"] = False
    ldpc_leakage_table.to_csv(results_dir / "cleaned_ldpc_leakage_table.csv", index=False)
    ldpc_protocols_available = sorted(ldpc_leakage_table["protocol"].unique()) if "protocol" in ldpc_leakage_table.columns else []
    print("LDPC leakage table loaded:", ldpc_leakage_path)
    print("LDPC protocols:", ldpc_protocols_available)
    display(ldpc_leakage_table.head(10))
else:
    USING_LDPC_DATA = False
    ldpc_leakage_table = pd.DataFrame()
    ldpc_protocols_available = []
    print("No LDPC leakage table found; LDPC models will be skipped.")
    print("Run: python run_ldpc_simulation.py --mode quick")
''')

md(r"""
The proof needs deterministic $L_{\max}$, not average leakage.  Empirical p95, p99, and max values are used to choose caps; in the protocol, exceeding the chosen cap causes abort.  `cascade_mean` is included for comparison only.  `cascade_p95` and `cascade_p99` are theorem-compatible only when they are enforced as hard abort caps.  `cascade_max` is the most conservative empirical cap in this table, but it is still limited by the simulation range.

The main lookup policy is conservative on the empirical grid: when possible, it chooses a simulated row with block size at least as large as the requested reconciliation block and QBER at least as large as the tolerated QBER.  If the requested point lies outside the simulated grid, the notebook marks the row as an extrapolated boundary fallback rather than silently treating it as a paper-grade empirical cap.
""")

md("## Leakage cap functions")

code(r'''
def ideal_leakage_cap(n, q_tol, f_ec=1.1):
    """Return ceil(f_ec * n * h2(q_tol))."""
    return int(math.ceil(float(f_ec) * int(n) * binary_entropy(float(q_tol))))


def _leakage_stat_column(table, statistic):
    """Return the leakage statistic column for mean/p95/p99/max."""
    statistic = str(statistic).lower()
    candidates = {
        "mean": ["mean_leakage"],
        "p95": ["p95_leakage"],
        "p99": ["p99_leakage"],
        "max": ["max_leakage"],
    }
    for col in candidates.get(statistic, []):
        if col in table.columns:
            return col
    return None


def empirical_leakage_cap(n, q_tol, leakage_table, statistic="p95", protocol="cascade"):
    """Return empirical L_max using a conservative grid-ceiling lookup when possible.

    The preferred lookup chooses a simulated row with n >= requested n and
    qber >= requested q_tol. If no such row exists, it falls back to the nearest
    boundary row and marks the lookup as extrapolated/approximate.
    """
    n = int(n)
    q_tol = float(q_tol)
    statistic = str(statistic).lower()
    protocol = str(protocol).lower()
    rows = leakage_table.copy()
    if "protocol" in rows.columns:
        rows = rows[rows["protocol"].astype(str).str.lower().str.contains(protocol, na=False)].copy()
    stat_col = _leakage_stat_column(rows, statistic)
    if rows.empty or stat_col is None:
        L = ideal_leakage_cap(n, q_tol, DEFAULT_F_EC)
        return {
            "L_max": int(L),
            "nearest_n": n,
            "nearest_qber": q_tol,
            "statistic": statistic,
            "protocol": protocol,
            "extrapolated_n": False,
            "extrapolated_qber": False,
            "source": "ideal_fallback",
            "lookup_policy": "ideal_fallback",
        }
    rows = rows.dropna(subset=["n", "qber", stat_col]).copy()
    n_values = rows["n"].to_numpy(dtype=float)
    q_values = rows["qber"].to_numpy(dtype=float)
    conservative = rows[(rows["n"].astype(float) >= float(n)) & (rows["qber"].astype(float) >= q_tol)].copy()
    if conservative.empty:
        distance = np.abs(np.log(np.maximum(n_values, 1.0) / max(float(n), 1.0)))
        distance += 30.0 * np.abs(q_values - q_tol)
        selected = rows.iloc[int(np.argmin(distance))]
        lookup_policy = "nearest_neighbor_boundary_fallback"
    else:
        distance = np.log(np.maximum(conservative["n"].to_numpy(dtype=float), 1.0) / max(float(n), 1.0))
        distance += 30.0 * (conservative["qber"].to_numpy(dtype=float) - q_tol)
        selected = conservative.iloc[int(np.argmin(distance))]
        lookup_policy = "conservative_larger_or_equal_grid"
    extrapolated_n = bool(n < np.min(n_values) or n > np.max(n_values))
    extrapolated_qber = bool(q_tol < np.min(q_values) or q_tol > np.max(q_values))
    return {
        "L_max": int(math.ceil(float(selected[stat_col]))),
        "nearest_n": int(selected["n"]),
        "nearest_qber": float(selected["qber"]),
        "statistic": statistic,
        "protocol": protocol,
        "extrapolated_n": extrapolated_n,
        "extrapolated_qber": extrapolated_qber,
        "source": f"{protocol}_{statistic}",
        "lookup_policy": lookup_policy,
    }


def leakage_cap_for_model(n, q_tol, ec_model, leakage_table=None, f_ec=1.1):
    """Return leakage cap metadata for a named security-table EC model."""
    if leakage_table is None:
        leakage_table = cascade_leakage_table
    model = str(ec_model).lower()
    if model == "ideal_fec_1_1":
        return {
            "L_max": ideal_leakage_cap(n, q_tol, f_ec),
            "nearest_n": int(n),
            "nearest_qber": float(q_tol),
            "statistic": "ideal",
            "protocol": "ideal",
            "extrapolated_n": False,
            "extrapolated_qber": False,
            "source": "ideal_fec_1_1",
            "lookup_policy": "analytic_ideal_formula",
        }
    if model.startswith("ldpc_"):
        # e.g. "ldpc_beta01" or "ldpc_beta05"
        if ldpc_leakage_table is None or len(ldpc_leakage_table) == 0:
            raise ValueError(f"LDPC leakage table not loaded; cannot evaluate {ec_model}")
        protocol = model  # e.g. "ldpc_beta01"
        return empirical_leakage_cap(n, q_tol, ldpc_leakage_table, statistic="mean", protocol=protocol)
    if not model.startswith("cascade_"):
        raise ValueError(f"Unsupported EC model: {ec_model}")
    statistic = model.replace("cascade_", "")
    return empirical_leakage_cap(n, q_tol, leakage_table, statistic=statistic, protocol="cascade")


for model in ["ideal_fec_1_1", "cascade_mean", "cascade_p95", "cascade_p99", "cascade_max"]:
    print(model, leakage_cap_for_model(1024, 0.02, model))
if USING_LDPC_DATA:
    for proto in ldpc_protocols_available[:2]:
        try:
            print(proto, leakage_cap_for_model(1024, 0.02, proto))
        except Exception as exc:
            print(f"  LDPC lookup for {proto}: {exc}")
''')

md("## Theorem-level key-length function")

code(r'''
_KEY_CACHE = {}


def key_length_theorem(
    N,
    q_tol,
    m_fraction=0.2,
    eps_total=1e-9,
    p_sift=0.5,
    eps_mode="balanced",
    pe_method="hypergeom",
    ec_model="ideal_fec_1_1",
    leakage_table=None,
    f_ec=1.1,
    exact_hamming=True,
    return_details=True,
):
    """Compute theorem-level key length with exact Hamming-ball entropy by default."""
    if leakage_table is None:
        leakage_table = cascade_leakage_table
    N = int(N)
    q_tol = float(q_tol)
    m_fraction = float(m_fraction)
    s = int(math.floor(float(p_sift) * N))
    m = int(math.floor(m_fraction * s))
    n = s - m
    eps = split_security_budget(eps_total, eps_mode)
    cache_key = (
        N, round(q_tol, 12), round(m_fraction, 8), round(float(eps_total), 24),
        round(float(p_sift), 12), eps_mode, pe_method, ec_model,
        round(float(f_ec), 12), bool(exact_hamming)
    )
    if cache_key in _KEY_CACHE:
        result = dict(_KEY_CACHE[cache_key])
        return result if return_details else result["ell"]
    notes = []
    if s <= 1 or m <= 0 or n <= 0:
        result = {
            "N": N, "s": s, "m": m, "n": max(0, n), "m_fraction": m_fraction,
            "q_tol": q_tol, "e_tol": accepted_error_threshold(q_tol, max(m, 1)),
            "t_ph_upper": np.nan, "q_ph_upper": 1.0,
            "entropy_exact": 0.0, "entropy_binary": 0.0, "entropy_used": 0.0,
            "L_max": np.inf, "leakage_model": ec_model, "t_ver": verification_tag_length(eps["eps_cor"]),
            "leakage_lookup_policy": "invalid",
            "pa_penalty": pa_penalty(eps["eps_pa"]),
            "eps_cor": eps["eps_cor"], "eps_pe": eps["eps_pe"], "eps_smooth": eps["eps_smooth"],
            "eps_pa": eps["eps_pa"], "eps_total_implied": eps["eps_total_implied"],
            "ell": -np.inf, "key_success": False, "pe_method": pe_method,
            "pe_fallback_used": False, "leakage_extrapolated": False,
            "notes": "invalid block dimensions",
        }
        return result if return_details else result["ell"]

    pe = phase_error_upper_count(q_tol, m, s, eps["eps_pe"], method=pe_method, exact_s_limit=EXACT_S_LIMIT)
    t_ph_upper = int(pe["t_ph_upper"])
    q_ph_upper = float(pe["q_ph_upper"])
    if q_ph_upper > 0.5:
        entropy_exact = 0.0
        entropy_binary = 0.0
        notes.append("q_ph_upper exceeds 0.5; entropy set to zero")
    else:
        entropy_exact = float(n - log2_hamming_ball(n, t_ph_upper))
        entropy_binary = float(n * (1.0 - binary_entropy(t_ph_upper / n if n else 0.0)))
    entropy_used = entropy_exact if exact_hamming else entropy_binary

    leak = leakage_cap_for_model(n, q_tol, ec_model, leakage_table=leakage_table, f_ec=f_ec)
    t_ver = verification_tag_length(eps["eps_cor"])
    pa = pa_penalty(eps["eps_pa"])
    ell_real = entropy_used - leak["L_max"] - t_ver - pa
    ell = int(math.floor(ell_real))
    result = {
        "N": N,
        "s": int(s),
        "m": int(m),
        "n": int(n),
        "m_fraction": m_fraction,
        "q_tol": q_tol,
        "e_tol": int(pe["e_tol"]),
        "t_ph_upper": int(t_ph_upper),
        "q_ph_upper": q_ph_upper,
        "entropy_exact": float(entropy_exact),
        "entropy_binary": float(entropy_binary),
        "entropy_used": float(entropy_used),
        "L_max": int(leak["L_max"]),
        "leakage_model": ec_model,
        "leakage_source": leak["source"],
        "leakage_lookup_policy": leak.get("lookup_policy", "unknown"),
        "leakage_nearest_n": leak["nearest_n"],
        "leakage_nearest_qber": leak["nearest_qber"],
        "t_ver": int(t_ver),
        "pa_penalty": float(pa),
        "eps_cor": float(eps["eps_cor"]),
        "eps_pe": float(eps["eps_pe"]),
        "eps_smooth": float(eps["eps_smooth"]),
        "eps_pa": float(eps["eps_pa"]),
        "eps_total_implied": float(eps["eps_total_implied"]),
        "ell_real": float(ell_real),
        "ell": int(ell),
        "key_success": bool(ell >= TARGET_KEY_LENGTH),
        "pe_method": pe["pe_method"],
        "pe_fallback_used": bool(pe["pe_fallback_used"]),
        "leakage_extrapolated": bool(leak["extrapolated_n"] or leak["extrapolated_qber"]),
        "leakage_extrapolated_n": bool(leak["extrapolated_n"]),
        "leakage_extrapolated_qber": bool(leak["extrapolated_qber"]),
        "exact_hamming": bool(exact_hamming),
        "eps_mode": eps_mode,
        "notes": "; ".join(notes) if notes else "ok",
    }
    _KEY_CACHE[cache_key] = dict(result)
    return result if return_details else result["ell"]


demo_key = key_length_theorem(5000, 0.02, m_fraction=0.2, ec_model="cascade_p95")
demo_key
''')

md("## Optimize parameter-estimation fraction and find N_min")

code(r'''
SEARCH_TRACE_ROWS = []


def optimize_m_fraction_for_N(N, q_tol, m_fraction_grid=None, **kwargs):
    """Optimize m/s over a grid and return the best theorem key-length row."""
    if m_fraction_grid is None:
        m_fraction_grid = np.linspace(0.05, 0.45, 41)
    rows = []
    for frac in m_fraction_grid:
        rows.append(key_length_theorem(N, q_tol, m_fraction=float(frac), **kwargs))
    df = pd.DataFrame(rows)
    best = df.loc[int(df["ell"].idxmax())].to_dict()
    return best, df


def find_N_min(
    q_tol,
    ec_model,
    eps_total=1e-9,
    p_sift=0.5,
    m_fraction_grid=None,
    N_min_start=100,
    N_max=5_000_000,
    **kwargs,
):
    """Find N_min by exponential search plus binary search, optimizing m_fraction at each N."""
    if m_fraction_grid is None:
        m_fraction_grid = np.linspace(0.05, 0.45, 41)
    search_id = f"q={q_tol}_ec={ec_model}_eps={eps_total}_exact={kwargs.get('exact_hamming', True)}_{len(SEARCH_TRACE_ROWS)}"

    def evaluate(N, stage):
        best, grid = optimize_m_fraction_for_N(
            int(N),
            q_tol,
            m_fraction_grid=m_fraction_grid,
            eps_total=eps_total,
            p_sift=p_sift,
            ec_model=ec_model,
            **kwargs,
        )
        trace = dict(best)
        trace["search_id"] = search_id
        trace["search_stage"] = stage
        SEARCH_TRACE_ROWS.append(trace)
        return best

    low = int(N_min_start)
    high = max(2 * low, 200)
    high_result = evaluate(high, "exponential")
    while not bool(high_result["key_success"]) and high < int(N_max):
        low = high + 1
        high = min(int(N_max), high * 2)
        high_result = evaluate(high, "exponential")

    if not bool(high_result["key_success"]):
        result = dict(high_result)
        result["N_min"] = np.inf
        result["status"] = "not_found"
        return result

    answer = dict(high_result)
    left, right = int(low), int(high)
    while left <= right:
        mid = (left + right) // 2
        mid_result = evaluate(mid, "binary")
        if bool(mid_result["key_success"]):
            answer = dict(mid_result)
            right = mid - 1
        else:
            left = mid + 1

    answer["N_min"] = int(answer["N"])
    answer["status"] = "ok"
    return answer


quick_best, quick_grid = optimize_m_fraction_for_N(
    5000, 0.02, m_fraction_grid=DIAGNOSTIC_M_FRACTION_GRID, ec_model="cascade_p95"
)
print("Quick optimized row:", {k: quick_best[k] for k in ["N", "m_fraction", "ell", "q_ph_upper", "L_max"]})
''')

md("## Main N_min table")

code(r'''
q_tol_values = DEFAULT_QTOL_GRID
ec_models_cascade = ["ideal_fec_1_1", "cascade_p95", "cascade_p99", "cascade_max"]
ec_models_ldpc = [p for p in ldpc_protocols_available if p.startswith("ldpc_")] if USING_LDPC_DATA else []
ec_models = ec_models_cascade + ec_models_ldpc

main_rows = []
for q_tol, ec_model in itertools.product(q_tol_values, ec_models):
    is_ldpc = ec_model.startswith("ldpc_")
    print(f"Main N_min search: q_tol={q_tol:.3f}, ec_model={ec_model}")
    row = find_N_min(
        q_tol,
        ec_model,
        eps_total=DEFAULT_EPS_TOTAL,
        p_sift=DEFAULT_P_SIFT,
        m_fraction_grid=MAIN_M_FRACTION_GRID,
        pe_method="hypergeom",
        leakage_table=ldpc_leakage_table if is_ldpc else cascade_leakage_table,
        exact_hamming=True,
        N_min_start=500,
    )
    main_rows.append(row)

main_Nmin_table = pd.DataFrame(main_rows)
main_Nmin_table["q_tol_percent"] = 100.0 * main_Nmin_table["q_tol"]
main_columns = [
    "q_tol", "q_tol_percent", "leakage_model", "N_min", "s", "m", "n", "m_fraction",
    "t_ph_upper", "q_ph_upper", "entropy_used", "L_max", "t_ver", "pa_penalty",
    "ell", "leakage_lookup_policy", "leakage_nearest_n", "leakage_nearest_qber",
    "leakage_extrapolated", "pe_fallback_used",
]
main_Nmin_table[main_columns].to_csv(tables_dir / "main_Nmin_table.csv", index=False)
pd.DataFrame(SEARCH_TRACE_ROWS).to_csv(results_dir / "Nmin_search_traces.csv", index=False)
display(main_Nmin_table[main_columns])
''')

md(r"""
This is the central numerical result.  It gives the minimum transmitted-signal budget needed for a 256-bit key under the exact Hamming-ball theorem expression.  Differences between rows are driven mainly by $L_{\max}$, the finite-size phase-error upper bound, and the loss of raw key positions to parameter estimation.
""")

md("## Local verification of reported N_min values")

md(r"""
The binary search used above assumes that key success is effectively monotone in $N$. Empirical leakage caps and integer parameter-estimation sizes can create small non-monotone jumps. This verification scans every integer in $[N_{\min}-500,N_{\min}+500]$ while re-optimizing the same $m/s$ grid. If it finds an earlier passing value, that value replaces the binary-search candidate and the lower scan edge is extended until the corrected reported value itself has a complete 500-point lower-side certificate.
""")

code(r'''
LOCAL_VERIFY_RADIUS = 500
local_verification_rows = []
local_scan_detail_rows = []
local_scan_checkpoint_path = results_dir / "Nmin_local_scan_details_binary_candidates.csv"
if local_scan_checkpoint_path.exists():
    local_scan_checkpoint = pd.read_csv(local_scan_checkpoint_path)
else:
    local_scan_checkpoint = pd.DataFrame()

for main_index, main_row in main_Nmin_table.iterrows():
    q_tol = float(main_row["q_tol"])
    ec_model = str(main_row["leakage_model"])
    binary_search_N = int(main_row["N_min"])
    scan_results = {}

    def evaluate_interval(start, stop):
        for N in range(max(1, int(start)), int(stop) + 1):
            if N in scan_results:
                continue
            best, _ = optimize_m_fraction_for_N(
                N,
                q_tol,
                m_fraction_grid=MAIN_M_FRACTION_GRID,
                ec_model=ec_model,
                eps_total=DEFAULT_EPS_TOTAL,
                p_sift=DEFAULT_P_SIFT,
                pe_method="hypergeom",
                leakage_table=cascade_leakage_table,
                exact_hamming=True,
            )
            scan_results[N] = dict(best)

    if not local_scan_checkpoint.empty:
        checkpoint_rows = local_scan_checkpoint[
            np.isclose(local_scan_checkpoint["q_tol"].astype(float), q_tol)
            & (local_scan_checkpoint["leakage_model"].astype(str) == ec_model)
            & (local_scan_checkpoint["reported_N_min"].astype(int) == binary_search_N)
        ].copy()
        expected_N = set(range(max(1, binary_search_N - LOCAL_VERIFY_RADIUS), binary_search_N + LOCAL_VERIFY_RADIUS + 1))
        if expected_N.issubset(set(checkpoint_rows["N"].astype(int))):
            for _, checkpoint_row in checkpoint_rows.iterrows():
                N = int(checkpoint_row["N"])
                scan_results[N] = {
                    "N": N,
                    "ell": int(checkpoint_row["ell"]),
                    "key_success": bool(checkpoint_row["key_success"]),
                    "m_fraction": float(checkpoint_row["m_fraction"]),
                    "L_max": int(checkpoint_row["L_max"]),
                    "q_ph_upper": float(checkpoint_row["q_ph_upper"]),
                    "leakage_lookup_policy": checkpoint_row.get("leakage_lookup_policy", "unknown"),
                }

    evaluate_interval(binary_search_N - LOCAL_VERIFY_RADIUS, binary_search_N + LOCAL_VERIFY_RADIUS)
    verified_N = min(N for N, row in scan_results.items() if bool(row["key_success"]))

    # If refinement moved the candidate downward, extend the scan so the final
    # reported value still has a complete 500-point lower-side certificate.
    while min(scan_results) > max(1, verified_N - LOCAL_VERIFY_RADIUS):
        evaluate_interval(verified_N - LOCAL_VERIFY_RADIUS, min(scan_results) - 1)
        verified_N = min(N for N, row in scan_results.items() if bool(row["key_success"]))
    evaluate_interval(verified_N, verified_N + LOCAL_VERIFY_RADIUS)

    final_start = max(1, verified_N - LOCAL_VERIFY_RADIUS)
    final_stop = verified_N + LOCAL_VERIFY_RADIUS
    final_rows = {N: scan_results[N] for N in range(final_start, final_stop + 1)}
    smaller_passing = [N for N, row in final_rows.items() if N < verified_N and bool(row["key_success"])]
    best_below_N = max(range(final_start, verified_N), key=lambda N: final_rows[N]["ell"], default=None)
    verified_best = final_rows[verified_N]

    for column in main_Nmin_table.columns:
        if column in verified_best:
            main_Nmin_table.at[main_index, column] = verified_best[column]
    main_Nmin_table.at[main_index, "N_min"] = verified_N
    main_Nmin_table.at[main_index, "binary_search_N_min"] = binary_search_N

    for N, best in final_rows.items():
        local_scan_detail_rows.append({
            "q_tol": q_tol,
            "leakage_model": ec_model,
            "binary_search_N_min": binary_search_N,
            "reported_N_min": verified_N,
            "N": int(N),
            "ell": int(best["ell"]),
            "key_success": bool(best["key_success"]),
            "m_fraction": float(best["m_fraction"]),
            "L_max": int(best["L_max"]),
            "q_ph_upper": float(best["q_ph_upper"]),
            "leakage_lookup_policy": best.get("leakage_lookup_policy", "unknown"),
            "is_below_reported_N": bool(N < verified_N),
        })

    local_verification_rows.append({
        "q_tol": q_tol,
        "leakage_model": ec_model,
        "binary_search_N_min": binary_search_N,
        "reported_N_min": verified_N,
        "binary_search_correction": verified_N - binary_search_N,
        "scan_start": final_start,
        "scan_stop": final_stop,
        "first_passing_N_in_window": min(N for N, row in final_rows.items() if bool(row["key_success"])),
        "best_ell_below_reported": np.nan if best_below_N is None else int(final_rows[best_below_N]["ell"]),
        "best_N_below_reported": np.nan if best_below_N is None else int(best_below_N),
        "reported_N_passes": bool(verified_best["key_success"]),
        "smaller_passing_count": len(smaller_passing),
        "smallest_smaller_passing_N": min(smaller_passing) if smaller_passing else np.nan,
        "locally_verified_minimal": len(smaller_passing) == 0 and bool(verified_best["key_success"]),
    })

Nmin_local_verification = pd.DataFrame(local_verification_rows)
Nmin_local_scan_details = pd.DataFrame(local_scan_detail_rows)
main_Nmin_table = main_Nmin_table.sort_values(["q_tol", "leakage_model"]).reset_index(drop=True)
main_Nmin_table.to_csv(tables_dir / "main_Nmin_table.csv", index=False)
Nmin_local_verification.to_csv(tables_dir / "Nmin_local_verification.csv", index=False)
Nmin_local_scan_details.to_csv(results_dir / "Nmin_local_scan_details.csv", index=False)
display(Nmin_local_verification)
if not Nmin_local_verification["locally_verified_minimal"].all():
    warnings.warn("At least one reported N_min has a smaller passing N in the local verification window.")
else:
    print("All reported N_min values passed local verification.")
''')

md("## Plot 3 -- Key length vs N")

code(r'''
key_grid_rows = []
q_plot_values = [0.01, 0.03, 0.05]
plot_models = ["ideal_fec_1_1", "cascade_p95", "cascade_p99", "cascade_max"]
for q_tol in q_plot_values:
    max_N = int(main_Nmin_table[np.isclose(main_Nmin_table["q_tol"], q_tol)]["N_min"].max())
    min_N = max(500, int(0.55 * main_Nmin_table[np.isclose(main_Nmin_table["q_tol"], q_tol)]["N_min"].min()))
    N_grid = np.unique(np.linspace(min_N, int(1.25 * max_N), 18).round().astype(int))
    fig, ax = plt.subplots(figsize=(8, 5))
    for model in plot_models:
        ells = []
        for N in N_grid:
            best, _ = optimize_m_fraction_for_N(
                int(N),
                q_tol,
                m_fraction_grid=DIAGNOSTIC_M_FRACTION_GRID,
                ec_model=model,
                eps_total=DEFAULT_EPS_TOTAL,
                p_sift=DEFAULT_P_SIFT,
                pe_method="hypergeom",
                leakage_table=cascade_leakage_table,
                exact_hamming=True,
            )
            best["grid_q_tol"] = q_tol
            key_grid_rows.append(best)
            ells.append(best["ell"])
        ax.plot(N_grid, ells, marker="o", markersize=3, label=model)
    ax.axhline(TARGET_KEY_LENGTH, color="black", linewidth=1.0, linestyle="--", label="256-bit target")
    ax.set_xlabel(r"Transmitted signals $N$")
    ax.set_ylabel(r"Optimized key length $\ell$ (bits)")
    ax.set_title(fr"Key length versus $N$ at $Q_{{\mathrm{{tol}}}}={100*q_tol:.0f}\%$")
    ax.legend(fontsize=8)
    stem = f"03_key_length_vs_N_qber_{int(round(100*q_tol))}pct"
    save_figure(fig, stem)
    plt.show()

key_length_vs_N_grid = pd.DataFrame(key_grid_rows)
key_length_vs_N_grid.to_csv(results_dir / "key_length_vs_N_grid.csv", index=False)
''')

md(r"""
These plots show where each leakage model crosses the 256-bit target.  Higher enforced leakage caps push the crossing to larger $N$.  The plotted key lengths optimize over a coarse diagnostic $m/s$ grid so the curves reflect the same PE tradeoff used in the main result, without hiding the crossing behavior.
""")

md("## Plot 4 -- N_min vs QBER")

code(r'''
fig, ax = plt.subplots(figsize=(8, 5))
for model in ec_models:
    sub = main_Nmin_table[main_Nmin_table["leakage_model"] == model].sort_values("q_tol")
    ax.plot(sub["q_tol"], sub["N_min"], marker="o", label=model)
ax.set_xlabel(r"Tolerated QBER $Q_{\mathrm{tol}}$")
ax.set_ylabel(r"Minimum transmitted signals $N_{\min}$")
title_suffix = " -- DEMONSTRATION ONLY" if USING_FALLBACK_DATA else ""
ax.set_title("Minimum signal budget vs tolerated QBER" + title_suffix)
ax.legend()
save_figure(fig, "04_Nmin_vs_QBER")
plt.show()
''')

md(r"""
This figure shows how the tolerated error rate affects the signal budget.  Higher QBER both reduces the entropy term and increases reconciliation leakage.  The Cascade cap curves sit above the ideal leakage curve because the theorem subtracts a larger deterministic transcript cap.
""")

md("## Plot 5 -- Percent increase over ideal leakage")

code(r'''
ideal_rows = main_Nmin_table[main_Nmin_table["leakage_model"] == "ideal_fec_1_1"][["q_tol", "N_min"]].rename(columns={"N_min": "N_min_ideal"})
percent_rows = []
for _, row in main_Nmin_table.iterrows():
    ideal_N = float(ideal_rows[np.isclose(ideal_rows["q_tol"], row["q_tol"])]["N_min_ideal"].iloc[0])
    inc = 100.0 * (float(row["N_min"]) - ideal_N) / ideal_N
    percent_rows.append({
        "q_tol": float(row["q_tol"]),
        "q_tol_percent": 100.0 * float(row["q_tol"]),
        "ec_model": row["leakage_model"],
        "N_min": row["N_min"],
        "N_min_ideal": ideal_N,
        "percent_increase_over_ideal": inc,
    })
percent_increase = pd.DataFrame(percent_rows)
percent_increase.to_csv(tables_dir / "percent_increase_over_ideal.csv", index=False)

fig, ax = plt.subplots(figsize=(8, 5))
for model in ["cascade_p95", "cascade_p99", "cascade_max"]:
    sub = percent_increase[percent_increase["ec_model"] == model].sort_values("q_tol")
    ax.plot(sub["q_tol"], sub["percent_increase_over_ideal"], marker="o", label=model)
ax.axhline(0.0, color="black", linewidth=0.8)
ax.set_xlabel(r"Tolerated QBER $Q_{\mathrm{tol}}$")
ax.set_ylabel(r"Increase in $N_{\min}$ over ideal (\%)")
ax.set_title("Cost of enforced Cascade leakage caps" + title_suffix)
ax.legend()
save_figure(fig, "05_percent_increase_over_ideal")
plt.show()
display(percent_increase)
''')

md(r"""
This is likely the paper's most important numerical result.  It quantifies the cost in $N_{\min}$, not the cost in leakage bits alone, when idealized EC leakage is replaced by measured Cascade leakage caps enforced as abort thresholds.
""")

md("## LDPC comparison plots (when LDPC data available)")

code(r'''
if USING_LDPC_DATA and ec_models_ldpc:
    # --- Plot A: LDPC leakage efficiency heatmap (r / [n h2(Q)]) ---
    import math as _math
    for beta_proto in ec_models_ldpc:
        sub = ldpc_leakage_table[ldpc_leakage_table["protocol"] == beta_proto].copy()
        if sub.empty or "selected_r" not in sub.columns:
            continue
        # Build pivot: rows=Q, cols=n
        sub = sub.dropna(subset=["selected_r"])
        sub["efficiency"] = sub.apply(
            lambda row: float(row["selected_r"]) / max(
                float(row["n"]) * (-(float(row["qber"]) * _math.log2(max(float(row["qber"]), 1e-15))
                                   + (1 - float(row["qber"])) * _math.log2(max(1 - float(row["qber"]), 1e-15)))),
                1e-6),
            axis=1,
        )
        n_vals = sorted(sub["n"].unique())
        q_vals = sorted(sub["qber"].unique())
        pivot = sub.pivot(index="qber", columns="n", values="efficiency")
        fig, ax = plt.subplots(figsize=(9, 5))
        im = ax.imshow(pivot.values, aspect="auto", origin="lower", cmap="YlOrRd")
        plt.colorbar(im, ax=ax, label=r"$r\,/\,[n\,h_2(Q)]$")
        ax.set_xticks(range(len(n_vals)))
        ax.set_xticklabels([str(int(n)) for n in n_vals], rotation=45, ha="right")
        ax.set_yticks(range(len(q_vals)))
        ax.set_yticklabels([f"{100*q:.1f}%" for q in q_vals])
        ax.set_xlabel("Raw block length n")
        ax.set_ylabel("QBER")
        beta_val = beta_proto.replace("ldpc_beta", "")
        ax.set_title(fr"LDPC leakage efficiency $r/[n\,h_2(Q)]$, $\beta={int(beta_val)}\%$")
        save_figure(fig, f"ldpc_efficiency_heatmap_{beta_proto}")
        plt.show()

    # --- Plot B: N_min comparison: Cascade vs LDPC ---
    fig, ax = plt.subplots(figsize=(9, 5.5))
    plot_models_cmp = ["ideal_fec_1_1", "cascade_p95", "cascade_p99"] + ec_models_ldpc
    linestyles = ["-", "--", ":", "-.", (0, (3, 1, 1, 1))]
    for idx, model in enumerate(plot_models_cmp):
        sub = main_Nmin_table[main_Nmin_table["leakage_model"] == model].sort_values("q_tol")
        if sub.empty:
            continue
        ls = linestyles[idx % len(linestyles)]
        ax.plot(sub["q_tol"], sub["N_min"], marker="o", linestyle=ls, label=model)
    ax.set_xlabel(r"Tolerated QBER $Q_{\mathrm{tol}}$")
    ax.set_ylabel(r"$N_{\min}$")
    ax.set_title(r"$N_{\min}$ comparison: Cascade vs LDPC reconciliation")
    ax.legend(fontsize=8)
    save_figure(fig, "ldpc_nmin_comparison")
    plt.show()

    # --- Plot C: Percent increase, extended with LDPC ---
    fig, ax = plt.subplots(figsize=(9, 5.5))
    models_pct = ["cascade_p95", "cascade_p99"] + ec_models_ldpc
    for model in models_pct:
        sub_pct = percent_increase[percent_increase["ec_model"] == model].sort_values("q_tol")
        if sub_pct.empty:
            continue
        ax.plot(sub_pct["q_tol"], sub_pct["percent_increase_over_ideal"], marker="o", label=model)
    ax.axhline(0.0, color="black", linewidth=0.8)
    ax.set_xlabel(r"Tolerated QBER $Q_{\mathrm{tol}}$")
    ax.set_ylabel(r"Increase in $N_{\min}$ over ideal (\%)")
    ax.set_title("Cost of enforced leakage caps: Cascade and LDPC")
    ax.legend(fontsize=8)
    save_figure(fig, "ldpc_percent_increase_comparison")
    plt.show()

    # --- Plot D: Leakage bit comparison: Cascade p95 vs LDPC r ---
    if "selected_r" in ldpc_leakage_table.columns:
        fig, axes = plt.subplots(1, len(ec_models_ldpc), figsize=(5 * len(ec_models_ldpc), 5), sharey=False)
        if len(ec_models_ldpc) == 1:
            axes = [axes]
        for ax, beta_proto in zip(axes, ec_models_ldpc):
            ldpc_sub = ldpc_leakage_table[ldpc_leakage_table["protocol"] == beta_proto].copy()
            for qber in sorted(ldpc_sub["qber"].unique()):
                ls_sub = ldpc_sub[np.isclose(ldpc_sub["qber"], qber)].sort_values("n")
                ax.plot(ls_sub["n"], ls_sub["selected_r"], marker="o", label=f"LDPC r (Q={100*qber:.0f}%)")
                cas_sub = cascade_leakage_table[np.isclose(cascade_leakage_table["qber"], qber)].sort_values("n")
                if not cas_sub.empty and "p95_leakage" in cas_sub.columns:
                    ax.plot(cas_sub["n"], cas_sub["p95_leakage"], linestyle="--", alpha=0.6, label=f"Cascade p95 (Q={100*qber:.0f}%)")
            ax.set_xscale("log", base=2)
            ax.set_xlabel("n")
            ax.set_ylabel("Leakage bits")
            beta_val = beta_proto.replace("ldpc_beta", "")
            ax.set_title(fr"Leakage: Cascade p95 vs LDPC $r$ ($\beta={int(beta_val)}\%$)")
            ax.legend(fontsize=7)
        save_figure(fig, "ldpc_leakage_vs_cascade")
        plt.show()

    # --- Plot E: Failure rate comparison ---
    if "failure_rate" in ldpc_leakage_table.columns:
        fig, ax = plt.subplots(figsize=(8, 5))
        # Cascade failure rate
        if "failure_rate" in cascade_leakage_table.columns:
            cas_fail = cascade_leakage_table.groupby("qber", as_index=False)["failure_rate"].mean().sort_values("qber")
            ax.plot(cas_fail["qber"], cas_fail["failure_rate"], marker="s", linestyle="--", label="Cascade mean fail rate")
        for beta_proto in ec_models_ldpc:
            ldpc_sub = ldpc_leakage_table[ldpc_leakage_table["protocol"] == beta_proto].copy()
            if ldpc_sub.empty:
                continue
            agg = ldpc_sub.groupby("qber", as_index=False)["failure_rate"].mean().sort_values("qber")
            beta_val = beta_proto.replace("ldpc_beta", "")
            ax.plot(agg["qber"], agg["failure_rate"], marker="o", label=fr"LDPC $\beta={int(beta_val)}\%$ fail rate")
        ax.set_xlabel(r"QBER")
        ax.set_ylabel("Reconciliation failure rate")
        ax.set_title("Reconciliation failure rate: Cascade vs LDPC")
        ax.legend(fontsize=8)
        save_figure(fig, "ldpc_failure_rate_comparison")
        plt.show()

    # Save LDPC N_min sub-table
    ldpc_nmin_table = main_Nmin_table[main_Nmin_table["leakage_model"].str.startswith("ldpc_", na=False)].copy()
    ldpc_nmin_table.to_csv(tables_dir / "ldpc_Nmin_table.csv", index=False)

    # --- LDPC reconciliation statistics table ---
    if "failure_rate" in ldpc_leakage_table.columns:
        ldpc_stats_cols = [c for c in [
            "protocol", "n", "qber", "selected_r", "failure_rate",
            "efficiency_r_over_shannon", "mean_iterations", "p95_iterations", "max_iterations",
        ] if c in ldpc_leakage_table.columns]
        ldpc_stats = ldpc_leakage_table[ldpc_stats_cols].copy()
        ldpc_stats.to_csv(tables_dir / "ldpc_reconciliation_statistics.csv", index=False)
        display(ldpc_stats)

    print("LDPC comparison plots and tables generated.")
else:
    print("LDPC data not available; skipping comparison plots.")
    print("To enable: run  python run_ldpc_simulation.py --mode quick")
''')

md("## Plot 6 -- Bit budget decomposition")

code(r'''
bit_budget_rows = []
for q_tol, model in itertools.product([0.01, 0.03, 0.05], ["ideal_fec_1_1", "cascade_p95", "cascade_p99"]):
    row = main_Nmin_table[(np.isclose(main_Nmin_table["q_tol"], q_tol)) & (main_Nmin_table["leakage_model"] == model)].iloc[0].to_dict()
    bit_budget_rows.append({
        "q_tol": q_tol,
        "ec_model": model,
        "N_min": row["N_min"],
        "entropy_used": row["entropy_used"],
        "L_max": row["L_max"],
        "t_ver": row["t_ver"],
        "pa_penalty": row["pa_penalty"],
        "ell": row["ell"],
    })
bit_budget_table = pd.DataFrame(bit_budget_rows)
bit_budget_table.to_csv(tables_dir / "bit_budget_table.csv", index=False)

for q_tol in [0.01, 0.03, 0.05]:
    sub = bit_budget_table[np.isclose(bit_budget_table["q_tol"], q_tol)].copy()
    labels = sub["ec_model"].tolist()
    x = np.arange(len(labels))
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(x, sub["entropy_used"], label="entropy term", color="#4C78A8")
    ax.bar(x, -sub["L_max"], bottom=sub["entropy_used"], label=r"$-L_{\max}$", color="#F58518")
    after_leak = sub["entropy_used"] - sub["L_max"]
    ax.bar(x, -sub["t_ver"], bottom=after_leak, label="- t_ver", color="#54A24B")
    after_ver = after_leak - sub["t_ver"]
    ax.bar(x, -sub["pa_penalty"], bottom=after_ver, label="- PA penalty", color="#E45756")
    ax.scatter(x, sub["ell"], color="black", zorder=3, label="final ell")
    ax.axhline(TARGET_KEY_LENGTH, color="black", linewidth=0.8, linestyle="--")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, rotation=20, ha="right")
    ax.set_ylabel("Bits")
    ax.set_title(fr"Bit-budget decomposition at $Q_{{\mathrm{{tol}}}}={100*q_tol:.0f}\%$")
    ax.legend(fontsize=8)
    stem = f"06_bit_budget_qber_{int(round(100*q_tol))}pct"
    save_figure(fig, stem)
    plt.show()
display(bit_budget_table)
''')

md(r"""
The bit-budget plots show why a much larger raw entropy term is needed to produce only 256 final bits.  Reconciliation leakage, verification leakage, and privacy-amplification overhead are all theorem terms.  The plot makes the theorem's subtraction structure visible.
""")

md("## Plot 7 -- Optimized parameter-estimation fraction")

code(r'''
optimal_m_fraction_table = main_Nmin_table[[
    "q_tol", "q_tol_percent", "leakage_model", "N_min", "s", "m", "m_fraction"
]].copy()
optimal_m_fraction_table["m_over_s"] = optimal_m_fraction_table["m"] / optimal_m_fraction_table["s"]
optimal_m_fraction_table.to_csv(tables_dir / "optimal_m_fraction_table.csv", index=False)

fig, ax = plt.subplots(figsize=(8, 5))
for model in ec_models:
    sub = optimal_m_fraction_table[optimal_m_fraction_table["leakage_model"] == model].sort_values("q_tol")
    ax.plot(sub["q_tol"], sub["m_over_s"], marker="o", label=model)
ax.set_xlabel(r"Tolerated QBER $Q_{\mathrm{tol}}$")
ax.set_ylabel(r"Optimized parameter-estimation fraction $m/s$")
ax.set_title("Optimized parameter-estimation sample fraction")
ax.legend(fontsize=8)
save_figure(fig, "07_optimal_parameter_estimation_fraction")
plt.show()
''')

md(r"""
Increasing $m$ improves parameter-estimation confidence but leaves fewer unrevealed raw-key bits.  The optimum balances statistical confidence and raw-key size.  This figure justifies optimizing over $m/s$ rather than fixing it arbitrarily for the main tables.
""")

md("## Plot 8 -- Security budget sensitivity")

code(r'''
eps_values = [1e-6, 1e-9, 1e-12, 1e-15]
eps_modes = ["balanced", "pe_heavy", "pa_heavy", "cor_heavy", "smoothing_heavy"]
sensitivity_rows = []
for eps_total, mode in itertools.product(eps_values, eps_modes):
    print(f"Sensitivity search: eps={eps_total:.0e}, mode={mode}")
    row = find_N_min(
        0.03,
        "cascade_p95",
        eps_total=eps_total,
        p_sift=DEFAULT_P_SIFT,
        m_fraction_grid=DIAGNOSTIC_M_FRACTION_GRID,
        eps_mode=mode,
        pe_method="hypergeom",
        leakage_table=cascade_leakage_table,
        exact_hamming=True,
        N_min_start=500,
    )
    row["eps_total"] = eps_total
    row["allocation_mode"] = mode
    sensitivity_rows.append(row)

security_budget_sensitivity = pd.DataFrame(sensitivity_rows)
security_budget_sensitivity.to_csv(tables_dir / "security_budget_sensitivity.csv", index=False)
pd.DataFrame(SEARCH_TRACE_ROWS).to_csv(results_dir / "Nmin_search_traces.csv", index=False)

fig, ax = plt.subplots(figsize=(8, 5))
for mode in eps_modes:
    sub = security_budget_sensitivity[security_budget_sensitivity["allocation_mode"] == mode].sort_values("eps_total")
    ax.plot(sub["eps_total"], sub["N_min"], marker="o", label=mode)
ax.set_xscale("log")
ax.invert_xaxis()
ax.set_xlabel(r"Total security parameter $\varepsilon_{\mathrm{tot}}$")
ax.set_ylabel(r"$N_{\min}$ at $Q_X^{\mathrm{tol}}=Q_Z^{\mathrm{design}}=3\%$, Cascade p95")
ax.set_title("Security-budget sensitivity")
ax.legend(fontsize=8)
save_figure(fig, "08_security_budget_sensitivity")
plt.show()
''')

md(r"""
Smaller security parameters require larger $N$.  Allocation matters because PE, smoothing, correctness, and PA enter different theorem terms.  The balanced split is the default paper convention, not a claim of global optimality.
""")

md("## Plot 9 -- Exact Hamming-ball vs binary-entropy N_min")

code(r'''
exact_binary_rows = []
selected_entropy_models = ["ideal_fec_1_1", "cascade_p95"]
for q_tol, model in itertools.product(DEFAULT_QTOL_GRID, selected_entropy_models):
    exact_row = main_Nmin_table[(np.isclose(main_Nmin_table["q_tol"], q_tol)) & (main_Nmin_table["leakage_model"] == model)].iloc[0].to_dict()
    exact_row = dict(exact_row)
    exact_row["entropy_mode"] = "exact_hamming"
    exact_binary_rows.append(exact_row)
    print(f"Binary entropy comparison search: q_tol={q_tol:.3f}, model={model}")
    binary_row = find_N_min(
        q_tol,
        model,
        eps_total=DEFAULT_EPS_TOTAL,
        p_sift=DEFAULT_P_SIFT,
        m_fraction_grid=DIAGNOSTIC_M_FRACTION_GRID,
        pe_method="hypergeom",
        leakage_table=cascade_leakage_table,
        exact_hamming=False,
        N_min_start=500,
    )
    binary_row["entropy_mode"] = "binary_entropy_bound"
    exact_binary_rows.append(binary_row)

exact_vs_binary_entropy_Nmin = pd.DataFrame(exact_binary_rows)
exact_vs_binary_entropy_Nmin.to_csv(tables_dir / "exact_vs_binary_entropy_Nmin.csv", index=False)
pd.DataFrame(SEARCH_TRACE_ROWS).to_csv(results_dir / "Nmin_search_traces.csv", index=False)

fig, ax = plt.subplots(figsize=(8, 5))
for model in selected_entropy_models:
    for entropy_mode, linestyle in [("exact_hamming", "-"), ("binary_entropy_bound", "--")]:
        sub = exact_vs_binary_entropy_Nmin[
            (exact_vs_binary_entropy_Nmin["leakage_model"] == model)
            & (exact_vs_binary_entropy_Nmin["entropy_mode"] == entropy_mode)
        ].sort_values("q_tol")
        ax.plot(sub["q_tol"], sub["N_min"], marker="o", linestyle=linestyle, label=f"{model}, {entropy_mode}")
ax.set_xlabel(r"Symmetric planning error rate $Q$")
ax.set_ylabel(r"Minimum transmitted signals $N_{\min}$")
ax.set_title(r"Exact Hamming-ball versus binary-entropy $N_{\min}$")
ax.legend(fontsize=8)
save_figure(fig, "09_exact_vs_binary_entropy_Nmin")
plt.show()
''')

md(r"""
This comparison shows whether the finite Hamming-ball expression materially changes $N_{\min}$.  The exact Hamming-ball result is the main result because it matches the cleaned proof.  The binary-entropy version is a conservative simplified corollary.
""")

md("## Plot 10 -- Leakage cap visualization")

code(r'''
raw_candidates = [
    "results_03_reconciliation/tables/reconciliation_trials.csv",
    "results_03_reconciliation/tables/trial_data.csv",
    "/mnt/data/results_03_reconciliation/tables/reconciliation_trials.csv",
    "/mnt/data/results_03_reconciliation/tables/trial_data.csv",
]
raw_trials, raw_trials_path, raw_paths_checked = load_first_existing(raw_candidates)
if raw_trials is not None and "protocol" in raw_trials.columns:
    raw_cascade = raw_trials[raw_trials["protocol"].astype(str).str.contains("cascade", na=False)].copy()
else:
    raw_cascade = pd.DataFrame()

if not raw_cascade.empty and "leakage_bits" in raw_cascade.columns:
    q_rep = 0.03
    n_rep = int(cascade_leakage_table.iloc[(cascade_leakage_table["n"] - 2048).abs().idxmin()]["n"])
    q_values_available = np.array(sorted(raw_cascade["qber"].dropna().unique()), dtype=float)
    q_rep = float(q_values_available[np.argmin(np.abs(q_values_available - q_rep))])
    group = raw_cascade[(raw_cascade["n"] == n_rep) & (np.isclose(raw_cascade["qber"], q_rep))].copy()
    if group.empty:
        group = raw_cascade.copy()
    stats = {
        "mean": float(group["leakage_bits"].mean()),
        "p95": float(group["leakage_bits"].quantile(0.95)),
        "p99": float(group["leakage_bits"].quantile(0.99)),
        "max": float(group["leakage_bits"].max()),
    }
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(group["leakage_bits"], bins=24, alpha=0.75, color="#4C78A8", edgecolor="white")
    for name, value in stats.items():
        ax.axvline(value, linewidth=1.5, label=f"{name}={value:.1f}")
    ax.set_xlabel(r"Cascade parity leakage $L$ (bits)")
    ax.set_ylabel("Number of simulated runs")
    ax.set_title(f"Cascade leakage distribution, n={int(group['n'].iloc[0])}, QBER={float(group['qber'].iloc[0]):.3f}")
    ax.legend()
else:
    summary = cascade_leakage_table.sort_values(["qber", "n"]).copy()
    fig, ax = plt.subplots(figsize=(8, 5))
    for qber in sorted(summary["qber"].unique())[:5]:
        sub = summary[np.isclose(summary["qber"], qber)]
        ax.plot(sub["n"], sub["mean_leakage"], marker="o", label=f"mean Q={qber:.3f}")
        if "p95_leakage" in sub.columns:
            ax.plot(sub["n"], sub["p95_leakage"], linestyle="--", alpha=0.7, label=f"p95 Q={qber:.3f}")
    ax.set_xlabel(r"Raw reconciliation block $n$")
    ax.set_ylabel(r"Leakage cap $L_{\max}$ (bits)")
    title = "Cascade leakage summary statistics"
    if USING_FALLBACK_DATA:
        title += " -- DEMONSTRATION ONLY"
    ax.set_title(title)
    ax.legend(fontsize=7)

save_figure(fig, "10_leakage_caps_visualization")
plt.show()
print("Raw trials path:", raw_trials_path)
''')

md(r"""
Security uses the cap, not the average.  The cap becomes part of the protocol: if the public reconciliation transcript exceeds the chosen $L_{\max}$, the run aborts.  The leakage distribution or summary statistics explain the operational abort probability induced by that choice.
""")

md("## Plot 11 -- Operational abort probability from leakage cap")

code(r'''
if not raw_cascade.empty and "leakage_bits" in raw_cascade.columns:
    cap_abort_rows = []
    for (n, qber), group in raw_cascade.groupby(["n", "qber"]):
        for statistic, quantile in [("p95", 0.95), ("p99", 0.99), ("max", 1.0)]:
            cap = float(group["leakage_bits"].quantile(quantile)) if statistic != "max" else float(group["leakage_bits"].max())
            cap_abort_rows.append({
                "n": int(n),
                "qber": float(qber),
                "cap_statistic": statistic,
                "L_max_empirical": cap,
                "cap_abort_probability": float((group["leakage_bits"] > cap).mean()),
                "trials": int(len(group)),
            })
    cap_abort_probability_table = pd.DataFrame(cap_abort_rows)
else:
    cap_abort_probability_table = pd.DataFrame([{
        "status": "raw_trial_data_not_available",
        "needed_file": "results_03_reconciliation/tables/reconciliation_trials.csv",
    }])

cap_abort_probability_table.to_csv(tables_dir / "cap_abort_probability_table.csv", index=False)

fig, ax = plt.subplots(figsize=(8, 5))
if "cap_abort_probability" in cap_abort_probability_table.columns:
    for statistic in ["p95", "p99", "max"]:
        sub = cap_abort_probability_table[cap_abort_probability_table["cap_statistic"] == statistic]
        mean_by_q = sub.groupby("qber", as_index=False)["cap_abort_probability"].mean().sort_values("qber")
        ax.plot(mean_by_q["qber"], mean_by_q["cap_abort_probability"], marker="o", label=statistic)
    ax.set_xlabel("QBER")
    ax.set_ylabel(r"Empirical $\Pr[L>L_{\max}]$")
    ax.set_title("Operational cap-abort probability from Cascade trials")
    ax.legend()
else:
    ax.text(0.05, 0.55, "Raw trial data needed to estimate cap-abort probability.", transform=ax.transAxes)
    ax.set_axis_off()
save_figure(fig, "11_cap_abort_probability")
plt.show()
display(cap_abort_probability_table.head())
''')

md(r"""
Cap-abort is not a secrecy failure.  It is an operational success-rate cost.  This is why the notebook separates theorem security accounting from practical acceptance probability.

The p99 cap estimates should be treated cautiously when they come from only a few hundred trials.  They are useful for draft-level analysis, but publication-level p99 operational claims should be rerun with more reconciliation trials and confidence intervals.
""")

md("## Hamming baseline: why leakage-only comparisons can mislead")

code(r'''
if "protocol" in leakage_table.columns and leakage_table["protocol"].astype(str).str.contains("hamming", na=False).any():
    hamming_rows = leakage_table[leakage_table["protocol"].astype(str).str.contains("hamming", na=False)].copy()
    cascade_rows = cascade_leakage_table.copy()
    compare_rows = []
    for _, hrow in hamming_rows.iterrows():
        qber = float(hrow["qber"])
        n = int(hrow["n"])
        candidates = cascade_rows.copy()
        distance = np.abs(np.log(np.maximum(candidates["n"].to_numpy(dtype=float), 1.0) / max(float(n), 1.0)))
        distance += 30.0 * np.abs(candidates["qber"].to_numpy(dtype=float) - qber)
        crow = candidates.iloc[int(np.argmin(distance))]
        compare_rows.append({
            "n": n,
            "qber": qber,
            "hamming_protocol": hrow["protocol"],
            "hamming_mean_leakage": hrow.get("mean_leakage", np.nan),
            "hamming_failure_rate": hrow.get("failure_rate", np.nan),
            "cascade_mean_leakage": crow.get("mean_leakage", np.nan),
            "cascade_failure_rate": crow.get("failure_rate", np.nan),
        })
    hamming_cautionary_baseline = pd.DataFrame(compare_rows)
else:
    hamming_cautionary_baseline = pd.DataFrame([{"status": "hamming_data_not_available"}])

hamming_cautionary_baseline.to_csv(tables_dir / "hamming_cautionary_baseline.csv", index=False)

fig, ax = plt.subplots(figsize=(8, 5))
if "hamming_failure_rate" in hamming_cautionary_baseline.columns:
    agg = hamming_cautionary_baseline.groupby("qber", as_index=False)[["hamming_failure_rate", "cascade_failure_rate"]].mean().sort_values("qber")
    ax.plot(agg["qber"], agg["hamming_failure_rate"], marker="o", label="Hamming failure rate")
    ax.plot(agg["qber"], agg["cascade_failure_rate"], marker="s", label="Cascade failure rate")
    ax.set_xlabel("QBER")
    ax.set_ylabel(r"Mean failure rate across simulated $n$")
    ax.set_title("Hamming baseline caution: leakage alone is not enough")
    ax.legend()
else:
    ax.text(0.05, 0.55, "Hamming data not available; baseline skipped.", transform=ax.transAxes)
    ax.set_axis_off()
save_figure(fig, "12_hamming_cautionary_baseline")
plt.show()
display(hamming_cautionary_baseline.head())
''')

md(r"""
Hamming may leak fewer bits in some regimes but fail more often.  Therefore leakage-only $N_{\min}$ comparisons can be misleading.  Cascade remains the main reconciliation method for this paper-ready analysis.
""")

md("## Paper-ready summary tables")

code(r'''
paper_table_1_theory_terms = pd.DataFrame([
    {"Symbol": "N", "Meaning": "transmitted quantum signals", "How computed": "independent search variable", "Role in theorem": "resource budget minimized by N_min"},
    {"Symbol": "s", "Meaning": "sifted bits", "How computed": "floor(p_sift N)", "Role in theorem": "population before PE"},
    {"Symbol": "m", "Meaning": "parameter-estimation sample size", "How computed": "floor(m_fraction s)", "Role in theorem": "controls PE confidence"},
    {"Symbol": "n", "Meaning": "raw key bits after PE", "How computed": "s - m", "Role in theorem": "input length to entropy bound"},
    {"Symbol": "e_tol", "Meaning": "accepted sample-error threshold", "How computed": "floor(Q_tol m)", "Role in theorem": "accept/abort PE threshold"},
    {"Symbol": "t_ph^U", "Meaning": "phase-error upper count", "How computed": "hypergeometric threshold inversion", "Role in theorem": "sets Hamming-ball entropy loss"},
    {"Symbol": "B(n,t_ph^U)", "Meaning": "finite Hamming ball", "How computed": "sum_{i=0}^t binom(n,i)", "Role in theorem": "exact entropy correction"},
    {"Symbol": "L_max", "Meaning": "deterministic reconciliation leakage cap", "How computed": "ideal formula or empirical Cascade cap", "Role in theorem": "subtracted public leakage"},
    {"Symbol": "t_ver", "Meaning": "verification tag length", "How computed": "ceil(log2(1/eps_cor))", "Role in theorem": "subtracted verification leakage"},
    {"Symbol": "eps_cor", "Meaning": "correctness error", "How computed": "security budget split", "Role in theorem": "bounds accepted mismatch"},
    {"Symbol": "eps_PE", "Meaning": "PE failure", "How computed": "security budget split", "Role in theorem": "bounds PE event failure"},
    {"Symbol": "eps_s", "Meaning": "smoothing parameter", "How computed": "security budget split", "Role in theorem": "smooth min-entropy parameter"},
    {"Symbol": "eps_PA", "Meaning": "privacy amplification failure", "How computed": "security budget split", "Role in theorem": "sets PA penalty"},
    {"Symbol": "ell", "Meaning": "final key length", "How computed": "floor(entropy - L_max - t_ver - PA)", "Role in theorem": "must reach 256 bits"},
    {"Symbol": "N_min", "Meaning": "minimum signal budget", "How computed": "binary search over N", "Role in theorem": "main paper metric"},
])
paper_table_1_theory_terms.to_csv(tables_dir / "paper_table_1_theory_terms.csv", index=False)

paper_table_2_main_Nmin = main_Nmin_table[main_columns].copy()
paper_table_2_main_Nmin.to_csv(tables_dir / "paper_table_2_main_Nmin.csv", index=False)

paper_table_3_percent_increase = percent_increase.copy()
paper_table_3_percent_increase.to_csv(tables_dir / "paper_table_3_percent_increase.csv", index=False)

paper_table_4_bit_budget = bit_budget_table.copy()
paper_table_4_bit_budget.to_csv(tables_dir / "paper_table_4_bit_budget.csv", index=False)

paper_table_5_sensitivity = security_budget_sensitivity.copy()
paper_table_5_sensitivity.to_csv(tables_dir / "paper_table_5_sensitivity.csv", index=False)

print("Paper Table 1: theory terms")
display(paper_table_1_theory_terms)
print("Paper Table 2: main N_min")
display(paper_table_2_main_Nmin)
print("Paper Table 3: percent increase")
display(paper_table_3_percent_increase)
print("Paper Table 4: bit budget")
display(paper_table_4_bit_budget)
print("Paper Table 5: security sensitivity")
display(paper_table_5_sensitivity[["eps_total", "allocation_mode", "N_min", "ell", "m_fraction"]])
''')

md(r"""
## Final interpretation for the paper

The theorem-level key-length expression used in this notebook is

$$
\ell
=
\left\lfloor
n-\log_2 B(n,t_{\mathrm{ph}}^U)
-L_{\max}
-t_{\mathrm{ver}}
-2\log_2(1/\varepsilon_{\mathrm{PA}})
\right\rfloor.
$$

The exact Hamming-ball entropy term is used because it is the finite-size term in the cleaned proof.  The phase-error upper count $t_{\mathrm{ph}}^U$ is computed from an accept/abort parameter-estimation threshold, so the key-length formula is valid for every accepted test-sample error count.  The reconciliation term $L_{\max}$ must be a deterministic cap: empirical data helps choose it, but the protocol must abort if the transcript exceeds it.  The empirical cap lookup is conservative on the available simulation grid when possible, choosing larger-or-equal simulated block sizes and QBER values rather than optimistic nearest neighbors.

$N_{\min}$ measures the minimum transmitted-signal budget needed to obtain a 256-bit output under this idealized single-photon BB84 theorem wrapper.  The reported values are locally verified by scanning $N_{\min}\pm500$ and checking that no smaller $N$ in that window reaches the target under the same optimization grid.  The main result is that replacing idealized error-correction leakage by enforced Cascade leakage caps increases the minimum signal budget required for a 256-bit finite-key output.  The size of the increase depends on the tolerated QBER and the selected cap level.

The figures most likely to be used in the paper are the main $N_{\min}$ vs QBER plot, the percent-increase plot, the bit-budget decomposition, and the leakage-cap visualization.  The PE and exact-vs-binary plots are useful for methods and appendix discussion.

This notebook still does not prove implementation security.  It assumes the idealized protocol model from the cleaned proof: ideal single-photon BB84, trusted devices, authenticated public communication, and no side channels.
""")

code(r'''
if USING_FALLBACK_DATA:
    print("No publication-level empirical claim can be made because real reconciliation data was not loaded.")
else:
    print("Real reconciliation CSV data was loaded; empirical cap-based claims may be made subject to the limitations stated in the notebook.")
''')

md("## Reproducibility summary")

code(r'''
all_output_files = []
for directory in [results_dir, tables_dir, figures_dir]:
    for path in sorted(directory.glob("*")):
        if path.is_file():
            all_output_files.append(path.as_posix())

reproducibility_summary = {
    "timestamp": time.strftime("%Y-%m-%d %H:%M:%S %Z"),
    "using_fallback_data": bool(USING_FALLBACK_DATA),
    "theory_path": str(THEORY_PATH) if THEORY_PATH is not None else None,
    "leakage_path": leakage_path,
    "raw_trials_path": raw_trials_path,
    "paths_checked": {
        "leakage": leakage_paths_checked,
        "raw_trials": raw_paths_checked,
        "previous_theorem_outputs": previous_theorem_paths_loaded,
    },
    "number_of_empirical_rows_loaded": int(len(cascade_leakage_table)),
    "q_tol_grid": DEFAULT_QTOL_GRID,
    "ec_models_used": ec_models,
    "eps_total": DEFAULT_EPS_TOTAL,
    "p_sift": DEFAULT_P_SIFT,
    "target_key_length": TARGET_KEY_LENGTH,
    "exact_hamming_main_result": True,
    "empirical_leakage_lookup_policy": "conservative_larger_or_equal_grid_when_available",
    "local_Nmin_verification_radius": LOCAL_VERIFY_RADIUS,
    "local_Nmin_verification_all_passed": bool(Nmin_local_verification["locally_verified_minimal"].all()),
    "all_output_files_created": all_output_files,
    "total_runtime_seconds": round(time.time() - START_TIME, 2),
}
(results_dir / "reproducibility_summary.json").write_text(json.dumps(reproducibility_summary, indent=2), encoding="utf-8")

print("Final checklist:")
print(" - Theory sanity checks passed:", bool(sanity_checks["passed"].all()))
print(" - PE diagnostics generated:", (results_dir / "parameter_estimation_diagnostics.csv").exists())
print(" - Main N_min table generated:", (tables_dir / "main_Nmin_table.csv").exists())
print(" - Local N_min verification passed:", bool(Nmin_local_verification["locally_verified_minimal"].all()))
print(" - Percent increase table generated:", (tables_dir / "percent_increase_over_ideal.csv").exists())
print(" - Bit budget table generated:", (tables_dir / "bit_budget_table.csv").exists())
print(" - Figures saved:", len(list(figures_dir.glob("*.png"))), "PNG and", len(list(figures_dir.glob("*.pdf"))), "PDF")
print(" - Fallback data status:", USING_FALLBACK_DATA)
print("Notebook 05 completed successfully.")
''')


notebook = {
    "cells": cells,
    "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {
            "name": "python",
            "version": sys.version.split()[0],
            "mimetype": "text/x-python",
            "codemirror_mode": {"name": "ipython", "version": 3},
            "pygments_lexer": "ipython3",
            "nbconvert_exporter": "python",
            "file_extension": ".py",
        },
    },
    "nbformat": 4,
    "nbformat_minor": 5,
}


path = Path("05_publication_ready_analysis.ipynb")
path.write_text(json.dumps(notebook, indent=1), encoding="utf-8")
print(f"wrote {path.resolve()} with {len(cells)} cells")
