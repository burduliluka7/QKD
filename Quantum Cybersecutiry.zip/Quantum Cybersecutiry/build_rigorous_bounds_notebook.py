import json
import sys
from pathlib import Path
from textwrap import dedent


cells = []


def add_cell(kind, text):
    source = dedent(text).strip() + "\n"
    cell = {
        "cell_type": kind,
        "id": f"cell-{len(cells) + 1:03d}",
        "metadata": {},
        "source": source.splitlines(True),
    }
    if kind == "code":
        cell.update({"execution_count": None, "outputs": []})
    cells.append(cell)


def md(text):
    add_cell("markdown", text)


def code(text):
    add_cell("code", text)


md(r"""
# Rigorous Parameter-Estimation Bounds and Short-Block Error-Correction Leakage for 256-bit Finite-Key QKD

The previous notebook explored many possible directions for short-key finite-key QKD. This follow-up focuses on the most publishable numerical question:

$$
N_{\min}(Q,\varepsilon_{\mathrm{total}})
=
\min\{N:\ell(N,Q,\varepsilon_{\mathrm{total}})\ge 256\}.
$$

The notebook studies how the required minimum number of transmitted quantum signals changes under:

- statistically valid parameter-estimation bounds,
- short-block error-correction leakage assumptions,
- fixed 256-bit final-key target.

The focus is deliberately narrow: no machine learning, no Bayesian optimization, no broad sensitivity sweeps, and no Pareto plots. The aim is to make the parameter-estimation and error-correction assumptions explicit enough that they can later be replaced by theorem-level terms from a specific finite-key security proof.

**Scientific caution.** This notebook is still a simplified protocol-level planning model. It is not a complete composable security proof and not a hardware implementation-security proof. The purpose is to compare finite-key post-processing assumptions before replacing the toy formula with a theorem-level expression from a specific QKD paper.
""")

md(r"""
## Main Planning Formula

We use the simplified finite-key planning formula

$$
\ell_{\mathrm{toy}}
=
n[1-h_2(Q_{\mathrm{upper}})]
-
\mathrm{leak}_{\mathrm{EC}}(n,Q)
-
t_{\mathrm{ver}}
-
2\log_2(1/\varepsilon_{\mathrm{PA}}).
$$

Definitions:

- $N$: transmitted quantum signals.
- $p_{\mathrm{sift}}$: effective sifting fraction.
- $s=\lfloor p_{\mathrm{sift}}N\rfloor$: sifted bits.
- $m$: parameter-estimation sample size.
- $n=s-m$: bits kept for key generation.
- $\hat Q$: observed QBER in the parameter-estimation sample.
- $Q_{\mathrm{upper}}$: conservative upper confidence bound on the error rate.
- $h_2$: binary entropy.
- $\mathrm{leak}_{\mathrm{EC}}$: public error-correction leakage.
- $t_{\mathrm{ver}}=\lceil \log_2(1/\varepsilon_{\mathrm{cor}})\rceil$: verification tag cost.
- $2\log_2(1/\varepsilon_{\mathrm{PA}})$: privacy-amplification overhead.
- target: $\ell_{\mathrm{toy}}\ge256$.

The main output is

$$
N_{\min}
=
\min\{N:\max_m \ell_{\mathrm{toy}}(N,m,Q,\varepsilon)\ge256\}.
$$
""")

md("## Imports and Setup")

code(r'''
import itertools
import math
import sys
import warnings
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy.stats import beta, hypergeom
import matplotlib
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore", category=RuntimeWarning)

results_dir = Path("results_02_rigorous")
fig_dir = results_dir / "figures"
res_dir = results_dir / "tables"
fig_dir.mkdir(parents=True, exist_ok=True)
res_dir.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    "figure.figsize": (8.5, 5.2),
    "axes.grid": True,
    "grid.alpha": 0.25,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "font.size": 11,
})

TARGET_KEY_LENGTH = 256.0
DEFAULT_EPS_TOTAL = 1e-9
DEFAULT_P_SIFT = 0.5
DEFAULT_F_EC = 1.1
PE_METHODS = ["hoeffding", "serfling", "clopper_pearson", "hypergeom_exact"]
BASE_EC_MODELS = [
    "ideal",
    "rounded_syndrome",
    "fixed_overhead_64",
    "short_block_penalty",
    "pessimistic_short_block",
]
HYPERGEOM_EXACT_MAX_S = 200_000
OPTIMIZER_M_GRID = 180


def save_figure(filename):
    """Save the active matplotlib figure into the rigorous-figures folder."""
    path = fig_dir / filename
    plt.tight_layout()
    plt.savefig(path, dpi=180, bbox_inches="tight")
    return path


print(f"Figures directory: {fig_dir.resolve()}")
print(f"Results directory: {res_dir.resolve()}")
''')

md("## Utility Functions")

code(r'''
def clamp01(x):
    """Clamp a scalar or array to the interval [0, 1]."""
    arr = np.clip(np.asarray(x, dtype=float), 0.0, 1.0)
    if np.isscalar(x):
        return float(arr)
    return arr


def binary_entropy(q):
    """Return the binary entropy h2(q) for scalars or numpy arrays.

    Probabilities are clipped only internally for numerical logarithms.
    Exact boundary inputs q=0 and q=1 return zero entropy.
    """
    arr = np.asarray(q, dtype=float)
    safe = np.clip(arr, 1e-15, 1.0 - 1e-15)
    h = -(safe * np.log2(safe) + (1.0 - safe) * np.log2(1.0 - safe))
    h = np.where((arr <= 0.0) | (arr >= 1.0), 0.0, h)
    if np.isscalar(q):
        return float(h)
    return h


def verification_tag_length(eps_cor):
    """Return the verification tag length ceil(log2(1 / eps_cor))."""
    if not (0.0 < eps_cor < 1.0):
        raise ValueError("eps_cor must lie in (0, 1).")
    return int(np.ceil(np.log2(1.0 / eps_cor)))


def privacy_amplification_penalty(eps_pa):
    """Return the toy privacy-amplification penalty 2 log2(1 / eps_pa)."""
    if not (0.0 < eps_pa < 1.0):
        raise ValueError("eps_pa must lie in (0, 1).")
    return float(2.0 * np.log2(1.0 / eps_pa))


def split_epsilons(eps_total, mode="fixed"):
    """Return eps_pe, eps_pa, eps_cor for the toy formula.

    For this notebook only three epsilons enter the displayed planning formula.
    Smoothing is intentionally omitted because otherwise the optimizer would
    allocate budget to a parameter that does not affect the key length.
    A theorem-level version should reintroduce smoothing exactly as required by
    the selected finite-key proof.
    """
    if not (0.0 < eps_total < 1.0):
        raise ValueError("eps_total must lie in (0, 1).")
    if mode != "fixed":
        raise ValueError("Only mode='fixed' is used in this focused notebook.")
    return eps_total / 3.0, eps_total / 3.0, eps_total / 3.0
''')

md(r"""
### Epsilon Convention

Smoothing is intentionally omitted from this toy formula because otherwise we would be optimizing an epsilon that does not affect the displayed key length. A theorem-level version should reintroduce smoothing according to a specific finite-key proof and then allocate the full composable security budget across all theorem terms.
""")

md(r"""
## Parameter-Estimation Bounds

Parameter estimation converts an observed sample error rate $\hat Q$ into a conservative upper bound $Q_{\mathrm{upper}}$. This notebook compares Hoeffding, Serfling, Clopper-Pearson exact binomial, and an exact hypergeometric inversion where computationally feasible.
""")

md("### Hoeffding")

code(r'''
def q_upper_hoeffding(q_hat, m, eps_pe):
    """Hoeffding one-sided upper confidence bound for an error rate."""
    if m <= 0:
        return 0.5
    q_hat = min(0.5, max(0.0, float(q_hat)))
    delta = math.sqrt(math.log(1.0 / eps_pe) / (2.0 * m))
    return float(min(0.5, q_hat + delta))
''')

md("### Serfling")

code(r'''
def q_upper_serfling(q_hat, m, s, eps_pe):
    """Simplified Serfling-style bound for sampling without replacement.

    Here s is the total sifted block size before parameter estimation and m is
    the number of revealed PE bits. Constants and exact forms differ in the
    literature, so this is a comparison model, not a theorem claim.
    """
    if m <= 0 or s <= 0 or m >= s:
        return 0.5
    q_hat = min(0.5, max(0.0, float(q_hat)))
    delta = math.sqrt(((s - m + 1.0) * math.log(1.0 / eps_pe)) / (2.0 * m * s))
    return float(min(0.5, q_hat + delta))
''')

md("### Clopper-Pearson Exact Binomial Upper Bound")

code(r'''
def q_upper_clopper_pearson(k_errors, m, eps_pe):
    """One-sided exact binomial confidence upper bound.

    k_errors is the integer number of observed errors in m revealed PE bits.
    The result is clipped to 0.5 for the BB84-style entropy model used here.
    """
    if m <= 0:
        return 0.5
    k_errors = int(np.clip(k_errors, 0, m))
    if k_errors >= m:
        return 0.5
    q_upper = beta.ppf(1.0 - eps_pe, k_errors + 1, m - k_errors)
    if not np.isfinite(q_upper):
        q_upper = 0.5
    return float(np.clip(q_upper, 0.0, 0.5))
''')

md("### Exact Hypergeometric Bound")

code(r'''
@lru_cache(maxsize=200_000)
def _q_upper_hypergeom_exact_cached(k_errors, m, s, eps_pe):
    """Cached hypergeometric inversion helper for the unrevealed key block."""
    k_errors = int(k_errors)
    m = int(m)
    s = int(s)
    eps_pe = float(eps_pe)

    if m <= 0 or s <= 0 or m >= s:
        return 0.5
    if s > HYPERGEOM_EXACT_MAX_S:
        q_hat = k_errors / m
        return q_upper_serfling(q_hat, m, s, eps_pe)

    low = max(0, k_errors)
    high = s
    best = low

    while low <= high:
        mid = (low + high) // 2
        cdf = float(hypergeom.cdf(k_errors, s, mid, m))
        if not np.isfinite(cdf):
            q_hat = k_errors / m
            return q_upper_serfling(q_hat, m, s, eps_pe)
        if cdf >= eps_pe:
            best = mid
            low = mid + 1
        else:
            high = mid - 1

    remaining_errors_upper = max(0, best - k_errors)
    remaining_size = s - m
    q_key_upper = remaining_errors_upper / remaining_size

    return float(np.clip(q_key_upper, 0.0, 0.5))


def q_upper_hypergeom_exact(k_errors, m, s, eps_pe):
    """Exact conservative upper bound using hypergeometric inversion.

    We search over possible total error counts K in {k_errors, ..., s}. For a
    candidate K, hypergeom.cdf(k_errors, s, K, m) is the probability that a
    sample of size m from a population of size s with K errors would produce
    <= k_errors observed errors. The largest K still compatible at failure
    probability eps_pe defines an upper bound on the error rate of the
    unrevealed key block, not merely the total sifted block.

    For very large s this function falls back to the Serfling comparison model
    to keep the notebook executable from top to bottom.
    """
    k_errors = int(np.clip(k_errors, 0, m))
    return _q_upper_hypergeom_exact_cached(k_errors, int(m), int(s), float(eps_pe))
''')

md(r"""
### Bound Comparison Notes

Clopper-Pearson assumes independent binomial sampling. Hypergeometric inversion is conceptually more appropriate for sampling without replacement from a finite sifted block. Hoeffding and Serfling are analytic concentration bounds. Exact bounds may be tighter, but the hypergeometric inversion is computationally heavier, so this notebook uses an exact search for $s \le 200000$ and labels larger cases through a Serfling fallback.
""")

md("## Unified PE Dispatcher")

code(r'''
def q_upper_bound(qber, m, s, eps_pe, method):
    """Dispatch a PE method and return a detailed bound dictionary.

    qber is the observed QBER and is interpreted through the integer count
    k_errors = round(qber * m).
    """
    if m <= 0:
        raise ValueError("m must be positive.")
    method = method.lower()
    k_errors = int(np.clip(round(float(qber) * m), 0, m))
    q_hat_discrete = k_errors / m
    hypergeom_fallback = False

    if method == "hoeffding":
        q_upper = q_upper_hoeffding(q_hat_discrete, m, eps_pe)
        used_method = "hoeffding"
    elif method == "serfling":
        q_upper = q_upper_serfling(q_hat_discrete, m, s, eps_pe)
        used_method = "serfling"
    elif method == "clopper_pearson":
        q_upper = q_upper_clopper_pearson(k_errors, m, eps_pe)
        used_method = "clopper_pearson"
    elif method == "hypergeom_exact":
        hypergeom_fallback = s > HYPERGEOM_EXACT_MAX_S
        q_upper = q_upper_hypergeom_exact(k_errors, m, s, eps_pe)
        used_method = "serfling_fallback" if hypergeom_fallback else "hypergeom_exact"
    else:
        raise ValueError(f"Unknown PE method: {method}")

    return {
        "method": method,
        "used_method": used_method,
        "q_upper": float(q_upper),
        "q_hat_discrete": float(q_hat_discrete),
        "k_errors": int(k_errors),
        "m": int(m),
        "s": int(s),
        "hypergeom_fallback": bool(hypergeom_fallback),
    }
''')

md(r"""
## Error-Correction Leakage Models

The basic theory often writes

$$
\mathrm{leak}_{\mathrm{EC}}
=
f_{\mathrm{EC}} n h_2(Q).
$$

For very short blocks this may be optimistic. Real short-block reconciliation can have fixed overheads, lower efficiency, decoder failures, padding, syndrome rounding, or interaction costs. Models 2-5 below are stress tests, not claims about a particular code. The empirical-table hook is where real LDPC, BCH, Cascade, or polar-code data can later be inserted.
""")

code(r'''
_EC_TABLE_CACHE = {"checked": False, "df": None, "notified_missing": False}


def _load_ec_table():
    """Load optional empirical EC leakage data if ec_leakage_table.csv exists."""
    if not _EC_TABLE_CACHE["checked"]:
        path = Path("ec_leakage_table.csv")
        if path.exists():
            df = pd.read_csv(path)
            required = {"n", "qber", "leakage_bits"}
            missing = required.difference(df.columns)
            if missing:
                raise ValueError(f"ec_leakage_table.csv is missing columns: {sorted(missing)}")
            _EC_TABLE_CACHE["df"] = df.copy()
        _EC_TABLE_CACHE["checked"] = True
    return _EC_TABLE_CACHE["df"]


def _nearest_empirical_leakage(n, qber):
    """Nearest-neighbor lookup for the optional empirical EC leakage table."""
    df = _load_ec_table()
    if df is None:
        if not _EC_TABLE_CACHE["notified_missing"]:
            print("ec_leakage_table.csv not found; empirical_table falls back to short_block_penalty.")
            _EC_TABLE_CACHE["notified_missing"] = True
        return ec_leakage(n, qber, model="short_block_penalty", f_ec=DEFAULT_F_EC)
    n = max(float(n), 1.0)
    qber = float(qber)
    distance = np.abs(np.log(np.maximum(df["n"].to_numpy(dtype=float), 1.0) / n))
    distance += 20.0 * np.abs(df["qber"].to_numpy(dtype=float) - qber)
    return float(df.iloc[int(np.argmin(distance))]["leakage_bits"])


def ec_leakage(n, qber, model="ideal", f_ec=1.1):
    """Return error-correction leakage in bits for a named short-block model."""
    n = max(float(n), 1.0)
    qber = float(np.clip(qber, 0.0, 0.5))
    hq = binary_entropy(qber)

    if model == "ideal":
        leakage = f_ec * n * hq
    elif model == "rounded_syndrome":
        leakage = math.ceil(f_ec * n * hq) + 32.0
    elif model == "fixed_overhead_64":
        leakage = f_ec * n * hq + 64.0
    elif model == "short_block_penalty":
        f_eff = f_ec + 5.0 / math.sqrt(n)
        leakage = f_eff * n * hq + 32.0
    elif model == "pessimistic_short_block":
        f_eff = f_ec + 10.0 / math.sqrt(n) + 500.0 / n
        leakage = f_eff * n * hq + 64.0
    elif model == "empirical_table":
        leakage = _nearest_empirical_leakage(n, qber)
    else:
        raise ValueError(f"Unknown EC model: {model}")
    return float(leakage)


EC_MODELS = BASE_EC_MODELS.copy()
if Path("ec_leakage_table.csv").exists():
    EC_MODELS.append("empirical_table")

print("EC models included:", EC_MODELS)
''')

md("## Toy Key-Length Function")

code(r'''
def toy_key_length(
    N,
    qber,
    m,
    eps_total=1e-9,
    p_sift=0.5,
    f_ec=1.1,
    pe_method="hoeffding",
    ec_model="ideal",
    return_details=False,
):
    """Compute the simplified finite-key planning length for a fixed m.

    This is a toy planning model. It is not a complete finite-key theorem.
    """
    eps_pe, eps_pa, eps_cor = split_epsilons(eps_total)
    N = int(N)
    s = int(math.floor(p_sift * N))
    m = int(m)

    if m <= 0 or m >= s:
        details = {
            "N": N,
            "s": s,
            "m": m,
            "n": max(s - m, 0),
            "qber": float(qber),
            "k_errors": np.nan,
            "q_hat_discrete": np.nan,
            "q_upper": np.nan,
            "pe_method": pe_method,
            "used_pe_method": pe_method,
            "hypergeom_fallback": False,
            "ec_model": ec_model,
            "entropy_term": -np.inf,
            "ec_leakage": np.inf,
            "t_ver": verification_tag_length(eps_cor),
            "pa_penalty": privacy_amplification_penalty(eps_pa),
            "ell": -np.inf,
            "pass_target": False,
        }
        return details if return_details else -np.inf

    n = s - m
    pe = q_upper_bound(qber, m, s, eps_pe, pe_method)
    entropy_term = n * (1.0 - binary_entropy(pe["q_upper"]))
    leakage = ec_leakage(n, qber, model=ec_model, f_ec=f_ec)
    t_ver = verification_tag_length(eps_cor)
    pa = privacy_amplification_penalty(eps_pa)
    ell = entropy_term - leakage - t_ver - pa

    details = {
        "N": N,
        "s": s,
        "m": m,
        "n": int(n),
        "qber": float(qber),
        "k_errors": pe["k_errors"],
        "q_hat_discrete": pe["q_hat_discrete"],
        "q_upper": pe["q_upper"],
        "pe_method": pe_method,
        "used_pe_method": pe["used_method"],
        "hypergeom_fallback": pe["hypergeom_fallback"],
        "ec_model": ec_model,
        "entropy_term": float(entropy_term),
        "ec_leakage": float(leakage),
        "t_ver": int(t_ver),
        "pa_penalty": float(pa),
        "ell": float(ell),
        "pass_target": bool(ell >= TARGET_KEY_LENGTH),
    }
    return details if return_details else float(ell)
''')

md("## Optimize m for Fixed N")

code(r'''
def candidate_m_values(s, num=250):
    """Generate a useful grid of PE sample sizes.

    The grid includes logarithmic values, linear fractions of s, and a few
    small explicit values. It avoids exhaustive search for huge s.
    """
    s = int(s)
    if s <= 20:
        return np.array([], dtype=int)

    max_m = s - 1
    log_hi = max(10, int(0.5 * s))
    log_values = np.unique(np.logspace(np.log10(10), np.log10(max(10, log_hi)), max(20, num // 2)).round().astype(int))
    frac_values = np.unique((np.linspace(0.01, 0.80, max(20, num // 2)) * s).round().astype(int))
    explicit = np.array([1, 2, 5, 10, 20, 50, 100, 200, 500, 1000], dtype=int)
    values = np.unique(np.concatenate([explicit, log_values, frac_values]))
    values = values[(values > 0) & (values < max_m)]
    return values.astype(int)


def optimize_m_for_N(
    N,
    qber,
    eps_total=1e-9,
    p_sift=0.5,
    f_ec=1.1,
    pe_method="hoeffding",
    ec_model="ideal",
):
    """Optimize the PE sample size m for a fixed transmitted-signal count N."""
    s = int(math.floor(p_sift * int(N)))
    rows = []
    for m in candidate_m_values(s, num=OPTIMIZER_M_GRID):
        rows.append(toy_key_length(
            N,
            qber,
            int(m),
            eps_total=eps_total,
            p_sift=p_sift,
            f_ec=f_ec,
            pe_method=pe_method,
            ec_model=ec_model,
            return_details=True,
        ))
    df = pd.DataFrame(rows)
    if df.empty:
        details = toy_key_length(N, qber, 0, eps_total, p_sift, f_ec, pe_method, ec_model, True)
        return details, df
    best_idx = int(df["ell"].idxmax())
    return df.loc[best_idx].to_dict(), df
''')

md("## Find Minimum N")

code(r'''
_NMIN_CACHE = {}


def find_minimum_N(
    qber,
    eps_total=1e-9,
    p_sift=0.5,
    f_ec=1.1,
    pe_method="hoeffding",
    ec_model="ideal",
    N_low=500,
    N_high=5_000_000,
):
    """Binary search for the smallest N whose optimized key length passes.

    If N_high does not pass, it is repeatedly doubled up to 100 million. If no
    passing N is found, the function returns N_min=np.inf and status='not_found'.
    """
    key = (
        round(float(qber), 12),
        round(float(eps_total), 18),
        round(float(p_sift), 12),
        round(float(f_ec), 12),
        pe_method,
        ec_model,
        int(N_low),
        int(N_high),
    )
    if key in _NMIN_CACHE:
        return dict(_NMIN_CACHE[key])

    def evaluate(N):
        details, _ = optimize_m_for_N(
            int(N),
            qber,
            eps_total=eps_total,
            p_sift=p_sift,
            f_ec=f_ec,
            pe_method=pe_method,
            ec_model=ec_model,
        )
        return details

    high = int(N_high)
    high_details = evaluate(high)
    while (not high_details["pass_target"]) and high < 100_000_000:
        high *= 2
        high_details = evaluate(high)

    if not high_details["pass_target"]:
        result = {
            "N_min": np.inf,
            "status": "not_found",
            "qber": float(qber),
            "eps_total": float(eps_total),
            "p_sift": float(p_sift),
            "f_ec": float(f_ec),
            "pe_method": pe_method,
            "ec_model": ec_model,
            "ell": float(high_details.get("ell", -np.inf)),
        }
        _NMIN_CACHE[key] = dict(result)
        return result

    lo = int(N_low)
    hi = high
    best = high_details
    while lo < hi:
        mid = (lo + hi) // 2
        mid_details = evaluate(mid)
        if mid_details["pass_target"]:
            best = mid_details
            hi = mid
        else:
            lo = mid + 1

    final_details = evaluate(lo)
    if final_details["pass_target"]:
        best = final_details

    result = dict(best)
    result.update({
        "N_min": int(result["N"]),
        "status": "ok",
        "eps_total": float(eps_total),
        "p_sift": float(p_sift),
        "f_ec": float(f_ec),
    })
    _NMIN_CACHE[key] = dict(result)
    return result
''')

md("## Sanity Checks")

md("These checks verify basic numerical behavior: entropy boundaries, upper bounds not below observed QBER, approximate key-length growth with N, and increased signal requirements at larger QBER.")

code(r'''
print("binary_entropy(0)   =", binary_entropy(0.0))
print("binary_entropy(0.5) =", binary_entropy(0.5))
print("binary_entropy(1)   =", binary_entropy(1.0))

for method in PE_METHODS:
    bound = q_upper_bound(0.03, m=1000, s=5000, eps_pe=DEFAULT_EPS_TOTAL / 3, method=method)
    print(f"{method:18s} q_hat={bound['q_hat_discrete']:.4f}, q_upper={bound['q_upper']:.4f}, used={bound['used_method']}")

Ns = [5_000, 10_000, 20_000]
ells = []
for N in Ns:
    s = int(DEFAULT_P_SIFT * N)
    m = int(0.2 * s)
    ells.append(toy_key_length(N, 0.03, m, pe_method="serfling"))
print("Key length values for increasing N at fixed m/s:", list(zip(Ns, np.round(ells, 2))))

low_q = find_minimum_N(0.01, pe_method="serfling", ec_model="ideal")
high_q = find_minimum_N(0.03, pe_method="serfling", ec_model="ideal")
print("N_min at QBER=1%:", low_q["N_min"])
print("N_min at QBER=3%:", high_q["N_min"])
print("Increasing-QBER check:", high_q["N_min"] >= low_q["N_min"])
''')

md(r"""
## Experiment A: Compare PE Bounds Under Ideal EC Leakage

Question: how much does the parameter-estimation bound affect the minimum signal budget when EC leakage is ideal?
""")

code(r'''
qber_values_A = [0.0, 0.005, 0.01, 0.02, 0.03, 0.05, 0.08, 0.10]
rows = []
for qber, method in itertools.product(qber_values_A, PE_METHODS):
    print(f"Experiment A: QBER={qber:.3f}, PE={method}")
    rows.append(find_minimum_N(
        qber,
        eps_total=DEFAULT_EPS_TOTAL,
        p_sift=DEFAULT_P_SIFT,
        f_ec=DEFAULT_F_EC,
        pe_method=method,
        ec_model="ideal",
    ))

df_pe_ideal = pd.DataFrame(rows)
df_pe_ideal.to_csv(res_dir / "pe_bounds_ideal_ec.csv", index=False)
display_cols = ["qber", "pe_method", "used_pe_method", "hypergeom_fallback", "N_min", "m", "s", "q_upper", "ell", "status"]
display(df_pe_ideal[display_cols])

pivot = df_pe_ideal.replace([np.inf, -np.inf], np.nan).pivot(index="qber", columns="pe_method", values="N_min")
ax = pivot.plot(kind="bar", figsize=(10, 5.5), width=0.82)
ax.set_xlabel("Observed QBER")
ax.set_ylabel("Minimum transmitted signals N_min")
ax.set_title("PE bounds under ideal EC leakage")
ax.set_yscale("log")
ax.legend(title="PE bound", fontsize=9)
save_figure("pe_bounds_ideal_ec.png")
plt.show()
''')

md(r"""
### Experiment A Analysis

Hoeffding and Serfling are analytic concentration bounds and are often conservative in the short-key regime. Clopper-Pearson and hypergeometric inversion are more serious finite-sample comparisons than a normal approximation, which is intentionally excluded from the main results because it can be too optimistic near small sample sizes or zero observed errors. Exact bounds can reduce $N_{\min}$ when they permit a smaller $Q_{\mathrm{upper}}$, but the benefit depends on the optimal sample size and whether the hypergeometric calculation remains exact or falls back for very large sifted blocks.
""")

md(r"""
## Experiment B: Compare EC Leakage Models Under a QBER-Aware PE Bound

Question: how much does realistic short-block EC leakage change $N_{\min}$ when the PE bound is fixed within each QBER?

For each QBER, this experiment uses `hypergeom_exact` when Experiment A shows that the exact hypergeometric calculation did not fall back. Otherwise it uses Serfling as the conservative default.
""")

code(r'''
qber_values_B = [0.005, 0.01, 0.02, 0.03, 0.05, 0.08]

def experiment_b_pe_method_for_qber(qber):
    hypergeom_rows = df_pe_ideal[
        (df_pe_ideal["pe_method"] == "hypergeom_exact")
        & np.isclose(df_pe_ideal["qber"], qber)
    ]
    if len(hypergeom_rows) and not bool(hypergeom_rows["hypergeom_fallback"].iloc[0]):
        return "hypergeom_exact"
    return "serfling"

experiment_b_pe_method_by_qber = {
    qber: experiment_b_pe_method_for_qber(qber)
    for qber in qber_values_B
}

print("PE method choices for Experiment B:")
for qber, pe_method in experiment_b_pe_method_by_qber.items():
    print(f"  QBER={qber:.3f}: {pe_method}")

rows = []
for qber, model in itertools.product(qber_values_B, EC_MODELS):
    pe_method = experiment_b_pe_method_by_qber[qber]
    print(f"Experiment B: QBER={qber:.3f}, PE={pe_method}, EC={model}")
    rows.append(find_minimum_N(
        qber,
        eps_total=DEFAULT_EPS_TOTAL,
        p_sift=DEFAULT_P_SIFT,
        f_ec=DEFAULT_F_EC,
        pe_method=pe_method,
        ec_model=model,
    ))

df_ec = pd.DataFrame(rows)
df_ec.to_csv(res_dir / "ec_models_comparison.csv", index=False)
display(df_ec[["qber", "pe_method", "used_pe_method", "hypergeom_fallback", "ec_model", "N_min", "m", "s", "q_upper", "ec_leakage", "ell", "status"]])

pivot = df_ec.replace([np.inf, -np.inf], np.nan).pivot(index="qber", columns="ec_model", values="N_min")
ax = pivot.plot(kind="bar", figsize=(11, 5.8), width=0.82)
ax.set_xlabel("Observed QBER")
ax.set_ylabel("Minimum transmitted signals N_min")
ax.set_title("EC leakage models under QBER-aware PE choice")
ax.set_yscale("log")
ax.legend(title="EC model", fontsize=8)
save_figure("ec_models_comparison.png")
plt.show()
''')

md(r"""
### Experiment B Analysis

Fixed overheads matter strongly for a 256-bit key because dozens of public bits are no longer negligible. Short-block inefficiency can substantially increase $N_{\min}$ by reducing the usable bit budget at exactly the block lengths where the optimizer wants to operate. This is likely the most publishable direction because toy finite-key formulas often hide reconciliation costs inside a single asymptotic efficiency factor.
""")

md(r"""
## Experiment C: Full Matrix of PE Bounds and EC Models

Question: which combinations of PE bound and EC model are most and least favorable?
""")

code(r'''
qber_values_C = [0.01, 0.03, 0.05]
rows = []
for qber, pe_method, ec_model in itertools.product(qber_values_C, PE_METHODS, EC_MODELS):
    print(f"Experiment C: QBER={qber:.3f}, PE={pe_method}, EC={ec_model}")
    rows.append(find_minimum_N(
        qber,
        eps_total=DEFAULT_EPS_TOTAL,
        p_sift=DEFAULT_P_SIFT,
        f_ec=DEFAULT_F_EC,
        pe_method=pe_method,
        ec_model=ec_model,
    ))

df_full = pd.DataFrame(rows)
df_full.to_csv(res_dir / "full_pe_ec_matrix.csv", index=False)
display(df_full[["qber", "pe_method", "ec_model", "N_min", "m", "q_upper", "ec_leakage", "status"]])


def plot_matrix_heatmap(df, qber):
    """Plot one log-scaled heatmap of N_min for a fixed QBER."""
    sub = df[np.isclose(df["qber"], qber)].replace([np.inf, -np.inf], np.nan)
    table = sub.pivot(index="pe_method", columns="ec_model", values="N_min").reindex(index=PE_METHODS, columns=EC_MODELS)
    values = table.to_numpy(dtype=float)
    log_values = np.log10(values)

    fig, ax = plt.subplots(figsize=(11, 4.8))
    im = ax.imshow(log_values, aspect="auto", cmap="viridis")
    ax.set_xticks(np.arange(len(table.columns)))
    ax.set_xticklabels(table.columns, rotation=35, ha="right")
    ax.set_yticks(np.arange(len(table.index)))
    ax.set_yticklabels(table.index)
    ax.set_title(f"Full PE/EC matrix at QBER={100*qber:.1f}%")
    ax.set_xlabel("EC leakage model")
    ax.set_ylabel("PE bound")
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("log10(N_min)")

    for i in range(values.shape[0]):
        for j in range(values.shape[1]):
            val = values[i, j]
            label = "n/a" if not np.isfinite(val) else f"{val/1000:.1f}k"
            ax.text(j, i, label, ha="center", va="center", color="white", fontsize=8)

    filename = f"full_matrix_qber_{int(round(1000 * qber)):03d}.png"
    save_figure(filename)
    plt.show()


for qber in qber_values_C:
    plot_matrix_heatmap(df_full, qber)
''')

md(r"""
### Experiment C Analysis

This matrix separates the effect of statistical confidence bounds from the effect of reconciliation leakage. PE-bound choice matters most when the confidence interval is a large part of the entropy loss. EC leakage dominates when fixed overheads or short-block inefficiency consume a large share of a 256-bit target. The least favorable combinations identify where a theorem-level formula plus real reconciliation data will most strongly change the resource estimate.
""")

md(r"""
## Experiment D: Optimal m Behavior

Question: how does the optimal parameter-estimation sample size behave under different bounds?
""")

code(r'''
rows = []
for qber, ec_model, pe_method in itertools.product([0.01, 0.03, 0.05], ["ideal", "short_block_penalty"], PE_METHODS):
    result = find_minimum_N(
        qber,
        eps_total=DEFAULT_EPS_TOTAL,
        p_sift=DEFAULT_P_SIFT,
        f_ec=DEFAULT_F_EC,
        pe_method=pe_method,
        ec_model=ec_model,
    )
    rows.append({
        "qber": qber,
        "pe_method": pe_method,
        "ec_model": ec_model,
        "N_min": result.get("N_min", np.inf),
        "s": result.get("s", np.nan),
        "optimal_m": result.get("m", np.nan),
        "m_over_s": result.get("m", np.nan) / result.get("s", np.nan),
        "q_upper": result.get("q_upper", np.nan),
        "ell": result.get("ell", np.nan),
        "status": result.get("status", "unknown"),
    })

df_m = pd.DataFrame(rows)
df_m.to_csv(res_dir / "optimal_m_behavior.csv", index=False)
display(df_m)

plt.figure(figsize=(9, 5.6))
for ec_model, linestyle in [("ideal", "-"), ("short_block_penalty", "--")]:
    for pe_method in PE_METHODS:
        sub = df_m[(df_m["ec_model"] == ec_model) & (df_m["pe_method"] == pe_method)]
        plt.plot(100 * sub["qber"], sub["m_over_s"], marker="o", linestyle=linestyle, label=f"{pe_method}, {ec_model}")
plt.xlabel("Observed QBER (%)")
plt.ylabel("Optimal m / s")
plt.title("Optimal parameter-estimation fraction")
plt.legend(fontsize=8, ncol=2)
save_figure("optimal_m_fraction.png")
plt.show()
''')

md(r"""
### Experiment D Analysis

Small $m$ gives loose upper bounds, while large $m$ consumes bits that could have contributed to the key. Tighter or exact bounds can sometimes allow smaller PE samples. The optimal PE fraction is therefore part of the resource-minimization problem, not an external tuning detail.
""")

md(r"""
## Experiment E: Decomposition of the Bit Budget

Question: at the minimum passing $N$, where do the bits go?
""")

code(r'''
budget_qber_values = [0.01, 0.03, 0.05]
budget_pe_method_by_qber = {
    qber: experiment_b_pe_method_by_qber.get(qber, "serfling")
    for qber in budget_qber_values
}
budget_ec_models = ["ideal", "short_block_penalty", "pessimistic_short_block"]
rows = []
for qber, ec_model in itertools.product(budget_qber_values, budget_ec_models):
    pe_method = budget_pe_method_by_qber[qber]
    result = find_minimum_N(
        qber,
        eps_total=DEFAULT_EPS_TOTAL,
        p_sift=DEFAULT_P_SIFT,
        f_ec=DEFAULT_F_EC,
        pe_method=pe_method,
        ec_model=ec_model,
    )
    rows.append(result)

df_budget = pd.DataFrame(rows)
df_budget.to_csv(res_dir / "bit_budget_decomposition.csv", index=False)
display(df_budget[["qber", "pe_method", "ec_model", "N_min", "s", "m", "n", "entropy_term", "ec_leakage", "t_ver", "pa_penalty", "ell"]])

plot_df = df_budget.copy()
plot_df["case"] = plot_df.apply(lambda r: f"Q={100*r['qber']:.0f}%, {r['ec_model']}", axis=1)
terms = ["entropy_term", "ec_leakage", "t_ver", "pa_penalty", "ell"]
ax = plot_df.set_index("case")[terms].plot(kind="bar", figsize=(12, 5.8), width=0.78)
ax.set_ylabel("Bits")
ax.set_title("Bit-budget decomposition at minimum passing N")
ax.legend(title="Term", fontsize=9)
save_figure("bit_budget_decomposition.png")
plt.show()
''')

md(r"""
### Experiment E Analysis

The available entropy term is reduced by finite parameter estimation through $Q_{\mathrm{upper}}$, by EC leakage, and by fixed verification and privacy-amplification overheads. In the short-key regime, fixed costs are visible on the same scale as the 256-bit target. As QBER rises, EC leakage and the entropy loss caused by a larger $Q_{\mathrm{upper}}$ become the dominant pressure points.
""")

md(r"""
## Result Summary

- The notebook computed $N_{\min}$ for a 256-bit final key under a focused planning formula.
- Hoeffding, Serfling, Clopper-Pearson, and hypergeometric bounds produce different signal budgets.
- Clopper-Pearson and hypergeometric bounds are more serious than a normal approximation for the small-sample regimes considered here.
- Exact hypergeometric inversion is conceptually best matched to sampling without replacement, but it is computationally heavier and should be checked carefully against the exact theorem used in a final paper.
- Realistic short-block EC leakage can dominate the answer in the short-key regime.
- The most publishable next direction is to replace artificial EC stress tests with measured leakage and failure data from real short-block reconciliation codes.
""")

md(r"""
## Limitations

1. The key-length formula is still a planning formula, not a full theorem-level finite-key proof.
2. The phase-error treatment is simplified.
3. Decoy-state analysis is not included.
4. Authentication cost is not fully modelled.
5. Real device imperfections are not modelled.
6. EC models are stress tests unless empirical code data is provided.
7. Hypergeometric inversion must be checked carefully against the exact theorem used in a final paper.
""")

md(r"""
## Future Work Toward Publication

1. Choose one specific finite-key theorem from the literature and match every term exactly.
2. Replace the toy PE bounds with theorem-consistent bounds.
3. Implement real short-block reconciliation: LDPC, BCH, Cascade, and polar codes.
4. Measure actual leakage, reconciliation failure probability, and block-length dependence.
5. Add decoy-state source modelling.
6. Compare to published finite-key and small-block QKD baselines.
7. Produce paper-ready figures and release code.
""")

md("## Reproducibility")

code(r'''
print("Python:", sys.version.split()[0])
print("numpy:", np.__version__)
print("pandas:", pd.__version__)
print("scipy:", scipy.__version__)
print("matplotlib:", matplotlib.__version__)
print()
print("Results saved in:", res_dir.resolve())
for path in sorted(res_dir.glob("*.csv")):
    print(" -", path.as_posix())
print()
print("Figures saved in:", fig_dir.resolve())
for path in sorted(fig_dir.glob("*.png")):
    print(" -", path.as_posix())
''')


notebook = {
    "cells": cells,
    "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {
            "name": "python",
            "version": sys.version.split()[0],
            "mimetype": "text/x-python",
            "codemirror_mode": {"name": "ipython", "version": 3},
            "pygments_lexer": "ipython3",
            "nbconvert_exporter": "python",
            "file_extension": ".py",
        },
    },
    "nbformat": 4,
    "nbformat_minor": 5,
}


path = Path("02_rigorous_bounds_and_ec_leakage.ipynb")
path.write_text(json.dumps(notebook, indent=1), encoding="utf-8")
print(f"wrote {path.resolve()} with {len(cells)} cells")
