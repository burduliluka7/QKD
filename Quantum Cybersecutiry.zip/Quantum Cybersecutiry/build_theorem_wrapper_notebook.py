import json
import sys
from pathlib import Path
from textwrap import dedent


cells = []


def add_cell(kind, text):
    source = dedent(text).strip() + "\n"
    cell = {
        "cell_type": kind,
        "id": f"cell-{len(cells) + 1:03d}",
        "metadata": {},
        "source": source.splitlines(True),
    }
    if kind == "code":
        cell.update({"execution_count": None, "outputs": []})
    cells.append(cell)


def md(text):
    add_cell("markdown", text)


def code(text):
    add_cell("code", text)


md(r"""
# Theorem-Locked Finite-Key Wrapper for 256-bit Short-Key BB84

The previous notebooks studied the short-key quantity

$$
N_{\min}(Q,\varepsilon_{\mathrm{total}})
=
\min\{N:\ell(N,Q,\varepsilon_{\mathrm{total}})\ge256\}.
$$

Notebook 03 measured empirical reconciliation leakage. However, the previous key-length formula was still a planning model. Notebook 04 now makes the finite-key accounting more disciplined by locking the calculation to one explicit theorem-style structure.

The goal is:

1. Define an idealized BB84 protocol model.
2. Define correctness and secrecy parameters.
3. Use one consistent finite-key key-length expression.
4. Insert deterministic error-correction leakage caps $L_{\max}$.
5. Compute $N_{\min}$ for a 256-bit final key.
6. Separate security accounting from operational abort-rate estimates.

**Scientific caution.** This notebook does not prove real hardware security. It does not include decoy-state source modelling, device imperfections, detector attacks, authentication-key consumption, or side channels. It studies an idealized single-photon BB84 model with trusted devices and authenticated classical communication.
""")

md(r"""
## Protocol Model and Assumptions

Alice and Bob run a BB84-like protocol with:

- ideal single-photon states,
- trusted preparation and measurement devices,
- independent random basis choices,
- authenticated public classical channel,
- no detector side channels,
- no Trojan-horse attacks,
- no decoy-state source modelling,
- no finite detector efficiency model,
- no loss model except through the effective number of sifted bits,
- error-correction transcript bounded by a pre-declared cap $L_{\max}$,
- error verification by universal hashing,
- privacy amplification by two-universal hashing.

The data flow is

$$
N
\rightarrow s=\lfloor p_{\mathrm{sift}}N\rfloor
\rightarrow m \text{ test bits}
\rightarrow n=s-m \text{ raw key bits}
\rightarrow \ell \text{ final bits}.
$$

Definitions:

- $N$: transmitted quantum signals.
- $s$: sifted bits.
- $m$: parameter-estimation sample size.
- $n$: raw key length after parameter estimation.
- $Q_{\mathrm{obs}}$: observed QBER in the test sample.
- $Q_{\mathrm{phase}}^{U}$: finite-key upper bound on phase-error rate.
- $L_{\max}$: deterministic error-correction leakage cap.
- $\ell$: final key length.

This is a theorem-compatible idealized BB84 wrapper, not a full implementation-security proof and not a decoy-state commercial-QKD proof.
""")

md(r"""
## Security Definition

Correctness is defined by

$$
\Pr[K_A\neq K_B]\le\varepsilon_{\mathrm{cor}}.
$$

Secrecy is defined by

$$
\frac12\|\rho_{KE}-\tau_K\otimes\rho_E\|_1
\le
\varepsilon_{\mathrm{sec}}.
$$

The total composable security parameter is

$$
\varepsilon_{\mathrm{total}}
=
\varepsilon_{\mathrm{cor}}
+
\varepsilon_{\mathrm{sec}}.
$$

This notebook decomposes secrecy into theorem sub-parameters:

$$
\varepsilon_{\mathrm{sec}}
=
\varepsilon_{\mathrm{PE}}
+
\varepsilon_{\mathrm{smooth}}
+
\varepsilon_{\mathrm{PA}}.
$$

Therefore

$$
\varepsilon_{\mathrm{total}}
=
\varepsilon_{\mathrm{cor}}
+
\varepsilon_{\mathrm{PE}}
+
\varepsilon_{\mathrm{smooth}}
+
\varepsilon_{\mathrm{PA}}.
$$

Roles:

- $\varepsilon_{\mathrm{PE}}$: parameter-estimation failure probability.
- $\varepsilon_{\mathrm{smooth}}$: smooth-min-entropy smoothing failure.
- $\varepsilon_{\mathrm{PA}}$: privacy-amplification failure.
- $\varepsilon_{\mathrm{cor}}$: probability verification accepts unequal keys.
""")

md(r"""
## The Theorem-Locked Key-Length Expression

This notebook uses a simplified ideal-BB84 finite-key expression inspired by smooth-entropy and entropic-uncertainty finite-key BB84 analyses.

**Important.** In a final paper, the exact constants must be matched line-by-line to a chosen reference theorem. This notebook is structured so that all theorem-dependent terms are isolated in one function and can be replaced once the final theorem is chosen.

The theorem-style expression is

$$
\ell
=
\left\lfloor
n\left[1-h_2(Q_{\mathrm{phase}}^{U})\right]
- L_{\max}
- \Delta_{\mathrm{smooth}}
- \Delta_{\mathrm{PA}}
\right\rfloor.
$$

The privacy-amplification penalty is

$$
\Delta_{\mathrm{PA}}
=
2\log_2(1/\varepsilon_{\mathrm{PA}}).
$$

This notebook uses a transparent smoothing penalty model

$$
\Delta_{\mathrm{smooth}}
=
c_{\mathrm{smooth}}\log_2(1/\varepsilon_{\mathrm{smooth}}),
$$

with default $c_{\mathrm{smooth}}=4$.

This smoothing term is a configurable theorem-placeholder. It is included to avoid the earlier problem where $\varepsilon_{\mathrm{smooth}}$ was tracked but did not affect the key length. In a final paper, this term must be replaced by the exact smoothing correction from the selected finite-key theorem.

The correctness verification tag length is

$$
t_{\mathrm{ver}}
=
\lceil \log_2(1/\varepsilon_{\mathrm{cor}})\rceil.
$$

Convention:

- $L_{\max}$ is reconciliation leakage only.
- $t_{\mathrm{ver}}$ is public verification leakage.
- This notebook subtracts $t_{\mathrm{ver}}$ from the key length as part of public communication leakage unless the user disables it.
- The correctness failure is bounded by $\varepsilon_{\mathrm{cor}}$.

The implemented default expression is

$$
\ell
=
\left\lfloor
n[1-h_2(Q_{\mathrm{phase}}^{U})]
- L_{\max}
- t_{\mathrm{ver}}
- \Delta_{\mathrm{smooth}}
- \Delta_{\mathrm{PA}}
\right\rfloor.
$$

Some finite-key theorems include verification leakage inside $\mathrm{leak}_{EC}$ or treat it separately. This notebook uses the explicit separate convention and labels it.
""")

md(r"""
## Parameter Estimation and Phase-Error Upper Bound

In ideal BB84, the observed bit-error statistics from the test sample are used to upper-bound the relevant phase-error rate. This notebook uses a finite-population sampling bound.

The preferred method is a corrected hypergeometric inversion for sampling without replacement. Given:

- $s$: total sifted block before parameter estimation.
- $m$: revealed test sample size.
- $k$: observed errors in the test sample.
- $n=s-m$: unrevealed key block size.

We bound the possible number of total errors $K$ in the full sifted block by hypergeometric inversion, then convert it into an upper bound on the unrevealed key block:

$$
Q_{\mathrm{phase}}^{U}
=
\frac{K_{\mathrm{upper}}-k}{s-m}.
$$

The result is clipped to $[0,0.5]$. Serfling is implemented as a fallback for large blocks.
""")

md("## Imports and Setup")

code(r'''
import itertools
import json
import math
import platform
import sys
import time
import warnings
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy


START_TIME = time.time()

results_dir = Path("results_04_theorem-wrapper")
fig_dir = results_dir / "figures"
res_dir = results_dir / "tables"
fig_dir.mkdir(parents=True, exist_ok=True)
res_dir.mkdir(parents=True, exist_ok=True)

TARGET_KEY_LENGTH = 256
DEFAULT_EPS_TOTAL = 1e-9
DEFAULT_P_SIFT = 0.5
DEFAULT_F_EC = 1.1
DEFAULT_C_SMOOTH = 4.0
HYPERGEOM_EXACT_MAX_S = 200_000
OPTIMIZER_COARSE_GRID = 64
OPTIMIZER_LOCAL_GRID = 25

plt.rcParams.update({
    "figure.figsize": (8.0, 4.8),
    "axes.grid": True,
    "grid.alpha": 0.25,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "font.size": 10,
    "axes.titlesize": 12,
    "axes.labelsize": 10,
    "legend.frameon": False,
})

warnings.filterwarnings("once", category=RuntimeWarning)
print("Setup complete.")
''')

md("## Utility Functions")

code(r'''
def binary_entropy(q):
    """Return the binary entropy h2(q), with q clipped to [0, 1]."""
    q = np.asarray(q, dtype=float)
    q_clip = np.clip(q, 0.0, 1.0)
    out = np.zeros_like(q_clip, dtype=float)
    mask = (q_clip > 0.0) & (q_clip < 1.0)
    out[mask] = (
        -q_clip[mask] * np.log2(q_clip[mask])
        - (1.0 - q_clip[mask]) * np.log2(1.0 - q_clip[mask])
    )
    if out.shape == ():
        return float(out)
    return out


def verification_tag_length(eps_cor):
    """Return ceil(log2(1 / eps_cor)) for a universal-hash verification tag."""
    eps_cor = float(eps_cor)
    if eps_cor <= 0.0:
        raise ValueError("eps_cor must be positive.")
    return int(math.ceil(math.log2(1.0 / eps_cor)))


def privacy_amplification_penalty(eps_pa):
    """Return the two-universal hashing privacy-amplification penalty."""
    eps_pa = float(eps_pa)
    if eps_pa <= 0.0:
        raise ValueError("eps_pa must be positive.")
    return float(2.0 * math.log2(1.0 / eps_pa))


def smoothing_penalty(eps_smooth, c_smooth=4.0):
    """Return the configurable theorem-placeholder smoothing penalty."""
    eps_smooth = float(eps_smooth)
    c_smooth = float(c_smooth)
    if eps_smooth <= 0.0:
        raise ValueError("eps_smooth must be positive.")
    return float(c_smooth * math.log2(1.0 / eps_smooth))


def split_security_budget(eps_total, mode="default"):
    """Split eps_total into correctness, PE, smoothing, and PA budgets."""
    eps_total = float(eps_total)
    if eps_total <= 0.0:
        raise ValueError("eps_total must be positive.")
    mode = str(mode).lower()
    weights_by_mode = {
        "default": {"eps_cor": 1.0, "eps_pe": 1.0, "eps_smooth": 1.0, "eps_pa": 1.0},
        "pa_heavy": {"eps_cor": 1.0, "eps_pe": 1.0, "eps_smooth": 1.0, "eps_pa": 5.0},
        "pe_heavy": {"eps_cor": 1.0, "eps_pe": 5.0, "eps_smooth": 1.0, "eps_pa": 1.0},
        "cor_heavy": {"eps_cor": 5.0, "eps_pe": 1.0, "eps_smooth": 1.0, "eps_pa": 1.0},
    }
    if mode not in weights_by_mode:
        raise ValueError(f"Unknown epsilon split mode: {mode}")
    weights = weights_by_mode[mode]
    total_weight = float(sum(weights.values()))
    out = {name: eps_total * weight / total_weight for name, weight in weights.items()}
    out["eps_total"] = eps_total
    out["eps_sum"] = sum(out[name] for name in ["eps_cor", "eps_pe", "eps_smooth", "eps_pa"])
    out["eps_mode"] = mode
    return out


budget_rows = []
for mode in ["default", "pe_heavy", "pa_heavy", "cor_heavy"]:
    row = split_security_budget(DEFAULT_EPS_TOTAL, mode=mode)
    budget_rows.append(row)
budget_table = pd.DataFrame(budget_rows)
budget_table["sum_matches_total"] = np.isclose(
    budget_table["eps_sum"], budget_table["eps_total"], rtol=0.0, atol=DEFAULT_EPS_TOTAL * 1e-12
)
budget_table.to_csv(res_dir / "security_budget_sanity_table.csv", index=False)
budget_table
''')

md("## Parameter-Estimation Functions")

code(r'''
_PE_CACHE = {}


def q_upper_serfling(q_hat, m, s, eps_pe):
    """Return a Serfling-style finite-population upper bound."""
    q_hat = float(q_hat)
    m = int(m)
    s = int(s)
    eps_pe = float(eps_pe)
    if m <= 0 or s <= 0 or m >= s or eps_pe <= 0.0:
        return 0.5
    q_hat = float(np.clip(q_hat, 0.0, 0.5))
    delta = math.sqrt(((s - m + 1.0) * math.log(1.0 / eps_pe)) / (2.0 * m * s))
    return float(np.clip(q_hat + delta, 0.0, 0.5))


def _hypergeom_candidate_is_compatible(k_errors, m, s, K_total, eps_pe):
    """Return True if total error count K_total is compatible with the sample."""
    cdf = scipy.stats.hypergeom.cdf(int(k_errors), int(s), int(K_total), int(m))
    if not np.isfinite(cdf):
        return False
    return bool(float(cdf) >= float(eps_pe))


def q_upper_hypergeom_key_block(k_errors, m, s, eps_pe, max_s_exact=200_000):
    """Return (Q_phase_upper, pe_fallback) using hypergeometric inversion.

    A candidate total error count K is compatible if
    Pr[sample errors <= k | K] >= eps_pe. The largest compatible K gives the
    upper bound on the unrevealed key block, (K_upper - k) / (s - m).
    """
    k_errors = int(np.clip(k_errors, 0, int(m)))
    m = int(m)
    s = int(s)
    eps_pe = float(eps_pe)
    if m <= 0 or s <= 0 or m >= s:
        return 0.5, True
    q_hat = k_errors / m
    if s > int(max_s_exact):
        return q_upper_serfling(q_hat, m, s, eps_pe), True

    low = k_errors
    high = min(s, k_errors + (s - m))
    best = low
    while low <= high:
        mid = (low + high) // 2
        if _hypergeom_candidate_is_compatible(k_errors, m, s, mid, eps_pe):
            best = mid
            low = mid + 1
        else:
            high = mid - 1

    key_errors_upper = max(0, best - k_errors)
    q_key = key_errors_upper / max(1, s - m)
    return float(np.clip(q_key, 0.0, 0.5)), False


def q_phase_upper_bound(qber, m, s, eps_pe, method="hypergeom_key_block"):
    """Return a detailed finite-key phase-error upper-bound dictionary."""
    method = str(method).lower()
    m = int(m)
    s = int(s)
    eps_pe = float(eps_pe)
    k_errors = int(np.clip(round(float(qber) * m), 0, m))
    q_hat = k_errors / m if m > 0 else 0.5
    cache_key = (round(float(qber), 12), m, s, round(eps_pe, 20), method)
    if cache_key in _PE_CACHE:
        return dict(_PE_CACHE[cache_key])

    if method in ["hypergeom_key_block", "hypergeom", "exact"]:
        q_upper, fallback = q_upper_hypergeom_key_block(
            k_errors, m, s, eps_pe, max_s_exact=HYPERGEOM_EXACT_MAX_S
        )
        used_method = "serfling_fallback" if fallback else "hypergeom_key_block"
    elif method == "serfling":
        q_upper = q_upper_serfling(q_hat, m, s, eps_pe)
        fallback = False
        used_method = "serfling"
    else:
        raise ValueError(f"Unknown PE method: {method}")

    result = {
        "q_phase_upper": float(np.clip(q_upper, 0.0, 0.5)),
        "q_hat_discrete": float(q_hat),
        "k_errors": int(k_errors),
        "pe_method": method,
        "used_pe_method": used_method,
        "pe_fallback": bool(fallback),
    }
    _PE_CACHE[cache_key] = dict(result)
    return result


for q in [0.005, 0.01, 0.03]:
    demo = q_phase_upper_bound(q, m=500, s=2000, eps_pe=DEFAULT_EPS_TOTAL / 4)
    print(q, demo)
''')

md(r"""
## Load Empirical Reconciliation Leakage Caps from Notebook 03

Notebook 03 produced empirical leakage summaries for Cascade and Hamming. For theorem compatibility, we cannot simply say "mean leakage." We need a deterministic cap $L_{\max}$.

Protocol rule: during reconciliation, count public parity or syndrome bits. If the count exceeds $L_{\max}$, abort.

Then the finite-key theorem can safely subtract $L_{\max}$. Empirical simulations estimate how often this cap is exceeded, which affects operational efficiency, not secrecy.
""")

code(r'''
def normalize_reconciliation_columns(df):
    """Normalize reconciliation table column names and numeric columns."""
    out = df.copy()
    out.columns = [
        str(col).strip().lower().replace(" ", "_").replace("-", "_")
        for col in out.columns
    ]
    aliases = {
        "protocol_name": "protocol",
        "block_length": "n",
        "q": "qber",
        "q_obs": "qber",
        "leakage_mean": "mean_leakage",
        "leakage_p95": "p95_leakage",
        "leakage_p99": "p99_leakage",
        "leakage_max": "max_leakage",
        "mean": "mean_leakage",
        "p95": "p95_leakage",
        "p99": "p99_leakage",
        "max": "max_leakage",
    }
    out = out.rename(columns={old: new for old, new in aliases.items() if old in out.columns})
    for col in out.columns:
        if col not in ["protocol"]:
            converted = pd.to_numeric(out[col], errors="coerce")
            if converted.notna().sum() > 0:
                out[col] = converted
    if "protocol" not in out.columns:
        out["protocol"] = "cascade"
    if "n" not in out.columns or "qber" not in out.columns:
        raise ValueError("Leakage table must contain n and qber columns.")
    return out


def find_leakage_source_file():
    """Return the first available Notebook 03 leakage table path, or None."""
    candidates = [
        Path("results_03_reconciliation") / "tables" / "empirical_leakage_table.csv",
        Path("results_03_reconciliation") / "tables" / "reconciliation_summary.csv",
        Path("/mnt/data/results_03_reconciliation/tables/empirical_leakage_table.csv"),
    ]
    for path in candidates:
        if path.exists():
            return path
    return None


def create_fallback_leakage_table():
    """Create a small synthetic leakage table for demonstration-only fallback."""
    rows = []
    for n, qber in itertools.product([256, 512, 1024, 2048, 4096, 8192], [0.005, 0.01, 0.02, 0.03, 0.05]):
        ideal = DEFAULT_F_EC * n * binary_entropy(qber)
        rows.append({
            "protocol": "cascade",
            "n": int(n),
            "qber": float(qber),
            "trials": 0,
            "mean_leakage": float(np.ceil(1.15 * ideal + 16.0)),
            "p95_leakage": float(np.ceil(1.25 * ideal + 32.0)),
            "p99_leakage": float(np.ceil(1.40 * ideal + 64.0)),
            "max_leakage": float(np.ceil(1.60 * ideal + 96.0)),
            "failure_rate": np.nan,
            "fallback_demonstration_only": True,
        })
    return pd.DataFrame(rows)


def load_empirical_leakage_table():
    """Load Notebook 03 leakage data or return a marked synthetic fallback table."""
    source_path = find_leakage_source_file()
    if source_path is None:
        table = create_fallback_leakage_table()
        using_fallback = True
        source = "synthetic_fallback_demonstration_only"
    else:
        table = normalize_reconciliation_columns(pd.read_csv(source_path))
        table["fallback_demonstration_only"] = False
        using_fallback = False
        source = str(source_path)
    table = normalize_reconciliation_columns(table)
    table.to_csv(res_dir / "cleaned_empirical_leakage_table.csv", index=False)
    return table, using_fallback, source


empirical_leakage_table, using_fallback_data, leakage_source = load_empirical_leakage_table()
print("Leakage source:", leakage_source)
print("Using fallback demonstration data:", using_fallback_data)
display(empirical_leakage_table.head())
''')

md(r"""
## Leakage-Cap Function

Mean leakage is not a security cap unless enforced. p95 and p99 are empirical quantile caps. In theorem-compatible mode, the protocol must abort if actual leakage exceeds the chosen cap. Therefore the finite-key theorem subtracts the cap, not the realized leakage.
""")

code(r'''
def ideal_leakage_cap(n, qber, f_ec=1.1):
    """Return ceil(f_ec * n * h2(qber)) as an idealized EC leakage cap."""
    return float(np.ceil(float(f_ec) * int(n) * binary_entropy(float(qber))))


def _protocol_rows(table, protocol):
    """Return rows matching a protocol name, with relaxed matching for Hamming."""
    protocol = str(protocol).lower()
    rows = table[table["protocol"].astype(str).str.lower() == protocol].copy()
    if rows.empty and protocol.startswith("hamming"):
        rows = table[table["protocol"].astype(str).str.lower().str.contains("hamming", na=False)].copy()
    if rows.empty and protocol.startswith("cascade"):
        rows = table[table["protocol"].astype(str).str.lower().str.contains("cascade", na=False)].copy()
    return rows


def _statistic_column(table, cap_statistic):
    """Map a requested cap statistic to the best available leakage column."""
    cap_statistic = str(cap_statistic).lower()
    candidates = {
        "mean": ["mean_leakage", "mean"],
        "p95": ["p95_leakage", "leakage_p95", "p95"],
        "p99": ["p99_leakage", "leakage_p99", "p99"],
        "max": ["max_leakage", "leakage_max", "max"],
    }
    for col in candidates.get(cap_statistic, []):
        if col in table.columns:
            return col, cap_statistic
    for col in ["p95_leakage", "mean_leakage"]:
        if col in table.columns:
            return col, "p95" if col == "p95_leakage" else "mean"
    return None, "ideal_fallback"


def _interpolate_at_qber(rows, n, value_col):
    """Interpolate or linearly extrapolate a leakage statistic over n."""
    sub = rows.sort_values("n")
    x = sub["n"].to_numpy(dtype=float)
    y = sub[value_col].to_numpy(dtype=float)
    n = float(n)
    if len(x) == 0:
        return np.nan, True
    if len(x) == 1:
        scale = n / max(x[0], 1.0)
        return max(0.0, float(y[0] * scale)), bool(not np.isclose(n, x[0]))
    if x[0] <= n <= x[-1]:
        return float(np.interp(n, x, y)), False
    if n < x[0]:
        slope = (y[1] - y[0]) / max(x[1] - x[0], 1.0)
        return max(0.0, float(y[0] + slope * (n - x[0]))), True
    slope = (y[-1] - y[-2]) / max(x[-1] - x[-2], 1.0)
    return max(0.0, float(y[-1] + slope * (n - x[-1]))), True


def _interpolate_leakage(rows, n, qber, value_col):
    """Interpolate a leakage statistic over qber and n."""
    rows = rows.dropna(subset=["n", "qber", value_col]).copy()
    if rows.empty:
        return np.nan, np.nan, np.nan, True
    q_values = np.array(sorted(rows["qber"].astype(float).unique()), dtype=float)
    qber = float(qber)
    if qber <= q_values[0]:
        q_low = q_high = q_values[0]
        q_extra = not np.isclose(qber, q_values[0])
    elif qber >= q_values[-1]:
        q_low = q_high = q_values[-1]
        q_extra = not np.isclose(qber, q_values[-1])
    else:
        q_low = q_values[q_values <= qber].max()
        q_high = q_values[q_values >= qber].min()
        q_extra = False

    low_rows = rows[np.isclose(rows["qber"].astype(float), q_low)]
    low_value, low_extra = _interpolate_at_qber(low_rows, n, value_col)
    if np.isclose(q_low, q_high):
        cap_value = low_value
        high_extra = False
    else:
        high_rows = rows[np.isclose(rows["qber"].astype(float), q_high)]
        high_value, high_extra = _interpolate_at_qber(high_rows, n, value_col)
        cap_value = float(np.interp(qber, [q_low, q_high], [low_value, high_value]))

    distance = np.abs(np.log(np.maximum(rows["n"].to_numpy(dtype=float), 1.0) / max(float(n), 1.0)))
    distance += 30.0 * np.abs(rows["qber"].to_numpy(dtype=float) - qber)
    nearest = rows.iloc[int(np.argmin(distance))]
    extrapolated = bool(q_extra or low_extra or high_extra)
    return cap_value, int(nearest["n"]), float(nearest["qber"]), extrapolated


def empirical_leakage_cap(
    n,
    qber,
    table,
    protocol="cascade",
    cap_statistic="p95",
    fallback_to_ideal=True,
):
    """Return an integer empirical L_max cap and metadata for theorem accounting."""
    n = int(n)
    qber = float(qber)
    rows = _protocol_rows(table, protocol)
    statistic_col, used_statistic = _statistic_column(rows, cap_statistic)
    if rows.empty or statistic_col is None:
        if not fallback_to_ideal:
            raise ValueError(f"No leakage data available for protocol={protocol}, statistic={cap_statistic}.")
        cap_value = ideal_leakage_cap(n, qber, DEFAULT_F_EC)
        return {
            "cap_value": int(math.ceil(cap_value)),
            "nearest_n": int(n),
            "nearest_qber": float(qber),
            "extrapolated": False,
            "protocol": protocol,
            "cap_statistic": cap_statistic,
            "statistic_column": "ideal_leakage_cap",
            "source": "ideal_fallback",
        }

    cap_value, nearest_n, nearest_qber, extrapolated = _interpolate_leakage(rows, n, qber, statistic_col)
    if not np.isfinite(cap_value) and fallback_to_ideal:
        cap_value = ideal_leakage_cap(n, qber, DEFAULT_F_EC)
        statistic_col = "ideal_leakage_cap"
        used_statistic = "ideal_fallback"
    return {
        "cap_value": int(math.ceil(max(0.0, float(cap_value)))),
        "nearest_n": int(nearest_n),
        "nearest_qber": float(nearest_qber),
        "extrapolated": bool(extrapolated),
        "protocol": protocol,
        "cap_statistic": used_statistic,
        "statistic_column": statistic_col,
        "source": f"{protocol}_{used_statistic}",
    }


for model in ["mean", "p95", "p99", "max"]:
    print(model, empirical_leakage_cap(1000, 0.02, empirical_leakage_table, cap_statistic=model))
''')

md("## Theorem-Level Key-Length Function")

code(r'''
def _parse_ec_cap_model(ec_cap_model):
    """Parse an EC cap model into protocol and statistic choices."""
    model = str(ec_cap_model).lower()
    if model == "ideal_fec_1_1":
        return "ideal", "ideal"
    mapping = {
        "cascade_mean": ("cascade", "mean"),
        "cascade_p95": ("cascade", "p95"),
        "cascade_p99": ("cascade", "p99"),
        "cascade_max": ("cascade", "max"),
        "hamming_mean": ("hamming", "mean"),
        "hamming_p95": ("hamming", "p95"),
        "hamming_p99": ("hamming", "p99"),
        "hamming_max": ("hamming", "max"),
    }
    if model not in mapping:
        raise ValueError(f"Unknown EC cap model: {ec_cap_model}")
    return mapping[model]


def theorem_locked_key_length(
    N,
    qber,
    m,
    eps_total=1e-9,
    p_sift=0.5,
    pe_method="hypergeom_key_block",
    ec_cap_model="cascade_p95",
    leakage_table=None,
    f_ec=1.1,
    c_smooth=4.0,
    subtract_verification=True,
    eps_mode="default",
    return_details=False,
):
    """Compute the theorem-wrapper finite-key length for one N and m."""
    if leakage_table is None:
        leakage_table = empirical_leakage_table
    N = int(N)
    m = int(m)
    qber = float(qber)
    eps = split_security_budget(eps_total, mode=eps_mode)
    s = int(math.floor(float(p_sift) * N))
    invalid = s <= 1 or m <= 0 or m >= s
    if invalid:
        details = {
            "N": N,
            "s": s,
            "m": m,
            "n": max(0, s - m),
            "qber": qber,
            "k_errors": np.nan,
            "q_hat_discrete": np.nan,
            "q_phase_upper": np.nan,
            "pe_method": pe_method,
            "used_pe_method": "invalid",
            "pe_fallback": False,
            "ec_cap_model": ec_cap_model,
            "L_max": np.inf,
            "L_max_source": "invalid",
            "L_max_nearest_n": np.nan,
            "L_max_nearest_qber": np.nan,
            "L_max_extrapolated": False,
            "entropy_term": -np.inf,
            "t_ver": verification_tag_length(eps["eps_cor"]),
            "subtract_verification": bool(subtract_verification),
            "smoothing_penalty": smoothing_penalty(eps["eps_smooth"], c_smooth),
            "pa_penalty": privacy_amplification_penalty(eps["eps_pa"]),
            "eps_cor": eps["eps_cor"],
            "eps_pe": eps["eps_pe"],
            "eps_smooth": eps["eps_smooth"],
            "eps_pa": eps["eps_pa"],
            "eps_total": eps["eps_total"],
            "eps_mode": eps["eps_mode"],
            "ell": -np.inf,
            "pass_target": False,
            "status": "invalid",
        }
        return details if return_details else float("-inf")

    n = s - m
    pe = q_phase_upper_bound(qber, m, s, eps["eps_pe"], method=pe_method)
    q_phase = pe["q_phase_upper"]
    entropy_term = n * (1.0 - binary_entropy(q_phase))

    protocol, statistic = _parse_ec_cap_model(ec_cap_model)
    if protocol == "ideal":
        L_max = int(math.ceil(ideal_leakage_cap(n, qber, f_ec=f_ec)))
        cap_info = {
            "source": "ideal_fec_1_1",
            "nearest_n": n,
            "nearest_qber": qber,
            "extrapolated": False,
            "protocol": "ideal",
            "cap_statistic": "ideal",
            "statistic_column": "ideal_leakage_cap",
        }
    else:
        cap_info = empirical_leakage_cap(
            n,
            qber,
            leakage_table,
            protocol=protocol,
            cap_statistic=statistic,
            fallback_to_ideal=True,
        )
        L_max = int(cap_info["cap_value"])

    t_ver = verification_tag_length(eps["eps_cor"])
    t_ver_subtracted = t_ver if subtract_verification else 0
    smooth = smoothing_penalty(eps["eps_smooth"], c_smooth=c_smooth)
    pa = privacy_amplification_penalty(eps["eps_pa"])
    ell_real = entropy_term - L_max - t_ver_subtracted - smooth - pa
    ell = math.floor(ell_real)

    details = {
        "N": N,
        "s": int(s),
        "m": int(m),
        "n": int(n),
        "qber": qber,
        "k_errors": int(pe["k_errors"]),
        "q_hat_discrete": float(pe["q_hat_discrete"]),
        "q_phase_upper": float(q_phase),
        "pe_method": pe_method,
        "used_pe_method": pe["used_pe_method"],
        "pe_fallback": bool(pe["pe_fallback"]),
        "ec_cap_model": ec_cap_model,
        "L_max": int(L_max),
        "L_max_source": cap_info["source"],
        "L_max_protocol": cap_info["protocol"],
        "L_max_statistic": cap_info["cap_statistic"],
        "L_max_statistic_column": cap_info["statistic_column"],
        "L_max_nearest_n": int(cap_info["nearest_n"]),
        "L_max_nearest_qber": float(cap_info["nearest_qber"]),
        "L_max_extrapolated": bool(cap_info["extrapolated"]),
        "entropy_term": float(entropy_term),
        "t_ver": int(t_ver),
        "subtract_verification": bool(subtract_verification),
        "smoothing_penalty": float(smooth),
        "pa_penalty": float(pa),
        "eps_cor": float(eps["eps_cor"]),
        "eps_pe": float(eps["eps_pe"]),
        "eps_smooth": float(eps["eps_smooth"]),
        "eps_pa": float(eps["eps_pa"]),
        "eps_total": float(eps["eps_total"]),
        "eps_mode": eps["eps_mode"],
        "c_smooth": float(c_smooth),
        "ell_real": float(ell_real),
        "ell": int(ell),
        "pass_target": bool(ell >= TARGET_KEY_LENGTH),
        "status": "ok" if ell >= TARGET_KEY_LENGTH else "short",
    }
    return details if return_details else int(ell)


demo_details = theorem_locked_key_length(5000, 0.02, 1000, return_details=True)
demo_details
''')

md("## Optimize m and Find N_min")

code(r'''
_NMIN_CACHE = {}


def candidate_m_values(s, num=250):
    """Return candidate PE sample sizes for a sifted block of size s."""
    s = int(s)
    if s <= 3:
        return np.array([], dtype=int)
    upper_log = max(10, int(math.floor(0.5 * s)))
    log_values = np.logspace(math.log10(10), math.log10(upper_log), max(20, num // 2))
    fraction_values = np.linspace(0.01, 0.80, max(20, num // 2)) * s
    fixed_values = np.array([1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048], dtype=float)
    values = np.unique(np.concatenate([log_values, fraction_values, fixed_values]).round().astype(int))
    values = values[(values > 0) & (values < s)]
    return values.astype(int)


def optimize_m_for_N(
    N,
    qber,
    eps_total=1e-9,
    p_sift=0.5,
    pe_method="hypergeom_key_block",
    ec_cap_model="cascade_p95",
    leakage_table=None,
    f_ec=1.1,
    c_smooth=4.0,
    subtract_verification=True,
    eps_mode="default",
    return_grid=True,
):
    """Test candidate m values and return the best details plus the m-grid DataFrame.

    The optimizer uses a coarse candidate grid followed by a local refinement
    around the best coarse m. The standalone candidate_m_values(s, num=250)
    function remains available for denser checks.
    """
    if leakage_table is None:
        leakage_table = empirical_leakage_table
    s = int(math.floor(float(p_sift) * int(N)))
    rows = []
    evaluated = set()
    for m in candidate_m_values(s, num=OPTIMIZER_COARSE_GRID):
        details = theorem_locked_key_length(
            N,
            qber,
            int(m),
            eps_total=eps_total,
            p_sift=p_sift,
            pe_method=pe_method,
            ec_cap_model=ec_cap_model,
            leakage_table=leakage_table,
            f_ec=f_ec,
            c_smooth=c_smooth,
            subtract_verification=subtract_verification,
            eps_mode=eps_mode,
            return_details=True,
        )
        rows.append(details)
        evaluated.add(int(m))
    grid = pd.DataFrame(rows)
    if grid.empty:
        best = theorem_locked_key_length(
            N, qber, 0, eps_total, p_sift, pe_method, ec_cap_model,
            leakage_table, f_ec, c_smooth, subtract_verification, eps_mode, True
        )
        return best, grid
    coarse_best_m = int(grid.loc[int(grid["ell"].idxmax()), "m"])
    radius = max(12, int(round(0.18 * coarse_best_m)))
    local_values = np.unique(
        np.linspace(coarse_best_m - radius, coarse_best_m + radius, OPTIMIZER_LOCAL_GRID)
        .round()
        .astype(int)
    )
    for m in local_values:
        if m <= 0 or m >= s or int(m) in evaluated:
            continue
        details = theorem_locked_key_length(
            N,
            qber,
            int(m),
            eps_total=eps_total,
            p_sift=p_sift,
            pe_method=pe_method,
            ec_cap_model=ec_cap_model,
            leakage_table=leakage_table,
            f_ec=f_ec,
            c_smooth=c_smooth,
            subtract_verification=subtract_verification,
            eps_mode=eps_mode,
            return_details=True,
        )
        rows.append(details)
        evaluated.add(int(m))
    grid = pd.DataFrame(rows)
    best = grid.loc[int(grid["ell"].idxmax())].to_dict()
    if return_grid:
        return best, grid
    return best, pd.DataFrame()


def find_minimum_N_theorem_locked(
    qber,
    eps_total=1e-9,
    p_sift=0.5,
    pe_method="hypergeom_key_block",
    ec_cap_model="cascade_p95",
    leakage_table=None,
    f_ec=1.1,
    c_smooth=4.0,
    subtract_verification=True,
    eps_mode="default",
    target=256,
    N_low=500,
    N_high=5_000_000,
    max_N=100_000_000,
):
    """Find the smallest passing N using binary search over optimized m."""
    if leakage_table is None:
        leakage_table = empirical_leakage_table
    key = (
        round(float(qber), 12),
        round(float(eps_total), 20),
        round(float(p_sift), 12),
        pe_method,
        ec_cap_model,
        round(float(f_ec), 12),
        round(float(c_smooth), 12),
        bool(subtract_verification),
        eps_mode,
        int(target),
        int(N_low),
        int(N_high),
    )
    if key in _NMIN_CACHE:
        return dict(_NMIN_CACHE[key])

    def passes(N):
        best, _ = optimize_m_for_N(
            int(N),
            qber,
            eps_total=eps_total,
            p_sift=p_sift,
            pe_method=pe_method,
            ec_cap_model=ec_cap_model,
            leakage_table=leakage_table,
            f_ec=f_ec,
            c_smooth=c_smooth,
            subtract_verification=subtract_verification,
            eps_mode=eps_mode,
            return_grid=False,
        )
        return bool(best.get("ell", -np.inf) >= target), best

    low = int(N_low)
    high = int(N_high)
    high_passes, high_details = passes(high)
    while not high_passes and high < int(max_N):
        low = high + 1
        high = min(int(max_N), high * 2)
        high_passes, high_details = passes(high)

    if not high_passes:
        result = {
            "N_min": np.inf,
            "optimal_m": np.nan,
            "status": "not_found",
            "qber": float(qber),
            "ec_cap_model": ec_cap_model,
            "eps_mode": eps_mode,
            "c_smooth": float(c_smooth),
            "ell": float(high_details.get("ell", -np.inf)),
        }
        _NMIN_CACHE[key] = dict(result)
        return result

    answer = high_details
    left, right = low, high
    while left <= right:
        mid = (left + right) // 2
        mid_passes, mid_details = passes(mid)
        if mid_passes:
            answer = mid_details
            right = mid - 1
        else:
            left = mid + 1

    answer = dict(answer)
    answer["N_min"] = int(answer["N"])
    answer["optimal_m"] = int(answer["m"])
    answer["status"] = "ok"
    _NMIN_CACHE[key] = dict(answer)
    return answer


best_demo, grid_demo = optimize_m_for_N(6000, 0.02, ec_cap_model="cascade_p95")
print("Demo optimized m:", best_demo["m"], "ell:", best_demo["ell"])
''')

md("## Sanity Checks")

md(r"""
These checks confirm the helper functions behave as expected. They do not validate real QKD hardware security; they only check internal consistency of this idealized theorem wrapper.
""")

code(r'''
def print_check(name, passed, detail):
    """Print a readable sanity-check status line."""
    status = "PASS" if bool(passed) else "FAIL"
    print(f"{status}: {name} -- {detail}")


h0 = binary_entropy(0.0)
hhalf = binary_entropy(0.5)
print_check("h2(0)=0", np.isclose(h0, 0.0), f"h2(0)={h0}")
print_check("h2(0.5)=1", np.isclose(hhalf, 1.0), f"h2(0.5)={hhalf}")

budget = split_security_budget(DEFAULT_EPS_TOTAL)
print_check(
    "epsilon budget sums to eps_total",
    np.isclose(budget["eps_sum"], DEFAULT_EPS_TOTAL),
    f"sum={budget['eps_sum']:.3e}, total={DEFAULT_EPS_TOTAL:.3e}",
)

pe_test = q_phase_upper_bound(0.02, m=800, s=3000, eps_pe=budget["eps_pe"])
print_check(
    "Q_phase^U >= observed discrete QBER",
    pe_test["q_phase_upper"] >= pe_test["q_hat_discrete"] - 1e-12,
    f"upper={pe_test['q_phase_upper']:.5f}, observed={pe_test['q_hat_discrete']:.5f}",
)

base = theorem_locked_key_length(7000, 0.02, 1200, ec_cap_model="ideal_fec_1_1", return_details=True)
ell_with_more_leakage = math.floor(
    base["entropy_term"]
    - (base["L_max"] + 100)
    - base["t_ver"]
    - base["smoothing_penalty"]
    - base["pa_penalty"]
)
print_check(
    "increasing L_max decreases key length",
    ell_with_more_leakage < base["ell"],
    f"base={base['ell']}, with extra leakage={ell_with_more_leakage}",
)

m1 = int(math.floor(DEFAULT_P_SIFT * 7000 * 0.25))
m2 = int(math.floor(DEFAULT_P_SIFT * 9000 * 0.25))
ell1 = theorem_locked_key_length(7000, 0.02, m1, ec_cap_model="cascade_p95")
ell2 = theorem_locked_key_length(9000, 0.02, m2, ec_cap_model="cascade_p95")
print_check(
    "increasing N generally increases key length at fixed m/s",
    ell2 >= ell1,
    f"N=7000 ell={ell1}, N=9000 ell={ell2}",
)

print_check(
    "no double-counting convention stated",
    base["L_max_source"] == "ideal_fec_1_1" and base["subtract_verification"],
    "L_max is reconciliation leakage; t_ver is separate verification leakage.",
)
''')

md(r"""
## Experiment A: Theorem-Locked N_min Under Ideal vs Empirical Leakage Caps

Question: how does $N_{\min}$ change when the theorem-level formula subtracts deterministic Cascade leakage caps instead of ideal leakage?
""")

code(r'''
qber_values = [0.005, 0.01, 0.02, 0.03, 0.05]
ec_cap_models = [
    "ideal_fec_1_1",
    "cascade_mean",
    "cascade_p95",
    "cascade_p99",
    "cascade_max",
]

rows = []
for qber, ec_model in itertools.product(qber_values, ec_cap_models):
    print(f"Experiment A: qber={qber:.3f}, ec_cap_model={ec_model}")
    result = find_minimum_N_theorem_locked(
        qber,
        eps_total=DEFAULT_EPS_TOTAL,
        p_sift=DEFAULT_P_SIFT,
        pe_method="hypergeom_key_block",
        ec_cap_model=ec_model,
        eps_mode="default",
    )
    rows.append(result)

nmin_theorem = pd.DataFrame(rows)
nmin_theorem.to_csv(res_dir / "nmin_theorem_locked_leakage_caps.csv", index=False)
display(nmin_theorem[["qber", "ec_cap_model", "N_min", "optimal_m", "n", "ell", "L_max", "q_phase_upper", "L_max_extrapolated"]])

fig, ax = plt.subplots(figsize=(9, 5))
x = np.arange(len(qber_values))
width = 0.15
for i, model in enumerate(ec_cap_models):
    sub = nmin_theorem[nmin_theorem["ec_cap_model"] == model].set_index("qber").reindex(qber_values)
    ax.bar(x + (i - 2) * width, sub["N_min"].to_numpy(dtype=float), width=width, label=model)
ax.set_xticks(x)
ax.set_xticklabels([f"{q:.3f}" for q in qber_values])
ax.set_xlabel("QBER")
ax.set_ylabel("N_min for 256 final bits")
ax.set_title("Theorem-locked N_min by deterministic leakage cap")
ax.set_yscale("log")
ax.legend(ncol=2)
fig.tight_layout()
fig.savefig(fig_dir / "nmin_theorem_locked_leakage_caps.png", dpi=200)
plt.show()
''')

md(r"""
Empirical caps can increase $N_{\min}$ because the theorem-compatible calculation subtracts a deterministic public-transcript bound, not an average realized transcript length. p95, p99, and max caps reflect different abort conventions: a p95 cap is operationally cheaper than a p99 or max cap, but it should abort more often. Extrapolated leakage rows should be treated as sensitivity evidence and excluded from main publication claims until the reconciliation simulation directly covers the required block sizes.
""")

md("## Experiment B: Percent Increase Over Ideal Leakage")

code(r'''
ideal = (
    nmin_theorem[nmin_theorem["ec_cap_model"] == "ideal_fec_1_1"]
    [["qber", "N_min"]]
    .rename(columns={"N_min": "N_min_ideal"})
)
percent_rows = []
for _, row in nmin_theorem.iterrows():
    ideal_N = float(ideal.loc[np.isclose(ideal["qber"], row["qber"]), "N_min_ideal"].iloc[0])
    cap_N = float(row["N_min"])
    increase = 100.0 * (cap_N - ideal_N) / ideal_N
    new_row = row.to_dict()
    new_row["N_min_ideal"] = ideal_N
    new_row["percent_increase_over_ideal"] = increase
    percent_rows.append(new_row)

percent_increase = pd.DataFrame(percent_rows)
percent_increase.to_csv(res_dir / "percent_increase_theorem_locked.csv", index=False)
display(percent_increase[["qber", "ec_cap_model", "N_min", "N_min_ideal", "percent_increase_over_ideal"]])

fig, ax = plt.subplots(figsize=(8, 5))
for model in ["cascade_mean", "cascade_p95", "cascade_p99", "cascade_max"]:
    sub = percent_increase[percent_increase["ec_cap_model"] == model].sort_values("qber")
    ax.plot(sub["qber"], sub["percent_increase_over_ideal"], marker="o", label=model)
ax.axhline(0.0, color="black", linewidth=0.8)
ax.set_xlabel("QBER")
ax.set_ylabel("Increase over ideal leakage (%)")
ax.set_title("Cost of theorem-compatible empirical leakage caps")
ax.legend()
fig.tight_layout()
fig.savefig(fig_dir / "percent_increase_theorem_locked.png", dpi=200)
plt.show()

for model in ["cascade_p95", "cascade_p99"]:
    sub = percent_increase[percent_increase["ec_cap_model"] == model].sort_values("qber")
    parts = [f"Q={r.qber:.3f}: {r.percent_increase_over_ideal:.1f}%" for r in sub.itertuples()]
    print(
        "Under this idealized theorem-wrapper model and empirical leakage-cap convention, "
        f"{model} caps increase N_min by approximately "
        + "; ".join(parts)
        + " compared with ideal 1.1*n*h2(Q) leakage."
    )
''')

md(r"""
This is the main result section. The numerical percentages above should be read under the idealized theorem-wrapper assumptions. They do not establish implementation security. They quantify how deterministic empirical leakage caps change the minimum transmitted-signal budget relative to the ideal $1.1nh_2(Q)$ leakage model.
""")

md(r"""
## Experiment C: Security-Budget Allocation

Question: how sensitive is $N_{\min}$ to the allocation of $\varepsilon_{\mathrm{total}}$ among correctness, PE, smoothing, and PA?
""")

code(r'''
eps_modes = ["default", "pe_heavy", "pa_heavy", "cor_heavy"]
qber_values_c = [0.01, 0.03, 0.05]
rows = []
for qber, mode in itertools.product(qber_values_c, eps_modes):
    print(f"Experiment C: qber={qber:.3f}, eps_mode={mode}")
    result = find_minimum_N_theorem_locked(
        qber,
        eps_total=DEFAULT_EPS_TOTAL,
        p_sift=DEFAULT_P_SIFT,
        pe_method="hypergeom_key_block",
        ec_cap_model="cascade_p95",
        eps_mode=mode,
    )
    rows.append(result)

budget_allocation = pd.DataFrame(rows)
budget_allocation.to_csv(res_dir / "security_budget_allocation.csv", index=False)
display(budget_allocation[["qber", "eps_mode", "N_min", "optimal_m", "q_phase_upper", "t_ver", "pa_penalty"]])

fig, ax = plt.subplots(figsize=(8, 5))
x = np.arange(len(qber_values_c))
width = 0.18
for i, mode in enumerate(eps_modes):
    sub = budget_allocation[budget_allocation["eps_mode"] == mode].set_index("qber").reindex(qber_values_c)
    ax.bar(x + (i - 1.5) * width, sub["N_min"].to_numpy(dtype=float), width=width, label=mode)
ax.set_xticks(x)
ax.set_xticklabels([f"{q:.2f}" for q in qber_values_c])
ax.set_xlabel("QBER")
ax.set_ylabel("N_min")
ax.set_title("Sensitivity to epsilon allocation")
ax.legend()
fig.tight_layout()
fig.savefig(fig_dir / "security_budget_allocation.png", dpi=200)
plt.show()
''')

md(r"""
PE-heavy allocations can reduce the parameter-estimation penalty; PA-heavy allocations can reduce the privacy-amplification penalty; correctness-heavy allocations can reduce the verification tag length. The best allocation depends on the exact theorem terms, especially once the smoothing term is replaced by the chosen theorem's expression.
""")

md(r"""
## Experiment D: Effect of the Smoothing Term

Question: how much does the theorem-placeholder smoothing penalty affect $N_{\min}$?
""")

code(r'''
c_smooth_values = [0.0, 2.0, 4.0, 8.0]
rows = []
for qber, c_value in itertools.product(qber_values_c, c_smooth_values):
    print(f"Experiment D: qber={qber:.3f}, c_smooth={c_value:g}")
    result = find_minimum_N_theorem_locked(
        qber,
        eps_total=DEFAULT_EPS_TOTAL,
        p_sift=DEFAULT_P_SIFT,
        pe_method="hypergeom_key_block",
        ec_cap_model="cascade_p95",
        eps_mode="default",
        c_smooth=c_value,
    )
    rows.append(result)

smoothing_sensitivity = pd.DataFrame(rows)
smoothing_sensitivity.to_csv(res_dir / "smoothing_penalty_sensitivity.csv", index=False)
display(smoothing_sensitivity[["qber", "c_smooth", "N_min", "optimal_m", "smoothing_penalty", "ell"]])

fig, ax = plt.subplots(figsize=(8, 5))
for qber in qber_values_c:
    sub = smoothing_sensitivity[np.isclose(smoothing_sensitivity["qber"], qber)].sort_values("c_smooth")
    ax.plot(sub["c_smooth"], sub["N_min"], marker="o", label=f"QBER {qber:.2f}")
ax.set_xlabel("c_smooth")
ax.set_ylabel("N_min")
ax.set_title("Sensitivity to theorem-placeholder smoothing penalty")
ax.legend()
fig.tight_layout()
fig.savefig(fig_dir / "smoothing_penalty_sensitivity.png", dpi=200)
plt.show()
''')

md(r"""
The exact smoothing term must eventually be replaced by the chosen theorem's exact expression. This experiment shows how sensitive the result is to that placeholder term before the final theorem is selected.
""")

md(r"""
## Experiment E: Operational Acceptance with Leakage Caps

Security accounting uses a deterministic leakage cap $L_{\max}$. If Cascade exceeds $L_{\max}$, the protocol aborts. Simulations estimate the probability of exceeding the cap.

Approximate cap exceedance probabilities:

- mean cap: may exceed often, modelled here as 50% unless direct distribution data are added.
- p95 cap: around 5% by construction.
- p99 cap: around 1% by construction.
- max observed cap: 0% exceedance in the finite sample, but not a theorem-level worst case.

This is operational, not security.
""")

code(r'''
def estimate_cap_exceedance(ec_cap_model):
    """Return an approximate operational probability that leakage exceeds the cap."""
    model = str(ec_cap_model).lower()
    if model.endswith("_mean"):
        return 0.50
    if model.endswith("_p95"):
        return 0.05
    if model.endswith("_p99"):
        return 0.01
    if model.endswith("_max"):
        return 0.00
    return 0.00


def estimate_reconciliation_failure_rate(n, qber, ec_cap_model, table):
    """Return nearest empirical reconciliation failure rate for an EC cap model."""
    protocol, _ = _parse_ec_cap_model(ec_cap_model)
    if protocol == "ideal" or "failure_rate" not in table.columns:
        return 0.0
    rows = _protocol_rows(table, protocol).dropna(subset=["n", "qber", "failure_rate"])
    if rows.empty:
        return np.nan
    distance = np.abs(np.log(np.maximum(rows["n"].to_numpy(dtype=float), 1.0) / max(float(n), 1.0)))
    distance += 30.0 * np.abs(rows["qber"].to_numpy(dtype=float) - float(qber))
    return float(rows.iloc[int(np.argmin(distance))]["failure_rate"])


op_rows = []
for _, row in nmin_theorem.iterrows():
    exceed = estimate_cap_exceedance(row["ec_cap_model"])
    fail = estimate_reconciliation_failure_rate(row["n"], row["qber"], row["ec_cap_model"], empirical_leakage_table)
    fail_for_calc = 0.0 if not np.isfinite(fail) else float(np.clip(fail, 0.0, 1.0))
    acceptance = max(0.0, (1.0 - exceed) * (1.0 - fail_for_calc))
    expected_N = np.inf if acceptance <= 0.0 else float(row["N_min"]) / acceptance
    op_rows.append({
        "qber": float(row["qber"]),
        "ec_cap_model": row["ec_cap_model"],
        "N_min": row["N_min"],
        "estimated_cap_exceedance": exceed,
        "estimated_reconciliation_failure_rate": fail,
        "estimated_acceptance_probability": acceptance,
        "expected_N_per_accepted_key": expected_N,
    })

operational_acceptance = pd.DataFrame(op_rows)
operational_acceptance.to_csv(res_dir / "operational_acceptance_with_caps.csv", index=False)
display(operational_acceptance)

fig, ax = plt.subplots(figsize=(8, 5))
for model in ["ideal_fec_1_1", "cascade_p95", "cascade_p99", "cascade_max"]:
    sub = operational_acceptance[operational_acceptance["ec_cap_model"] == model].sort_values("qber")
    ax.plot(sub["qber"], sub["expected_N_per_accepted_key"], marker="o", label=model)
ax.set_xlabel("QBER")
ax.set_ylabel("Expected N per accepted 256-bit key")
ax.set_title("Operational cost after cap exceedance and reconciliation failure")
ax.set_yscale("log")
ax.legend()
fig.tight_layout()
fig.savefig(fig_dir / "operational_acceptance_with_caps.png", dpi=200)
plt.show()
''')

md(r"""
The leakage cap controls theorem leakage. Exceeding the cap causes abort. Failure after reconciliation should be caught by verification and also causes abort. Operational efficiency may therefore be worse than the raw $N_{\min}$ calculation.
""")

md(r"""
## Experiment F: Bit-Budget Decomposition

Question: at theorem-locked $N_{\min}$, where do the bits go?
""")

code(r'''
bit_rows = []
for qber, model in itertools.product([0.01, 0.03, 0.05], ["ideal_fec_1_1", "cascade_p95", "cascade_p99"]):
    match = nmin_theorem[(np.isclose(nmin_theorem["qber"], qber)) & (nmin_theorem["ec_cap_model"] == model)]
    if match.empty:
        result = find_minimum_N_theorem_locked(qber, ec_cap_model=model)
    else:
        result = match.iloc[0].to_dict()
    bit_rows.append({
        "qber": qber,
        "ec_cap_model": model,
        "N_min": result["N_min"],
        "s": result["s"],
        "m": result["m"],
        "n": result["n"],
        "entropy_term": result["entropy_term"],
        "L_max": result["L_max"],
        "t_ver": result["t_ver"],
        "smoothing_penalty": result["smoothing_penalty"],
        "pa_penalty": result["pa_penalty"],
        "ell": result["ell"],
    })

bit_budget = pd.DataFrame(bit_rows)
bit_budget.to_csv(res_dir / "bit_budget_theorem_locked.csv", index=False)
display(bit_budget)

components = ["entropy_term", "L_max", "t_ver", "smoothing_penalty", "pa_penalty", "ell"]
labels = [f"Q={r.qber:.2f}\n{r.ec_cap_model.replace('_', ' ')}" for r in bit_budget.itertuples()]
x = np.arange(len(bit_budget))
width = 0.13
fig, ax = plt.subplots(figsize=(12, 5.5))
for i, component in enumerate(components):
    ax.bar(x + (i - 2.5) * width, bit_budget[component].to_numpy(dtype=float), width=width, label=component)
ax.set_xticks(x)
ax.set_xticklabels(labels, rotation=35, ha="right")
ax.set_ylabel("Bits")
ax.set_title("Bit-budget decomposition at theorem-locked N_min")
ax.legend(ncol=3)
fig.tight_layout()
fig.savefig(fig_dir / "bit_budget_theorem_locked.png", dpi=200)
plt.show()
''')

md(r"""
The dominant loss usually comes from the entropy term reduction and reconciliation leakage. The verification, smoothing, and PA terms are smaller but matter for 256-bit short-key targets. Empirical leakage caps change the budget by replacing an ideal leakage estimate with an enforced public-transcript cap.
""")

md("## Comparison with Notebook 03 Planning-Model Results")

code(r'''
comparison_path = Path("results_03_reconciliation") / "tables" / "nmin_empirical_reconciliation.csv"
if comparison_path.exists():
    nb03 = pd.read_csv(comparison_path)
    nb03 = nb03.rename(columns={"ec_model": "ec_cap_model", "N_min": "planning_model_N_min"})
    nb03_small = nb03[["qber", "ec_cap_model", "planning_model_N_min"]].copy()
    theorem_small = nmin_theorem[["qber", "ec_cap_model", "N_min"]].rename(columns={"N_min": "theorem_locked_N_min"})
    comparison = pd.merge(nb03_small, theorem_small, on=["qber", "ec_cap_model"], how="inner")
    comparison["difference"] = comparison["theorem_locked_N_min"] - comparison["planning_model_N_min"]
    comparison["percent_difference"] = 100.0 * comparison["difference"] / comparison["planning_model_N_min"]
    if comparison.empty:
        comparison = pd.DataFrame([{
            "status": "no_matching_rows",
            "source": str(comparison_path),
        }])
else:
    comparison = pd.DataFrame([{
        "status": "notebook03_file_missing",
        "source": str(comparison_path),
    }])

comparison.to_csv(res_dir / "notebook03_vs_theorem_locked.csv", index=False)
display(comparison)

if {"planning_model_N_min", "theorem_locked_N_min"}.issubset(comparison.columns) and not comparison.empty:
    fig, ax = plt.subplots(figsize=(7, 5))
    for model in sorted(comparison["ec_cap_model"].unique()):
        sub = comparison[comparison["ec_cap_model"] == model].sort_values("qber")
        ax.plot(sub["qber"], sub["planning_model_N_min"], marker="o", linestyle="--", label=f"Notebook 03 {model}")
        ax.plot(sub["qber"], sub["theorem_locked_N_min"], marker="s", label=f"Wrapper {model}")
    ax.set_xlabel("QBER")
    ax.set_ylabel("N_min")
    ax.set_title("Notebook 03 planning model vs theorem-locked wrapper")
    ax.set_yscale("log")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(fig_dir / "notebook03_vs_theorem_locked.png", dpi=200)
    plt.show()
else:
    print("Notebook 03 comparison plot skipped because matching data were unavailable.")
''')

md(r"""
The theorem-locked results may be larger than Notebook 03 planning-model results because the smoothing penalty is now included, the verification convention is explicit, leakage caps are deterministic, and the PE bound is tied to a phase-error upper bound. Differences should be interpreted as accounting changes under an idealized theorem wrapper, not as a claim of complete QKD implementation security.
""")

md(r"""
## Main Conclusion

This notebook converts the previous empirical reconciliation study into a theorem-compatible finite-key wrapper. The central change is that reconciliation leakage is treated as a deterministic cap $L_{\max}$, and the protocol aborts if the public transcript exceeds this cap. This allows the key-length formula to subtract $L_{\max}$ in a theorem-compatible way.

Under the idealized single-photon BB84 assumptions used here, the experiments compare ideal leakage against Cascade mean, p95, p99, and max caps; compute percent increases in $N_{\min}$; test security-budget allocations; vary the configurable smoothing term; estimate operational cost from cap exceedance and reconciliation failure; and decompose the bit budget at the theorem-locked minimum.

The result is still under ideal BB84 assumptions and is not a full hardware security proof. It is not a decoy-state commercial-QKD proof. It assumes trusted devices, authenticated classical communication, and no side channels.
""")

md(r"""
## Limitations

1. The theorem expression is still a theorem-wrapper template unless the exact constants are matched to a chosen paper.
2. The smoothing penalty is configurable and must be replaced by the exact theorem term.
3. The phase-error bound is simplified to a finite-population upper bound.
4. No decoy-state source modelling is included.
5. No device imperfections or side channels are included.
6. Empirical leakage caps come from finite simulations and must be validated with more trials.
7. p95/p99 caps are operational choices; theorem compatibility requires aborting if the cap is exceeded.
8. Authentication-key consumption is not modelled.
9. Cascade implementation should be validated against references or standard implementations.
""")

md(r"""
## Future Work

1. Choose the final reference theorem and replace the theorem-placeholder terms exactly.
2. Verify every constant and security parameter against the selected theorem.
3. Increase Cascade trials and compute confidence intervals for cap exceedance.
4. Validate Cascade against known test cases.
5. Add LDPC or BCH reconciliation if reliable libraries are available.
6. Add decoy-state analysis for weak coherent pulse sources.
7. Include authentication-key consumption.
8. Write a paper around the claim: "Measured short-block reconciliation leakage caps increase the minimum signal budget for a 256-bit finite-key QKD key by X% compared with ideal EC leakage."
""")

md("## Reproducibility")

code(r'''
total_runtime = time.time() - START_TIME
print("Python:", sys.version.split()[0])
print("numpy:", np.__version__)
print("pandas:", pd.__version__)
print("scipy:", scipy.__version__)
print("matplotlib:", matplotlib.__version__)
print("platform:", platform.platform())
print("total runtime seconds:", round(total_runtime, 2))
print("empirical Notebook 03 data loaded:", not using_fallback_data)
print("leakage source:", leakage_source)
print()
print("Generated CSV files:")
for path in sorted(res_dir.glob("*.csv")):
    print(" -", path.as_posix())
print()
print("Generated PNG files:")
for path in sorted(fig_dir.glob("*.png")):
    print(" -", path.as_posix())
''')


notebook = {
    "cells": cells,
    "metadata": {
        "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
        "language_info": {
            "name": "python",
            "version": sys.version.split()[0],
            "mimetype": "text/x-python",
            "codemirror_mode": {"name": "ipython", "version": 3},
            "pygments_lexer": "ipython3",
            "nbconvert_exporter": "python",
            "file_extension": ".py",
        },
    },
    "nbformat": 4,
    "nbformat_minor": 5,
}


path = Path("04_theorem_level_finite_key_wrapper.ipynb")
path.write_text(json.dumps(notebook, indent=1), encoding="utf-8")
print(f"wrote {path.resolve()} with {len(cells)} cells")
