from __future__ import annotations

import argparse
from pathlib import Path

from qkd.reporting import export_tables


def main() -> None:
    parser = argparse.ArgumentParser(description="Export decoy result CSV files as LaTeX table fragments.")
    parser.add_argument("--config", help="Accepted for interface consistency; tables read saved CSV files.")
    parser.add_argument("--output-dir", default="results/decoy", help="Directory containing generated CSV results.")
    parser.add_argument("--seed", type=int, default=12345, help="Accepted for interface consistency; no randomness is used.")
    parser.add_argument("--quick", action="store_true", help="Accepted for interface consistency.")
    args = parser.parse_args()
    export_tables(Path(args.output_dir), Path("report/generated_tables"))
    print("Regenerated decoy LaTeX tables.")


if __name__ == "__main__":
    main()
