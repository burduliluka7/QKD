from __future__ import annotations

import argparse
from pathlib import Path

from qkd.reporting import make_figures


def main() -> None:
    parser = argparse.ArgumentParser(description="Regenerate report decoy figures from saved CSV files.")
    parser.add_argument("--config", help="Accepted for interface consistency; figures read saved CSV files.")
    parser.add_argument("--output-dir", default="results/decoy", help="Directory containing generated CSV results.")
    parser.add_argument("--seed", type=int, default=12345, help="Accepted for interface consistency; no randomness is used.")
    parser.add_argument("--quick", action="store_true", help="Accepted for interface consistency.")
    args = parser.parse_args()
    make_figures(Path(args.output_dir), Path("report/figures"))
    print("Regenerated decoy figures.")


if __name__ == "__main__":
    main()

