"""Merge parallel exhaustive ideal-BB84 search shards."""

from __future__ import annotations
import json
from pathlib import Path
import sys
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))
from run_ideal_basis_results import Q_VALUES, write_tex

frames, certificates, runtimes = [], [], []
for q in Q_VALUES:
    shard = ROOT / "results" / f"ideal_basis_q{int(round(10000*q)):04d}"
    frames.append(pd.read_csv(shard / "minima.csv"))
    certificates.extend(json.loads((shard / "search_certificate.json").read_text(encoding="utf-8")))
    runtimes.append(json.loads((shard / "run_metadata.json").read_text(encoding="utf-8"))["runtime_seconds"])
out = ROOT / "results" / "ideal_basis"
out.mkdir(parents=True, exist_ok=True)
frame = pd.concat(frames, ignore_index=True).sort_values(["q_tol", "leakage_model"])
frame.to_csv(out / "minima.csv", index=False)
(out / "search_certificate.json").write_text(json.dumps(certificates, indent=2), encoding="utf-8")
(out / "run_metadata.json").write_text(json.dumps({"command": "five parallel q-tol shards plus python code/merge_ideal_basis_results.py", "wall_runtime_bounded_by_slowest_shard_seconds": max(runtimes), "sum_shard_runtime_seconds": sum(runtimes)}, indent=2), encoding="utf-8")
write_tex(frame, ROOT / "report" / "generated_tables" / "ideal_basis_minima.tex")
fig, ax = plt.subplots(figsize=(7.2, 4.5))
for model, group in frame.groupby("leakage_model"):
    ax.plot(100 * group.q_tol, group.N_min, marker="o", label=model.replace("ideal_fec_1_1", "ideal").replace("cascade_", "Cascade "))
ax.set(xlabel=r"symmetric planning error rate $Q$ (\%)", ylabel="transmitted pulses", title=r"Accepted-run minima: $Q=Q_X^{\rm tol}=Q_Z^{\rm design}$")
ax.legend(); fig.tight_layout(); fig.savefig(ROOT / "report" / "figures" / "ideal_basis_minima.pdf")
print(frame[["q_tol", "leakage_model", "N_min", "p_z", "n_Z", "m_X", "ell"]].to_string(index=False))
