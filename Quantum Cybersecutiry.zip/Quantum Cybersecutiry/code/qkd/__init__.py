"""Small deterministic QKD utilities used by the report scripts."""

