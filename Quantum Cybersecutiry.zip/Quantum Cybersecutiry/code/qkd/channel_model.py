"""Honest weak-coherent-pulse channel model for deterministic planning."""

from __future__ import annotations

from dataclasses import dataclass
import math


@dataclass(frozen=True)
class ChannelParams:
    """Total channel-plus-detection transmittance model."""

    eta: float
    y0: float = 1e-6
    e_d: float = 0.01
    e0: float = 0.5

    @classmethod
    def from_loss_db(cls, loss_db: float, y0: float = 1e-6, e_d: float = 0.01) -> "ChannelParams":
        return cls(eta=10.0 ** (-loss_db / 10.0), y0=y0, e_d=e_d)


def yield_n(n: int, params: ChannelParams) -> float:
    if n < 0:
        raise ValueError("n must be nonnegative")
    return 1.0 - (1.0 - params.y0) * ((1.0 - params.eta) ** n)


def gain(intensity: float, params: ChannelParams) -> float:
    if intensity < 0:
        raise ValueError("intensity must be nonnegative")
    return 1.0 - (1.0 - params.y0) * math.exp(-params.eta * intensity)


def error_gain(intensity: float, params: ChannelParams) -> float:
    if intensity < 0:
        raise ValueError("intensity must be nonnegative")
    signal_click = 1.0 - math.exp(-params.eta * intensity)
    return params.e0 * params.y0 + params.e_d * signal_click


def qber(intensity: float, params: ChannelParams) -> float:
    q = gain(intensity, params)
    if q <= 0.0:
        return 0.5
    return min(0.5, max(0.0, error_gain(intensity, params) / q))


def true_single_photon_error(params: ChannelParams) -> float:
    y1 = yield_n(1, params)
    if y1 <= 0.0:
        return 0.5
    return min(0.5, max(0.0, (params.e0 * params.y0 + params.e_d * params.eta) / y1))

