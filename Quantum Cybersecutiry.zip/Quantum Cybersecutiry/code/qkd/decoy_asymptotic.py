"""Asymptotic vacuum-plus-weak decoy formulas."""

from __future__ import annotations

from dataclasses import dataclass
import math

from .channel_model import ChannelParams, gain, qber, true_single_photon_error, yield_n
from .hamming import binary_entropy
from .ideal_basis import truncated_binary_entropy


@dataclass(frozen=True)
class AsymptoticDecoyResult:
    mu: float
    nu: float
    q_mu: float
    q_nu: float
    e_mu: float
    e_nu: float
    y0: float
    true_y1: float
    y1_lower: float
    q1_lower: float
    true_e1: float
    e1_upper: float
    rate_gllp: float


def vacuum_weak_bounds(
    mu: float,
    nu: float,
    params: ChannelParams,
    p_z: float = 1.0,
    p_mu: float = 1.0,
    f_ec: float = 1.16,
) -> AsymptoticDecoyResult:
    """Ma-Qi-Zhao-Lo vacuum+weak asymptotic estimates.

    The returned rate is per total emitted pulse and uses q = p_mu * p_z^2.
    """
    if not (0.0 < nu < mu):
        raise ValueError("requires 0 < nu < mu")
    q_mu = gain(mu, params)
    q_nu = gain(nu, params)
    q0 = gain(0.0, params)
    e_mu = qber(mu, params)
    e_nu = qber(nu, params)
    y0 = q0
    denom = mu * nu - nu * nu
    y1_l = (mu / denom) * (
        q_nu * math.exp(nu)
        - q_mu * math.exp(mu) * (nu / mu) ** 2
        - ((mu * mu - nu * nu) / (mu * mu)) * y0
    )
    y1_l = min(1.0, max(0.0, y1_l))
    q1_l = mu * math.exp(-mu) * y1_l
    if y1_l <= 0.0:
        e1_u = 0.5
    else:
        e1_u = (e_nu * q_nu * math.exp(nu) - 0.5 * y0) / (nu * y1_l)
        e1_u = min(0.5, max(0.0, e1_u))
    rate = p_mu * (p_z**2) * (
        -q_mu * f_ec * binary_entropy(e_mu) + q1_l * (1.0 - truncated_binary_entropy(e1_u))
    )
    return AsymptoticDecoyResult(
        mu=mu,
        nu=nu,
        q_mu=q_mu,
        q_nu=q_nu,
        e_mu=e_mu,
        e_nu=e_nu,
        y0=y0,
        true_y1=yield_n(1, params),
        y1_lower=y1_l,
        q1_lower=q1_l,
        true_e1=true_single_photon_error(params),
        e1_upper=e1_u,
        rate_gllp=rate,
    )
