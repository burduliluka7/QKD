"""Finite-count two-decoy/vacuum-plus-weak planning calculations.

The implemented finite-count bounds follow the notation of Wiesemann et al.,
Appendix A.2, specialized to three intensities (mu, nu, omega=0). Counts in
this project are deterministic expected-count planning inputs; a real run must
replace them with observed integer counts.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
import math

from .channel_model import ChannelParams, error_gain, gain, qber
from .hamming import binary_entropy
from .ideal_basis import truncated_binary_entropy


COUNT_CONCENTRATION_EVENTS: tuple[str, ...] = (
    "epsilon_n_minus_Z_mu2",
    "epsilon_n_plus_Z_mu3",
    "epsilon_n_plus_Z_mu1",
    "epsilon_n_minus_Z_mu3",
    "epsilon_n_plus_Z_mu2",
    "epsilon_n_minus_X_mu2",
    "epsilon_n_plus_X_mu3",
    "epsilon_n_plus_X_mu1",
    "epsilon_n_minus_X_mu3",
    "epsilon_n_plus_X_mu2",
    "epsilon_c_plus_X_mu2",
    "epsilon_c_minus_X_mu3",
)

COUNT_EVENT_DETAILS: dict[str, tuple[str, str, str, str, str]] = {
    "epsilon_n_minus_Z_mu2": ("Z", "detection", "nu", "lower", "Eq. (132)"),
    "epsilon_n_plus_Z_mu3": ("Z", "detection", "omega", "upper", "Eq. (132)"),
    "epsilon_n_plus_Z_mu1": ("Z", "detection", "mu", "upper", "Eq. (132)"),
    "epsilon_n_minus_Z_mu3": ("Z", "detection", "omega", "lower", "Eq. (127)"),
    "epsilon_n_plus_Z_mu2": ("Z", "detection", "nu", "upper", "Eq. (127)"),
    "epsilon_n_minus_X_mu2": ("X", "detection", "nu", "lower", "Eq. (132)"),
    "epsilon_n_plus_X_mu3": ("X", "detection", "omega", "upper", "Eq. (132)"),
    "epsilon_n_plus_X_mu1": ("X", "detection", "mu", "upper", "Eq. (132)"),
    "epsilon_n_minus_X_mu3": ("X", "detection", "omega", "lower", "Eq. (127)"),
    "epsilon_n_plus_X_mu2": ("X", "detection", "nu", "upper", "Eq. (127)"),
    "epsilon_c_plus_X_mu2": ("X", "error", "nu", "upper", "Eq. (134)"),
    "epsilon_c_minus_X_mu3": ("X", "error", "omega", "lower", "Eq. (134)"),
}

TWO_DECOY_GLOBAL_BRANCH_MULTIPLICITY = 2 + 2 + 1
TWO_DECOY_COMMON_SECURITY_BRANCHES = (
    len(COUNT_CONCENTRATION_EVENTS) + TWO_DECOY_GLOBAL_BRANCH_MULTIPLICITY
)


@dataclass(frozen=True)
class SecurityBudget:
    """Explicit Wiesemann two-decoy security allocation.

    The simplified Eq. (137) convention uses a common auxiliary value for the
    twelve count-concentration events, the Serfling term, the smoothing term,
    and privacy amplification. The multiplicities in Eq. (135) are kept here so
    the factor in the overhead is derived instead of being a hidden constant.
    """

    epsilon_cor: float
    epsilon_sec_prime: float
    epsilon_serfling: float
    epsilon_smoothing: float
    epsilon_pa: float
    concentration_epsilons: Mapping[str, float]

    @classmethod
    def wiesemann_equal_split(cls, eps_tot: float) -> "SecurityBudget":
        if eps_tot <= 0.0:
            raise ValueError("eps_tot must be positive")
        eps_cor = eps_tot / 2.0
        eps_sec_prime = eps_tot / 2.0
        epsilon0 = eps_sec_prime / TWO_DECOY_COMMON_SECURITY_BRANCHES
        return cls(
            epsilon_cor=eps_cor,
            epsilon_sec_prime=eps_sec_prime,
            epsilon_serfling=epsilon0,
            epsilon_smoothing=epsilon0,
            epsilon_pa=epsilon0,
            concentration_epsilons={name: epsilon0 for name in COUNT_CONCENTRATION_EVENTS},
        )

    def total_secrecy_failure(self) -> float:
        concentration_total = sum(self.concentration_epsilons.values())
        return (
            2.0 * self.epsilon_serfling
            + 2.0 * self.epsilon_smoothing
            + self.epsilon_pa
            + concentration_total
        )

    def validate(self) -> None:
        events = set(self.concentration_epsilons)
        expected = set(COUNT_CONCENTRATION_EVENTS)
        missing = sorted(expected - events)
        extra = sorted(events - expected)
        if missing:
            raise ValueError("Missing concentration events: " + ", ".join(missing))
        if extra:
            raise ValueError("Unexpected concentration events: " + ", ".join(extra))

        values = [
            self.epsilon_cor,
            self.epsilon_sec_prime,
            self.epsilon_serfling,
            self.epsilon_smoothing,
            self.epsilon_pa,
            *self.concentration_epsilons.values(),
        ]
        if any(value <= 0.0 or not math.isfinite(value) for value in values):
            raise ValueError("All security parameters must be positive finite values.")

        if self.total_secrecy_failure() > self.epsilon_sec_prime * (1.0 + 1e-12):
            raise ValueError("Allocated secrecy failure exceeds epsilon_sec_prime.")

    def common_auxiliary_value(self, rtol: float = 1e-12) -> float:
        self.validate()
        values = [
            self.epsilon_serfling,
            self.epsilon_smoothing,
            self.epsilon_pa,
            *[self.concentration_epsilons[name] for name in COUNT_CONCENTRATION_EVENTS],
        ]
        reference = values[0]
        if any(abs(value - reference) > rtol * max(1.0, abs(reference)) for value in values):
            raise ValueError("Wiesemann Eq. (137) requires a common auxiliary value.")
        return reference

    def verification_overhead_bits(self) -> float:
        self.validate()
        return math.log2(2.0 / self.epsilon_cor)

    def secrecy_overhead_bits(self) -> float:
        epsilon0 = self.common_auxiliary_value()
        return 4.0 * math.log2(1.0 / ((2.0 ** 0.25) * epsilon0))


@dataclass(frozen=True)
class FiniteDecoyConfig:
    mu: float = 0.5
    nu: float = 0.1
    omega: float = 0.0
    p_mu: float = 0.8
    p_nu: float = 0.15
    p_omega: float = 0.05
    p_z: float = 0.9
    eps_tot: float = 1e-9
    f_ec: float = 1.16
    target_bits: int = 256

    def validate(self) -> None:
        if not (self.mu > self.nu > self.omega >= 0.0):
            raise ValueError("requires mu > nu > omega >= 0")
        if not (self.mu > self.nu + self.omega):
            raise ValueError("Wiesemann A.2 requires mu > nu + omega")
        if min(self.p_mu, self.p_nu, self.p_omega) <= 0.0:
            raise ValueError("all intensity probabilities must be positive")
        if abs(self.p_mu + self.p_nu + self.p_omega - 1.0) > 1e-9:
            raise ValueError("intensity probabilities must sum to one")
        if not (0.0 < self.p_z < 1.0):
            raise ValueError("p_z must lie in (0,1)")
        if self.eps_tot <= 0.0:
            raise ValueError("eps_tot must be positive")


@dataclass(frozen=True)
class BasisCounts:
    detections: dict[str, int]
    errors: dict[str, int]

    @property
    def total_detections(self) -> int:
        return int(sum(self.detections.values()))

    @property
    def total_errors(self) -> int:
        return int(sum(self.errors.values()))


@dataclass(frozen=True)
class FiniteDecoyResult:
    N: int
    loss_db: float
    eta: float
    config: FiniteDecoyConfig
    security_budget: SecurityBudget
    sent_counts: dict[str, dict[str, int]]
    z_counts: BasisCounts
    x_counts: BasisCounts
    s_z0_lower: float
    s_x0_lower: float
    s_z1_lower: float
    s_x1_lower: float
    v_x1_upper: float
    lambda_x_upper: float
    gamma: float
    phase_error_upper: float
    leak_ec: int
    verification_overhead: float
    secrecy_overhead: float
    real_key_length: float
    final_key_length: int
    estimation_feasible: bool
    feasible: bool
    status: str
    failure_reason: str
    n_feas: int | None = None
    ell_previous: int | None = None
    previous_status: str | None = None
    previous_failure_reason: str | None = None
    verified_interval_start: int | None = None
    verified_interval_end: int | None = None
    search_method: str = "direct_evaluation"

    @property
    def z_detection_count(self) -> int:
        return self.z_counts.total_detections

    @property
    def z_error_rate(self) -> float:
        if self.z_counts.total_detections <= 0:
            return 0.5
        return self.z_counts.total_errors / self.z_counts.total_detections


def _intensity_items(cfg: FiniteDecoyConfig) -> list[tuple[str, float, float]]:
    return [("mu", cfg.mu, cfg.p_mu), ("nu", cfg.nu, cfg.p_nu), ("omega", cfg.omega, cfg.p_omega)]


def tau(cfg: FiniteDecoyConfig, m: int) -> float:
    total = 0.0
    for _, intensity, prob in _intensity_items(cfg):
        total += prob * math.exp(-intensity) * (intensity**m) / math.factorial(m)
    return total


def _hoeffding_delta(total: float, eps: float) -> float:
    total = max(0.0, float(total))
    return math.sqrt(total * math.log(1.0 / eps) / 2.0)


def _lower_count(value: int, total: int, eps: float) -> float:
    return max(0.0, float(value) - _hoeffding_delta(total, eps))


def _upper_count(value: int, total: int, eps: float) -> float:
    return min(float(total), float(value) + _hoeffding_delta(total, eps))


def _largest_remainder(values: list[tuple[str, float]], total: int) -> dict[str, int]:
    floors = {name: int(math.floor(value)) for name, value in values}
    remainder = int(total - sum(floors.values()))
    if remainder < 0:
        raise ValueError("largest-remainder allocation overfilled the total")
    fractions = sorted(
        ((value - math.floor(value), name) for name, value in values),
        key=lambda item: (-item[0], item[1]),
    )
    for _frac, name in fractions[:remainder]:
        floors[name] += 1
    return floors


def allocate_sent_pulses(N: int, cfg: FiniteDecoyConfig) -> dict[str, dict[str, int]]:
    """Allocate all sent pulses exactly across basis-pair and intensity categories.

    The finite-decoy formulas use only the matched-basis categories ``ZZ`` and
    ``XX``. Those security-relevant categories are rounded down so increasing
    ``N`` cannot reduce a planning count or silently improve a lower bound. The
    remaining bookkeeping pulses are assigned to a non-key ``remainder`` bucket
    so the total still sums exactly to ``N``.
    """
    cfg.validate()
    if N < 0:
        raise ValueError("N must be nonnegative")
    p_x = 1.0 - cfg.p_z
    basis_pairs = [
        ("ZZ", cfg.p_z * cfg.p_z),
        ("ZX", cfg.p_z * p_x),
        ("XZ", p_x * cfg.p_z),
        ("XX", p_x * p_x),
    ]
    nested = {basis_name: {} for basis_name, _prob in basis_pairs}
    allocated_total = 0
    for basis_name, basis_prob in basis_pairs:
        for intensity_name, _intensity, intensity_prob in _intensity_items(cfg):
            count = int(math.floor(N * basis_prob * intensity_prob))
            nested[basis_name][intensity_name] = count
            allocated_total += count
    nested["remainder"] = {"all": int(N - allocated_total)}
    return nested


def expected_counts(N: int, cfg: FiniteDecoyConfig, channel: ChannelParams) -> tuple[BasisCounts, BasisCounts]:
    cfg.validate()
    sent_counts = allocate_sent_pulses(N, cfg)
    counts: dict[str, BasisCounts] = {}
    for basis, sent_basis in (("Z", "ZZ"), ("X", "XX")):
        det: dict[str, int] = {}
        err: dict[str, int] = {}
        for name, intensity, prob in _intensity_items(cfg):
            _ = prob
            sent = sent_counts[sent_basis][name]
            det[name] = int(math.floor(sent * gain(intensity, channel)))
            err[name] = int(math.ceil(sent * error_gain(intensity, channel)))
            err[name] = min(err[name], det[name])
        counts[basis] = BasisCounts(det, err)
    return counts["Z"], counts["X"]


def _two_decoy_bounds(
    z_counts: BasisCounts,
    x_counts: BasisCounts,
    budget: SecurityBudget,
) -> tuple[dict[str, float], dict[str, float], dict[str, float], dict[str, float], dict[str, float], dict[str, float]]:
    eps = budget.concentration_epsilons
    nZ_m = {
        "nu": _lower_count(z_counts.detections["nu"], z_counts.total_detections, eps["epsilon_n_minus_Z_mu2"]),
        "omega": _lower_count(z_counts.detections["omega"], z_counts.total_detections, eps["epsilon_n_minus_Z_mu3"]),
    }
    nZ_p = {
        "mu": _upper_count(z_counts.detections["mu"], z_counts.total_detections, eps["epsilon_n_plus_Z_mu1"]),
        "nu": _upper_count(z_counts.detections["nu"], z_counts.total_detections, eps["epsilon_n_plus_Z_mu2"]),
        "omega": _upper_count(z_counts.detections["omega"], z_counts.total_detections, eps["epsilon_n_plus_Z_mu3"]),
    }
    nX_m = {
        "nu": _lower_count(x_counts.detections["nu"], x_counts.total_detections, eps["epsilon_n_minus_X_mu2"]),
        "omega": _lower_count(x_counts.detections["omega"], x_counts.total_detections, eps["epsilon_n_minus_X_mu3"]),
    }
    nX_p = {
        "mu": _upper_count(x_counts.detections["mu"], x_counts.total_detections, eps["epsilon_n_plus_X_mu1"]),
        "nu": _upper_count(x_counts.detections["nu"], x_counts.total_detections, eps["epsilon_n_plus_X_mu2"]),
        "omega": _upper_count(x_counts.detections["omega"], x_counts.total_detections, eps["epsilon_n_plus_X_mu3"]),
    }
    cX_m = {
        "omega": _lower_count(x_counts.errors["omega"], x_counts.total_errors, eps["epsilon_c_minus_X_mu3"]),
    }
    cX_p = {
        "nu": _upper_count(x_counts.errors["nu"], x_counts.total_errors, eps["epsilon_c_plus_X_mu2"]),
    }
    return nZ_m, nZ_p, nX_m, nX_p, cX_m, cX_p


def serfling_gamma(eps_phase: float, s_z1: float, s_x1: float) -> float:
    if s_z1 <= 0.0 or s_x1 <= 0.0:
        return float("inf")
    return math.sqrt(((s_z1 + s_x1) * (s_x1 + 1.0)) / (s_z1 * s_x1 * s_x1) * math.log(1.0 / eps_phase))


def evaluate_finite_decoy(
    N: int,
    loss_db: float,
    cfg: FiniteDecoyConfig,
    y0: float = 1e-6,
    e_d: float = 0.01,
    security_budget: SecurityBudget | None = None,
) -> FiniteDecoyResult:
    cfg.validate()
    channel = ChannelParams.from_loss_db(loss_db, y0=y0, e_d=e_d)
    sent_counts = allocate_sent_pulses(N, cfg)
    z_counts, x_counts = expected_counts(N, cfg, channel)
    return evaluate_finite_decoy_from_counts(
        N=N,
        loss_db=loss_db,
        cfg=cfg,
        sent_counts=sent_counts,
        z_counts=z_counts,
        x_counts=x_counts,
        channel=channel,
        security_budget=security_budget,
    )


def evaluate_finite_decoy_from_counts(
    N: int,
    loss_db: float,
    cfg: FiniteDecoyConfig,
    sent_counts: dict[str, dict[str, int]],
    z_counts: BasisCounts,
    x_counts: BasisCounts,
    channel: ChannelParams | None = None,
    security_budget: SecurityBudget | None = None,
) -> FiniteDecoyResult:
    cfg.validate()
    budget = security_budget or SecurityBudget.wiesemann_equal_split(cfg.eps_tot)
    budget.validate()
    channel = channel or ChannelParams.from_loss_db(loss_db)
    t0 = tau(cfg, 0)
    t1 = tau(cfg, 1)
    nZ_m, nZ_p, nX_m, nX_p, cX_m, cX_p = _two_decoy_bounds(z_counts, x_counts, budget)

    mu1, mu2, mu3 = cfg.mu, cfg.nu, cfg.omega
    p1, p2, p3 = cfg.p_mu, cfg.p_nu, cfg.p_omega
    denom0 = mu2 - mu3
    denom1 = mu1 * (mu2 - mu3) - (mu2 * mu2 - mu3 * mu3)

    def vacuum_lower(n_minus: dict[str, float], n_plus: dict[str, float], total: int) -> float:
        value = t0 / denom0 * (
            mu2 * math.exp(mu3) * n_minus["omega"] / p3
            - mu3 * math.exp(mu2) * n_plus["nu"] / p2
        )
        return min(float(total), max(0.0, value))

    s_z0 = vacuum_lower(nZ_m, nZ_p, z_counts.total_detections)
    s_x0 = vacuum_lower(nX_m, nX_p, x_counts.total_detections)

    def single_lower(n_minus: dict[str, float], n_plus: dict[str, float], total: int, s_b0: float) -> float:
        bracket = (
            math.exp(mu2) * n_minus["nu"] / p2
            - math.exp(mu3) * n_plus["omega"] / p3
            + ((mu2 * mu2 - mu3 * mu3) / (mu1 * mu1))
            * (s_b0 / t0 - math.exp(mu1) * n_plus["mu"] / p1)
        )
        value = (mu1 * t1 / denom1) * bracket
        return min(float(total), max(0.0, value))

    s_z1 = single_lower(nZ_m, nZ_p, z_counts.total_detections, s_z0)
    s_x1 = single_lower(nX_m, nX_p, x_counts.total_detections, s_x0)

    v_x1 = t1 / denom0 * (
        math.exp(mu2) * cX_p["nu"] / p2
        - math.exp(mu3) * cX_m["omega"] / p3
    )
    v_x1 = max(0.0, v_x1)
    if s_x1 > 0.0:
        v_x1 = min(v_x1, s_x1)
        lambda_x = min(1.0, max(0.0, v_x1 / s_x1))
    else:
        lambda_x = 1.0

    gamma = serfling_gamma(budget.epsilon_serfling, s_z1, s_x1)
    phase = min(1.0, max(0.0, lambda_x + gamma))
    z_err_rate = z_counts.total_errors / z_counts.total_detections if z_counts.total_detections else 0.5
    leak_ec = int(math.ceil(cfg.f_ec * z_counts.total_detections * binary_entropy(z_err_rate)))
    verification_overhead = budget.verification_overhead_bits()
    secrecy_overhead = budget.secrecy_overhead_bits()
    real_length = s_z0 + s_z1 * (1.0 - truncated_binary_entropy(phase)) - leak_ec - verification_overhead - secrecy_overhead
    ell = int(math.floor(real_length))

    estimation_feasible = bool(s_z1 > 0.0 and s_x1 > 0.0 and math.isfinite(phase) and phase < 0.5)
    feasible = bool(estimation_feasible and ell >= cfg.target_bits)
    if s_z1 <= 0.0:
        status = "insufficient_Z_single_photons"
    elif s_x1 <= 0.0:
        status = "insufficient_X_single_photons"
    elif not math.isfinite(phase):
        status = "invalid_phase_bound"
    elif phase >= 0.5:
        status = "phase_error_at_or_above_half"
    elif ell < 0:
        status = "negative_key_length"
    elif ell < cfg.target_bits:
        status = "reconciliation_cost_too_large"
    else:
        status = "ok"
    failure_reason = "ok" if status == "ok" else status
    return FiniteDecoyResult(
        N=N,
        loss_db=loss_db,
        eta=channel.eta,
        config=cfg,
        security_budget=budget,
        sent_counts=sent_counts,
        z_counts=z_counts,
        x_counts=x_counts,
        s_z0_lower=s_z0,
        s_x0_lower=s_x0,
        s_z1_lower=s_z1,
        s_x1_lower=s_x1,
        v_x1_upper=v_x1,
        lambda_x_upper=lambda_x,
        gamma=gamma,
        phase_error_upper=phase,
        leak_ec=leak_ec,
        verification_overhead=verification_overhead,
        secrecy_overhead=secrecy_overhead,
        real_key_length=real_length,
        final_key_length=ell,
        estimation_feasible=estimation_feasible,
        feasible=feasible,
        status=status,
        failure_reason=failure_reason,
    )
