"""Operating-point layer for main-manuscript finite-decoy resource studies.

The objects in this module deliberately sit above the finite-decoy security
estimator.  They convert externally supplied intensity-level gains and error
rates into deterministic integer planning counts.  A real protocol can bypass
this layer and pass observed integer counts directly to
``evaluate_finite_decoy_from_counts``.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
from collections import Counter
import csv
import math
from pathlib import Path
from typing import Iterable

import numpy as np
from scipy.stats import beta as beta_distribution

from .channel_model import ChannelParams
from .decoy_finite import (
    BasisCounts,
    FiniteDecoyConfig,
    FiniteDecoyResult,
    SecurityBudget,
    allocate_sent_pulses,
    evaluate_finite_decoy_from_counts,
)
from .fixed_output import AcceptancePolicy, build_acceptance_policy


INTENSITY_NAMES: tuple[str, ...] = ("mu", "nu", "omega")


@dataclass(frozen=True)
class DecoyOperatingPoint:
    """Externally supplied decoy operating point.

    The gain ``q_*`` is the click probability conditional on the chosen
    intensity.  The error rate ``e_*`` is the bit-error fraction among those
    clicks.  These are aggregate intensity-level quantities, not photon-number
    yields or photon-number error rates.
    """

    operating_point_id: str
    mu: float
    nu: float
    q_mu: float
    q_nu: float
    q_0: float
    e_mu: float
    e_nu: float
    e_0: float
    loss_db: float | None = None
    description: str = ""
    provenance: str = ""

    def validate(self) -> None:
        if not self.operating_point_id:
            raise ValueError("operating_point_id must be nonempty")
        if not (0.0 < self.nu < self.mu):
            raise ValueError(f"{self.operating_point_id}: requires 0 < nu < mu")
        denominator = self.mu * self.nu - self.nu * self.nu
        if denominator <= 0.0:
            raise ValueError(f"{self.operating_point_id}: nonpositive decoy denominator")
        for name, value in self.gains.items():
            if not (0.0 <= value <= 1.0) or not math.isfinite(value):
                raise ValueError(f"{self.operating_point_id}: invalid gain {name}={value}")
        for name, value in self.error_rates.items():
            if not (0.0 <= value <= 0.5) or not math.isfinite(value):
                raise ValueError(f"{self.operating_point_id}: invalid error rate {name}={value}")
        for name in INTENSITY_NAMES:
            q = self.gains[name]
            t = self.error_gain(name)
            if not (0.0 <= t <= q + 1e-15):
                raise ValueError(f"{self.operating_point_id}: invalid error gain for {name}")

    @property
    def gains(self) -> dict[str, float]:
        return {"mu": self.q_mu, "nu": self.q_nu, "omega": self.q_0}

    @property
    def error_rates(self) -> dict[str, float]:
        return {"mu": self.e_mu, "nu": self.e_nu, "omega": self.e_0}

    def error_gain(self, name: str) -> float:
        if name not in INTENSITY_NAMES:
            raise ValueError(f"unknown intensity name: {name}")
        return self.gains[name] * self.error_rates[name]


@dataclass(frozen=True)
class DecoySourceProbabilities:
    """Free source-selection and basis probabilities for a fixed operating point."""

    p_mu: float = 0.8
    p_nu: float = 0.15
    p_0: float = 0.05
    p_z: float = 0.9

    def validate(self) -> None:
        values = [self.p_mu, self.p_nu, self.p_0, self.p_z]
        if any(not math.isfinite(value) for value in values):
            raise ValueError("source probabilities must be finite")
        if min(self.p_mu, self.p_nu, self.p_0) <= 0.0:
            raise ValueError("p_mu, p_nu, and p_0 must be positive")
        if abs(self.p_mu + self.p_nu + self.p_0 - 1.0) > 1e-9:
            raise ValueError("intensity probabilities must sum to one")
        if not (0.0 < self.p_z < 1.0):
            raise ValueError("p_z must lie in (0,1)")


@dataclass(frozen=True)
class NominalDecoyCounts:
    """Deterministic integer counts generated from an operating point."""

    sent_counts: dict[str, dict[str, int]]
    z_counts: BasisCounts
    x_counts: BasisCounts


@dataclass(frozen=True)
class DecoyFirstCrossing:
    """First-crossing result for the deterministic main-manuscript objective."""

    operating_point: DecoyOperatingPoint
    probabilities: DecoySourceProbabilities
    result: FiniteDecoyResult
    previous_result: FiniteDecoyResult | None
    verified_interval_start: int
    verified_interval_end: int
    search_status: str
    policy_label: str

    @property
    def N_256(self) -> int:
        return self.result.N

    @property
    def ell_previous(self) -> int | None:
        return self.previous_result.final_key_length if self.previous_result else None

    @property
    def previous_failure_reason(self) -> str:
        if self.previous_result is None:
            return "no_previous_point"
        return self.previous_result.failure_reason


@dataclass(frozen=True)
class OperationalDecoyThreshold:
    """Completeness-aware fixed-output threshold for an external operating point."""

    operating_point: DecoyOperatingPoint
    probabilities: DecoySourceProbabilities
    result: FiniteDecoyResult
    policy: AcceptancePolicy
    previous_result: FiniteDecoyResult | None
    previous_policy: AcceptancePolicy | None
    verified_interval_start: int
    verified_interval_end: int
    policy_label: str

    @property
    def N_256(self) -> int:
        return self.result.N


@dataclass(frozen=True)
class OperatingPointSuccessEstimate:
    """Held-out count-acceptance estimate for a frozen decoy policy.

    The simulated trials include random basis and intensity choices, detections,
    and errors.  Reconciliation is deliberately held successful because this
    source-layer study uses an analytical leakage allowance rather than a
    validated decoder.  The resulting probability must therefore not be called
    a full protocol-success probability.
    """

    trials: int
    successes: int
    estimate: float
    lower_95_one_sided: float
    upper_95_one_sided: float
    abort_reasons: dict[str, int]


def _float_or_none(text: str | None) -> float | None:
    if text is None or str(text).strip() == "":
        return None
    return float(text)


def load_operating_points(path: str | Path) -> list[DecoyOperatingPoint]:
    points: list[DecoyOperatingPoint] = []
    with Path(path).open("r", newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        for row in reader:
            point = DecoyOperatingPoint(
                operating_point_id=str(row["operating_point_id"]).strip(),
                mu=float(row["mu"]),
                nu=float(row["nu"]),
                q_mu=float(row["Q_mu"]),
                q_nu=float(row["Q_nu"]),
                q_0=float(row["Q_0"]),
                e_mu=float(row["E_mu"]),
                e_nu=float(row["E_nu"]),
                e_0=float(row["E_0"]),
                loss_db=_float_or_none(row.get("loss_db")),
                description=str(row.get("description", "")),
                provenance=str(row.get("provenance", "")),
            )
            point.validate()
            points.append(point)
    if not points:
        raise ValueError(f"no operating points found in {path}")
    return points


def finite_config_from_operating_point(
    operating_point: DecoyOperatingPoint,
    probabilities: DecoySourceProbabilities,
    eps_tot: float = 1e-9,
    f_ec: float = 1.16,
    target_bits: int = 256,
) -> FiniteDecoyConfig:
    operating_point.validate()
    probabilities.validate()
    cfg = FiniteDecoyConfig(
        mu=operating_point.mu,
        nu=operating_point.nu,
        omega=0.0,
        p_mu=probabilities.p_mu,
        p_nu=probabilities.p_nu,
        p_omega=probabilities.p_0,
        p_z=probabilities.p_z,
        eps_tot=eps_tot,
        f_ec=f_ec,
        target_bits=target_bits,
    )
    cfg.validate()
    return cfg


def build_nominal_decoy_counts(
    N: int,
    operating_point: DecoyOperatingPoint,
    probabilities: DecoySourceProbabilities,
    eps_tot: float = 1e-9,
    f_ec: float = 1.16,
    target_bits: int = 256,
) -> NominalDecoyCounts:
    """Construct conservative deterministic counts for a candidate pulse budget."""

    if N < 0:
        raise ValueError("N must be nonnegative")
    cfg = finite_config_from_operating_point(
        operating_point,
        probabilities,
        eps_tot=eps_tot,
        f_ec=f_ec,
        target_bits=target_bits,
    )
    sent_counts = allocate_sent_pulses(N, cfg)
    basis_counts: dict[str, BasisCounts] = {}
    for public_basis, sent_basis in (("Z", "ZZ"), ("X", "XX")):
        detections: dict[str, int] = {}
        errors: dict[str, int] = {}
        for name in INTENSITY_NAMES:
            sent = sent_counts[sent_basis][name]
            expected_detections = sent * operating_point.gains[name]
            expected_errors = sent * operating_point.error_gain(name)
            detections[name] = int(math.floor(expected_detections))
            errors[name] = min(detections[name], int(math.ceil(expected_errors)))
        basis_counts[public_basis] = BasisCounts(detections=detections, errors=errors)
    return NominalDecoyCounts(
        sent_counts=sent_counts,
        z_counts=basis_counts["Z"],
        x_counts=basis_counts["X"],
    )


def evaluate_decoy_key_length_from_counts(
    N: int,
    operating_point: DecoyOperatingPoint,
    probabilities: DecoySourceProbabilities,
    eps_tot: float = 1e-9,
    f_ec: float = 1.16,
    target_bits: int = 256,
    security_budget: SecurityBudget | None = None,
) -> FiniteDecoyResult:
    """Evaluate the finite-decoy formula from operating-point planning counts."""

    cfg = finite_config_from_operating_point(
        operating_point,
        probabilities,
        eps_tot=eps_tot,
        f_ec=f_ec,
        target_bits=target_bits,
    )
    counts = build_nominal_decoy_counts(
        N,
        operating_point,
        probabilities,
        eps_tot=eps_tot,
        f_ec=f_ec,
        target_bits=target_bits,
    )
    loss_db = operating_point.loss_db if operating_point.loss_db is not None else float("nan")
    eta = 10.0 ** (-loss_db / 10.0) if operating_point.loss_db is not None else 0.0
    return evaluate_finite_decoy_from_counts(
        N=N,
        loss_db=loss_db,
        cfg=cfg,
        sent_counts=counts.sent_counts,
        z_counts=counts.z_counts,
        x_counts=counts.x_counts,
        channel=ChannelParams(eta=eta),
        security_budget=security_budget,
    )


def operational_decoy_candidate(
    N: int,
    operating_point: DecoyOperatingPoint,
    probabilities: DecoySourceProbabilities,
    eps_tot: float = 1e-9,
    f_ec: float = 1.16,
    target_bits: int = 256,
    completeness_beta: float = 0.01,
    margin_scale: float = 3.0,
) -> tuple[FiniteDecoyResult, AcceptancePolicy]:
    """Construct a fixed policy with honest-operation margins at one pulse count."""
    result = evaluate_decoy_key_length_from_counts(
        N,
        operating_point,
        probabilities,
        eps_tot=eps_tot,
        f_ec=f_ec,
        target_bits=target_bits,
    )
    policy = build_acceptance_policy(
        result,
        output_bits=target_bits,
        completeness_beta=completeness_beta,
        margin_scale=margin_scale,
    )
    return result, policy


def find_operational_decoy_threshold(
    operating_point: DecoyOperatingPoint,
    probabilities: DecoySourceProbabilities,
    eps_tot: float = 1e-9,
    f_ec: float = 1.16,
    target_bits: int = 256,
    completeness_beta: float = 0.01,
    margin_scale: float = 3.0,
    start: int = 1024,
    max_N: int = 50_000_000_000,
    exact_scan_limit: int = 1024,
    policy_label: str = "operational-grid",
) -> OperationalDecoyThreshold:
    """Find the first count whose precommitted, margin-bearing policy certifies 256 bits."""
    cache: dict[int, tuple[FiniteDecoyResult, AcceptancePolicy]] = {}

    def candidate(value: int) -> tuple[FiniteDecoyResult, AcceptancePolicy]:
        if value not in cache:
            cache[value] = operational_decoy_candidate(
                value,
                operating_point,
                probabilities,
                eps_tot=eps_tot,
                f_ec=f_ec,
                target_bits=target_bits,
                completeness_beta=completeness_beta,
                margin_scale=margin_scale,
            )
        return cache[value]

    def passes(value: int) -> bool:
        _result, policy = candidate(value)
        return policy.is_certifying()

    high = max(1, start)
    while high < max_N and not passes(high):
        high *= 2
    high = min(high, max_N)
    if not passes(high):
        result, policy = candidate(high)
        return OperationalDecoyThreshold(
            operating_point,
            probabilities,
            result,
            policy,
            None,
            None,
            high,
            high,
            "no_crossing",
        )

    low = 1
    while high - low > exact_scan_limit:
        middle = (low + high) // 2
        if passes(middle):
            high = middle
        else:
            low = middle + 1
    first = high
    for value in range(low, high + 1):
        if passes(value):
            first = value
            break
    result, policy = candidate(first)
    previous_result = previous_policy = None
    if first > 1:
        previous_result, previous_policy = candidate(first - 1)
    return OperationalDecoyThreshold(
        operating_point,
        probabilities,
        result,
        policy,
        previous_result,
        previous_policy,
        low,
        first,
        policy_label,
    )


def simulate_operating_point_trial(
    N: int,
    operating_point: DecoyOperatingPoint,
    probabilities: DecoySourceProbabilities,
    rng: np.random.Generator,
    eps_tot: float = 1e-9,
    f_ec: float = 1.16,
    target_bits: int = 256,
    security_budget: SecurityBudget | None = None,
) -> FiniteDecoyResult:
    """Draw one honest run directly from the supplied gains and error rates."""
    operating_point.validate()
    probabilities.validate()
    cfg = finite_config_from_operating_point(
        operating_point,
        probabilities,
        eps_tot=eps_tot,
        f_ec=f_ec,
        target_bits=target_bits,
    )
    p_x = 1.0 - probabilities.p_z
    basis_probabilities = {
        "ZZ": probabilities.p_z**2,
        "ZX": probabilities.p_z * p_x,
        "XZ": p_x * probabilities.p_z,
        "XX": p_x**2,
    }
    intensity_probabilities = {
        "mu": probabilities.p_mu,
        "nu": probabilities.p_nu,
        "omega": probabilities.p_0,
    }
    labels = [
        (basis, intensity)
        for basis in ("ZZ", "ZX", "XZ", "XX")
        for intensity in INTENSITY_NAMES
    ]
    category_probabilities = [
        basis_probabilities[basis] * intensity_probabilities[intensity]
        for basis, intensity in labels
    ]
    sampled = rng.multinomial(N, category_probabilities)
    sent_counts = {
        basis: {intensity: 0 for intensity in INTENSITY_NAMES}
        for basis in ("ZZ", "ZX", "XZ", "XX")
    }
    for (basis, intensity), count in zip(labels, sampled):
        sent_counts[basis][intensity] = int(count)
    sent_counts["remainder"] = {"all": 0}

    observed: dict[str, BasisCounts] = {}
    for public_basis, sent_basis in (("Z", "ZZ"), ("X", "XX")):
        detections: dict[str, int] = {}
        errors: dict[str, int] = {}
        for intensity in INTENSITY_NAMES:
            sent = sent_counts[sent_basis][intensity]
            detected = int(rng.binomial(sent, operating_point.gains[intensity]))
            wrong = int(rng.binomial(detected, operating_point.error_rates[intensity])) if detected else 0
            detections[intensity] = detected
            errors[intensity] = wrong
        observed[public_basis] = BasisCounts(detections=detections, errors=errors)

    loss_db = operating_point.loss_db if operating_point.loss_db is not None else float("nan")
    eta = 10.0 ** (-loss_db / 10.0) if operating_point.loss_db is not None else 0.0
    return evaluate_finite_decoy_from_counts(
        N=N,
        loss_db=loss_db,
        cfg=cfg,
        sent_counts=sent_counts,
        z_counts=observed["Z"],
        x_counts=observed["X"],
        channel=ChannelParams(eta=eta),
        security_budget=security_budget,
    )


def estimate_operating_point_success(
    threshold: OperationalDecoyThreshold,
    trials: int = 2000,
    seed: int = 12345,
) -> OperatingPointSuccessEstimate:
    """Validate count acceptance of a frozen policy on independent trials.

    ``AcceptancePolicy.failure_reason`` is evaluated with its default
    ``reconciliation_succeeded=True``.  Consequently this routine measures the
    source-count part of honest operation, conditional on reconciliation meeting
    the precommitted leakage cap.
    """
    rng = np.random.default_rng(seed)
    reasons: Counter[str] = Counter()
    successes = 0
    cfg = threshold.result.config
    for _ in range(trials):
        observed = simulate_operating_point_trial(
            threshold.N_256,
            threshold.operating_point,
            threshold.probabilities,
            rng,
            eps_tot=cfg.eps_tot,
            f_ec=cfg.f_ec,
            target_bits=cfg.target_bits,
            security_budget=threshold.policy.security_budget,
        )
        reason = threshold.policy.failure_reason(observed)
        reasons[reason] += 1
        successes += int(reason == "accept")
    if successes == 0:
        lower = 0.0
    else:
        lower = float(beta_distribution.ppf(0.05, successes, trials - successes + 1))
    if successes == trials:
        upper = 1.0
    else:
        upper = float(beta_distribution.ppf(0.95, successes + 1, trials - successes))
    return OperatingPointSuccessEstimate(
        trials=trials,
        successes=successes,
        estimate=successes / trials,
        lower_95_one_sided=lower,
        upper_95_one_sided=upper,
        abort_reasons=dict(sorted(reasons.items())),
    )


def find_first_decoy_crossing(
    operating_point: DecoyOperatingPoint,
    probabilities: DecoySourceProbabilities,
    eps_tot: float = 1e-9,
    f_ec: float = 1.16,
    target_bits: int = 256,
    start: int = 1024,
    max_N: int = 50_000_000_000,
    exact_scan_limit: int = 1024,
    policy_label: str = "fixed",
) -> DecoyFirstCrossing:
    """Find the first deterministic count where ell_decoy reaches target_bits."""

    cache: dict[int, FiniteDecoyResult] = {}

    def evaluate(N: int) -> FiniteDecoyResult:
        if N not in cache:
            cache[N] = evaluate_decoy_key_length_from_counts(
                N,
                operating_point,
                probabilities,
                eps_tot=eps_tot,
                f_ec=f_ec,
                target_bits=target_bits,
            )
        return cache[N]

    def passes(N: int) -> bool:
        result = evaluate(N)
        return bool(result.estimation_feasible and result.final_key_length >= target_bits)

    hi = max(1, start)
    while hi < max_N and not passes(hi):
        hi *= 2
    if not passes(hi):
        result = evaluate(hi)
        previous = evaluate(hi - 1) if hi > 1 else None
        return DecoyFirstCrossing(
            operating_point=operating_point,
            probabilities=probabilities,
            result=result,
            previous_result=previous,
            verified_interval_start=hi,
            verified_interval_end=hi,
            search_status="no_crossing_within_max_N",
            policy_label=policy_label,
        )

    lo = 1
    while hi - lo > exact_scan_limit:
        mid = (lo + hi) // 2
        if passes(mid):
            hi = mid
        else:
            lo = mid + 1

    first_N = hi
    for N in range(lo, hi + 1):
        if passes(N):
            first_N = N
            break
    result = evaluate(first_N)
    previous = evaluate(first_N - 1) if first_N > 1 else None
    if previous is not None and previous.estimation_feasible and previous.final_key_length >= target_bits:
        status = "warning_previous_point_passes"
    else:
        status = "ok"
    return DecoyFirstCrossing(
        operating_point=operating_point,
        probabilities=probabilities,
        result=result,
        previous_result=previous,
        verified_interval_start=lo,
        verified_interval_end=first_N,
        search_status=status,
        policy_label=policy_label,
    )


def probability_grid(
    p_z_values: Iterable[float],
    p_mu_values: Iterable[float],
    p_nu_values: Iterable[float],
) -> list[DecoySourceProbabilities]:
    rows: list[DecoySourceProbabilities] = []
    seen: set[tuple[float, float, float]] = set()
    for p_z in p_z_values:
        for p_mu in p_mu_values:
            for p_nu in p_nu_values:
                p_0 = 1.0 - p_mu - p_nu
                key = (round(p_z, 12), round(p_mu, 12), round(p_nu, 12))
                if key in seen or p_0 <= 1e-12:
                    continue
                seen.add(key)
                probs = DecoySourceProbabilities(
                    p_mu=round(float(p_mu), 12),
                    p_nu=round(float(p_nu), 12),
                    p_0=round(float(p_0), 12),
                    p_z=round(float(p_z), 12),
                )
                probs.validate()
                rows.append(probs)
    return rows


def replace_probabilities(
    crossing: DecoyFirstCrossing,
    probabilities: DecoySourceProbabilities,
    label: str,
) -> DecoyFirstCrossing:
    return replace(crossing, probabilities=probabilities, policy_label=label)
