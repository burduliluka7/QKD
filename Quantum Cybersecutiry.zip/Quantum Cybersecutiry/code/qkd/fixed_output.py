"""Fixed-output output-or-abort layer for the finite decoy calculation."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, replace
import math
from statistics import NormalDist

import numpy as np

from .channel_model import ChannelParams, gain, qber
from .decoy_finite import (
    BasisCounts,
    FiniteDecoyConfig,
    FiniteDecoyResult,
    SecurityBudget,
    evaluate_finite_decoy,
    evaluate_finite_decoy_from_counts,
    serfling_gamma,
)
from .ideal_basis import truncated_binary_entropy


@dataclass(frozen=True)
class AcceptancePolicy:
    """Precommitted fixed-length acceptance rule for a single planned run."""

    output_bits: int
    min_z_detections: int
    min_x_detections: int
    min_s_z0: float
    min_s_z1: float
    min_s_x1: float
    max_lambda_x: float
    max_leak_ec: int
    security_budget: SecurityBudget
    completeness_beta: float
    margin_z: float

    def phase_error_bound(self) -> float:
        gamma = serfling_gamma(self.security_budget.epsilon_serfling, self.min_s_z1, self.min_s_x1)
        return min(1.0, max(0.0, self.max_lambda_x + gamma))

    def certified_real_key_length(self) -> float:
        phase = self.phase_error_bound()
        return (
            self.min_s_z0
            + self.min_s_z1 * (1.0 - truncated_binary_entropy(phase))
            - self.max_leak_ec
            - self.security_budget.verification_overhead_bits()
            - self.security_budget.secrecy_overhead_bits()
        )

    def certified_key_length(self) -> int:
        real_length = self.certified_real_key_length()
        if not math.isfinite(real_length):
            return -10**18
        return int(math.floor(real_length))

    def is_certifying(self) -> bool:
        phase = self.phase_error_bound()
        return bool(
            self.min_s_z1 > 0.0
            and self.min_s_x1 > 0.0
            and math.isfinite(phase)
            and phase < 0.5
            and self.certified_key_length() >= self.output_bits
        )

    def accepts(self, result: FiniteDecoyResult, reconciliation_succeeded: bool = True) -> bool:
        return self.failure_reason(result, reconciliation_succeeded) == "accept"

    def protocol_output(self, result: FiniteDecoyResult, reconciliation_succeeded: bool = True) -> int | None:
        """Return the precommitted length, or None to represent abort."""
        return self.output_bits if self.accepts(result, reconciliation_succeeded) else None

    def failure_reason(self, result: FiniteDecoyResult, reconciliation_succeeded: bool = True) -> str:
        if not reconciliation_succeeded:
            return "reconciliation_failed"
        if not self.is_certifying():
            return "policy_does_not_certify_output_length"
        if result.z_detection_count < self.min_z_detections:
            return "too_few_z_detections"
        if result.x_counts.total_detections < self.min_x_detections:
            return "too_few_x_detections"
        if result.s_z0_lower < self.min_s_z0:
            return "too_few_vacuum_events"
        if result.s_z1_lower < self.min_s_z1:
            return "too_few_z_single_photons"
        if result.s_x1_lower < self.min_s_x1:
            return "too_few_x_single_photons"
        if result.lambda_x_upper > self.max_lambda_x:
            return "single_photon_error_too_high"
        if result.leak_ec > self.max_leak_ec:
            return "leakage_cap_exceeded"
        return "accept"


def boundary_acceptance_policy(
    planning_result: FiniteDecoyResult,
    output_bits: int = 256,
) -> AcceptancePolicy:
    """Freeze the theorem-adverse boundary values of a reported planning row."""
    return AcceptancePolicy(
        output_bits=output_bits,
        min_z_detections=0,
        min_x_detections=0,
        min_s_z0=planning_result.s_z0_lower,
        min_s_z1=planning_result.s_z1_lower,
        min_s_x1=planning_result.s_x1_lower,
        max_lambda_x=planning_result.lambda_x_upper,
        max_leak_ec=planning_result.leak_ec,
        security_budget=planning_result.security_budget,
        completeness_beta=0.0,
        margin_z=0.0,
    )


@dataclass(frozen=True)
class FixedOutputSearchResult:
    """Search result for a fixed-output acceptance protocol."""

    result: FiniteDecoyResult
    policy: AcceptancePolicy
    previous_result: FiniteDecoyResult | None
    previous_policy: AcceptancePolicy | None
    verified_interval_start: int
    verified_interval_end: int
    search_method: str
    honest_success: "HonestSuccessEstimate | None" = None

    @property
    def N(self) -> int:
        return self.result.N

    @property
    def config(self) -> FiniteDecoyConfig:
        return self.result.config

    @property
    def loss_db(self) -> float:
        return self.result.loss_db

    @property
    def fixed_output_bits(self) -> int:
        return self.policy.output_bits


@dataclass(frozen=True)
class HonestSuccessEstimate:
    """Monte Carlo estimate of honest output probability for a fixed policy."""

    trials: int
    successes: int
    estimate: float
    wilson_lower_95: float
    wilson_upper_95: float
    abort_reasons: dict[str, int]


def _normal_margin(beta: float, branch_count: int = 8, scale: float = 3.0) -> float:
    beta = min(max(beta, 1e-12), 0.49)
    return scale * NormalDist().inv_cdf(1.0 - beta / branch_count)


def _lower_margin(value: float, z_margin: float) -> float:
    return max(0.0, math.floor(value - z_margin * math.sqrt(max(value, 1.0))))


def _upper_margin(value: float, z_margin: float) -> int:
    return int(math.ceil(value + z_margin * math.sqrt(max(value, 1.0))))


def build_acceptance_policy(
    planning_result: FiniteDecoyResult,
    output_bits: int = 256,
    completeness_beta: float = 1e-2,
    margin_scale: float = 3.0,
) -> AcceptancePolicy:
    """Build a conservative policy from honest-model planning counts.

    The policy is fixed before the experimental run. It uses lower margins for
    favourable quantities and an upper margin for leakage and the single-photon
    X-error rate. The resulting certificate is still evaluated with the standard
    Wiesemann binary-entropy term.
    """

    z_margin = _normal_margin(completeness_beta, scale=margin_scale)
    lambda_stderr = math.sqrt(
        max(planning_result.lambda_x_upper * (1.0 - planning_result.lambda_x_upper), 1e-8)
        / max(planning_result.s_x1_lower, 1.0)
    )
    max_lambda_x = min(
        0.499,
        planning_result.lambda_x_upper + z_margin * lambda_stderr + 1.0 / max(planning_result.s_x1_lower, 1.0),
    )
    return AcceptancePolicy(
        output_bits=output_bits,
        min_z_detections=int(_lower_margin(planning_result.z_detection_count, z_margin)),
        min_x_detections=int(_lower_margin(planning_result.x_counts.total_detections, z_margin)),
        min_s_z0=_lower_margin(planning_result.s_z0_lower, z_margin),
        min_s_z1=_lower_margin(planning_result.s_z1_lower, z_margin),
        min_s_x1=_lower_margin(planning_result.s_x1_lower, z_margin),
        max_lambda_x=max_lambda_x,
        max_leak_ec=_upper_margin(planning_result.leak_ec, z_margin),
        security_budget=planning_result.security_budget,
        completeness_beta=completeness_beta,
        margin_z=z_margin,
    )


def _build_fixed_candidate(
    N: int,
    loss_db: float,
    cfg: FiniteDecoyConfig,
    y0: float,
    e_d: float,
    output_bits: int,
    completeness_beta: float,
    security_budget: SecurityBudget | None,
    margin_scale: float,
) -> tuple[FiniteDecoyResult, AcceptancePolicy]:
    result = evaluate_finite_decoy(N, loss_db, cfg, y0=y0, e_d=e_d, security_budget=security_budget)
    policy = build_acceptance_policy(
        result,
        output_bits=output_bits,
        completeness_beta=completeness_beta,
        margin_scale=margin_scale,
    )
    return result, policy


def find_fixed_output_threshold(
    loss_db: float,
    cfg: FiniteDecoyConfig,
    y0: float = 1e-6,
    e_d: float = 0.01,
    output_bits: int = 256,
    completeness_beta: float = 1e-2,
    security_budget: SecurityBudget | None = None,
    start: int = 1024,
    max_N: int = 100_000_000_000,
    exact_scan_limit: int = 512,
    margin_scale: float = 3.0,
) -> FixedOutputSearchResult:
    """First crossing for a precommitted fixed-output policy."""

    cache: dict[int, tuple[FiniteDecoyResult, AcceptancePolicy]] = {}

    def candidate(N: int) -> tuple[FiniteDecoyResult, AcceptancePolicy]:
        if N not in cache:
            cache[N] = _build_fixed_candidate(
                N,
                loss_db,
                cfg,
                y0,
                e_d,
                output_bits,
                completeness_beta,
                security_budget,
                margin_scale,
            )
        return cache[N]

    def passes(N: int) -> bool:
        _result, policy = candidate(N)
        return policy.is_certifying()

    hi = max(start, 1)
    while hi < max_N and not passes(hi):
        hi *= 2
    if not passes(hi):
        result, policy = candidate(hi)
        return FixedOutputSearchResult(
            result=result,
            policy=policy,
            previous_result=None,
            previous_policy=None,
            verified_interval_start=hi,
            verified_interval_end=hi,
            search_method="fixed_output_no_crossing",
        )

    interval_start = 1
    interval_end = hi
    while interval_end - interval_start > exact_scan_limit:
        width = interval_end - interval_start
        step = max(1, width // 64)
        if passes(interval_start):
            interval_end = interval_start
            break
        previous = interval_start
        found = False
        sample = interval_start + step
        while sample < interval_end:
            if passes(sample):
                interval_start = previous + 1
                interval_end = sample
                found = True
                break
            previous = sample
            sample += step
        if not found:
            interval_start = previous + 1

    first_N = interval_end
    for N in range(interval_start, interval_end + 1):
        if passes(N):
            first_N = N
            break
    result, policy = candidate(first_N)
    previous_result = previous_policy = None
    if first_N > 1:
        previous_result, previous_policy = candidate(first_N - 1)
    return FixedOutputSearchResult(
        result=result,
        policy=policy,
        previous_result=previous_result,
        previous_policy=previous_policy,
        verified_interval_start=interval_start,
        verified_interval_end=first_N,
        search_method="fixed_output_exponential_bracket_exact_interval_scan",
    )


def simulate_honest_counts(
    N: int,
    loss_db: float,
    cfg: FiniteDecoyConfig,
    rng: np.random.Generator,
    y0: float = 1e-6,
    e_d: float = 0.01,
) -> tuple[dict[str, dict[str, int]], BasisCounts, BasisCounts, ChannelParams]:
    cfg.validate()
    channel = ChannelParams.from_loss_db(loss_db, y0=y0, e_d=e_d)
    p_x = 1.0 - cfg.p_z
    basis_probs = {
        "ZZ": cfg.p_z * cfg.p_z,
        "ZX": cfg.p_z * p_x,
        "XZ": p_x * cfg.p_z,
        "XX": p_x * p_x,
    }
    intensities = [("mu", cfg.mu, cfg.p_mu), ("nu", cfg.nu, cfg.p_nu), ("omega", cfg.omega, cfg.p_omega)]
    labels: list[tuple[str, str, float]] = []
    probs: list[float] = []
    for basis_name, basis_prob in basis_probs.items():
        for intensity_name, _intensity, intensity_prob in intensities:
            labels.append((basis_name, intensity_name, _intensity))
            probs.append(basis_prob * intensity_prob)
    total_prob = sum(probs)
    probs = [prob / total_prob for prob in probs]
    sampled = rng.multinomial(N, probs)
    sent = {basis: {name: 0 for name, _value, _prob in intensities} for basis in basis_probs}
    for (basis_name, intensity_name, _intensity), count in zip(labels, sampled):
        sent[basis_name][intensity_name] = int(count)
    sent["remainder"] = {"all": 0}

    basis_counts: dict[str, BasisCounts] = {}
    for public_basis, basis_name in (("Z", "ZZ"), ("X", "XX")):
        detections: dict[str, int] = {}
        errors: dict[str, int] = {}
        for intensity_name, intensity, _prob in intensities:
            count = sent[basis_name][intensity_name]
            det = int(rng.binomial(count, gain(intensity, channel)))
            err = int(rng.binomial(det, qber(intensity, channel))) if det else 0
            detections[intensity_name] = det
            errors[intensity_name] = min(err, det)
        basis_counts[public_basis] = BasisCounts(detections=detections, errors=errors)
    return sent, basis_counts["Z"], basis_counts["X"], channel


def evaluate_honest_trial(
    N: int,
    loss_db: float,
    cfg: FiniteDecoyConfig,
    rng: np.random.Generator,
    security_budget: SecurityBudget | None = None,
    y0: float = 1e-6,
    e_d: float = 0.01,
) -> FiniteDecoyResult:
    sent, z_counts, x_counts, channel = simulate_honest_counts(N, loss_db, cfg, rng, y0=y0, e_d=e_d)
    return evaluate_finite_decoy_from_counts(
        N=N,
        loss_db=loss_db,
        cfg=cfg,
        sent_counts=sent,
        z_counts=z_counts,
        x_counts=x_counts,
        channel=channel,
        security_budget=security_budget,
    )


def _wilson_interval(successes: int, trials: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if trials <= 0:
        return 0.0, 0.0
    phat = successes / trials
    denom = 1.0 + z * z / trials
    center = (phat + z * z / (2.0 * trials)) / denom
    half = z * math.sqrt((phat * (1.0 - phat) + z * z / (4.0 * trials)) / trials) / denom
    return max(0.0, center - half), min(1.0, center + half)


def estimate_honest_success(
    fixed_result: FixedOutputSearchResult,
    trials: int = 2000,
    seed: int = 12345,
    y0: float = 1e-6,
    e_d: float = 0.01,
) -> HonestSuccessEstimate:
    rng = np.random.default_rng(seed)
    reasons: Counter[str] = Counter()
    successes = 0
    for _trial in range(trials):
        observed = evaluate_honest_trial(
            fixed_result.N,
            fixed_result.loss_db,
            fixed_result.config,
            rng,
            security_budget=fixed_result.policy.security_budget,
            y0=y0,
            e_d=e_d,
        )
        reason = fixed_result.policy.failure_reason(observed)
        reasons[reason] += 1
        if reason == "accept":
            successes += 1
    lower, upper = _wilson_interval(successes, trials)
    return HonestSuccessEstimate(
        trials=trials,
        successes=successes,
        estimate=successes / trials if trials else 0.0,
        wilson_lower_95=lower,
        wilson_upper_95=upper,
        abort_reasons=dict(sorted(reasons.items())),
    )


def attach_honest_success(
    fixed_result: FixedOutputSearchResult,
    trials: int,
    seed: int,
    y0: float = 1e-6,
    e_d: float = 0.01,
) -> FixedOutputSearchResult:
    return replace(
        fixed_result,
        honest_success=estimate_honest_success(fixed_result, trials=trials, seed=seed, y0=y0, e_d=e_d),
    )
