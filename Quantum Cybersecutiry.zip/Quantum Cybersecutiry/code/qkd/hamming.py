"""Finite Hamming-ball utilities.

The report uses base-two logarithms for entropy, while SciPy's special
functions use natural logarithms internally.
"""

from __future__ import annotations

import math
from functools import lru_cache

import numpy as np
from scipy.special import gammaln, logsumexp

LOG2 = math.log(2.0)


def binary_entropy(p: float) -> float:
    """Binary entropy h_2(p), truncated to 1 for p >= 1/2."""
    if p <= 0.0:
        return 0.0
    if p >= 0.5:
        return 1.0
    return -(p * math.log2(p) + (1.0 - p) * math.log2(1.0 - p))


def log2_binom(n: int, k: int) -> float:
    if k < 0 or k > n:
        return float("-inf")
    return float((gammaln(n + 1) - gammaln(k + 1) - gammaln(n - k + 1)) / LOG2)


@lru_cache(maxsize=None)
def log2_hamming_ball(n: int, t: int) -> float:
    """Return log2(sum_{j=0}^t binom(n,j)).

    The exact summation is intended for the finite-block validation and for
    report-size integer radii. For t > n/2 the complement is not needed by the
    current numerical pipeline, so the full sum is used only when moderate.
    """
    if n < 0:
        raise ValueError("n must be nonnegative")
    if t < 0:
        return float("-inf")
    if t >= n:
        return float(n)
    js = np.arange(t + 1, dtype=np.float64)
    terms = gammaln(n + 1) - gammaln(js + 1) - gammaln(n - js + 1)
    return float(logsumexp(terms) / LOG2)


def finite_entropy(n: int, t: int) -> float:
    """F(n,t) = n - log2 B(n,t)."""
    return float(n - log2_hamming_ball(n, t))


def hamming_sandwich(n: int, t: int) -> tuple[float, float, float, float]:
    """Return rigorous bounds for log2 B and F when 0 <= t < n/2.

    Returns (logB_lower, logB_upper, F_lower, F_upper), where
    binom(n,t) <= B(n,t) <= binom(n,t)*(n-t+1)/(n-2t+1).
    """
    if not (0 <= t < n / 2):
        raise ValueError("sandwich bound requires 0 <= t < n/2")
    log_c = log2_binom(n, t)
    ratio = (n - t + 1.0) / (n - 2.0 * t + 1.0)
    log_b_lower = log_c
    log_b_upper = log_c + math.log2(ratio)
    return log_b_lower, log_b_upper, n - log_b_upper, n - log_b_lower


def finite_gain(n: int, t: int) -> float:
    """G(n,t) = n h2(t/n) - log2 B(n,t)."""
    if n <= 0:
        raise ValueError("n must be positive")
    return n * binary_entropy(t / n) - log2_hamming_ball(n, t)


def finite_gain_approx(n: int, q: float) -> float:
    """Leading fixed-q approximation requested in the project brief."""
    if not (0.0 < q < 0.5):
        raise ValueError("q must be in (0, 1/2)")
    return 0.5 * math.log2(2.0 * math.pi * n * q * (1.0 - q)) - math.log2(
        (1.0 - q) / (1.0 - 2.0 * q)
    )
