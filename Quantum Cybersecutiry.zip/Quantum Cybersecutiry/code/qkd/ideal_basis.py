"""Basis-resolved finite-key calculation for the trusted ideal BB84 model."""

from __future__ import annotations

from dataclasses import dataclass
import math
from functools import lru_cache

from scipy.stats import hypergeom

from .hamming import binary_entropy, log2_hamming_ball


@dataclass(frozen=True)
class BasisAllocation:
    N: int
    p_z: float
    n_z: int
    m_x: int
    remainder: int

    @property
    def p_x(self) -> float:
        return 1.0 - self.p_z

    @property
    def matched(self) -> int:
        return self.n_z + self.m_x


@dataclass(frozen=True)
class BasisCountPolicy:
    """Precommitted target counts and the realized matched-basis counts."""

    n_z_target: int
    m_x_target: int
    n_z_observed: int
    m_x_observed: int

    @property
    def accepted_count_condition(self) -> bool:
        return self.n_z_observed >= self.n_z_target and self.m_x_observed >= self.m_x_target

    def selected_block_sizes(self) -> tuple[int, int] | None:
        """Symbolize uniform subsampling of excess matched events, or abort."""
        if not self.accepted_count_condition:
            return None
        return self.n_z_target, self.m_x_target


def basis_count_policy(N: int, p_z: float, n_z_observed: int, m_x_observed: int) -> BasisCountPolicy:
    targets = allocate_basis_counts(N, p_z)
    return BasisCountPolicy(targets.n_z, targets.m_x, int(n_z_observed), int(m_x_observed))


def allocate_basis_counts(N: int, p_z: float) -> BasisAllocation:
    """Conservative deterministic planning counts with every pulse accounted for."""
    if N < 0 or not 0.0 <= p_z <= 1.0:
        raise ValueError("requires N >= 0 and p_z in [0,1]")
    p_x = 1.0 - p_z
    n_z = math.floor(N * p_z * p_z)
    m_x = math.floor(N * p_x * p_x)
    return BasisAllocation(N, p_z, n_z, m_x, N - n_z - m_x)


@lru_cache(maxsize=None)
def hypergeom_total_error_upper(e_x: int, n_z: int, m_x: int, eps_pe: float) -> int:
    """Upper count using a tail probability ``eps_pe**2``.

    ``eps_pe`` is the purified-distance amplitude charged twice in the secrecy
    budget.  The underlying classical sampling failure probability is its
    square, as in the Serfling/conditioning convention used by Wiesemann et al.
    """
    population = n_z + m_x
    if n_z <= 0 or m_x <= 0:
        return population
    low, high, best = 0, population, 0
    while low <= high:
        mid = (low + high) // 2
        cdf = float(hypergeom.cdf(e_x, population, mid, m_x))
        if math.isfinite(cdf) and cdf >= eps_pe * eps_pe:
            best, low = mid, mid + 1
        else:
            high = mid - 1
    return best


def phase_error_upper_for_observation(e_x: int, n_z: int, m_x: int, eps_pe: float) -> int:
    if not 0 <= e_x <= m_x:
        raise ValueError("e_x must be an X-sample error count")
    total = hypergeom_total_error_upper(e_x, n_z, m_x, eps_pe)
    return min(n_z, max(0, total - e_x))


def accepted_phase_error_upper(q_x_tol: float, n_z: int, m_x: int, eps_pe: float) -> tuple[int, int]:
    """Worst phase count over every accepted X-sample observation."""
    e_tol = math.floor(q_x_tol * m_x)
    # K^U(e)-e is nondecreasing under the standard coupling, so the maximum
    # is at the accepted endpoint. Tests compare this reduction to enumeration.
    return e_tol, phase_error_upper_for_observation(e_tol, n_z, m_x, eps_pe)


def split_security_budget(eps_total: float) -> dict[str, float]:
    # eps_cor + 2 eps_pe + 2 eps_smooth + eps_pa = eps_total.  The sampling
    # tail used by hypergeometric inversion is eps_pe**2.
    unit = eps_total / 6.0
    return {"eps_cor": unit, "eps_pe": unit, "eps_smooth": unit, "eps_pa": unit}


def ideal_key_length(
    N: int,
    p_z: float,
    q_x_tol: float,
    q_z_design: float,
    leakage_cap: int | None = None,
    eps_total: float = 1e-9,
) -> dict[str, int | float | bool]:
    allocation = allocate_basis_counts(N, p_z)
    eps = split_security_budget(eps_total)
    e_tol, t_ph = accepted_phase_error_upper(q_x_tol, allocation.n_z, allocation.m_x, eps["eps_pe"])
    if leakage_cap is None:
        leakage_cap = math.ceil(1.1 * allocation.n_z * binary_entropy(q_z_design))
    entropy = 0.0
    if allocation.n_z and t_ph / allocation.n_z <= 0.5:
        entropy = allocation.n_z - log2_hamming_ball(allocation.n_z, t_ph)
    t_ver = math.ceil(math.log2(1.0 / eps["eps_cor"]))
    pa = 2.0 * math.log2(1.0 / eps["eps_pa"])
    real = entropy - leakage_cap - t_ver - pa
    return {
        "N": N, "p_z": p_z, "p_x": 1.0 - p_z,
        "q_x_tol": q_x_tol, "q_z_design": q_z_design,
        "n_Z": allocation.n_z, "m_X": allocation.m_x,
        "unmatched_and_floor_remainder": allocation.remainder,
        "matched_count": allocation.matched,
        "matched_probability": p_z * p_z + (1.0 - p_z) ** 2,
        "e_X_tol": e_tol, "t_ph_upper": t_ph,
        "q_ph_upper": t_ph / allocation.n_z if allocation.n_z else 1.0,
        "entropy_exact": entropy, "L_max": leakage_cap,
        "t_ver": t_ver, "pa_penalty": pa,
        "ell_real": real, "ell": math.floor(real), "passes": math.floor(real) >= 256,
    }


def truncated_binary_entropy(x: float) -> float:
    """Explicit name for h-bar used by the decoy theorem."""
    return binary_entropy(min(max(x, 0.0), 0.5))
