"""Operational-completeness accounting for the ideal-source BB84 study.

The security theorem bounds accepted keys.  This module adds a separate honest-
operation model: basis choices and bit errors are independent, and the actual
bit-error probability is the stated planning value.  It never changes the
security parameter; it only chooses precommitted block and test thresholds that
are likely to be met when the apparatus behaves as planned.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from pathlib import Path

import pandas as pd
from scipy.stats import beta as beta_distribution
from scipy.stats import binom

from .hamming import binary_entropy, log2_hamming_ball
from .ideal_basis import phase_error_upper_for_observation, split_security_budget


@dataclass(frozen=True)
class CascadeValidationPoint:
    """Held-out performance record for one fixed Cascade block and error rate."""

    block_size: int
    qber: float
    design_trials: int
    design_successes: int
    design_accepted_runs: int
    design_success_lower_95: float
    validation_trials: int
    successes: int
    cap_exceedances: int
    accepted_validation_runs: int
    success_lower_95: float
    selection_family_size: int
    selection_adjusted_success_lower_95: float
    parity_query_cap: int
    transcript_cap: int


@dataclass(frozen=True)
class OperationalIdealResult:
    """One completeness-aware ideal-source candidate."""

    N: int
    p_z: float
    q_honest: float
    leakage_model: str
    n_z_available_lower: int
    n_z: int
    m_x: int
    e_x_tol: int
    q_x_tol_effective: float
    t_ph_upper: int
    leakage_cap: int
    ell_real: float
    ell: int
    basis_shortfall_budget: float
    test_abort_budget: float
    cascade_success_source: str
    cascade_success_lower_95: float
    honest_success_lower_95: float

    @property
    def passes(self) -> bool:
        return self.ell >= 256 and self.honest_success_lower_95 >= 0.90


def one_sided_binomial_lower(successes: int, trials: int, alpha: float = 0.05) -> float:
    """Exact one-sided Clopper--Pearson lower confidence endpoint."""
    if trials <= 0 or not 0 <= successes <= trials:
        raise ValueError("requires 0 <= successes <= trials and trials > 0")
    if successes == 0:
        return 0.0
    return float(beta_distribution.ppf(alpha, successes, trials - successes + 1))


def binomial_lower_target(N: int, probability: float, shortfall_budget: float) -> int:
    """Largest convenient target with Pr[count < target] <= budget.

    ``binom.ppf`` returns the first integer whose cumulative probability reaches
    the budget.  Using that integer as the target makes the strict-lower tail
    no larger than the requested budget.
    """
    if N < 0 or not 0.0 <= probability <= 1.0 or not 0.0 < shortfall_budget < 1.0:
        raise ValueError("invalid binomial target inputs")
    return max(0, int(binom.ppf(shortfall_budget, N, probability)))


def binomial_upper_acceptance_count(trials: int, error_probability: float, abort_budget: float) -> int:
    """Smallest integer threshold accepting with probability at least 1-budget."""
    if trials < 0 or not 0.0 <= error_probability <= 1.0 or not 0.0 < abort_budget < 1.0:
        raise ValueError("invalid binomial acceptance inputs")
    return min(trials, int(binom.ppf(1.0 - abort_budget, trials, error_probability)))


def load_cascade_validation(
    path: str | Path,
    confidence_alpha: float = 0.05,
) -> dict[tuple[int, float], CascadeValidationPoint]:
    """Build fixed padded-transcript records from the raw Cascade trials.

    Each parity query is represented by two public bits: the parity supplied by
    one party and the other party's match/branch response.  A run is padded to a
    fixed cap, so transcript length itself reveals nothing.  The first half of
    the trials chooses the cap; the second half independently measures the
    probability of both reconciling successfully and staying within it.  The
    cap is twice the largest parity-query count in the design half.  This is
    deliberately more conservative than treating a parity-query count as the
    whole public transcript.  Because six block sizes are later compared at
    each fixed error probability, the record stores both the ordinary
    pointwise lower confidence endpoint and an alpha/6 endpoint whose six-way
    simultaneous coverage is at least 95% by the union bound.
    """
    frame = pd.read_csv(path)
    frame = frame[frame["protocol"].astype(str).str.lower().str.contains("cascade")].copy()
    family_sizes = frame.groupby("qber")["n"].nunique().to_dict()
    records: dict[tuple[int, float], CascadeValidationPoint] = {}
    for (block_size, qber), group in frame.groupby(["n", "qber"], sort=True):
        group = group.sort_values("trial").reset_index(drop=True)
        split = len(group) // 2
        design = group.iloc[:split]
        validation = group.iloc[split:]
        if design.empty or validation.empty:
            raise ValueError("each Cascade point needs separate design and validation trials")
        parity_cap = int(math.ceil(float(design["leakage_bits"].max())))
        design_success = design["success"].astype(bool)
        design_within_cap = design["leakage_bits"].astype(float) <= parity_cap
        design_accepted = design_success & design_within_cap
        validation_success = validation["success"].astype(bool)
        validation_within_cap = validation["leakage_bits"].astype(float) <= parity_cap
        accepted = validation_success & validation_within_cap
        design_successes = int(design_success.sum())
        design_accepted_runs = int(design_accepted.sum())
        successes = int(validation_success.sum())
        cap_exceedances = int((~validation_within_cap).sum())
        accepted_runs = int(accepted.sum())
        validation_trials = int(len(validation))
        family_size = int(family_sizes[float(qber)])
        record = CascadeValidationPoint(
            block_size=int(block_size),
            qber=float(qber),
            design_trials=int(len(design)),
            design_successes=design_successes,
            design_accepted_runs=design_accepted_runs,
            design_success_lower_95=one_sided_binomial_lower(
                design_accepted_runs,
                int(len(design)),
                confidence_alpha,
            ),
            validation_trials=validation_trials,
            successes=successes,
            cap_exceedances=cap_exceedances,
            accepted_validation_runs=accepted_runs,
            success_lower_95=one_sided_binomial_lower(accepted_runs, validation_trials, confidence_alpha),
            selection_family_size=family_size,
            selection_adjusted_success_lower_95=one_sided_binomial_lower(
                accepted_runs,
                validation_trials,
                confidence_alpha / family_size,
            ),
            parity_query_cap=parity_cap,
            transcript_cap=2 * parity_cap,
        )
        records[(record.block_size, round(record.qber, 12))] = record
    if not records:
        raise ValueError(f"no Cascade trials found in {path}")
    return records


def evaluate_operational_ideal(
    N: int,
    p_z: float,
    q_honest: float,
    leakage_model: str,
    cascade_records: dict[tuple[int, float], CascadeValidationPoint] | None = None,
    cascade_block_size: int | None = None,
    cascade_success_source: str = "validation",
    eps_total: float = 1e-9,
    basis_shortfall_budget: float = 0.01,
    test_abort_budget: float = 0.01,
) -> OperationalIdealResult | None:
    """Evaluate one precommitted policy under the explicit honest model."""
    if leakage_model not in {"analytic_fec_1_1", "cascade_four_pass"}:
        raise ValueError("unknown leakage model")
    if cascade_success_source not in {"design", "validation", "selection_adjusted"}:
        raise ValueError(
            "cascade_success_source must be 'design', 'validation', or 'selection_adjusted'"
        )
    branch_basis = basis_shortfall_budget / 2.0
    n_available = binomial_lower_target(N, p_z * p_z, branch_basis)
    m_x = binomial_lower_target(N, (1.0 - p_z) ** 2, branch_basis)
    if n_available <= 0 or m_x <= 0:
        return None

    if leakage_model == "analytic_fec_1_1":
        n_z = n_available
        leakage_cap = int(math.ceil(1.1 * n_z * binary_entropy(q_honest)))
        cascade_success = 1.0
        success_source = "not_applicable"
    else:
        if cascade_records is None or cascade_block_size is None:
            raise ValueError("Cascade evaluation requires a validation table and fixed block size")
        record = cascade_records.get((int(cascade_block_size), round(float(q_honest), 12)))
        if record is None or n_available < record.block_size:
            return None
        n_z = record.block_size
        leakage_cap = record.transcript_cap
        if cascade_success_source == "design":
            cascade_success = record.design_success_lower_95
        elif cascade_success_source == "selection_adjusted":
            cascade_success = record.selection_adjusted_success_lower_95
        else:
            cascade_success = record.success_lower_95
        success_source = cascade_success_source

    e_x_tol = binomial_upper_acceptance_count(m_x, q_honest, test_abort_budget)
    eps = split_security_budget(eps_total)
    t_ph = phase_error_upper_for_observation(e_x_tol, n_z, m_x, eps["eps_pe"])
    entropy = 0.0
    if t_ph / n_z <= 0.5:
        entropy = n_z - log2_hamming_ball(n_z, t_ph)
    verification = math.ceil(math.log2(1.0 / eps["eps_cor"]))
    privacy = 2.0 * math.log2(1.0 / eps["eps_pa"])
    real_length = entropy - leakage_cap - verification - privacy

    # No independence is needed for this lower bound: the union bound subtracts
    # the four possible honest abort contributions.
    honest_lower = max(
        0.0,
        1.0 - basis_shortfall_budget - test_abort_budget - (1.0 - cascade_success),
    )
    return OperationalIdealResult(
        N=N,
        p_z=p_z,
        q_honest=q_honest,
        leakage_model=leakage_model,
        n_z_available_lower=n_available,
        n_z=n_z,
        m_x=m_x,
        e_x_tol=e_x_tol,
        q_x_tol_effective=e_x_tol / m_x,
        t_ph_upper=t_ph,
        leakage_cap=leakage_cap,
        ell_real=real_length,
        ell=math.floor(real_length),
        basis_shortfall_budget=basis_shortfall_budget,
        test_abort_budget=test_abort_budget,
        cascade_success_source=success_source,
        cascade_success_lower_95=cascade_success,
        honest_success_lower_95=honest_lower,
    )


def find_operational_ideal_threshold(
    p_z: float,
    q_honest: float,
    leakage_model: str,
    cascade_records: dict[tuple[int, float], CascadeValidationPoint] | None = None,
    cascade_block_size: int | None = None,
    cascade_success_source: str = "validation",
    max_N: int = 500_000,
    local_window: int = 128,
) -> OperationalIdealResult | None:
    """Locate the first crossing, then scan a local window for integer jumps."""

    def candidate(value: int) -> OperationalIdealResult | None:
        return evaluate_operational_ideal(
            value,
            p_z,
            q_honest,
            leakage_model,
            cascade_records=cascade_records,
            cascade_block_size=cascade_block_size,
            cascade_success_source=cascade_success_source,
        )

    def passes(value: int) -> bool:
        result = candidate(value)
        return result is not None and result.passes

    high = 256
    while high < max_N and not passes(high):
        high *= 2
    if high > max_N:
        high = max_N
    if not passes(high):
        return None
    low = 256
    while low < high:
        middle = (low + high) // 2
        if passes(middle):
            high = middle
        else:
            low = middle + 1
    start = max(256, low - local_window)
    for value in range(start, low + 1):
        result = candidate(value)
        if result is not None and result.passes:
            return result
    return candidate(low)
