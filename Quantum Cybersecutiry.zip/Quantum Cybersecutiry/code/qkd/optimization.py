"""Search helpers for deterministic decoy planning."""

from __future__ import annotations

from dataclasses import replace
from itertools import product
from typing import Callable

from scipy.optimize import differential_evolution

from .decoy_finite import FiniteDecoyConfig, FiniteDecoyResult, evaluate_finite_decoy
from .fixed_output import FixedOutputSearchResult, find_fixed_output_threshold


def _find_first_by_interval_scan(
    loss_db: float,
    cfg: FiniteDecoyConfig,
    predicate: Callable[[FiniteDecoyResult], bool],
    y0: float,
    e_d: float,
    start: int,
    max_N: int,
    exact_scan_limit: int,
) -> tuple[FiniteDecoyResult, int, int, dict[int, FiniteDecoyResult]]:
    """Find a first passing point with bracketing and an exact final scan.

    The interval reduction samples boundaries and then scans every integer in
    the final interval. This avoids presenting the returned point as a global
    mathematical minimum when the full function has only been verified on the
    recorded final interval.
    """
    cache: dict[int, FiniteDecoyResult] = {}

    def eval_cached(N: int) -> FiniteDecoyResult:
        if N not in cache:
            cache[N] = evaluate_finite_decoy(N, loss_db, cfg, y0=y0, e_d=e_d)
        return cache[N]

    hi = max(start, 1)
    while hi < max_N and not predicate(eval_cached(hi)):
        hi *= 2
    if not predicate(eval_cached(hi)):
        return eval_cached(hi), hi, hi, cache

    interval_start = 1
    interval_end = hi
    while interval_end - interval_start > exact_scan_limit:
        width = interval_end - interval_start
        step = max(1, width // 64)
        if predicate(eval_cached(interval_start)):
            interval_end = interval_start
            break
        previous = interval_start
        found = False
        sample = interval_start + step
        while sample < interval_end:
            if predicate(eval_cached(sample)):
                interval_start = previous + 1
                interval_end = sample
                found = True
                break
            previous = sample
            sample += step
        if not found:
            interval_start = previous + 1

    first = eval_cached(interval_end)
    for N in range(interval_start, interval_end + 1):
        res = eval_cached(N)
        if predicate(res):
            first = res
            break
    return first, interval_start, first.N, cache


def find_minimum_N(
    loss_db: float,
    cfg: FiniteDecoyConfig,
    y0: float = 1e-6,
    e_d: float = 0.01,
    start: int = 1024,
    max_N: int = 50_000_000_000,
    local_window: int = 512,
) -> FiniteDecoyResult:
    """Return the first locally verified 256-bit crossing for a fixed tuple."""
    n_feas, _feas_start, _feas_end, _feas_cache = _find_first_by_interval_scan(
        loss_db,
        cfg,
        lambda r: r.estimation_feasible,
        y0,
        e_d,
        start,
        max_N,
        max(64, local_window),
    )
    best, checked_start, checked_end, cache = _find_first_by_interval_scan(
        loss_db,
        cfg,
        lambda r: r.feasible,
        y0,
        e_d,
        start,
        max_N,
        max(64, local_window),
    )
    if not best.feasible:
        return replace(
            best,
            n_feas=n_feas.N if n_feas.estimation_feasible else None,
            verified_interval_start=checked_start,
            verified_interval_end=checked_end,
            search_method="exponential_bracket_interval_scan_no_crossing",
        )
    previous = cache.get(best.N - 1) if best.N > 1 else None
    if previous is None and best.N > 1:
        previous = evaluate_finite_decoy(best.N - 1, loss_db, cfg, y0=y0, e_d=e_d)
    return replace(
        best,
        n_feas=n_feas.N if n_feas.estimation_feasible else None,
        ell_previous=previous.final_key_length if previous else None,
        previous_status=previous.status if previous else None,
        previous_failure_reason=previous.failure_reason if previous else None,
        verified_interval_start=checked_start,
        verified_interval_end=checked_end,
        search_method="exponential_bracket_boundary_refinement_exact_interval_scan",
    )


def optimize_grid(
    loss_db: float,
    base_cfg: FiniteDecoyConfig,
    y0: float = 1e-6,
    e_d: float = 0.01,
    quick: bool = False,
) -> list[FiniteDecoyResult]:
    """Evaluate the requested coarse grid and return feasible results sorted by N."""
    if quick:
        mus = [0.4, 0.5]
        nus = [0.1]
        pzs = [0.9]
        pmus = [0.8]
        pnus = [0.1, 0.15]
    else:
        mus = [0.3, 0.4, 0.5, 0.6, 0.7]
        nus = [0.05, 0.10, 0.15, 0.20]
        pzs = [0.80, 0.90, 0.95]
        pmus = [0.70, 0.80, 0.90]
        pnus = [0.05, 0.10, 0.20]

    return search_parameter_grid(
        loss_db,
        base_cfg,
        {"mu": mus, "nu": nus, "p_z": pzs, "p_mu": pmus, "p_nu": pnus},
        y0=y0,
        e_d=e_d,
    )


def search_parameter_grid(
    loss_db: float,
    base_cfg: FiniteDecoyConfig,
    grids: dict[str, list[float]],
    y0: float = 1e-6,
    e_d: float = 0.01,
) -> list[FiniteDecoyResult]:
    """Evaluate a deterministic parameter grid and return feasible rows sorted by N."""
    mus = grids.get("mu", [base_cfg.mu])
    nus = grids.get("nu", [base_cfg.nu])
    pzs = grids.get("p_z", [base_cfg.p_z])
    pmus = grids.get("p_mu", [base_cfg.p_mu])
    pnus = grids.get("p_nu", [base_cfg.p_nu])

    results: list[FiniteDecoyResult] = []
    seen: set[tuple[float, float, float, float, float]] = set()
    for mu, nu, p_z, p_mu, p_nu in product(mus, nus, pzs, pmus, pnus):
        key = (round(mu, 12), round(nu, 12), round(p_z, 12), round(p_mu, 12), round(p_nu, 12))
        if key in seen:
            continue
        seen.add(key)
        p_omega = 1.0 - p_mu - p_nu
        if not (0.0 < nu < mu and p_omega > 0.0):
            continue
        cfg = replace(
            base_cfg,
            mu=mu,
            nu=nu,
            omega=0.0,
            p_mu=p_mu,
            p_nu=p_nu,
            p_omega=p_omega,
            p_z=p_z,
        )
        try:
            res = find_minimum_N(loss_db, cfg, y0=y0, e_d=e_d)
        except ValueError:
            continue
        if res.feasible:
            results.append(res)
    results.sort(key=lambda r: (r.N, -r.final_key_length))
    return results


def one_dimensional_boundary_probes(
    loss_db: float,
    center: FiniteDecoyConfig,
    y0: float = 1e-6,
    e_d: float = 0.01,
) -> list[tuple[str, FiniteDecoyResult]]:
    """Stage-A probes requested in the audit brief."""
    domains = {
        "p_z": [0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90],
        "p_mu": [0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80],
        "p_nu": [0.05, 0.10, 0.15, 0.20, 0.25, 0.30],
        "nu": [0.10, 0.15, 0.20, 0.25, 0.30],
        "mu": [0.30, 0.40, 0.50, 0.60, 0.70],
    }
    rows: list[tuple[str, FiniteDecoyResult]] = []
    for name, values in domains.items():
        for value in values:
            updates = {name: value}
            p_mu = updates.get("p_mu", center.p_mu)
            p_nu = updates.get("p_nu", center.p_nu)
            p_omega = 1.0 - p_mu - p_nu
            updates["p_omega"] = p_omega
            cfg = replace(center, **updates)
            if not (0.0 < cfg.nu < cfg.mu and cfg.p_omega > 0.0):
                continue
            try:
                cfg.validate()
                res = find_minimum_N(loss_db, cfg, y0=y0, e_d=e_d)
            except ValueError:
                continue
            if res.feasible:
                rows.append((name, res))
    return rows


def refined_local_grid(
    loss_db: float,
    center: FiniteDecoyConfig,
    y0: float = 1e-6,
    e_d: float = 0.01,
) -> list[FiniteDecoyResult]:
    """Stage-B local grid near the active coarse-grid boundaries."""
    grids = {
        "mu": sorted({center.mu, max(0.25, center.mu - 0.10), center.mu + 0.10}),
        "nu": sorted({0.15, 0.20, 0.25, 0.30, center.nu}),
        "p_z": sorted({0.60, 0.65, 0.70, 0.75, 0.80, center.p_z}),
        "p_mu": sorted({0.50, 0.55, 0.60, 0.65, 0.70, 0.75, center.p_mu}),
        "p_nu": sorted({0.10, 0.15, 0.20, 0.25, 0.30, center.p_nu}),
    }
    return search_parameter_grid(loss_db, center, grids, y0=y0, e_d=e_d)


def coordinate_descent_search(
    loss_db: float,
    center: FiniteDecoyConfig,
    y0: float = 1e-6,
    e_d: float = 0.01,
    rounds: int = 2,
) -> FiniteDecoyResult:
    """Small deterministic derivative-free local search around a candidate."""
    best = find_minimum_N(loss_db, center, y0=y0, e_d=e_d)
    cfg = center
    for _round in range(rounds):
        improved = False
        candidates: list[FiniteDecoyConfig] = []
        for delta in (-0.05, 0.05):
            candidates.append(replace(cfg, mu=round(cfg.mu + delta, 4)))
        for delta in (-0.025, 0.025):
            candidates.append(replace(cfg, nu=round(cfg.nu + delta, 4)))
            candidates.append(replace(cfg, p_z=round(cfg.p_z + delta, 4)))
            candidates.append(replace(cfg, p_mu=round(cfg.p_mu + delta, 4), p_omega=1.0 - round(cfg.p_mu + delta, 4) - cfg.p_nu))
            candidates.append(replace(cfg, p_nu=round(cfg.p_nu + delta, 4), p_omega=1.0 - cfg.p_mu - round(cfg.p_nu + delta, 4)))
        for cand in candidates:
            if not (
                0.30 <= cand.mu <= 0.80
                and 0.05 <= cand.nu <= 0.30
                and 0.0 < cand.nu < cand.mu
                and 0.60 <= cand.p_z <= 0.90
                and 0.50 <= cand.p_mu <= 0.80
                and 0.05 <= cand.p_nu <= 0.30
                and cand.p_omega > 0.0
            ):
                continue
            try:
                cand.validate()
                res = find_minimum_N(loss_db, cand, y0=y0, e_d=e_d)
            except ValueError:
                continue
            if res.feasible and (not best.feasible or res.N < best.N):
                best = res
                cfg = cand
                improved = True
        if not improved:
            break
    return best


def find_minimum_fixed_output_N(
    loss_db: float,
    cfg: FiniteDecoyConfig,
    y0: float = 1e-6,
    e_d: float = 0.01,
    output_bits: int = 256,
    completeness_beta: float = 1e-2,
    start: int = 1024,
    max_N: int = 100_000_000_000,
    local_window: int = 512,
    margin_scale: float = 12.0,
) -> FixedOutputSearchResult:
    return find_fixed_output_threshold(
        loss_db,
        cfg,
        y0=y0,
        e_d=e_d,
        output_bits=output_bits,
        completeness_beta=completeness_beta,
        start=start,
        max_N=max_N,
        exact_scan_limit=max(64, local_window),
        margin_scale=margin_scale,
    )


def search_fixed_output_grid(
    loss_db: float,
    base_cfg: FiniteDecoyConfig,
    grids: dict[str, list[float]],
    y0: float = 1e-6,
    e_d: float = 0.01,
    output_bits: int = 256,
    completeness_beta: float = 1e-2,
    margin_scale: float = 12.0,
) -> list[FixedOutputSearchResult]:
    """Evaluate a deterministic grid under the fixed-output objective."""
    mus = grids.get("mu", [base_cfg.mu])
    nus = grids.get("nu", [base_cfg.nu])
    pzs = grids.get("p_z", [base_cfg.p_z])
    pmus = grids.get("p_mu", [base_cfg.p_mu])
    pnus = grids.get("p_nu", [base_cfg.p_nu])

    results: list[FixedOutputSearchResult] = []
    seen: set[tuple[float, float, float, float, float]] = set()
    for mu, nu, p_z, p_mu, p_nu in product(mus, nus, pzs, pmus, pnus):
        key = (round(mu, 12), round(nu, 12), round(p_z, 12), round(p_mu, 12), round(p_nu, 12))
        if key in seen:
            continue
        seen.add(key)
        p_omega = 1.0 - p_mu - p_nu
        if not (0.0 < nu < mu and p_omega > 0.0):
            continue
        cfg = replace(
            base_cfg,
            mu=mu,
            nu=nu,
            omega=0.0,
            p_mu=p_mu,
            p_nu=p_nu,
            p_omega=p_omega,
            p_z=p_z,
        )
        try:
            cfg.validate()
            res = find_minimum_fixed_output_N(
                loss_db,
                cfg,
                y0=y0,
                e_d=e_d,
                output_bits=output_bits,
                completeness_beta=completeness_beta,
                margin_scale=margin_scale,
            )
        except ValueError:
            continue
        if res.policy.is_certifying():
            results.append(res)
    results.sort(key=lambda r: (r.N, -r.policy.certified_key_length()))
    return results


def optimize_fixed_output_grid(
    loss_db: float,
    base_cfg: FiniteDecoyConfig,
    y0: float = 1e-6,
    e_d: float = 0.01,
    quick: bool = False,
    output_bits: int = 256,
    completeness_beta: float = 1e-2,
    margin_scale: float = 12.0,
) -> list[FixedOutputSearchResult]:
    if quick:
        grids = {
            "mu": [0.6, 0.8],
            "nu": [0.25, 0.30],
            "p_z": [0.6],
            "p_mu": [0.5],
            "p_nu": [0.25, 0.30],
        }
    else:
        grids = {
            "mu": [0.3, 0.4, 0.5, 0.6, 0.7],
            "nu": [0.05, 0.10, 0.15, 0.20],
            "p_z": [0.80, 0.90, 0.95],
            "p_mu": [0.70, 0.80, 0.90],
            "p_nu": [0.05, 0.10, 0.20],
        }
    return search_fixed_output_grid(
        loss_db,
        base_cfg,
        grids,
        y0=y0,
        e_d=e_d,
        output_bits=output_bits,
        completeness_beta=completeness_beta,
        margin_scale=margin_scale,
    )


def refined_fixed_output_grid(
    loss_db: float,
    center: FiniteDecoyConfig,
    y0: float = 1e-6,
    e_d: float = 0.01,
    output_bits: int = 256,
    completeness_beta: float = 1e-2,
    margin_scale: float = 12.0,
) -> list[FixedOutputSearchResult]:
    grids = {
        "mu": sorted({round(center.mu + delta, 3) for delta in (-0.08, 0.0, 0.08)}),
        "nu": sorted({round(center.nu + delta, 3) for delta in (-0.04, 0.0, 0.04)}),
        "p_z": sorted({round(center.p_z + delta, 3) for delta in (-0.06, 0.0, 0.06)}),
        "p_mu": sorted({round(center.p_mu + delta, 3) for delta in (-0.06, 0.0, 0.06)}),
        "p_nu": sorted({round(center.p_nu + delta, 3) for delta in (-0.04, 0.0, 0.04)}),
    }
    grids["mu"] = [x for x in grids["mu"] if 0.25 <= x <= 0.9]
    grids["nu"] = [x for x in grids["nu"] if 0.03 <= x <= 0.4]
    grids["p_z"] = [x for x in grids["p_z"] if 0.50 <= x <= 0.90]
    grids["p_mu"] = [x for x in grids["p_mu"] if 0.40 <= x <= 0.85]
    grids["p_nu"] = [x for x in grids["p_nu"] if 0.05 <= x <= 0.40]
    return search_fixed_output_grid(
        loss_db,
        center,
        grids,
        y0=y0,
        e_d=e_d,
        output_bits=output_bits,
        completeness_beta=completeness_beta,
        margin_scale=margin_scale,
    )


def coordinate_descent_fixed_output_search(
    loss_db: float,
    center: FiniteDecoyConfig,
    y0: float = 1e-6,
    e_d: float = 0.01,
    rounds: int = 2,
    output_bits: int = 256,
    completeness_beta: float = 1e-2,
    margin_scale: float = 12.0,
) -> FixedOutputSearchResult:
    best = find_minimum_fixed_output_N(
        loss_db,
        center,
        y0=y0,
        e_d=e_d,
        output_bits=output_bits,
        completeness_beta=completeness_beta,
        margin_scale=margin_scale,
    )
    cfg = center
    for round_index in range(rounds):
        step_mu = 0.05 / (round_index + 1)
        step_other = 0.025 / (round_index + 1)
        candidates: list[FiniteDecoyConfig] = []
        for delta in (-step_mu, step_mu):
            candidates.append(replace(cfg, mu=round(cfg.mu + delta, 4)))
        for delta in (-step_other, step_other):
            candidates.append(replace(cfg, nu=round(cfg.nu + delta, 4)))
            candidates.append(replace(cfg, p_z=round(cfg.p_z + delta, 4)))
            p_mu = round(cfg.p_mu + delta, 4)
            candidates.append(replace(cfg, p_mu=p_mu, p_omega=1.0 - p_mu - cfg.p_nu))
            p_nu = round(cfg.p_nu + delta, 4)
            candidates.append(replace(cfg, p_nu=p_nu, p_omega=1.0 - cfg.p_mu - p_nu))

        improved = False
        for cand in candidates:
            if not (
                0.25 <= cand.mu <= 0.90
                and 0.03 <= cand.nu <= 0.40
                and 0.0 < cand.nu < cand.mu
                and 0.50 <= cand.p_z <= 0.90
                and 0.40 <= cand.p_mu <= 0.85
                and 0.05 <= cand.p_nu <= 0.40
                and cand.p_omega > 0.0
            ):
                continue
            try:
                cand.validate()
                res = find_minimum_fixed_output_N(
                    loss_db,
                    cand,
                    y0=y0,
                    e_d=e_d,
                    output_bits=output_bits,
                    completeness_beta=completeness_beta,
                    margin_scale=margin_scale,
                )
            except ValueError:
                continue
            if res.policy.is_certifying() and res.N < best.N:
                best = res
                cfg = cand
                improved = True
        if not improved:
            break
    return best


def _decode_de_vector(base_cfg: FiniteDecoyConfig, vector: tuple[float, float, float, float, float]) -> FiniteDecoyConfig:
    mu = float(vector[0])
    nu_fraction = float(vector[1])
    nu = 0.01 + nu_fraction * (mu - 0.0101)
    p_z = float(vector[2])
    p_mu = float(vector[3])
    decoy_split = float(vector[4])
    remaining = 1.0 - p_mu
    p_nu = remaining * decoy_split
    p_omega = remaining * (1.0 - decoy_split)
    return replace(
        base_cfg,
        mu=round(mu, 5),
        nu=round(nu, 5),
        omega=0.0,
        p_z=round(p_z, 5),
        p_mu=round(p_mu, 5),
        p_nu=round(p_nu, 5),
        p_omega=round(p_omega, 5),
    )


def differential_evolution_fixed_output_search(
    loss_db: float,
    base_cfg: FiniteDecoyConfig,
    y0: float = 1e-6,
    e_d: float = 0.01,
    output_bits: int = 256,
    completeness_beta: float = 1e-2,
    margin_scale: float = 12.0,
    seeds: tuple[int, ...] = (12345, 67890),
    maxiter: int = 4,
    popsize: int = 5,
    local_window: int = 128,
) -> list[FixedOutputSearchResult]:
    """Moderate global search using a constrained parameterization.

    The variables are mu, a nu fraction constrained below mu, p_Z, p_mu, and
    a split of the remaining probability between weak decoy and vacuum.
    """

    cache: dict[tuple[float, float, float, float, float], FixedOutputSearchResult] = {}
    bounds = [
        (0.1, 1.0),
        (0.0, 0.999),
        (0.5, 0.95),
        (0.05, 0.90),
        (0.03, 0.97),
    ]

    def evaluate_vector(vector: tuple[float, float, float, float, float]) -> float:
        cfg = _decode_de_vector(base_cfg, vector)
        key = (cfg.mu, cfg.nu, cfg.p_z, cfg.p_mu, cfg.p_nu)
        if key in cache:
            return float(cache[key].N)
        try:
            cfg.validate()
            res = find_minimum_fixed_output_N(
                loss_db,
                cfg,
                y0=y0,
                e_d=e_d,
                output_bits=output_bits,
                completeness_beta=completeness_beta,
                margin_scale=margin_scale,
                local_window=local_window,
            )
        except ValueError:
            return 1e15
        if not res.policy.is_certifying():
            return 1e15
        cache[key] = res
        return float(res.N)

    for seed in seeds:
        differential_evolution(
            evaluate_vector,
            bounds,
            seed=seed,
            maxiter=maxiter,
            popsize=popsize,
            polish=False,
            tol=0.02,
            updating="immediate",
            workers=1,
        )

    results = sorted(cache.values(), key=lambda r: (r.N, -r.policy.certified_key_length()))
    polished: list[FixedOutputSearchResult] = []
    for candidate in results[: min(5, len(results))]:
        try:
            polished.append(
                coordinate_descent_fixed_output_search(
                    loss_db,
                    candidate.config,
                    y0=y0,
                    e_d=e_d,
                    rounds=2,
                    output_bits=output_bits,
                    completeness_beta=completeness_beta,
                    margin_scale=margin_scale,
                )
            )
        except ValueError:
            continue
    combined = results + polished
    seen: set[tuple[float, float, float, float, float]] = set()
    unique: list[FixedOutputSearchResult] = []
    for result in sorted(combined, key=lambda r: (r.N, -r.policy.certified_key_length())):
        cfg = result.config
        key = (cfg.mu, cfg.nu, cfg.p_z, cfg.p_mu, cfg.p_nu)
        if key in seen:
            continue
        seen.add(key)
        unique.append(result)
    return unique
