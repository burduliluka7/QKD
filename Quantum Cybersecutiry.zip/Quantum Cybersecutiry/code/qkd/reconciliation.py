"""Analytical reconciliation leakage helpers for decoy planning."""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Protocol

from .hamming import binary_entropy


@dataclass(frozen=True)
class ReconciliationPlan:
    """Precommitted reconciliation budget for a raw Z-basis block."""

    leakage_cap: int
    model_name: str


@dataclass(frozen=True)
class ReconciliationOutcome:
    """Observed reconciliation result passed to an acceptance policy."""

    leakage: int
    succeeded: bool


class ReconciliationModel(Protocol):
    """Interface for future measured Cascade or LDPC reconciliation models."""

    def plan(self, z_detections: int, z_error_rate: float) -> ReconciliationPlan:
        ...


def analytical_leak_ec(n_z: int, qber_z: float, f_ec: float = 1.16) -> int:
    return int(math.ceil(f_ec * n_z * binary_entropy(qber_z)))


@dataclass(frozen=True)
class AnalyticalLeakageModel:
    """Planning baseline, not a measured Cascade or LDPC implementation."""

    f_ec: float = 1.16

    def plan(self, z_detections: int, z_error_rate: float) -> ReconciliationPlan:
        return ReconciliationPlan(
            leakage_cap=analytical_leak_ec(z_detections, z_error_rate, self.f_ec),
            model_name=f"analytical_f_ec_{self.f_ec:.3g}",
        )
