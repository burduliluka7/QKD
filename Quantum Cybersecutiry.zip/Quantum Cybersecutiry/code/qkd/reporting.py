"""CSV, TeX table, and figure helpers for the decoy extension."""

from __future__ import annotations

from pathlib import Path
import math

import matplotlib.pyplot as plt
import pandas as pd
from pandas.errors import EmptyDataError

from .channel_model import ChannelParams, gain, qber
from .hamming import binary_entropy


def _read_csv_or_empty(path: Path) -> pd.DataFrame:
    try:
        return pd.read_csv(path)
    except EmptyDataError:
        return pd.DataFrame()


def write_tex_table(
    path: Path,
    caption: str,
    label: str,
    headers: list[str],
    rows: list[list[str]],
    fit_width: bool = False,
    align: str | None = None,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if align is None:
        align = "@{}" + " ".join(["r"] * len(headers)) + "@{}"
    lines = [
        "\\begin{table}[htbp]",
        "\\centering",
        "\\small",
        f"\\caption{{{caption}}}",
        f"\\label{{{label}}}",
    ]
    if fit_width:
        lines.append("\\resizebox{\\textwidth}{!}{%")
    lines.extend([
        f"\\begin{{tabular}}{{{align}}}",
        "\\toprule",
        " & ".join(headers) + " \\\\",
        "\\midrule",
    ])
    for row in rows:
        lines.append(" & ".join(row) + " \\\\")
    lines.extend(["\\bottomrule", "\\end{tabular}"])
    if fit_width:
        lines.append("}")
    lines.extend(["\\end{table}", ""])
    path.write_text("\n".join(lines), encoding="utf-8")


def _tex_symbol(value: object) -> str:
    text = str(value)
    symbols = {
        "epsilon_cor": "$\\epsilon_{\\mathrm{cor}}$",
        "epsilon'_sec": "$\\epsilon'_{\\mathrm{sec}}$",
        "epsilon_0": "$\\epsilon_0$",
        "nu": "$\\nu$",
        "alpha^2": "$\\alpha^2$",
        "Delta_zeta_pa": "$\\Delta_{\\zeta,\\mathrm{pa}}$",
        "17": "17",
        "2^(1/4)": "$2^{1/4}$",
    }
    return symbols.get(text, text.replace("_", "\\_"))


def _fmt_sci_tex(value: float, each: bool = False) -> str:
    mantissa, exponent = f"{float(value):.3e}".split("e")
    suffix = " each" if each else ""
    return f"${float(mantissa):.3f}\\times10^{{{int(exponent)}}}${suffix}"


def _epsilon_value(epsilon: pd.DataFrame, event: str) -> float:
    row = epsilon.loc[epsilon["event"] == event, "value"]
    if row.empty:
        raise ValueError(f"missing epsilon allocation row: {event}")
    return float(row.iloc[0])


def export_tables(results_dir: Path, report_tables_dir: Path) -> None:
    report_tables_dir.mkdir(parents=True, exist_ok=True)
    asym = pd.read_csv(results_dir / "asymptotic_validation.csv")
    fixed = pd.read_csv(results_dir / "fixed_parameters.csv")
    coarse = pd.read_csv(results_dir / "coarse_grid_best_parameters.csv")
    budget = pd.read_csv(results_dir / "bit_budgets.csv")
    comparison = pd.read_csv(results_dir / "parameter_search_comparison.csv")
    epsilon = pd.read_csv(results_dir / "epsilon_allocation.csv")
    benchmark = pd.read_csv(results_dir / "source_benchmark.csv")
    honest = pd.read_csv(results_dir / "honest_success.csv")

    asym_row = asym.iloc[0]
    write_tex_table(
        report_tables_dir / "decoy_asymptotic_validation.tex",
        "Asymptotic vacuum-plus-weak estimator validation under the honest-channel model.",
        "tab:decoy-asymptotic-validation",
        ["$Y_1$", "$Y_1^L$", "$e_1$", "$e_1^U$", "$Q_1^L$", "rate"],
        [[
            f"{asym_row.true_y1:.6f}",
            f"{asym_row.y1_lower:.6f}",
            f"{asym_row.true_e1:.6f}",
            f"{asym_row.e1_upper:.6f}",
            f"{asym_row.q1_lower:.6f}",
            f"{asym_row.rate_gllp:.6f}",
        ]],
    )

    def beta_tex(beta: float) -> str:
        if abs(beta - 1e-2) < 1e-15:
            return "$10^{-2}$"
        if abs(beta - 1e-3) < 1e-15:
            return "$10^{-3}$"
        return f"${beta:.1e}$"

    rows = []
    for r in fixed.itertuples(index=False):
        rows.append([
            f"{r.loss_db:.0f}",
            beta_tex(r.beta),
            f"{int(r.N_256_planning_comparison):,}",
            f"{int(r.N_256):,}",
            f"{int(r.fixed_output_bits)}",
            f"{int(r.ell_min_previous)}",
            f"{int(r.ell_min_at_N_256)}",
            f"{r.phase_error_acc:.4f}",
            f"{int(r.leak_ec_cap):,}",
            f"{r.honest_success_estimate:.4f}",
        ])
    write_tex_table(
        report_tables_dir / "decoy_fixed_parameters.tex",
        "Fixed-parameter finite decoy comparison between the deterministic mean-count diagnostic and the precommitted fixed-output threshold.",
        "tab:decoy-fixed",
        ["loss dB", "$\\beta$", "$N_{256}^{\\rm mean}$", "$N_{256}^{(\\beta)}$", "$\\ell_{\\rm out}$", "$\\ell_{\\min}(N-1)$", "$\\ell_{\\min}(N)$", "$\\phi_Z^{\\rm acc}$", "$L_{\\rm EC}^{\\max}$", "$\\hat P_{\\rm succ}$"],
        rows,
        fit_width=True,
    )

    rows = []
    for r in coarse.itertuples(index=False):
        rows.append([
            f"{r.loss_db:.0f}",
            beta_tex(r.beta),
            f"{int(r.N_256):,}",
            f"{int(r.fixed_output_bits)}",
            f"{r.mu:.2f}",
            f"{r.nu:.2f}",
            f"{r.p_z:.2f}",
            f"{r.p_mu:.2f}",
            f"{r.p_nu:.2f}",
            f"{r.p_omega:.2f}",
            f"{r.improvement_percent:.1f}\\%",
        ])
    write_tex_table(
        report_tables_dir / "decoy_optimized_parameters.tex",
        "Initial coarse-grid fixed-output finite decoy results.",
        "tab:decoy-optimized",
        ["loss dB", "$\\beta$", "$N_{256}^{(\\beta)}$", "$\\ell_{\\rm out}$", "$\\mu$", "$\\nu$", "$p_Z$", "$p_\\mu$", "$p_\\nu$", "$p_0$", "impr."],
        rows,
        fit_width=True,
    )

    rows = []
    for r in comparison.itertuples(index=False):
        rows.append([
            f"{r.loss_db:.0f}",
            beta_tex(r.beta),
            f"{int(r.fixed_N_256):,}",
            f"{int(r.initial_grid_N_256):,}",
            f"{int(r.refined_grid_N_256):,}",
            f"{int(r.differential_evolution_N_256):,}",
            f"{int(r.local_search_N_256):,}",
            f"{int(r.selected_N_256):,}",
            f"{int(r.fixed_output_bits)}",
            f"{r.honest_success_estimate:.4f}",
            f"{r.mu:.3f}",
            f"{r.nu:.3f}",
            f"{r.p_Z:.3f}",
            f"{r.p_mu:.3f}",
            f"{r.p_nu:.3f}",
            f"{r.p_0:.3f}",
            f"{r.improvement_vs_fixed:.1f}\\%",
        ])
    write_tex_table(
        report_tables_dir / "decoy_parameter_search.tex",
        "Finite decoy parameter-search comparison for the fixed 256-bit output. Every threshold column is an $N_{256}^{(\\beta)}$ first-crossing value.",
        "tab:decoy-search-comparison",
        ["loss dB", "$\\beta$", "$N$ fixed", "$N$ initial", "$N$ refined", "$N$ DE", "$N$ local", "$N$ selected", "$\\ell_{\\rm out}$", "$\\hat P_{\\rm succ}$", "$\\mu$", "$\\nu$", "$p_Z$", "$p_\\mu$", "$p_\\nu$", "$p_0$", "impr."],
        rows,
        fit_width=True,
    )

    rows = []
    for r in honest.itertuples(index=False):
        rows.append([
            f"{r.loss_db:.0f}",
            beta_tex(r.beta),
            f"{int(r.N_256):,}",
            f"{int(r.fixed_output_bits)}",
            f"{r.target_success:.3f}",
            f"{r.honest_success_estimate:.4f}",
            f"[{r.honest_success_ci_low_95:.4f},{r.honest_success_ci_high_95:.4f}]",
            f"{int(r.honest_trials):,}",
            f"{r.s_z1_acc:,.0f}",
            f"{r.s_x1_acc:,.0f}",
            f"{r.phase_error_acc:.4f}",
            f"{int(r.leak_ec_cap):,}",
        ])
    write_tex_table(
        report_tables_dir / "decoy_honest_success.tex",
        "Honest-success estimates for the selected fixed-output acceptance policies. Confidence intervals are Wilson 95\\% intervals.",
        "tab:decoy-honest-success",
        ["loss dB", "$\\beta$", "$N_{256}^{(\\beta)}$", "$\\ell_{\\rm out}$", "target", "$\\hat P_{\\rm succ}$", "95\\% CI", "trials", "$s_{Z,1}^{\\rm acc}$", "$s_{X,1}^{\\rm acc}$", "$\\phi_Z^{\\rm acc}$", "$L_{\\rm EC}^{\\max}$"],
        rows,
        fit_width=True,
    )

    rows = []
    for r in budget.itertuples(index=False):
        rows.append([
            f"{r.loss_db:.0f}",
            beta_tex(r.beta),
            r.stage,
            f"{r.value:.2f}" if abs(r.value) < 10_000 else f"{r.value:,.0f}",
        ])
    write_tex_table(
        report_tables_dir / "decoy_bit_budgets.tex",
        "Representative selected decoy bit-budget decomposition at 5 dB and 15 dB loss.",
        "tab:decoy-bit-budgets",
        ["loss dB", "$\\beta$", "stage", "value"],
        rows,
    )

    eps_cor = _epsilon_value(epsilon, "correctness")
    eps_sec = _epsilon_value(epsilon, "secrecy_prime")
    eps0 = _epsilon_value(epsilon, "common_auxiliary")
    count_total = int(_epsilon_value(epsilon, "count_event_total"))
    common_total = int(_epsilon_value(epsilon, "common_branch_total"))
    fourth_root = _epsilon_value(epsilon, "fourth_root_factor")
    rows = [
        [
            "Correctness verification",
            "failure probability assigned to the final key-verification tag",
            "$\\epsilon_{\\mathrm{cor}}$",
            _fmt_sci_tex(eps_cor),
        ],
        [
            "Accepted-key secrecy",
            "secrecy branch in the finite-key expression",
            "$\\epsilon'_{\\mathrm{sec}}$",
            _fmt_sci_tex(eps_sec),
        ],
        [
            "Common auxiliary budget",
            "shared value used by the Eq. (137) equal-allocation simplification",
            f"$\\epsilon_0=\\epsilon'_{{\\mathrm{{sec}}}}/{common_total}$",
            _fmt_sci_tex(eps0),
        ],
        [
            "Serfling phase sampling",
            "random-sampling contribution; it enters the secrecy sum with multiplicity two",
            "$\\nu_{\\mathrm{sf}}$",
            _fmt_sci_tex(eps0, each=True),
        ],
        [
            "Smooth-min-entropy auxiliary",
            "smoothing contribution; it enters the secrecy sum with multiplicity two",
            "$\\alpha_2$",
            _fmt_sci_tex(eps0, each=True),
        ],
        [
            "Privacy amplification branch",
            "leftover-hash privacy-amplification branch",
            "$\\Delta_{\\zeta,\\mathrm{pa}}$",
            _fmt_sci_tex(eps0),
        ],
        [
            "Count-concentration events",
            "distinct one-sided Hoeffding events that actually appear in Eqs. (127), (132), and (134)",
            f"${count_total}$ named events",
            _fmt_sci_tex(eps0, each=True),
        ],
        [
            "Union-bound denominator",
            "number of common auxiliary branches in the Eq. (137) convention",
            f"${count_total}+2+2+1={common_total}$",
            f"${common_total}$",
        ],
        [
            "Fourth-root factor",
            "algebraic factor in the secrecy overhead",
            "$2^{1/4}$",
            f"${fourth_root:.3f}$",
        ],
    ]
    write_tex_table(
        report_tables_dir / "decoy_epsilon_allocation.tex",
        "Finite-decoy security allocation used in the numerical run. Rows marked ``each'' assign the displayed value separately to every listed concentration event.",
        "tab:decoy-epsilon-allocation",
        ["allocation branch", "meaning", "symbol(s)", "value"],
        rows,
        align="@{}>{\\raggedright\\arraybackslash}p{0.20\\textwidth} >{\\raggedright\\arraybackslash}p{0.33\\textwidth} >{\\raggedright\\arraybackslash}p{0.22\\textwidth} >{\\raggedleft\\arraybackslash}p{0.14\\textwidth}@{}",
    )

    rows = []
    for r in benchmark.itertuples(index=False):
        src = str(r.source_reference_value)
        local = str(r.local_implementation_value)
        abs_diff = "" if pd.isna(r.absolute_difference) else str(r.absolute_difference)
        rows.append([
            str(r.quantity).replace("_", "\\_"),
            src if len(src) < 24 else "not published",
            local if len(local) < 24 else local[:21] + "...",
            abs_diff,
            str(r.note).replace("closest local 2-decoy planning point; official public code is 1-decoy Fig. 5", "no published 2-decoy point; official code is 1-decoy Fig. 5").replace("_", "\\_"),
        ])
    write_tex_table(
        report_tables_dir / "decoy_source_benchmark.tex",
        "Primary-source benchmark and reproducibility status. Wiesemann et al. provide an official 1-decoy Fig. 5 code release, but no fully specified 2-decoy numerical table for Eq. (137).",
        "tab:decoy-source-benchmark",
        ["quantity", "source/ref.", "local", "abs. diff.", "note"],
        rows,
        fit_width=True,
    )


def make_figures(results_dir: Path, figures_dir: Path) -> None:
    figures_dir.mkdir(parents=True, exist_ok=True)
    fixed = pd.read_csv(results_dir / "fixed_parameters.csv")
    selected = pd.read_csv(results_dir / "selected_parameters.csv")
    budget = pd.read_csv(results_dir / "bit_budgets.csv")
    comp = pd.read_csv(results_dir / "parameter_search_comparison.csv")
    diag = pd.read_csv(results_dir / "local_threshold_diagnostics.csv")
    fec = pd.read_csv(results_dir / "f_ec_sensitivity.csv")
    main_beta = 1e-2 if 1e-2 in set(comp["beta"].round(12)) else float(comp["beta"].iloc[0])
    comp_main = comp[comp["beta"].round(12) == round(main_beta, 12)]
    selected_main = selected[selected["beta"].round(12) == round(main_beta, 12)]
    fixed_main = fixed[fixed["beta"].round(12) == round(main_beta, 12)]

    losses = list(range(0, 21))
    intensities = [0.5, 0.1, 0.0]
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    for inten in intensities:
        gains = [gain(inten, ChannelParams.from_loss_db(x, y0=1e-6, e_d=0.01)) for x in losses]
        qbers = [qber(inten, ChannelParams.from_loss_db(x, y0=1e-6, e_d=0.01)) for x in losses]
        label = f"k={inten:g}"
        axes[0].plot(losses, gains, marker="o", label=label)
        axes[1].plot(losses, qbers, marker="o", label=label)
    axes[0].set_yscale("log")
    axes[0].set_xlabel("loss (dB)")
    axes[0].set_ylabel("gain $Q_k$")
    axes[1].set_xlabel("loss (dB)")
    axes[1].set_ylabel("QBER $E_k$")
    axes[0].legend()
    axes[1].legend()
    fig.tight_layout()
    fig.savefig(figures_dir / "decoy_honest_channel_gains.pdf")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6, 4))
    for beta, group in fixed.groupby("beta"):
        ax.plot(group["loss_db"], group["N_256"], marker="o", label=fr"$\beta={beta:g}$")
    ax.set_yscale("log")
    ax.set_xlabel("loss (dB)")
    ax.set_ylabel("$N_{256}^{(\\beta)}$ transmitted WCP pulses")
    ax.legend()
    fig.tight_layout()
    fig.savefig(figures_dir / "decoy_fixed_n256_vs_loss.pdf")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(comp_main["loss_db"], comp_main["fixed_N_256"], marker="o", label="fixed baseline")
    ax.plot(comp_main["loss_db"], comp_main["initial_grid_N_256"], marker="s", label="initial coarse-grid best")
    ax.set_yscale("log")
    ax.set_xlabel("loss (dB)")
    ax.set_ylabel("$N_{256}^{(\\beta)}$ transmitted WCP pulses")
    ax.legend()
    fig.tight_layout()
    fig.savefig(figures_dir / "decoy_fixed_vs_initial_coarse.pdf")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(comp_main["loss_db"], comp_main["fixed_N_256"], marker="o", label="fixed baseline")
    ax.plot(comp_main["loss_db"], comp_main["initial_grid_N_256"], marker="s", label="initial coarse grid")
    ax.plot(comp_main["loss_db"], comp_main["refined_grid_N_256"], marker="^", label="refined grid")
    ax.plot(comp_main["loss_db"], comp_main["differential_evolution_N_256"], marker="v", label="differential evolution")
    ax.plot(comp_main["loss_db"], comp_main["local_search_N_256"], marker="P", label="local polish")
    ax.plot(comp_main["loss_db"], comp_main["selected_N_256"], marker="D", label="selected best found")
    ax.set_yscale("log")
    ax.set_xlabel("loss (dB)")
    ax.set_ylabel("$N_{256}^{(\\beta)}$ transmitted WCP pulses")
    ax.legend()
    fig.tight_layout()
    fig.savefig(figures_dir / "decoy_n256_search_comparison.pdf")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6, 4))
    ideal_source = [2246] * len(comp_main)
    ax.plot(comp_main["loss_db"], ideal_source, marker="o", label="ideal single-photon source")
    ax.plot(comp_main["loss_db"], comp_main["fixed_N_256"], marker="s", label="fixed decoy baseline")
    ax.plot(comp_main["loss_db"], comp_main["initial_grid_N_256"], marker="^", label="initial coarse-grid decoy")
    ax.plot(comp_main["loss_db"], comp_main["selected_N_256"], marker="D", label="selected decoy best found")
    ax.set_yscale("log")
    ax.set_xlabel("loss (dB)")
    ax.set_ylabel("transmitted pulses")
    ax.legend()
    fig.tight_layout()
    fig.savefig(figures_dir / "decoy_ideal_vs_decoy.pdf")
    plt.close(fig)

    selected = budget[budget["loss_db"].isin([5.0, 15.0])]
    stages = [
        "fixed output bits",
        "policy vacuum credit",
        "policy single-photon credit",
        "policy phase deduction",
        "precommitted leakage cap",
        "correctness deduction",
        "secrecy deduction",
        "certified minimum key length",
    ]
    fig, axes = plt.subplots(1, 2, figsize=(11, 4), sharey=False)
    for ax, loss in zip(axes, [5.0, 15.0]):
        sub = selected[selected["loss_db"] == loss].set_index("stage")
        vals = [float(sub.loc[s, "value"]) for s in stages]
        ax.bar(range(len(stages)), vals)
        ax.set_title(f"{loss:.0f} dB")
        ax.set_xticks(range(len(stages)))
        ax.set_xticklabels(stages, rotation=45, ha="right")
        ax.set_ylabel("bits or counts")
    fig.tight_layout()
    fig.savefig(figures_dir / "decoy_bit_budget_representative.pdf")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6, 4))
    x = selected_main["N_256"].astype(float)
    selected_params = selected_main
    basis_test_fraction = 1.0 - selected_params["p_z"].astype(float)
    decoy_fraction = selected_params["p_nu"].astype(float) + selected_params["p_omega"].astype(float)
    ref = basis_test_fraction.iloc[0] * (x / x.iloc[0]) ** (-1.0 / 3.0)
    ax.plot(x, basis_test_fraction, marker="o", label="$1-p_Z$")
    ax.plot(x, decoy_fraction, marker="s", label="$p_\\nu+p_0$")
    ax.plot(x, ref, linestyle="--", color="black", label="$N^{-1/3}$ reference")
    ax.set_xscale("log")
    ax.set_xlabel("selected $N_{256}^{(\\beta)}$")
    ax.set_ylabel("selected estimator fraction")
    ax.legend()
    fig.tight_layout()
    fig.savefig(figures_dir / "decoy_allocation_diagnostic.pdf")
    plt.close(fig)

    sub = diag[diag["loss_db"] == 10.0]
    if sub.empty:
        sub = diag[diag["loss_db"] == float(diag["loss_db"].iloc[len(diag) // 2])]
    n0 = int(sub["N_256"].iloc[len(sub) // 2]) if "N_256" in sub.columns else int(sub["N_min"].iloc[len(sub) // 2])
    fig, ax = plt.subplots(figsize=(6, 4))
    xvals = sub["N_min"].astype(int) - n0
    colors = ["tab:green" if s == "ok" else "tab:red" for s in sub["status"]]
    ax.scatter(xvals, sub["final_key_length"], c=colors)
    ax.axhline(256, color="black", linestyle="--", linewidth=1)
    ax.axvline(0, color="gray", linestyle=":", linewidth=1)
    ax.set_xlabel("$N-N_{256}$")
    ax.set_ylabel("$\\ell_{\\min}(N)$")
    fig.tight_layout()
    fig.savefig(figures_dir / "decoy_threshold_diagnostic.pdf")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6, 4))
    fec_main = fec[fec["beta"].round(12) == round(main_beta, 12)] if "beta" in fec.columns else fec
    for f_value, group in fec_main.groupby("f_ec"):
        ax.plot(group["loss_db"], group["N_256"], marker="o", label=f"$f_{{EC}}={f_value:.2f}$")
    ax.set_yscale("log")
    ax.set_xlabel("loss (dB)")
    ax.set_ylabel("$N_{256}^{(\\beta)}$")
    ax.legend()
    fig.tight_layout()
    fig.savefig(figures_dir / "decoy_fec_sensitivity.pdf")
    plt.close(fig)
