"""Refresh fixed-output semantics for numerically unchanged decoy rows."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))
from run_main_decoy_results import _export_tables


def main() -> None:
    out = ROOT / "results" / "main_decoy"
    path = out / "first_crossings.csv"
    frame = pd.read_csv(path)
    frame["N_256_certification"] = "locally_verified_candidate"
    frame["theorem_bound_real"] = frame["real_key_length"]
    frame["theorem_bound_integer"] = frame["final_key_length"]
    frame["protocol_output"] = frame["final_key_length"].map(lambda x: 256 if x >= 256 else "abort")
    frame["certified_slack_above_256"] = frame["real_key_length"] - 256.0
    frame["accept_min_s_z0"] = frame["s_z0_lower"]
    frame["accept_min_s_z1"] = frame["s_z1_lower"]
    frame["accept_min_s_x1"] = frame["s_x1_lower"]
    frame["accept_max_phase_error"] = frame["phase_error_upper"]
    frame["accept_max_leak_ec"] = frame["leak_ec"]
    frame["acceptance_policy_note"] = "precommitted thresholds; execution recomputes certified quantities from observed labelled counts"
    frame.to_csv(path, index=False)
    config_path = out / "configuration.json"
    config = json.loads(config_path.read_text(encoding="utf-8"))
    config.update(
        objective="locate a locally verified N-hat_256 candidate whose precommitted policy certifies a fixed 256-bit output",
        global_minimum_certified=False,
        search_classification="locally_verified_candidate; probability optimization is grid-best",
        protocol_output=256,
    )
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    metadata_path = out / "run_metadata.json"
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    metadata["result_interpretation"] = "fixed 256-bit output-or-abort; theorem bounds are certified capacities"
    metadata["threshold_certification"] = "adjacent locally verified candidates; grid-best probabilities; no global monotonicity proof"
    metadata_path.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    _export_tables(out, ROOT / "report" / "generated_tables")
    print(f"refreshed {len(frame)} decoy rows; numerical theorem bounds unchanged")


if __name__ == "__main__":
    main()
