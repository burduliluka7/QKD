"""Regression-check stored ideal minima without repeating exhaustive search."""

from __future__ import annotations
import json
from pathlib import Path
import sys
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))
from run_ideal_basis_results import evaluate_best, write_tex

source = pd.read_csv(ROOT / "results" / "ideal_basis" / "minima.csv")
leakage = pd.read_csv(ROOT / "results_03_reconciliation" / "tables" / "reconciliation_summary.csv")
if "protocol" in leakage:
    leakage = leakage[leakage.protocol.astype(str).str.lower().str.contains("cascade")]

rows, checks = [], []
for old in source.itertuples(index=False):
    q_x = float(old.q_x_tol) if hasattr(old, "q_x_tol") else float(old.q_tol)
    q_z = float(old.q_z_design) if hasattr(old, "q_z_design") else float(old.q_tol)
    current = evaluate_best(int(old.N_min), q_x, q_z, old.leakage_model, leakage)
    previous = evaluate_best(int(old.N_min) - 1, q_x, q_z, old.leakage_model, leakage)
    unchanged = bool(current["passes"] and not previous["passes"] and int(current["N"]) == int(old.N_min))
    checks.append({"q_x_tol": q_x, "q_z_design": q_z, "leakage_model": old.leakage_model,
                   "stored_N_min": int(old.N_min), "ell_previous": int(previous["ell"]),
                   "ell_at_N_min": int(current["ell"]), "unchanged": unchanged})
    current.update(N_min=int(old.N_min), global_minimum_certified_on_grid=True,
                   count_policy="abort on realized count shortfall; uniformly subsample excess matched events")
    rows.append(current)
if not all(row["unchanged"] for row in checks):
    raise SystemExit("stored-boundary regression failed; full exhaustive rerun required")
out = pd.DataFrame(rows).sort_values(["q_x_tol", "leakage_model"])
out.to_csv(ROOT / "results" / "ideal_basis" / "minima.csv", index=False)
(ROOT / "results" / "ideal_basis" / "boundary_regression.json").write_text(json.dumps(checks, indent=2), encoding="utf-8")
write_tex(out, ROOT / "report" / "generated_tables" / "ideal_basis_minima.tex")
print(f"{len(checks)} stored crossings unchanged; full exhaustive search not run")
