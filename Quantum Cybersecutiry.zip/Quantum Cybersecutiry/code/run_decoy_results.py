from __future__ import annotations

import argparse
import json
from dataclasses import asdict, replace
from datetime import datetime, timezone
import math
from pathlib import Path
import platform
import subprocess
import sys
import time

import matplotlib
import numpy
import pandas as pd
import scipy

from qkd.channel_model import ChannelParams
from qkd.decoy_asymptotic import vacuum_weak_bounds
from qkd.decoy_finite import (
    COUNT_CONCENTRATION_EVENTS,
    COUNT_EVENT_DETAILS,
    FiniteDecoyConfig,
    FiniteDecoyResult,
    SecurityBudget,
    TWO_DECOY_COMMON_SECURITY_BRANCHES,
    evaluate_finite_decoy,
)
from qkd.fixed_output import (
    FixedOutputSearchResult,
    attach_honest_success,
    build_acceptance_policy,
)
from qkd.hamming import binary_entropy
from qkd.optimization import (
    coordinate_descent_fixed_output_search,
    differential_evolution_fixed_output_search,
    find_minimum_N,
    find_minimum_fixed_output_N,
    optimize_fixed_output_grid,
    refined_fixed_output_grid,
)
from qkd.reporting import export_tables, make_figures


def _git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        return "unavailable"


def _load_config(path: str | None) -> dict:
    if not path:
        return {}
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def _parse_betas(text: str) -> list[float]:
    return [float(item.strip()) for item in text.split(",") if item.strip()]


def _search_status_from_cfg(cfg: FiniteDecoyConfig) -> str:
    boundary = []
    if abs(cfg.mu - 1.0) < 1e-5 or abs(cfg.mu - 0.1) < 1e-5:
        boundary.append("mu")
    if abs(cfg.nu - 0.01) < 1e-5 or cfg.nu > cfg.mu - 1e-4:
        boundary.append("nu")
    if abs(cfg.p_z - 0.5) < 1e-5 or abs(cfg.p_z - 0.95) < 1e-5:
        boundary.append("p_z")
    if min(cfg.p_mu, cfg.p_nu, cfg.p_omega) < 0.031:
        boundary.append("intensity_probability")
    return "boundary: " + ",".join(boundary) if boundary else "interior_or_grid_point"


def _planning_row(res: FiniteDecoyResult, label: str) -> dict:
    cfg = res.config
    return {
        "label": label,
        "loss_db": res.loss_db,
        "eta": res.eta,
        "N_256_planning": res.N,
        "ell_previous_planning": res.ell_previous,
        "ell_at_N_256_planning": res.final_key_length,
        "mu": cfg.mu,
        "nu": cfg.nu,
        "omega": cfg.omega,
        "p_z": cfg.p_z,
        "p_mu": cfg.p_mu,
        "p_nu": cfg.p_nu,
        "p_omega": cfg.p_omega,
        "z_detections": res.z_detection_count,
        "z_errors": res.z_counts.total_errors,
        "z_error_rate": res.z_error_rate,
        "s_z0_lower": res.s_z0_lower,
        "s_z1_lower": res.s_z1_lower,
        "s_x1_lower": res.s_x1_lower,
        "phase_error_upper": res.phase_error_upper,
        "leak_ec": res.leak_ec,
        "final_key_length": res.final_key_length,
        "status": res.status,
        "failure_reason": res.failure_reason,
        "search_method": res.search_method,
    }


def _fixed_row(
    fx: FixedOutputSearchResult,
    label: str,
    fixed_N: int | None = None,
    deterministic_planning_N: int | None = None,
) -> dict:
    res = fx.result
    cfg = fx.config
    policy = fx.policy
    success = fx.honest_success
    row = {
        "label": label,
        "loss_db": res.loss_db,
        "beta": policy.completeness_beta,
        "target_success": 1.0 - policy.completeness_beta,
        "eta": res.eta,
        "N_min": fx.N,
        "N_256": fx.N,
        "N_256_fixed_acceptance": fx.N,
        "N_256_planning_comparison": deterministic_planning_N,
        "fixed_output_bits": policy.output_bits,
        "ell_min_previous": fx.previous_policy.certified_key_length() if fx.previous_policy else None,
        "ell_min_at_N_256": policy.certified_key_length(),
        "ell_mean_count_posthoc": res.final_key_length,
        "mu": cfg.mu,
        "nu": cfg.nu,
        "omega": cfg.omega,
        "p_z": cfg.p_z,
        "p_mu": cfg.p_mu,
        "p_nu": cfg.p_nu,
        "p_omega": cfg.p_omega,
        "z_detections": res.z_detection_count,
        "x_detections": res.x_counts.total_detections,
        "z_errors": res.z_counts.total_errors,
        "z_error_rate": res.z_error_rate,
        "s_z0_lower": res.s_z0_lower,
        "s_x0_lower": res.s_x0_lower,
        "s_z1_lower": res.s_z1_lower,
        "s_x1_lower": res.s_x1_lower,
        "v_x1_upper": res.v_x1_upper,
        "lambda_x_upper": res.lambda_x_upper,
        "gamma_mean_count": res.gamma,
        "phase_error_upper_mean_count": res.phase_error_upper,
        "leak_ec": res.leak_ec,
        "s_z0_acc": policy.min_s_z0,
        "s_z1_acc": policy.min_s_z1,
        "s_x1_acc": policy.min_s_x1,
        "lambda_x_acc": policy.max_lambda_x,
        "phase_error_acc": policy.phase_error_bound(),
        "leak_ec_cap": policy.max_leak_ec,
        "min_z_detections": policy.min_z_detections,
        "min_x_detections": policy.min_x_detections,
        "margin_z": policy.margin_z,
        "verification_overhead": res.verification_overhead,
        "secrecy_overhead": res.secrecy_overhead,
        "overhead": res.verification_overhead + res.secrecy_overhead,
        "certified_real_key_length": policy.certified_real_key_length(),
        "honest_trials": success.trials if success else None,
        "honest_success_estimate": success.estimate if success else None,
        "honest_success_ci_low_95": success.wilson_lower_95 if success else None,
        "honest_success_ci_high_95": success.wilson_upper_95 if success else None,
        "honest_abort_probability": 1.0 - success.estimate if success else None,
        "honest_abort_reasons": json.dumps(success.abort_reasons, sort_keys=True) if success else "",
        "verified_interval_start": fx.verified_interval_start,
        "verified_interval_end": fx.verified_interval_end,
        "search_method": fx.search_method,
        "search_status": _search_status_from_cfg(cfg),
    }
    if fixed_N is not None:
        row["improvement_percent"] = 100.0 * (fixed_N - fx.N) / fixed_N
    return row


def _local_diagnostic_rows(
    fx: FixedOutputSearchResult,
    y0: float,
    e_d: float,
    margin_scale: float,
) -> list[dict]:
    rows = []
    for N in range(max(1, fx.N - 3), fx.N + 4):
        res = evaluate_finite_decoy(N, fx.loss_db, fx.config, y0=y0, e_d=e_d, security_budget=fx.policy.security_budget)
        policy = build_acceptance_policy(
            res,
            output_bits=fx.policy.output_bits,
            completeness_beta=fx.policy.completeness_beta,
            margin_scale=margin_scale,
        )
        rows.append(
            {
                "loss_db": fx.loss_db,
                "beta": fx.policy.completeness_beta,
                "N_256": fx.N,
                "N_min": N,
                "final_key_length": policy.certified_key_length(),
                "fixed_output_bits": policy.output_bits,
                "status": "ok" if policy.is_certifying() else "abort",
                "failure_reason": "ok" if policy.is_certifying() else "policy_does_not_certify_output_length",
            }
        )
    return rows


def _budget_rows(fx: FixedOutputSearchResult) -> list[dict]:
    policy = fx.policy
    phase_deduction = policy.min_s_z1 * binary_entropy(policy.phase_error_bound())
    rows = [
        ("transmitted WCP pulses", float(fx.N)),
        ("fixed output bits", float(policy.output_bits)),
        ("policy vacuum credit", float(policy.min_s_z0)),
        ("policy single-photon credit", float(policy.min_s_z1)),
        ("policy phase deduction", float(phase_deduction)),
        ("precommitted leakage cap", float(policy.max_leak_ec)),
        ("correctness deduction", float(policy.security_budget.verification_overhead_bits())),
        ("secrecy deduction", float(policy.security_budget.secrecy_overhead_bits())),
        ("certified minimum key length", float(policy.certified_key_length())),
    ]
    return [
        {"loss_db": fx.loss_db, "beta": policy.completeness_beta, "N_256": fx.N, "stage": stage, "value": value}
        for stage, value in rows
    ]


def _epsilon_rows(cfg: FiniteDecoyConfig) -> list[dict]:
    budget = SecurityBudget.wiesemann_equal_split(cfg.eps_tot)
    eps0 = budget.common_auxiliary_value()
    rows = [
        ("correctness", "epsilon_cor", "correctness verification failure", "Wiesemann Theorem 2 / Eq. (137)", "verification_overhead", budget.epsilon_cor, 1),
        ("secrecy_prime", "epsilon'_sec", "accepted-key secrecy budget", "Wiesemann Eq. (135)", "secrecy_budget", budget.epsilon_sec_prime, 1),
        ("common_auxiliary", "epsilon_0", "common value assigned in the Eq. (137) simplification", "Wiesemann Eq. (137)", "derived_equal_split", eps0, TWO_DECOY_COMMON_SECURITY_BRANCHES),
        ("serfling_gamma", "nu_sec", "Serfling/random-sampling contribution, counted with multiplicity two", "Wiesemann Eqs. (73), (135)", "serfling_gamma", budget.epsilon_serfling, 2),
        ("smoothing_alpha2", "alpha_2", "smooth-min-entropy contribution, counted with multiplicity two", "Wiesemann Eq. (135)", "smooth_entropy", budget.epsilon_smoothing, 2),
        ("privacy_branch", "Delta_zeta_pa", "privacy-amplification branch", "Wiesemann Eq. (135)", "privacy_amplification", budget.epsilon_pa, 1),
    ]
    for name in COUNT_CONCENTRATION_EVENTS:
        basis, quantity, intensity, side, equation = COUNT_EVENT_DETAILS[name]
        symbol = f"{quantity}_{side}_{basis}_{intensity}"
        purpose = f"{side} one-sided Hoeffding bound for {basis}-basis {intensity} {quantity} count"
        rows.append((name, symbol, purpose, f"Wiesemann {equation}, Eq. (136)", "evaluate_finite_decoy", budget.concentration_epsilons[name], 1))
    rows.append(("count_event_total", "12", "distinct count-concentration events in the two-decoy specialization", "Wiesemann Eq. (136)", "COUNT_CONCENTRATION_EVENTS", float(len(COUNT_CONCENTRATION_EVENTS)), len(COUNT_CONCENTRATION_EVENTS)))
    rows.append(("common_branch_total", "17", "12 count events plus 2 Serfling plus 2 smoothing plus 1 privacy branch", "Wiesemann Eqs. (135)--(137)", "TWO_DECOY_COMMON_SECURITY_BRANCHES", float(TWO_DECOY_COMMON_SECURITY_BRANCHES), TWO_DECOY_COMMON_SECURITY_BRANCHES))
    rows.append(("fourth_root_factor", "2^(1/4)", "algebraic factor in the simplified secrecy overhead", "Wiesemann Eq. (137)", "secrecy_overhead_bits", 2.0 ** 0.25, 1))
    return [
        {
            "event": event,
            "source_symbol": symbol,
            "purpose": purpose,
            "source_equation": equation,
            "code_reference": code,
            "value": value,
            "multiplicity": multiplicity,
        }
        for event, symbol, purpose, equation, code, value, multiplicity in rows
    ]


def _benchmark_rows(fx: FixedOutputSearchResult) -> list[dict]:
    budget = fx.policy.security_budget
    comparable = [
        ("concentration_event_count", 12.0, float(len(COUNT_CONCENTRATION_EVENTS)), "Wiesemann Eq. (136)"),
        ("common_branch_count", 17.0, float(TWO_DECOY_COMMON_SECURITY_BRANCHES), "Wiesemann Eqs. (135)--(137)"),
        ("correctness_overhead_bits", math.log2(2.0 / budget.epsilon_cor), budget.verification_overhead_bits(), "Wiesemann Eq. (137)"),
        ("secrecy_overhead_bits", 4.0 * math.log2(1.0 / ((2.0 ** 0.25) * budget.common_auxiliary_value())), budget.secrecy_overhead_bits(), "Wiesemann Eq. (137)"),
        ("epsilon_common_auxiliary", budget.epsilon_sec_prime / TWO_DECOY_COMMON_SECURITY_BRANCHES, budget.common_auxiliary_value(), "Wiesemann Eq. (137)"),
    ]
    rows = []
    for quantity, source_value, local_value, note in comparable:
        rows.append(
            {
                "quantity": quantity,
                "source_reference_value": source_value,
                "local_implementation_value": local_value,
                "absolute_difference": abs(source_value - local_value),
                "relative_difference": 0.0 if source_value == 0 else abs(source_value - local_value) / abs(source_value),
                "note": note,
            }
        )
    for quantity, local_value in [
        ("fixed_output_bits", fx.policy.output_bits),
        ("selected_N_256_beta", fx.N),
        ("ell_min_acceptance_policy", fx.policy.certified_key_length()),
        ("honest_success_estimate", fx.honest_success.estimate if fx.honest_success else ""),
    ]:
        rows.append(
            {
                "quantity": quantity,
                "source_reference_value": "not published for a fully specified 2-decoy fixed-output numerical point",
                "local_implementation_value": local_value,
                "absolute_difference": "",
                "relative_difference": "",
                "note": "local fixed-output planning result",
            }
        )
    return rows


def _trials_for_beta(beta: float, quick: bool, default_trials: int, strict_trials: int) -> int:
    if quick:
        return min(default_trials, 200)
    return strict_trials if beta <= 1e-3 else default_trials


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate finite decoy-state fixed-output planning results.")
    parser.add_argument("--config", help="Optional JSON configuration override.")
    parser.add_argument("--output-dir", default="results/decoy", help="Directory for generated CSV/JSON results.")
    parser.add_argument("--seed", type=int, default=12345, help="Base random seed for honest-success estimates.")
    parser.add_argument("--quick", action="store_true", help="Use smaller search and Monte Carlo settings for smoke testing.")
    parser.add_argument("--resume", action="store_true", help="Accepted for reproducibility interface; deterministic outputs are regenerated.")
    parser.add_argument("--workers", type=int, default=1, help="Accepted for interface consistency; execution is single-process.")
    parser.add_argument("--betas", default="1e-2,1e-3", help="Comma-separated honest abort targets.")
    parser.add_argument("--mc-trials", type=int, default=2000, help="Monte Carlo trials for beta=1e-2 candidates.")
    parser.add_argument("--mc-trials-strict", type=int, default=6000, help="Monte Carlo trials for beta<=1e-3 candidates.")
    parser.add_argument("--margin-scale", type=float, default=12.0, help="Planning safety multiplier for fixed-acceptance thresholds.")
    parser.add_argument("--de-maxiter", type=int, default=3, help="Differential-evolution iterations.")
    parser.add_argument("--de-popsize", type=int, default=4, help="Differential-evolution population multiplier.")
    args = parser.parse_args()

    started = time.time()
    user_cfg = _load_config(args.config)
    losses = user_cfg.get("losses_db", [0, 5, 10, 15, 20])
    betas = _parse_betas(user_cfg.get("betas", args.betas) if isinstance(user_cfg.get("betas", args.betas), str) else args.betas)
    y0 = float(user_cfg.get("y0", 1e-6))
    e_d = float(user_cfg.get("e_d", 0.01))
    f_ec = float(user_cfg.get("f_ec", 1.16))
    output_bits = int(user_cfg.get("target_bits", 256))
    base = FiniteDecoyConfig(
        mu=float(user_cfg.get("mu", 0.5)),
        nu=float(user_cfg.get("nu", 0.1)),
        p_z=float(user_cfg.get("p_z", 0.9)),
        p_mu=float(user_cfg.get("p_mu", 0.8)),
        p_nu=float(user_cfg.get("p_nu", 0.15)),
        p_omega=float(user_cfg.get("p_omega", 0.05)),
        eps_tot=float(user_cfg.get("eps_tot", 1e-9)),
        f_ec=f_ec,
        target_bits=output_bits,
    )
    base.validate()

    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    report_figures = Path("report/figures")
    report_tables = Path("report/generated_tables")
    report_tables.mkdir(parents=True, exist_ok=True)

    asym = vacuum_weak_bounds(0.5, 0.1, ChannelParams(eta=0.1, y0=1e-5, e_d=0.01), p_z=1.0, f_ec=f_ec)
    pd.DataFrame([asdict(asym)]).to_csv(out / "asymptotic_validation.csv", index=False)

    planning_rows = []
    fixed_rows = []
    coarse_rows = []
    refined_rows = []
    de_rows = []
    local_rows = []
    selected_rows = []
    comparison_rows = []
    budget_rows = []
    top_rows = []
    diagnostic_rows = []
    sensitivity_rows = []
    completeness_rows = []
    selected_for_benchmark: FixedOutputSearchResult | None = None

    planning_by_loss: dict[float, FiniteDecoyResult] = {}
    selected_main_beta_by_loss: dict[float, FixedOutputSearchResult] = {}
    main_beta = betas[0]

    for loss in losses:
        loss = float(loss)
        planning = find_minimum_N(loss, base, y0=y0, e_d=e_d)
        planning_by_loss[loss] = planning
        planning_rows.append(_planning_row(planning, "deterministic_mean_count_fixed_baseline"))

        beta_selected: dict[float, FixedOutputSearchResult] = {}
        for beta_index, beta in enumerate(betas):
            trials = _trials_for_beta(beta, args.quick, args.mc_trials, args.mc_trials_strict)
            fixed = find_minimum_fixed_output_N(
                loss,
                base,
                y0=y0,
                e_d=e_d,
                output_bits=output_bits,
                completeness_beta=beta,
                margin_scale=args.margin_scale,
            )
            fixed = attach_honest_success(fixed, trials=trials, seed=args.seed + 1000 * beta_index + int(loss), y0=y0, e_d=e_d)
            fixed_rows.append(_fixed_row(fixed, "fixed_baseline", deterministic_planning_N=planning.N))

            candidates = optimize_fixed_output_grid(
                loss,
                base,
                y0=y0,
                e_d=e_d,
                quick=args.quick,
                output_bits=output_bits,
                completeness_beta=beta,
                margin_scale=args.margin_scale,
            )
            coarse_best = candidates[0] if candidates else fixed
            coarse_rows.append(_fixed_row(coarse_best, "initial_coarse_grid_best", fixed_N=fixed.N, deterministic_planning_N=planning.N))
            for rank, candidate in enumerate(candidates[:5], start=1):
                row = _fixed_row(candidate, "initial_coarse_grid_top5", fixed_N=fixed.N, deterministic_planning_N=planning.N)
                row["rank"] = rank
                top_rows.append(row)

            refined_candidates = refined_fixed_output_grid(
                loss,
                coarse_best.config,
                y0=y0,
                e_d=e_d,
                output_bits=output_bits,
                completeness_beta=beta,
                margin_scale=args.margin_scale,
            )
            refined_best = refined_candidates[0] if refined_candidates else coarse_best
            refined_rows.append(_fixed_row(refined_best, "refined_grid_best", fixed_N=fixed.N, deterministic_planning_N=planning.N))

            de_candidates: list[FixedOutputSearchResult] = []
            if not args.quick:
                de_candidates = differential_evolution_fixed_output_search(
                    loss,
                    base,
                    y0=y0,
                    e_d=e_d,
                    output_bits=output_bits,
                    completeness_beta=beta,
                    margin_scale=args.margin_scale,
                    seeds=(args.seed, args.seed + 7919),
                    maxiter=args.de_maxiter,
                    popsize=args.de_popsize,
                    local_window=128,
                )
            de_best = de_candidates[0] if de_candidates else refined_best
            de_rows.append(_fixed_row(de_best, "differential_evolution_best", fixed_N=fixed.N, deterministic_planning_N=planning.N))

            local_seed = min([coarse_best, refined_best, de_best], key=lambda r: (r.N, -r.policy.certified_key_length()))
            local_candidate = coordinate_descent_fixed_output_search(
                loss,
                local_seed.config,
                y0=y0,
                e_d=e_d,
                rounds=1 if args.quick else 2,
                output_bits=output_bits,
                completeness_beta=beta,
                margin_scale=args.margin_scale,
            )
            local_rows.append(_fixed_row(local_candidate, "local_polish_best", fixed_N=fixed.N, deterministic_planning_N=planning.N))

            selected = min([coarse_best, refined_best, de_best, local_candidate], key=lambda r: (r.N, -r.policy.certified_key_length()))
            selected = attach_honest_success(
                selected,
                trials=trials,
                seed=args.seed + 100_000 * beta_index + int(loss),
                y0=y0,
                e_d=e_d,
            )
            beta_selected[beta] = selected
            selected_rows.append(_fixed_row(selected, "selected_best_found", fixed_N=fixed.N, deterministic_planning_N=planning.N))
            completeness_rows.append(_fixed_row(selected, "honest_success_selected", fixed_N=fixed.N, deterministic_planning_N=planning.N))

            comparison_rows.append(
                {
                    "loss_db": loss,
                    "beta": beta,
                    "target_success": 1.0 - beta,
                    "planning_fixed_N_256": planning.N,
                    "fixed_N_256": fixed.N,
                    "initial_grid_N_256": coarse_best.N,
                    "refined_grid_N_256": refined_best.N,
                    "differential_evolution_N_256": de_best.N,
                    "local_search_N_256": local_candidate.N,
                    "selected_N_256": selected.N,
                    "fixed_output_bits": output_bits,
                    "honest_success_estimate": selected.honest_success.estimate if selected.honest_success else None,
                    "honest_success_ci_low_95": selected.honest_success.wilson_lower_95 if selected.honest_success else None,
                    "honest_success_ci_high_95": selected.honest_success.wilson_upper_95 if selected.honest_success else None,
                    "mu": selected.config.mu,
                    "nu": selected.config.nu,
                    "p_Z": selected.config.p_z,
                    "p_mu": selected.config.p_mu,
                    "p_nu": selected.config.p_nu,
                    "p_0": selected.config.p_omega,
                    "improvement_vs_fixed": 100.0 * (fixed.N - selected.N) / fixed.N,
                    "search_status": _search_status_from_cfg(selected.config),
                }
            )

            if beta == main_beta:
                selected_main_beta_by_loss[loss] = selected
                diagnostic_rows.extend(_local_diagnostic_rows(selected, y0=y0, e_d=e_d, margin_scale=args.margin_scale))
                for f_value in [1.10, 1.16, 1.20]:
                    sens_cfg = replace(selected.config, f_ec=f_value)
                    sens = find_minimum_fixed_output_N(
                        loss,
                        sens_cfg,
                        y0=y0,
                        e_d=e_d,
                        output_bits=output_bits,
                        completeness_beta=beta,
                        margin_scale=args.margin_scale,
                    )
                    row = _fixed_row(sens, f"f_ec_{f_value:.2f}", fixed_N=fixed.N, deterministic_planning_N=planning.N)
                    row["f_ec"] = f_value
                    sensitivity_rows.append(row)

        selected_for_benchmark = beta_selected.get(main_beta) or next(iter(beta_selected.values()))

    for loss in (5.0, 15.0):
        if loss in selected_main_beta_by_loss:
            budget_rows.extend(_budget_rows(selected_main_beta_by_loss[loss]))

    pd.DataFrame(planning_rows).to_csv(out / "deterministic_mean_count_crossings.csv", index=False)
    pd.DataFrame(fixed_rows).to_csv(out / "fixed_parameters.csv", index=False)
    pd.DataFrame(coarse_rows).to_csv(out / "coarse_grid_best_parameters.csv", index=False)
    pd.DataFrame(coarse_rows).to_csv(out / "optimized_parameters.csv", index=False)
    pd.DataFrame(refined_rows).to_csv(out / "refined_grid_best_parameters.csv", index=False)
    pd.DataFrame(de_rows).to_csv(out / "differential_evolution_parameters.csv", index=False)
    pd.DataFrame(local_rows).to_csv(out / "local_search_parameters.csv", index=False)
    pd.DataFrame(selected_rows).to_csv(out / "selected_parameters.csv", index=False)
    pd.DataFrame(top_rows).to_csv(out / "optimized_top5_parameters.csv", index=False)
    pd.DataFrame(comparison_rows).to_csv(out / "parameter_search_comparison.csv", index=False)
    pd.DataFrame(comparison_rows).to_csv(out / "ideal_vs_decoy.csv", index=False)
    pd.DataFrame(budget_rows).to_csv(out / "bit_budgets.csv", index=False)
    pd.DataFrame(diagnostic_rows).to_csv(out / "local_threshold_diagnostics.csv", index=False)
    pd.DataFrame(sensitivity_rows).to_csv(out / "f_ec_sensitivity.csv", index=False)
    pd.DataFrame(completeness_rows).to_csv(out / "honest_success.csv", index=False)
    pd.DataFrame(_epsilon_rows(base)).to_csv(out / "epsilon_allocation.csv", index=False)
    if selected_for_benchmark is not None:
        pd.DataFrame(_benchmark_rows(selected_for_benchmark)).to_csv(out / "source_benchmark.csv", index=False)

    config_record = {
        "description": "Finite decoy-state fixed-output output-or-abort planning configuration.",
        "counts_convention": "honest expected-count planning uses floors for detections and ceilings for errors; honest Monte Carlo samples intensities, bases, detections, and errors before applying the same observable-count estimator",
        "finite_key_source": "Wiesemann et al. arXiv:2405.16578v3, Appendix A.2 and Eq. (137)",
        "security_budget": {
            "epsilon_convention": "eps_cor=eps_sec_prime=eps_tot/2; common auxiliary epsilon_0=eps_sec_prime/(12+2+2+1)",
            "count_concentration_events": len(COUNT_CONCENTRATION_EVENTS),
            "common_branch_count": TWO_DECOY_COMMON_SECURITY_BRANCHES,
        },
        "fixed_output_protocol": {
            "output_bits": output_bits,
            "betas": betas,
            "acceptance_policy": "precommitted thresholds for s_Z0^L, s_Z1^L, s_X1^L, Lambda_X^U, and analytical leakage cap",
            "margin_scale": args.margin_scale,
            "mc_trials_beta_1e-2": args.mc_trials,
            "mc_trials_beta_le_1e-3": args.mc_trials_strict,
        },
        "asymptotic_source": "Lo-Ma-Chen / Ma-Qi-Zhao-Lo vacuum-plus-weak formulas",
        "losses_db": losses,
        "y0": y0,
        "e_d": e_d,
        "search_domain": {
            "initial_coarse_grid": "mu in {0.3,0.4,0.5,0.6,0.7}, nu in {0.05,0.10,0.15,0.20}, pZ in {0.80,0.90,0.95}, p_mu in {0.70,0.80,0.90}, p_nu in {0.05,0.10,0.20}",
            "differential_evolution": "mu in [0.1,1.0], nu=0.01+r(mu-0.0101), r in [0,0.999], pZ in [0.5,0.95], p_mu in [0.05,0.90], remaining probability split between p_nu and p_0 with split in [0.03,0.97]",
            "local_polish": "coordinate perturbations around the best coarse/refined/DE candidate",
        },
        "base_config": asdict(base),
    }
    (out / "configuration.json").write_text(json.dumps(config_record, indent=2), encoding="utf-8")

    metadata = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "runtime_seconds": round(time.time() - started, 3),
        "python": sys.version,
        "platform": platform.platform(),
        "packages": {
            "numpy": numpy.__version__,
            "scipy": scipy.__version__,
            "pandas": pd.__version__,
            "matplotlib": matplotlib.__version__,
        },
        "git_commit": _git_commit(),
        "quick": bool(args.quick),
        "seed": args.seed,
        "resume": bool(args.resume),
        "workers": int(args.workers),
        "search_method": "fixed-output first crossing, original coarse grid, refined grid, differential evolution with local polish, and Monte Carlo honest-success estimates",
    }
    (out / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    make_figures(out, report_figures)
    export_tables(out, report_tables)
    print(f"Wrote decoy results to {out}")
    print(f"Wrote decoy figures to {report_figures}")
    print(f"Wrote decoy TeX tables to {report_tables}")


if __name__ == "__main__":
    main()
