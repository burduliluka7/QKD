"""Regenerate exhaustive basis-resolved ideal-BB84 headline results."""

from __future__ import annotations

import argparse
import csv
from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
import sys
import time

import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))

from qkd.hamming import binary_entropy
from qkd.ideal_basis import ideal_key_length
from qkd.operational import find_operational_ideal_threshold, load_cascade_validation


Q_VALUES = (0.005, 0.01, 0.02, 0.03, 0.05)
MODELS = ("ideal_fec_1_1", "cascade_p95", "cascade_p99", "cascade_max")
PZ_GRID = tuple(round(0.50 + 0.02 * k, 2) for k in range(21))


def empirical_cap(table: pd.DataFrame, n_z: int, q_z_design: float, statistic: str) -> tuple[int, int, float, str]:
    col = {"p95": "p95_leakage", "p99": "p99_leakage", "max": "max_leakage"}[statistic]
    candidates = table[(table.n >= n_z) & (table.qber >= q_z_design)]
    if candidates.empty:
        distance = (table.n / max(n_z, 1)).apply(lambda x: abs(math.log(max(x, 1e-12)))) + 30 * abs(table.qber - q_z_design)
        row = table.loc[distance.idxmin()]
        policy = "nearest_boundary_fallback"
    else:
        distance = (candidates.n / max(n_z, 1)).apply(math.log) + 30 * (candidates.qber - q_z_design)
        row = candidates.loc[distance.idxmin()]
        policy = "conservative_larger_or_equal_grid"
    return math.ceil(float(row[col])), int(row.n), float(row.qber), policy


def cap_for(table: pd.DataFrame, model: str, n_z: int, q_z_design: float) -> tuple[int, int, float, str]:
    if model == "ideal_fec_1_1":
        return math.ceil(1.1 * n_z * binary_entropy(q_z_design)), n_z, q_z_design, "analytic_ideal_formula"
    return empirical_cap(table, n_z, q_z_design, model.removeprefix("cascade_"))


def evaluate_best(N: int, q_x_tol: float, q_z_design: float, model: str, leakage: pd.DataFrame) -> dict:
    best: dict | None = None
    for p_z in PZ_GRID:
        n_z = math.floor(N * p_z * p_z)
        cap, lookup_n, lookup_q, lookup_policy = cap_for(leakage, model, n_z, q_z_design)
        row = ideal_key_length(N, p_z, q_x_tol, q_z_design, cap)
        row.update(q_x_tol=q_x_tol, q_z_design=q_z_design, leakage_model=model, leakage_lookup_n=lookup_n, leakage_lookup_qber=lookup_q,
                   leakage_lookup_policy=lookup_policy)
        if best is None or (row["ell"], row["ell_real"], row["p_z"]) > (best["ell"], best["ell_real"], best["p_z"]):
            best = row
    assert best is not None
    return best


def write_capacity_tex(rows: pd.DataFrame, path: Path) -> None:
    lines = [r"\begin{tabular}{llrrrrr}", r"\toprule", r"$Q_X=Q_Z$ & leakage & $N_{\min}$ & $p_Z$ & $n_Z$ & $m_X$ & $t_{\rm ph}^U$\\", r"\midrule"]
    for row in rows.itertuples():
        label = row.leakage_model.replace("ideal_fec_1_1", r"ideal $f_{\mathrm{EC}}=1.1$").replace("cascade_", "Cascade ")
        lines.append(f"{100*row.q_x_tol:.1f}\\% & {label} & {row.N_min:,} & {row.p_z:.2f} & {row.n_Z:,} & {row.m_X:,} & {row.t_ph_upper:,}\\\\")
    lines.extend([r"\bottomrule", r"\end{tabular}"])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def operational_results(trial_path: Path) -> pd.DataFrame:
    records = load_cascade_validation(trial_path)
    rows: list[dict[str, object]] = []

    def certified_row(chosen, model: str) -> dict[str, object]:
        row = asdict(chosen)
        row["N_min"] = chosen.N
        row["expected_transmissions_upper"] = math.ceil(
            chosen.N / chosen.honest_success_lower_95
        )
        row["status"] = "certified"
        row["integer_search"] = "doubling_and_binary_search_with_final_64_integer_scan"
        if model == "analytic_fec_1_1":
            row["search_scope"] = "best_threshold_found_on_declared_p_z_grid"
            row["confidence_scope"] = "exact_count_and_test_tails_only"
            row["cascade_policy_selection"] = "not_applicable"
        else:
            point = records[(chosen.n_z, round(float(chosen.q_honest), 12))]
            row["search_scope"] = "selection_adjusted_four_pass_cascade_policy_on_declared_p_z_and_block_grid"
            row["confidence_scope"] = "simultaneous_one_sided_95_percent_over_six_block_sizes_at_each_fixed_q"
            row["cascade_policy_selection"] = "design_half_sets_caps_then_bonferroni_adjusted_validation_permits_block_selection"
            row["cascade_design_accepted_runs"] = point.design_accepted_runs
            row["cascade_design_trials"] = point.design_trials
            row["cascade_design_success_lower_95"] = point.design_success_lower_95
            row["cascade_validation_accepted_runs"] = point.accepted_validation_runs
            row["cascade_validation_trials"] = point.validation_trials
            row["cascade_validation_pointwise_lower_95"] = point.success_lower_95
            row["cascade_selection_family_size"] = point.selection_family_size
            row["cascade_selection_adjusted_lower_95"] = point.selection_adjusted_success_lower_95
        return row

    for q_honest in Q_VALUES:
        analytic_candidates = []
        for p_z in PZ_GRID:
            result = find_operational_ideal_threshold(
                p_z=p_z,
                q_honest=q_honest,
                leakage_model="analytic_fec_1_1",
                local_window=64,
            )
            if result is not None:
                analytic_candidates.append(result)
        analytic = min(analytic_candidates, key=lambda item: (item.N, -item.ell, item.p_z))
        rows.append(certified_row(analytic, "analytic_fec_1_1"))

        # The first half fixes one cap for every tested block size.  The second
        # half supplies simultaneous lower bounds over the six blocks at this
        # Q, using alpha/6.  Selection may therefore use those adjusted bounds
        # without treating an ordinary pointwise interval as post-selection.
        cascade_candidates = []
        eligible_block_sizes = tuple(
            sorted(
                block_size
                for (block_size, qber), point in records.items()
                if math.isclose(qber, q_honest)
                and point.selection_adjusted_success_lower_95 >= 0.92
            )
        )
        for p_z in PZ_GRID:
            for block_size in eligible_block_sizes:
                result = find_operational_ideal_threshold(
                    p_z=p_z,
                    q_honest=q_honest,
                    leakage_model="cascade_four_pass",
                    cascade_records=records,
                    cascade_block_size=block_size,
                    cascade_success_source="selection_adjusted",
                    local_window=64,
                )
                if result is not None:
                    cascade_candidates.append(result)
        if not cascade_candidates:
            rows.append(
                {
                    "q_honest": q_honest,
                    "leakage_model": "cascade_four_pass",
                    "status": "not_certified_on_selection_adjusted_cascade_block_grid",
                    "cascade_policy_selection": "no_block_met_both_security_and_selection_adjusted_success_requirements",
                }
            )
            continue
        selected = min(cascade_candidates, key=lambda item: (item.N, -item.ell, item.p_z))
        rows.append(certified_row(selected, "cascade_four_pass"))
    return pd.DataFrame(rows).sort_values(["q_honest", "leakage_model"])


def write_operational_tex(rows: pd.DataFrame, path: Path) -> None:
    lines = [
        r"\resizebox{\textwidth}{!}{%",
        r"\begin{tabular}{llrrrrrrr}",
        r"\toprule",
        r"honest $Q$ & reconciliation & transmissions & repeat-cost upper & $p_Z$ & $n_Z$ & $m_X$ & transcript cap & success lower bound\\",
        r"\midrule",
    ]
    for row in rows.itertuples(index=False):
        model = str(row.leakage_model)
        label = (
            r"analytical planning; no decoder"
            if model == "analytic_fec_1_1"
            else "Cascade IID simulation policy"
        )
        if str(row.status) != "certified":
            lines.append(f"{100*row.q_honest:.1f}\\% & {label} & not certified & -- & -- & -- & -- & -- & --\\\\")
            continue
        success = float(row.honest_success_lower_95)
        lines.append(
            f"{100*row.q_honest:.1f}\\% & {label} & {int(row.N_min):,} & {int(row.expected_transmissions_upper):,} & {row.p_z:.2f} & "
            f"{int(row.n_z):,} & {int(row.m_x):,} & {int(row.leakage_cap):,} & {100*success:.2f}\\%\\\\"
        )
    lines.extend([r"\bottomrule", r"\end{tabular}", r"}"])
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_operational_figures(rows: pd.DataFrame) -> None:
    usable = rows[rows.status == "certified"].copy()
    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    for model, group in usable.groupby("leakage_model"):
        label = "analytic leakage planning reference" if model == "analytic_fec_1_1" else "four-pass Cascade, 90% honest-success target"
        ax.plot(100 * group.q_honest, group.N_min, marker="o", label=label)
    ax.set(
        xlabel="honest independent bit-error probability (\%)",
        ylabel="transmitted ideal single photons",
        title="Completeness-aware 256-bit resource thresholds",
    )
    ax.legend()
    fig.tight_layout()
    fig.savefig(ROOT / "report" / "figures" / "ideal_basis_minima.pdf")
    plt.close(fig)

    pivot = usable.pivot(index="q_honest", columns="leakage_model", values="N_min")
    if {"analytic_fec_1_1", "cascade_four_pass"}.issubset(pivot.columns):
        comparison = pivot.dropna().copy()
        increase = 100.0 * (
            comparison["cascade_four_pass"] / comparison["analytic_fec_1_1"] - 1.0
        )
        fig, ax = plt.subplots(figsize=(7.0, 4.2))
        ax.plot(100 * increase.index, increase.values, marker="o")
        ax.set(
            xlabel="honest independent bit-error probability (\%)",
            ylabel="increase over analytic planning reference (\%)",
            title="Cost of a complete padded Cascade transcript",
        )
        fig.tight_layout()
        fig.savefig(ROOT / "report" / "figures" / "main_05_percent_increase_over_ideal.pdf")
        plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-n", type=int, default=100_000)
    parser.add_argument("--q-x-tol", type=float)
    parser.add_argument("--q-z-design", type=float)
    parser.add_argument("--output-dir", default="results/ideal_basis")
    parser.add_argument("--operational-only", action="store_true", help="Reuse the existing capacity table and regenerate only completeness-aware results.")
    args = parser.parse_args()
    started = time.perf_counter()
    out = ROOT / args.output_dir
    out.mkdir(parents=True, exist_ok=True)
    leakage = pd.read_csv(ROOT / "results_03_reconciliation" / "tables" / "reconciliation_summary.csv")
    if "protocol" in leakage:
        leakage = leakage[leakage.protocol.astype(str).str.lower().str.contains("cascade")]
    results, certificates = [], []
    if args.operational_only:
        existing = out / "capacity_minima.csv"
        if not existing.exists():
            existing = out / "minima.csv"
        if not existing.exists():
            raise FileNotFoundError("--operational-only requires an existing capacity minima CSV")
        frame = pd.read_csv(existing)
    else:
        frame = None
    if (args.q_x_tol is None) != (args.q_z_design is None):
        parser.error("--q-x-tol and --q-z-design must be supplied together")
    q_pairs = ((args.q_x_tol, args.q_z_design),) if args.q_x_tol is not None else tuple((q, q) for q in Q_VALUES)
    for q_x_tol, q_z_design in (() if args.operational_only else q_pairs):
        pending = set(MODELS)
        previous: dict[str, dict] = {}
        for N in range(256, args.max_n + 1):
            for model in tuple(pending):
                current = evaluate_best(N, q_x_tol, q_z_design, model, leakage)
                if not current["passes"]:
                    previous[model] = current
                    continue
                current["N_min"] = current["N"]
                current["global_minimum_certified_on_grid"] = True
                results.append(current)
                before = previous.get(model)
                certificates.append({
                    "q_x_tol": q_x_tol, "q_z_design": q_z_design, "leakage_model": model, "tested_interval_start": 256,
                    "tested_interval_end": current["N"], "integers_tested": current["N"] - 255,
                    "p_z_grid": list(PZ_GRID), "ell_N_minus_1": before["ell"] if before else None,
                    "ell_N": current["ell"], "best_p_z_N_minus_1": before["p_z"] if before else None,
                    "best_p_z_N": current["p_z"], "chosen_L_max": current["L_max"],
                    "chosen_t_ph_upper": current["t_ph_upper"], "n_Z": current["n_Z"], "m_X": current["m_X"],
                    "e_X_tol": current["e_X_tol"], "certification": "exhaustive_integer_search_over_declared_p_z_grid",
                })
                pending.remove(model)
            if not pending:
                break
        if pending:
            raise RuntimeError(f"no crossing for {(q_x_tol, q_z_design)=}: {sorted(pending)}")
    if frame is None:
        frame = pd.DataFrame(results).sort_values(["q_x_tol", "q_z_design", "leakage_model"])
    frame.to_csv(out / "capacity_minima.csv", index=False)
    if not args.operational_only:
        (out / "capacity_search_certificate.json").write_text(
            json.dumps(certificates, indent=2),
            encoding="utf-8",
        )
    if args.q_x_tol is None:
        write_capacity_tex(frame, ROOT / "report" / "generated_tables" / "ideal_capacity_minima.tex")
        operational = operational_results(
            ROOT / "results_03_reconciliation" / "tables" / "reconciliation_trials.csv"
        )
        operational.to_csv(out / "minima.csv", index=False)
        write_operational_tex(operational, ROOT / "report" / "generated_tables" / "ideal_basis_minima.tex")
        write_operational_figures(operational)
    trial_path = ROOT / "results_03_reconciliation" / "tables" / "reconciliation_trials.csv"
    trial_hash = hashlib.sha256(trial_path.read_bytes()).hexdigest()
    metadata = {
        "schema_version": "ideal-operational-thresholds-v2",
        "command": "python code/run_ideal_basis_results.py" + (" --operational-only" if args.operational_only else ""),
        "runtime_seconds": time.perf_counter() - started,
        "capacity_results_refreshed": not args.operational_only,
        "capacity_search_certificate": "results/ideal_basis/capacity_search_certificate.json",
        "legacy_capacity_certificate_alias": "results/ideal_basis/search_certificate.json",
        "search_start": 256,
        "p_z_grid": list(PZ_GRID),
        "symmetric_q_values": list(Q_VALUES),
        "capacity_models": list(MODELS),
        "operational_models": ["analytic_fec_1_1", "cascade_four_pass"],
        "honest_link_model": "lossless ideal single photons with independent basis choices and independent bit errors",
        "basis_shortfall_budget": 0.01,
        "x_test_abort_budget": 0.01,
        "cascade_success_gate": 0.92,
        "combined_cascade_success_target": 0.90,
        "cascade_trial_file": str(trial_path.relative_to(ROOT)),
        "cascade_trial_file_sha256": trial_hash,
        "cascade_split": "the first 100 trials set one two-bit transcript cap per block; the last 100 trials validate each cap and decoder jointly",
        "cascade_transcript_bits_per_query": 2,
        "cascade_selection_adjustment": "for each fixed Q, six block sizes are compared with one-sided Clopper-Pearson alpha=0.05/6, giving at least 95% simultaneous coverage by the union bound",
        "confidence_scope": "simultaneous over the six tested block sizes at each fixed Q; the separate Q rows do not have a joint family-wise confidence statement",
    }
    (out / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print("Accepted-run capacity thresholds:")
    print(frame[["q_x_tol", "q_z_design", "leakage_model", "N_min", "p_z", "n_Z", "m_X", "ell"]].to_string(index=False))
    if args.q_x_tol is None:
        print("\nCompleteness-aware thresholds:")
        print(operational.to_string(index=False))


if __name__ == "__main__":
    main()
