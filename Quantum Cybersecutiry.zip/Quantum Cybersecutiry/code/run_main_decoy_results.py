from __future__ import annotations

import argparse
import csv
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import re
import platform
import subprocess
import sys
import time

import matplotlib
import matplotlib.pyplot as plt
import numpy
import pandas as pd
import scipy

from qkd.decoy_finite import (
    COUNT_CONCENTRATION_EVENTS,
    COUNT_EVENT_DETAILS,
    SecurityBudget,
    TWO_DECOY_COMMON_SECURITY_BRANCHES,
)
from qkd.decoy_operating import (
    DecoyFirstCrossing,
    DecoyOperatingPoint,
    DecoySourceProbabilities,
    build_nominal_decoy_counts,
    estimate_operating_point_success,
    find_first_decoy_crossing,
    find_operational_decoy_threshold,
    load_operating_points,
    OperationalDecoyThreshold,
    OperatingPointSuccessEstimate,
    probability_grid,
)
from qkd.hamming import binary_entropy
from qkd.fixed_output import boundary_acceptance_policy
from qkd.reporting import write_tex_table


ROOT = Path(__file__).resolve().parents[1]


def _git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=ROOT,
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        return "unavailable"


def _git_status() -> str:
    try:
        status = subprocess.check_output(
            ["git", "status", "--short"],
            cwd=ROOT,
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        return status or "clean"
    except Exception:
        return "unavailable"


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _fmt_float(value: float, digits: int = 3) -> str:
    if not math.isfinite(value):
        return "nan"
    if value == 0.0:
        return "0"
    if abs(value) < 1e-3 or abs(value) >= 1e4:
        return f"{value:.{digits}e}"
    return f"{value:.{digits}f}"


def _escape(text: object) -> str:
    return str(text).replace("_", "\\_").replace("%", "\\%")


def _crossing_row(crossing: DecoyFirstCrossing) -> dict[str, object]:
    res = crossing.result
    prev = crossing.previous_result
    probs = crossing.probabilities
    op = crossing.operating_point
    return {
        "operating_point_id": op.operating_point_id,
        "policy": crossing.policy_label,
        "N_256": crossing.N_256,
        "N_256_certification": "locally_verified_candidate",
        "ell_previous": prev.final_key_length if prev else "",
        "ell_at_N_256": res.final_key_length,
        "theorem_bound_real": res.real_key_length,
        "theorem_bound_integer": res.final_key_length,
        "protocol_output": 256 if res.final_key_length >= 256 else "abort",
        "certified_slack_above_256": res.real_key_length - 256.0,
        "accept_min_s_z0": res.s_z0_lower,
        "accept_min_s_z1": res.s_z1_lower,
        "accept_min_s_x1": res.s_x1_lower,
        "accept_max_phase_error": res.phase_error_upper,
        "accept_max_leak_ec": res.leak_ec,
        "acceptance_policy_note": "precommitted thresholds; execution recomputes certified quantities from observed labelled counts",
        "previous_failure_reason": crossing.previous_failure_reason,
        "status": res.status,
        "search_status": crossing.search_status,
        "verified_interval_start": crossing.verified_interval_start,
        "verified_interval_end": crossing.verified_interval_end,
        "mu": op.mu,
        "nu": op.nu,
        "Q_mu": op.q_mu,
        "Q_nu": op.q_nu,
        "Q_0": op.q_0,
        "E_mu": op.e_mu,
        "E_nu": op.e_nu,
        "E_0": op.e_0,
        "loss_db_metadata": op.loss_db if op.loss_db is not None else "",
        "p_z": probs.p_z,
        "p_mu": probs.p_mu,
        "p_nu": probs.p_nu,
        "p_0": probs.p_0,
        "z_detections": res.z_counts.total_detections,
        "x_detections": res.x_counts.total_detections,
        "z_errors": res.z_counts.total_errors,
        "x_errors": res.x_counts.total_errors,
        "s_z0_lower": res.s_z0_lower,
        "s_z1_lower": res.s_z1_lower,
        "s_x1_lower": res.s_x1_lower,
        "v_x1_upper": res.v_x1_upper,
        "lambda_x_upper": res.lambda_x_upper,
        "gamma": res.gamma,
        "phase_error_upper": res.phase_error_upper,
        "leak_ec": res.leak_ec,
        "verification_overhead": res.verification_overhead,
        "secrecy_overhead": res.secrecy_overhead,
        "real_key_length": res.real_key_length,
        "final_key_length": res.final_key_length,
        "description": op.description,
        "provenance": op.provenance,
    }


def _operational_row(
    threshold: OperationalDecoyThreshold,
    success: OperatingPointSuccessEstimate,
    margin_scale: float,
) -> dict[str, object]:
    result = threshold.result
    previous = threshold.previous_policy
    policy = threshold.policy
    probabilities = threshold.probabilities
    operating_point = threshold.operating_point
    return {
        "operating_point_id": operating_point.operating_point_id,
        "policy": threshold.policy_label,
        "N_256": threshold.N_256,
        "N_256_certification": "precommitted_policy_with_held_out_count_acceptance_validation",
        "policy_bound_previous": previous.certified_key_length() if previous else "",
        "policy_bound_at_N_256": policy.certified_key_length(),
        "nominal_count_bound_at_N_256": result.final_key_length,
        "protocol_output": 256,
        "count_acceptance_trials": success.trials,
        "count_acceptances": success.successes,
        "count_acceptance_estimate": success.estimate,
        "count_acceptance_lower_95": success.lower_95_one_sided,
        "count_acceptance_upper_95": success.upper_95_one_sided,
        "count_repeat_cost_upper": math.ceil(
            threshold.N_256 / success.lower_95_one_sided
        ) if success.lower_95_one_sided > 0.0 else "",
        "full_protocol_repeat_cost": "not_available_without_validated_reconciliation_success",
        "count_abort_reasons": json.dumps(success.abort_reasons, sort_keys=True),
        "count_acceptance_target": 0.99,
        "count_acceptance_target_met": success.lower_95_one_sided >= 0.99,
        "margin_scale": margin_scale,
        "accept_min_z_detections": policy.min_z_detections,
        "accept_min_x_detections": policy.min_x_detections,
        "accept_min_s_z0": policy.min_s_z0,
        "accept_min_s_z1": policy.min_s_z1,
        "accept_min_s_x1": policy.min_s_x1,
        "accept_max_lambda_x": policy.max_lambda_x,
        "accept_max_leak_ec": policy.max_leak_ec,
        "accept_phase_error": policy.phase_error_bound(),
        "policy_bound_real": policy.certified_real_key_length(),
        "p_z": probabilities.p_z,
        "p_mu": probabilities.p_mu,
        "p_nu": probabilities.p_nu,
        "p_0": probabilities.p_0,
        "mu": operating_point.mu,
        "nu": operating_point.nu,
        "Q_mu": operating_point.q_mu,
        "Q_nu": operating_point.q_nu,
        "Q_0": operating_point.q_0,
        "E_mu": operating_point.e_mu,
        "E_nu": operating_point.e_nu,
        "E_0": operating_point.e_0,
        "z_detections_nominal": result.z_counts.total_detections,
        "x_detections_nominal": result.x_counts.total_detections,
        "s_z0_lower_nominal": result.s_z0_lower,
        "s_z1_lower_nominal": result.s_z1_lower,
        "s_x1_lower_nominal": result.s_x1_lower,
        "lambda_x_upper_nominal": result.lambda_x_upper,
        "leak_ec_nominal": result.leak_ec,
        "verified_interval_start": threshold.verified_interval_start,
        "verified_interval_end": threshold.verified_interval_end,
        "description": operating_point.description,
        "provenance": operating_point.provenance,
    }


def _operating_point_row(op: DecoyOperatingPoint) -> dict[str, object]:
    return {
        "operating_point_id": op.operating_point_id,
        "mu": op.mu,
        "nu": op.nu,
        "Q_mu": op.q_mu,
        "Q_nu": op.q_nu,
        "Q_0": op.q_0,
        "E_mu": op.e_mu,
        "E_nu": op.e_nu,
        "E_0": op.e_0,
        "loss_db_metadata": op.loss_db if op.loss_db is not None else "",
        "description": op.description,
        "provenance": op.provenance,
        "validation_status": "ok",
    }


def _candidate_row(op: DecoyOperatingPoint, crossing: DecoyFirstCrossing, rank: int) -> dict[str, object]:
    row = _crossing_row(crossing)
    row["rank"] = rank
    row["operating_point_id"] = op.operating_point_id
    return row


def _local_diagnostic_rows(crossing: DecoyFirstCrossing, window: int = 5) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    op = crossing.operating_point
    probs = crossing.probabilities
    for N in range(max(1, crossing.N_256 - window), crossing.N_256 + window + 1):
        local = find_first_decoy_crossing(
            op,
            probs,
            eps_tot=crossing.result.config.eps_tot,
            f_ec=crossing.result.config.f_ec,
            target_bits=crossing.result.config.target_bits,
            start=N,
            max_N=N,
            exact_scan_limit=1,
            policy_label=crossing.policy_label,
        ).result
        rows.append(
            {
                "operating_point_id": op.operating_point_id,
                "policy": crossing.policy_label,
                "N_256": crossing.N_256,
                "N": N,
                "offset": N - crossing.N_256,
                "ell_decoy": local.final_key_length,
                "real_key_length": local.real_key_length,
                "status": "ok" if local.estimation_feasible and local.final_key_length >= local.config.target_bits else local.status,
            }
        )
    return rows


def _direct_local_diagnostic_rows(crossing: DecoyFirstCrossing, window: int = 5) -> list[dict[str, object]]:
    # Direct evaluation is faster and avoids re-running the crossing search for
    # a diagnostic window.
    from qkd.decoy_operating import evaluate_decoy_key_length_from_counts

    rows: list[dict[str, object]] = []
    op = crossing.operating_point
    probs = crossing.probabilities
    cfg = crossing.result.config
    for N in range(max(1, crossing.N_256 - window), crossing.N_256 + window + 1):
        local = evaluate_decoy_key_length_from_counts(
            N,
            op,
            probs,
            eps_tot=cfg.eps_tot,
            f_ec=cfg.f_ec,
            target_bits=cfg.target_bits,
            security_budget=crossing.result.security_budget,
        )
        rows.append(
            {
                "operating_point_id": op.operating_point_id,
                "policy": crossing.policy_label,
                "N_256": crossing.N_256,
                "N": N,
                "offset": N - crossing.N_256,
                "ell_decoy": local.final_key_length,
                "real_key_length": local.real_key_length,
                "status": "ok" if local.estimation_feasible and local.final_key_length >= cfg.target_bits else local.status,
            }
        )
    return rows


def _budget_rows(crossing: DecoyFirstCrossing) -> list[dict[str, object]]:
    result = crossing.result
    phase_deduction = result.s_z1_lower * binary_entropy(result.phase_error_upper)
    stages = [
        ("certified vacuum credit", result.s_z0_lower),
        ("certified Z single-photon credit", result.s_z1_lower),
        ("phase-error entropy deduction", phase_deduction),
        ("analytical reconciliation leakage", result.leak_ec),
        ("correctness deduction", result.verification_overhead),
        ("secrecy deduction", result.secrecy_overhead),
        ("real certified length", result.real_key_length),
        ("integer certified length", result.final_key_length),
    ]
    return [
        {
            "operating_point_id": crossing.operating_point.operating_point_id,
            "policy": crossing.policy_label,
            "N_256": crossing.N_256,
            "stage": stage,
            "value": value,
        }
        for stage, value in stages
    ]


def _operational_budget_rows(threshold: OperationalDecoyThreshold) -> list[dict[str, object]]:
    policy = threshold.policy
    phase = policy.phase_error_bound()
    phase_deduction = policy.min_s_z1 * binary_entropy(phase)
    stages = [
        ("accepted vacuum credit", policy.min_s_z0),
        ("accepted Z single-photon credit", policy.min_s_z1),
        ("phase-error entropy deduction", phase_deduction),
        ("reconciliation leakage cap", policy.max_leak_ec),
        ("correctness deduction", policy.security_budget.verification_overhead_bits()),
        ("secrecy deduction", policy.security_budget.secrecy_overhead_bits()),
        ("policy certified length", policy.certified_real_key_length()),
        ("fixed protocol output", policy.output_bits),
    ]
    return [
        {
            "operating_point_id": threshold.operating_point.operating_point_id,
            "policy": threshold.policy_label,
            "N_256": threshold.N_256,
            "stage": stage,
            "value": value,
        }
        for stage, value in stages
    ]


def _epsilon_rows(eps_tot: float) -> list[dict[str, object]]:
    budget = SecurityBudget.wiesemann_equal_split(eps_tot)
    eps0 = budget.common_auxiliary_value()
    rows = [
        {
            "event": "epsilon_cor",
            "meaning": "correctness verification failure",
            "symbol": "epsilon_cor",
            "value": budget.epsilon_cor,
            "multiplicity": 1,
        },
        {
            "event": "epsilon_sec_prime",
            "meaning": "accepted-key secrecy budget before correctness",
            "symbol": "epsilon_sec_prime",
            "value": budget.epsilon_sec_prime,
            "multiplicity": 1,
        },
        {
            "event": "common_auxiliary",
            "meaning": "equal value assigned to every Eq. (137) auxiliary branch",
            "symbol": f"epsilon_0=epsilon_sec_prime/{TWO_DECOY_COMMON_SECURITY_BRANCHES}",
            "value": eps0,
            "multiplicity": TWO_DECOY_COMMON_SECURITY_BRANCHES,
        },
    ]
    for name in COUNT_CONCENTRATION_EVENTS:
        basis, quantity, intensity, side, equation = COUNT_EVENT_DETAILS[name]
        rows.append(
            {
                "event": name,
                "meaning": f"{side} Hoeffding bound for {basis}-basis {intensity} {quantity} count",
                "symbol": name,
                "value": budget.concentration_epsilons[name],
                "multiplicity": 1,
                "source": equation,
            }
        )
    rows.append(
        {
            "event": "union_bound_denominator",
            "meaning": "12 count events plus 2 Serfling plus 2 smoothing plus 1 privacy branch",
            "symbol": "12+2+2+1",
            "value": TWO_DECOY_COMMON_SECURITY_BRANCHES,
            "multiplicity": TWO_DECOY_COMMON_SECURITY_BRANCHES,
        }
    )
    return rows


def _write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


RAW_OBSERVATION_FIELDS = [
    f"{quantity}_{basis}_{intensity}"
    for quantity in ("n", "c")
    for basis in ("Z", "X")
    for intensity in ("mu", "nu", "0")
]


def _security_record(budget: SecurityBudget) -> dict[str, object]:
    return {
        "epsilon_cor": budget.epsilon_cor,
        "epsilon_sec_prime": budget.epsilon_sec_prime,
        "epsilon_serfling": budget.epsilon_serfling,
        "epsilon_smoothing": budget.epsilon_smoothing,
        "epsilon_pa": budget.epsilon_pa,
        "concentration_epsilons": dict(budget.concentration_epsilons),
    }


def _acceptance_policy_row(crossing: DecoyFirstCrossing) -> dict[str, object]:
    result = crossing.result
    policy = boundary_acceptance_policy(result, output_bits=256)
    if not policy.is_certifying():
        raise ValueError(
            f"Policy {crossing.operating_point.operating_point_id}/{crossing.policy_label} "
            f"fails policy_bound_integer >= 256: {policy.certified_key_length()}"
        )
    op, probs = crossing.operating_point, crossing.probabilities
    return {
        "operating_point_id": op.operating_point_id,
        "policy_name": crossing.policy_label,
        "N": crossing.N_256,
        "mu": op.mu,
        "nu": op.nu,
        "p_z": probs.p_z,
        "p_mu": probs.p_mu,
        "p_nu": probs.p_nu,
        "p_0": probs.p_0,
        "basis_symmetric_planning": True,
        "a_0": policy.min_s_z0,
        "a_1": policy.min_s_z1,
        "a_X": policy.min_s_x1,
        "lambda_max": policy.max_lambda_x,
        "L_max": policy.max_leak_ec,
        "phase_error_policy_bound": policy.phase_error_bound(),
        "policy_bound_real": policy.certified_real_key_length(),
        "policy_bound_integer": policy.certified_key_length(),
        "fixed_output_bits": policy.output_bits,
        "acceptance_rule_version": "finite-decoy-fixed-output-v1",
        "security_parameters": _security_record(policy.security_budget),
        "count_rounding_convention": "matched sent and detections floor; errors ceil then clip at detections",
        "estimator_version": "wiesemann-eq137-two-decoy-v1",
    }


def _diagnostic_flags(result) -> dict[str, object]:
    cfg = result.config
    return {
        "s_Z_0_clipped": result.s_z0_lower in {0.0, float(result.z_counts.total_detections)},
        "s_Z_1_clipped": result.s_z1_lower in {0.0, float(result.z_counts.total_detections)},
        "s_X_1_clipped": result.s_x1_lower in {0.0, float(result.x_counts.total_detections)},
        "v_X_1_clipped": result.v_x1_upper in {0.0, result.s_x1_lower},
        "Lambda_X_denominator_valid": result.s_x1_lower > 0.0,
        "Lambda_X_clipped": result.lambda_x_upper in {0.0, 1.0},
        "gamma_domain_valid": result.s_z1_lower > 0.0 and result.s_x1_lower > 0.0,
        "phi_Z_clipped": result.phase_error_upper in {0.0, 1.0},
        "truncated_entropy_branch": result.phase_error_upper > 0.5,
        "zero_single_photon_test": result.s_x1_lower <= 0.0,
        "zero_single_photon_key": result.s_z1_lower <= 0.0,
        "estimator_feasible": result.estimation_feasible,
        "key_length_feasible": result.feasible,
        "vacuum_denominator_valid": cfg.nu - cfg.omega > 0.0,
        "single_photon_denominator_valid": cfg.mu * (cfg.nu - cfg.omega) - (cfg.nu**2 - cfg.omega**2) > 0.0,
        "abort_or_invalidity_status": result.status,
    }


def _boundary_rows(crossings: list[DecoyFirstCrossing]) -> list[dict[str, object]]:
    from qkd.decoy_operating import evaluate_decoy_key_length_from_counts
    rows: list[dict[str, object]] = []
    for crossing in crossings:
        pair = []
        for side, N in (("N_minus_1", crossing.N_256 - 1), ("N", crossing.N_256)):
            result = evaluate_decoy_key_length_from_counts(
                N, crossing.operating_point, crossing.probabilities,
                eps_tot=crossing.result.config.eps_tot,
                f_ec=crossing.result.config.f_ec,
                target_bits=crossing.result.config.target_bits,
                security_budget=crossing.result.security_budget,
            )
            row = {
                "operating_point_id": crossing.operating_point.operating_point_id,
                "policy": crossing.policy_label,
                "N": N,
                "boundary_side": side,
                "s_Z_0_L": result.s_z0_lower,
                "s_Z_1_L": result.s_z1_lower,
                "s_X_1_L": result.s_x1_lower,
                "v_X_1_U": result.v_x1_upper,
                "Lambda_X_U": result.lambda_x_upper,
                "gamma": result.gamma,
                "phi_Z_U": result.phase_error_upper,
                "leak_EC": result.leak_ec,
                "theorem_bound_real": result.real_key_length,
                "theorem_bound_integer": result.final_key_length,
                "protocol_output": 256 if result.feasible else "abort",
                "feasible": result.feasible,
                **_diagnostic_flags(result),
            }
            pair.append(row)
            rows.append(row)
        changed = [key for key in pair[0] if key not in {"N", "boundary_side", "theorem_bound_real", "theorem_bound_integer", "protocol_output"} and pair[0][key] != pair[1][key]]
        cause = "estimator feasibility boundary" if pair[0]["estimator_feasible"] != pair[1]["estimator_feasible"] else "count rounding changes theorem inputs"
        for row in pair:
            row["jump_cause"] = cause
            row["changed_fields"] = ";".join(changed)
    return rows


def _export_tables(results_dir: Path, tables_dir: Path) -> None:
    tables_dir.mkdir(parents=True, exist_ok=True)
    ops = pd.read_csv(results_dir / "operating_points_validated.csv")
    crossings = pd.read_csv(results_dir / "first_crossings.csv")
    budgets = pd.read_csv(results_dir / "bit_budgets.csv")
    epsilon = pd.read_csv(results_dir / "epsilon_allocation.csv")

    op_rows = []
    for row in ops.itertuples(index=False):
        loss_match = re.search(r"(\d+)\s*dB", str(row.operating_point_id))
        loss_label = f"{int(loss_match.group(1))}\\,dB" if loss_match else _escape(row.operating_point_id)
        op_rows.append(
            [
                loss_label,
                f"{row.mu:.3f}",
                f"{row.nu:.3f}",
                _fmt_float(row.Q_mu),
                _fmt_float(row.Q_nu),
                _fmt_float(row.Q_0),
                _fmt_float(row.E_mu),
                _fmt_float(row.E_nu),
                _fmt_float(row.E_0),
            ]
        )
    write_tex_table(
        tables_dir / "main_decoy_operating_points.tex",
        "Externally supplied decoy operating points used by the equal-basis planning model, $Q_{X,k}=Q_{Z,k}=Q_k$ and $E_{X,k}=E_{Z,k}=E_k$ for every intensity. Each row is a synthetic operating point at one nominal channel-loss level.",
        "tab:main-decoy-operating-points",
        ["Nominal loss", "$\\mu$", "$\\nu$", "$Q_\\mu$", "$Q_\\nu$", "$Q_0$", "$E_\\mu$", "$E_\\nu$", "$E_0$"],
        op_rows,
        fit_width=True,
    )

    first_rows = []
    selected = crossings[crossings["policy"].isin(["fixed-probability", "grid-best"])]
    for row in selected.itertuples(index=False):
        first_rows.append(
            [
                _escape(row.operating_point_id),
                _escape(row.policy),
                f"{int(row.N_256):,}",
                f"{int(row.count_repeat_cost_upper):,}",
                f"{row.p_z:.2f}",
                f"{row.p_mu:.2f}",
                f"{row.p_nu:.2f}",
                f"{row.p_0:.2f}",
                f"{int(row.count_acceptances):,}/{int(row.count_acceptance_trials):,}",
                f"{100*row.count_acceptance_lower_95:.2f}\\%",
                f"{int(row.accept_max_leak_ec):,}",
            ]
        )
    write_tex_table(
        tables_dir / "main_decoy_first_crossings.tex",
        "Pulse counts found from the supplied synthetic operating points. Every row outputs exactly 256 bits or aborts and assumes reconciliation succeeds within the analytical leakage cap. The displayed lower endpoint is a pointwise one-sided 95\\% Clopper--Pearson bound for source-count acceptance under the supplied model. The $\\lceil N/p_L\\rceil$ column is a count-only repeat-cost bound; no finite full-protocol repeat-cost bound is claimed.",
        "tab:main-decoy-first-crossings",
        ["ID", "policy", "$\\widehat N_{99}^{\\rm count}$", "count-repeat upper", "$p_Z$", "$p_\\mu$", "$p_\\nu$", "$p_0$", "count accepted/trials", "count lower", "$L_{\\max}$"],
        first_rows,
        fit_width=True,
    )

    eps_rows = []
    epsilon_labels = {
        "epsilon_cor": (
            "Correctness",
            "verification-hash collision",
            "$\\eps_{\\mathrm{cor}}$",
        ),
        "epsilon_sec_prime": (
            "Accepted-key secrecy",
            "secrecy budget before correctness",
            "$\\eps'_{\\mathrm{sec}}$",
        ),
        "common_auxiliary": (
            "Equal auxiliary split",
            "each auxiliary branch in Eq.~\\ref{eq:finite-decoy-key-length}",
            f"$\\eps_0=\\eps'_{{\\mathrm{{sec}}}}/{TWO_DECOY_COMMON_SECURITY_BRANCHES}$",
        ),
        "union_bound_denominator": (
            "Union-bound denominator",
            "12 count events, 2 Serfling, 2 smoothing, 1 privacy amplification",
            "$12+2+2+1$",
        ),
    }
    for row in epsilon.itertuples(index=False):
        if row.event in {"epsilon_cor", "epsilon_sec_prime", "common_auxiliary", "union_bound_denominator"}:
            value = f"${row.value:.3e}$" if float(row.value) < 1 else f"${int(row.value)}$"
            label, meaning, symbol = epsilon_labels[row.event]
            eps_rows.append([label, meaning, symbol, value, f"{int(row.multiplicity)}"])
    write_tex_table(
        tables_dir / "main_decoy_epsilon_allocation.tex",
        "Main-decoy security bookkeeping. Count events are one-sided Hoeffding confidence statements for observed count fields; correctness is separate from the accepted-key secrecy budget.",
        "tab:main-decoy-epsilon-allocation",
        ["branch", "meaning", "symbol", "value", "mult."],
        eps_rows,
        fit_width=True,
    )

    budget_rows = []
    for row in budgets.itertuples(index=False):
        budget_rows.append(
            [
                _escape(row.operating_point_id),
                _escape(row.policy),
                f"{int(row.N_256):,}",
                _escape(row.stage),
                f"{row.value:.2f}" if abs(row.value) < 10_000 else f"{row.value:,.0f}",
            ]
        )
    write_tex_table(
        tables_dir / "main_decoy_bit_budgets.tex",
        "Representative count-acceptance policy budgets. The final row is the fixed 256-bit protocol output; any larger policy bound is unused slack.",
        "tab:main-decoy-bit-budgets",
        ["ID", "policy", "$\\widehat N_{99}^{\\rm count}$", "stage", "value"],
        budget_rows,
        fit_width=True,
    )


def _make_figures(results_dir: Path, figures_dir: Path) -> None:
    figures_dir.mkdir(parents=True, exist_ok=True)
    crossings = pd.read_csv(results_dir / "first_crossings.csv")
    diagnostics = pd.read_csv(results_dir / "local_threshold_diagnostics.csv")
    budgets = pd.read_csv(results_dir / "bit_budgets.csv")

    plt.rcParams.update({
        "axes.grid": True,
        "grid.alpha": 0.25,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "legend.frameon": False,
    })

    selected = crossings[crossings["policy"].isin(["fixed-probability", "grid-best"])].copy()
    fig, ax = plt.subplots(figsize=(6.4, 4.2))
    for policy, group in selected.groupby("policy"):
        group = group.sort_values("Q_mu")
        ax.plot(group["Q_mu"], group["N_256"], marker="o", label=policy.replace("-", " "))
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("supplied signal gain $Q_\\mu$")
    ax.set_ylabel("$\\widehat N_{99}^{\\mathrm{count}}$ transmitted weak-coherent pulses")
    ax.legend()
    fig.tight_layout()
    fig.savefig(figures_dir / "main_decoy_n256_vs_qmu.pdf")
    plt.close(fig)

    order = list(dict.fromkeys(selected["operating_point_id"]))
    x = numpy.arange(len(order))
    width = 0.36
    fig, ax = plt.subplots(figsize=(8.0, 4.4))
    for offset, policy in [(-width / 2, "fixed-probability"), (width / 2, "grid-best")]:
        values = []
        for op_id in order:
            match = selected[(selected["operating_point_id"] == op_id) & (selected["policy"] == policy)]
            values.append(float(match["N_256"].iloc[0]) if not match.empty else numpy.nan)
        ax.bar(x + offset, values, width=width, label=policy.replace("-", " "))
    ax.set_yscale("log")
    ax.set_xticks(x)
    ax.set_xticklabels(order, rotation=25, ha="right")
    ax.set_ylabel("$\\widehat N_{99}^{\\mathrm{count}}$ transmitted weak-coherent pulses")
    ax.legend()
    fig.tight_layout()
    fig.savefig(figures_dir / "main_decoy_policy_comparison.pdf")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.0, 4.0))
    colors = ["tab:green" if status == "ok" else "tab:red" for status in diagnostics["status"]]
    ax.scatter(diagnostics["offset"], diagnostics["ell_decoy"], c=colors)
    ax.axhline(256, color="black", linestyle="--", linewidth=1)
    ax.axvline(0, color="gray", linestyle=":", linewidth=1)
    ax.set_xlabel("$N-\\widehat N_{99}^{\\mathrm{count}}$")
    ax.set_ylabel("$\\ell_{\\mathrm{decoy}}(N)$")
    fig.tight_layout()
    fig.savefig(figures_dir / "main_decoy_threshold_diagnostic.pdf")
    plt.close(fig)

    chosen_id = budgets["operating_point_id"].iloc[0]
    sub = budgets[budgets["operating_point_id"] == chosen_id].copy()
    fig, ax = plt.subplots(figsize=(7.6, 4.4))
    ax.bar(numpy.arange(len(sub)), sub["value"].astype(float))
    ax.axhline(256, color="black", linestyle="--", linewidth=1)
    ax.set_xticks(numpy.arange(len(sub)))
    ax.set_xticklabels(sub["stage"], rotation=35, ha="right")
    ax.set_ylabel("bits or certified counts")
    ax.set_title(str(chosen_id))
    fig.tight_layout()
    fig.savefig(figures_dir / "main_decoy_bit_budget.pdf")
    plt.close(fig)


def _build_main_pdf(pdflatex: str) -> None:
    report_dir = ROOT / "report"
    pdflatex_cmd = [pdflatex, "-synctex=1", "-interaction=nonstopmode", "-halt-on-error", "main.tex"]
    subprocess.run(pdflatex_cmd, cwd=report_dir, check=True)
    if (report_dir / "main.aux").exists():
        subprocess.run(["bibtex", "main"], cwd=report_dir, check=True)
    for _ in range(2):
        subprocess.run(pdflatex_cmd, cwd=report_dir, check=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate main-manuscript deterministic decoy operating-point results.")
    parser.add_argument("--operating-points", default="config/decoy_operating_points.csv")
    parser.add_argument("--output-dir", default="results/main_decoy")
    parser.add_argument("--target-bits", type=int, default=256)
    parser.add_argument("--eps-tot", type=float, default=1e-9)
    parser.add_argument("--f-ec", type=float, default=1.16)
    parser.add_argument("--max-N", type=int, default=50_000_000_000)
    parser.add_argument("--exact-scan-limit", type=int, default=2048)
    parser.add_argument("--honest-trials", type=int, default=2000)
    parser.add_argument("--margin-scale", type=float, default=12.0)
    parser.add_argument("--quick", action="store_true", help="Use a reduced probability grid for smoke tests.")
    parser.add_argument("--build-pdf", action="store_true", help="After exporting results, rebuild report/main.pdf with SyncTeX.")
    parser.add_argument("--pdflatex", default="pdflatex", help="pdflatex executable used with --build-pdf.")
    args = parser.parse_args()

    started = time.time()
    op_path = (ROOT / args.operating_points).resolve()
    out = (ROOT / args.output_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    tables_dir = ROOT / "report" / "generated_tables"
    figures_dir = ROOT / "report" / "figures"
    tables_dir.mkdir(parents=True, exist_ok=True)
    figures_dir.mkdir(parents=True, exist_ok=True)

    points = load_operating_points(op_path)
    fixed_probs = DecoySourceProbabilities()
    if args.quick:
        p_z_values = [0.50, 0.60, 0.70]
        p_mu_values = [0.10, 0.20, 0.40]
        p_nu_values = [0.20, 0.40, 0.60]
    else:
        p_z_values = [0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90]
        p_mu_values = [0.02, 0.05, 0.10, 0.15, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80]
        p_nu_values = [0.05, 0.10, 0.20, 0.30, 0.40, 0.50, 0.60, 0.70, 0.80]
    grid = probability_grid(p_z_values, p_mu_values, p_nu_values)

    op_rows: list[dict[str, object]] = []
    operational_rows: list[dict[str, object]] = []
    capacity_rows: list[dict[str, object]] = []
    candidate_rows: list[dict[str, object]] = []
    diagnostic_rows: list[dict[str, object]] = []
    budget_rows: list[dict[str, object]] = []
    selected_thresholds: list[OperationalDecoyThreshold] = []
    reported_thresholds: list[OperationalDecoyThreshold] = []

    for op_index, op in enumerate(points):
        op_rows.append(_operating_point_row(op))
        fixed_threshold = find_operational_decoy_threshold(
            op,
            fixed_probs,
            eps_tot=args.eps_tot,
            f_ec=args.f_ec,
            target_bits=args.target_bits,
            completeness_beta=0.01,
            margin_scale=args.margin_scale,
            max_N=args.max_N,
            exact_scan_limit=args.exact_scan_limit,
            policy_label="fixed-probability",
        )
        fixed_success = estimate_operating_point_success(
            fixed_threshold,
            trials=args.honest_trials,
            seed=100_000 + op_index,
        )
        if fixed_success.lower_95_one_sided < 0.99:
            raise RuntimeError(
                f"{op.operating_point_id}: fixed policy missed the 99% held-out lower bound "
                f"({fixed_success.lower_95_one_sided:.6f})"
            )
        operational_rows.append(_operational_row(fixed_threshold, fixed_success, args.margin_scale))
        reported_thresholds.append(fixed_threshold)

        candidates: list[OperationalDecoyThreshold] = []
        for probs in grid:
            try:
                candidate = find_operational_decoy_threshold(
                    op,
                    probs,
                    eps_tot=args.eps_tot,
                    f_ec=args.f_ec,
                    target_bits=args.target_bits,
                    completeness_beta=0.01,
                    margin_scale=args.margin_scale,
                    max_N=args.max_N,
                    exact_scan_limit=args.exact_scan_limit,
                    policy_label="grid-best",
                )
            except ValueError:
                continue
            if candidate.policy.is_certifying():
                candidates.append(candidate)
        candidates.sort(key=lambda item: (item.N_256, -item.policy.certified_key_length()))
        optimized = candidates[0] if candidates else fixed_threshold
        optimized_success = estimate_operating_point_success(
            optimized,
            trials=args.honest_trials,
            seed=200_000 + op_index,
        )
        if optimized_success.lower_95_one_sided < 0.99:
            raise RuntimeError(
                f"{op.operating_point_id}: grid policy missed the 99% held-out lower bound "
                f"({optimized_success.lower_95_one_sided:.6f})"
            )
        operational_rows.append(_operational_row(optimized, optimized_success, args.margin_scale))
        reported_thresholds.append(optimized)
        selected_thresholds.append(optimized)
        for rank, candidate in enumerate(candidates[:10], start=1):
            candidate_rows.append(
                {
                    "operating_point_id": op.operating_point_id,
                    "rank": rank,
                    "N_256": candidate.N_256,
                    "p_z": candidate.probabilities.p_z,
                    "p_mu": candidate.probabilities.p_mu,
                    "p_nu": candidate.probabilities.p_nu,
                    "p_0": candidate.probabilities.p_0,
                    "policy_bound": candidate.policy.certified_key_length(),
                }
            )

        # Preserve the old nominal-count crossing as a comparison, evaluated at
        # the two probability choices now reported.  It is not the headline.
        for label, probabilities in (
            ("nominal-fixed-probability", fixed_probs),
            ("nominal-at-grid-best", optimized.probabilities),
        ):
            capacity = find_first_decoy_crossing(
                op,
                probabilities,
                eps_tot=args.eps_tot,
                f_ec=args.f_ec,
                target_bits=args.target_bits,
                max_N=args.max_N,
                exact_scan_limit=args.exact_scan_limit,
                policy_label=label,
            )
            capacity_rows.append(_crossing_row(capacity))

    if selected_thresholds:
        representatives = [selected_thresholds[min(1, len(selected_thresholds) - 1)]]
        if len(selected_thresholds) > 3:
            representatives.append(selected_thresholds[3])
        for threshold in representatives:
            budget_rows.extend(_operational_budget_rows(threshold))
        middle = selected_thresholds[len(selected_thresholds) // 2]
        for side, value in (("N_minus_1", middle.N_256 - 1), ("N", middle.N_256)):
            result, policy = (
                (middle.previous_result, middle.previous_policy)
                if side == "N_minus_1"
                else (middle.result, middle.policy)
            )
            diagnostic_rows.append(
                {
                    "operating_point_id": middle.operating_point.operating_point_id,
                    "N_256": middle.N_256,
                    "N": value,
                    "offset": value - middle.N_256,
                    "ell_decoy": policy.certified_key_length() if policy else "",
                    "real_key_length": policy.certified_real_key_length() if policy else "",
                    "status": "ok" if policy and policy.is_certifying() else "abort",
                }
            )

    _write_csv(out / "operating_points_validated.csv", op_rows)
    _write_csv(out / "first_crossings.csv", operational_rows)
    _write_csv(out / "capacity_first_crossings.csv", capacity_rows)
    _write_csv(out / "probability_search_top.csv", candidate_rows)
    _write_csv(out / "local_threshold_diagnostics.csv", diagnostic_rows)
    _write_csv(out / "bit_budgets.csv", budget_rows)
    _write_csv(out / "epsilon_allocation.csv", _epsilon_rows(args.eps_tot))
    policy_rows = operational_rows
    _write_csv(out / "acceptance_policies.csv", policy_rows)
    policy_document = {
        "schema_version": "finite-decoy-count-acceptance-policy-v2",
        "raw_observation_fields": RAW_OBSERVATION_FIELDS,
        "raw_observation_description": {
            "n_B_k": "observed click count labelled by basis B and intensity k",
            "c_B_k": "observed error count labelled by basis B and intensity k",
        },
        "count_acceptance_rule": "z_detections>=z_min and x_detections>=x_min and s_Z_0_L>=a_0 and s_Z_1_L>=a_1 and s_X_1_L>=a_X and Lambda_X_U<=lambda_max and leak_EC<=L_max",
        "probability_scope": "held-out trials validate source-count acceptance only; reconciliation success is not simulated",
        "full_output_condition": "count acceptance and reconciliation succeeds without exceeding the analytical leak_EC cap",
        "repeat_cost_scope": "count_repeat_cost_upper is ceil(N/count_acceptance_lower_95); a full repeat cost is unavailable until reconciliation success is validated",
        "policies": policy_rows,
    }
    (out / "acceptance_policies.json").write_text(json.dumps(policy_document, indent=2), encoding="utf-8")

    config_record = {
        "description": "Main-manuscript numerical threshold search for a fixed 256-bit output-or-abort finite-decoy protocol.",
        "operating_point_file": str(op_path.relative_to(ROOT)),
        "operating_point_file_sha256": _file_sha256(op_path),
        "objective": "smallest pulse count found on the declared probability grid whose precommitted policy certifies 256 bits and passes held-out source-count acceptance validation, conditional on reconciliation success within its analytical cap",
        "global_minimum_certified": False,
        "search_classification": "best threshold found by bracketing plus a final exact integer scan on the declared finite probability grid; neither an unrestricted integer minimum nor a continuous-source optimum is claimed",
        "counts_convention": "matched-basis sent populations are floored; expected detections are floored; expected errors are ceiled and clipped at detections; unused sent-pulse remainder is tracked.",
        "free_parameters": ["p_mu", "p_nu", "p_0", "p_z"],
        "fixed_by_operating_point": ["mu", "nu", "Q_mu", "Q_nu", "Q_0", "E_mu", "E_nu", "E_0"],
        "not_in_primary_path": ["detector_model_inputs", "continuous_intensity_optimization"],
        "honest_count_operation": {
            "target_count_acceptance_probability": 0.99,
            "confidence": "one-sided 95% Clopper-Pearson lower endpoint",
            "held_out_trials_per_reported_policy": args.honest_trials,
            "margin_scale": args.margin_scale,
            "random_seeds": "100000+row for fixed and 200000+row for grid-best policy",
            "conditioning": "reconciliation succeeds and remains within the precommitted analytical leakage cap; no decoder is simulated in the decoy operating-point study",
            "count_repeat_cost": "ceil(N/p_L), where p_L is the pointwise one-sided 95% lower confidence endpoint for count acceptance; this is not a full protocol repeat cost",
        },
        "security": {
            "eps_tot": args.eps_tot,
            "eps_cor": args.eps_tot / 2.0,
            "eps_sec_prime": args.eps_tot / 2.0,
            "common_denominator": TWO_DECOY_COMMON_SECURITY_BRANCHES,
            "count_events": len(COUNT_CONCENTRATION_EVENTS),
        },
        "target_bits": args.target_bits,
        "f_ec": args.f_ec,
        "fixed_probabilities": asdict(fixed_probs),
        "probability_grid": {
            "p_z": p_z_values,
            "p_mu": p_mu_values,
            "p_nu": p_nu_values,
            "p_0": "1-p_mu-p_nu>0",
        },
        "max_N": args.max_N,
        "exact_scan_limit": args.exact_scan_limit,
        "quick": bool(args.quick),
    }
    (out / "configuration.json").write_text(json.dumps(config_record, indent=2), encoding="utf-8")

    metadata = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "runtime_seconds": round(time.time() - started, 3),
        "python": sys.version,
        "platform": platform.platform(),
        "packages": {
            "numpy": numpy.__version__,
            "scipy": scipy.__version__,
            "pandas": pd.__version__,
            "matplotlib": matplotlib.__version__,
        },
        "git_commit": _git_commit(),
        "git_status": _git_status(),
        "deterministic": False,
        "random_seed": "recorded deterministic row-specific seeds for held-out Monte Carlo validation",
    }
    (out / "run_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    _export_tables(out, tables_dir)
    _make_figures(out, figures_dir)
    if args.build_pdf:
        _build_main_pdf(args.pdflatex)
    print(f"Wrote main decoy results to {out}")
    print(f"Wrote main decoy tables to {tables_dir}")
    print(f"Wrote main decoy figures to {figures_dir}")


if __name__ == "__main__":
    main()
