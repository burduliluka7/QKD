#!/usr/bin/env python3
"""
generate_ldpc_figures.py
========================
Loads LDPC simulation tables and generates diagnostic figures for the QKD paper.
Run run_ldpc_simulation.py first to create or refresh the LDPC tables.

  1. ldpc_efficiency_heatmap_ldpc_beta05.pdf
  2. ldpc_failure_rate_comparison.pdf
  3. ldpc_nmin_comparison.pdf
  4. ldpc_percent_increase_comparison.pdf

Saves everything to report/figures/ (alongside existing figures).
"""

from __future__ import annotations

import csv
import argparse
import itertools
import math
import sys
import time
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy.special
import scipy.stats

_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(_ROOT))

from ldpc_reconciliation import (
    build_ldpc_matrix,
    matrix_rank_gf2,
    run_sanity_checks,
)

# ─────────────────────────────────────────────────────────────
# Paths
# ─────────────────────────────────────────────────────────────
RESULTS_LDPC_DIR = _ROOT / "results_ldpc"
TABLES_DIR       = RESULTS_LDPC_DIR / "tables"
FIGURES_OUT_DIR  = _ROOT / "report" / "figures"
CASCADE_LEAKAGE_CSV = _ROOT / "results_03_reconciliation" / "tables" / "empirical_leakage_table.csv"
PUB_NMIN_CSV        = _ROOT / "results_05_publication-ready" / "tables" / "Nmin_local_verification.csv"

TABLES_DIR.mkdir(parents=True, exist_ok=True)
FIGURES_OUT_DIR.mkdir(parents=True, exist_ok=True)

# ─────────────────────────────────────────────────────────────
# Simulation parameters
# ─────────────────────────────────────────────────────────────
N_VALUES    = [256, 512, 1024, 2048]
Q_VALUES    = [0.005, 0.01, 0.02, 0.03, 0.05, 0.08]
BETA_VALUES = [0.01, 0.05]

DESIGN_TRIALS       = 15        # per r candidate (uses fast vectorized decoder)
EVAL_TRIALS         = 50        # final eval trials for selected code
CANDIDATE_SEEDS     = [0, 1, 2]
COARSE_STEP_FRAC    = 0.15
MAX_R_MULT          = 3.0
DV                  = 3
MAX_ITER            = 100

# ─────────────────────────────────────────────────────────────
# Nmin search parameters (match publication notebook)
# ─────────────────────────────────────────────────────────────
TARGET_BITS    = 256
EPS_TOTAL      = 1e-9
P_SIFT         = 0.5
M_FRAC_GRID    = np.linspace(0.06, 0.44, 20)
QTOL_GRID      = [0.005, 0.01, 0.02, 0.03, 0.05]   # Q_tol values for Nmin table

# ─────────────────────────────────────────────────────────────
# Plot style (match existing figures)
# ─────────────────────────────────────────────────────────────
plt.rcParams.update({
    "figure.figsize": (8.0, 4.8),
    "axes.grid": True,
    "grid.alpha": 0.25,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "font.size": 10,
    "axes.titlesize": 12,
    "axes.labelsize": 10,
    "legend.frameon": False,
})


# ═════════════════════════════════════════════════════════════
# Section 1: Math helpers (from publication notebook)
# ═════════════════════════════════════════════════════════════

def h2(q: float) -> float:
    q = float(q)
    if q <= 0.0 or q >= 1.0:
        return 0.0
    return -q * math.log2(q) - (1.0 - q) * math.log2(1.0 - q)


_HAMMING_CACHE: dict = {}

def log2_hamming_ball(n: int, t: int) -> float:
    n = int(n)
    t = int(math.floor(t))
    if t < 0:
        return float("-inf")
    if t == 0:
        return 0.0
    if t >= n:
        return float(n)
    key = (n, t)
    if key in _HAMMING_CACHE:
        return _HAMMING_CACHE[key]
    if t <= n // 2:
        ks = np.arange(0, t + 1, dtype=float)
        logs = (scipy.special.gammaln(n + 1) - scipy.special.gammaln(ks + 1)
                - scipy.special.gammaln(n - ks + 1))
        val = float(scipy.special.logsumexp(logs) / math.log(2.0))
    else:
        ks = np.arange(t + 1, n + 1, dtype=float)
        tail = (scipy.special.gammaln(n + 1) - scipy.special.gammaln(ks + 1)
                - scipy.special.gammaln(n - ks + 1))
        log_tail = float(scipy.special.logsumexp(tail))
        log_total = n * math.log(2.0)
        ratio = math.exp(log_tail - log_total) if (log_tail - log_total) > -745 else 0.0
        val = float(n + math.log1p(-ratio) / math.log(2.0))
    _HAMMING_CACHE[key] = val
    return val


def split_budget_balanced(eps_total: float) -> dict:
    """Balanced: eps_cor = eps_pe = eps_s = eps_pa = eps_total/5."""
    e = eps_total / 5.0
    return {"eps_cor": e, "eps_pe": e, "eps_s": e, "eps_pa": e}


def hypergeom_K_upper(e: int, S: int, m: int, eps_pe: float) -> int:
    e, S, m = int(e), int(S), int(m)
    if m <= 0 or S <= 0 or m >= S:
        return S
    lo, hi, best = 0, S, 0
    while lo <= hi:
        mid = (lo + hi) // 2
        cdf = scipy.stats.hypergeom.cdf(e, S, mid, m)
        if np.isfinite(cdf) and float(cdf) >= eps_pe:
            best = mid
            lo = mid + 1
        else:
            hi = mid - 1
    return int(best)


def phase_error_t_upper(q_tol: float, m: int, s: int, eps_pe: float) -> int:
    """Return t_ph^U: worst-case phase-error count for the unrevealed block."""
    m, s = int(m), int(s)
    n = s - m
    e_tol = int(math.floor(q_tol * m))
    if m <= 0 or n <= 0:
        return max(0, n)
    K = hypergeom_K_upper(e_tol, s, m, eps_pe)
    return int(np.clip(K - e_tol, 0, n))


def key_length_real(N: int, q_tol: float, m_frac: float,
                    Lmax: int, eps: dict) -> float:
    """Return real-valued key length (before floor). Returns -inf if infeasible."""
    s = int(math.floor(P_SIFT * N))
    m = int(math.floor(m_frac * s))
    n = s - m
    if n <= 0 or m <= 0 or Lmax is None:
        return float("-inf")
    t_ph = phase_error_t_upper(q_tol, m, s, eps["eps_pe"])
    H_raw = n - log2_hamming_ball(n, t_ph)
    t_ver = int(math.ceil(math.log2(1.0 / eps["eps_cor"])))
    pa_pen = 2.0 * math.log2(1.0 / eps["eps_pa"])
    return H_raw - Lmax - t_ver - pa_pen


# ═════════════════════════════════════════════════════════════
# Section 2: LDPC leakage lookup and Nmin search
# ═════════════════════════════════════════════════════════════

def build_ldpc_lookup(leakage_df: pd.DataFrame, beta: float) -> dict:
    """Return {(n, q): r} for given beta."""
    label = f"ldpc_beta{int(round(beta * 100)):02d}"
    sub = leakage_df[leakage_df["protocol"] == label].copy()
    out: dict = {}
    for _, row in sub.iterrows():
        if pd.notna(row.get("selected_r")):
            out[(int(row["n"]), float(row["qber"]))] = int(row["selected_r"])
    return out


def ldpc_Lmax(n: int, q_tol: float, lookup: dict) -> int | None:
    """
    Conservative ceiling lookup over simulated points with n_g >= n and q_g >= q_tol.
    Uses the largest leakage among those dominating points.
    Returns None if nothing is found.
    """
    n, q_tol = int(n), float(q_tol)
    # Preferred: dominating point
    dom = [(n_g, q_g, r) for (n_g, q_g), r in lookup.items()
           if n_g >= n and q_g >= q_tol - 1e-9]
    if dom:
        return max(r for _, _, r in dom)
    return None


def find_nmin(q_tol: float, lookup: dict, eps: dict,
              N_max: int = 500_000) -> int | None:
    """Binary search for Nmin, optimised over m_frac. Returns None if not found."""
    def best_ell(N: int) -> float:
        best = float("-inf")
        s = int(math.floor(P_SIFT * N))
        for mf in M_FRAC_GRID:
            m = int(math.floor(mf * s))
            n = s - m
            if n <= 0:
                continue
            Lmax = ldpc_Lmax(n, q_tol, lookup)
            if Lmax is None:
                continue
            v = key_length_real(N, q_tol, mf, Lmax, eps)
            if v > best:
                best = v
        return best

    # Exponential search
    lo, hi = 200, 400
    t0 = time.time()
    while math.floor(best_ell(hi)) < TARGET_BITS:
        lo = hi + 1
        hi = min(hi * 2, N_max)
        if hi >= N_max:
            return None
        if time.time() - t0 > 120:
            print(f"    WARNING: Nmin search timed out for q_tol={q_tol}")
            return None

    # Binary search
    while lo < hi:
        mid = (lo + hi) // 2
        if math.floor(best_ell(mid)) >= TARGET_BITS:
            hi = mid
        else:
            lo = mid + 1
    return lo


# ═════════════════════════════════════════════════════════════
# Section 3: Vectorized BP decoder + LDPC simulation
# ═════════════════════════════════════════════════════════════

def _build_edges(var_adj, chk_adj, n: int, r: int):
    """Build edge-index arrays for the Tanner graph (no caching — r varies)."""
    ev_list, ec_list = [], []
    ce: list = [[] for _ in range(r)]
    k = 0
    for i in range(n):
        for a in var_adj[i]:
            ev_list.append(i); ec_list.append(a)
            ce[a].append(k)
            k += 1
    ev = np.array(ev_list, dtype=np.int64)
    ec = np.array(ec_list, dtype=np.int64)
    ce_np = [np.array(x, dtype=np.int64) for x in ce]
    return ev, ec, ce_np


def _fast_bp_decode(ev: np.ndarray, ec: np.ndarray, ce_arr: list,
                    sigma: np.ndarray, n: int, r: int, Q: float,
                    max_iter: int = MAX_ITER, clip: float = 20.0) -> tuple:
    """
    Vectorized BP decoder.  Returns (e_hat, converged, n_iters).
    C2V inner loop is numpy-vectorised (~9× faster than the per-element
    Python loop in ldpc_reconciliation.syndrome_bp_decode).
    """
    Q = max(1e-12, min(1 - 1e-12, float(Q)))
    lam = math.log((1.0 - Q) / Q)
    sigma_sign = np.where(sigma == 0, 1.0, -1.0)
    V2C = np.full(len(ev), lam, dtype=np.float64)
    C2V = np.zeros(len(ev), dtype=np.float64)

    for it in range(max_iter):
        vsum = np.zeros(n, dtype=np.float64)
        np.add.at(vsum, ev, C2V)
        V2C = np.clip(lam + vsum[ev] - C2V, -clip, clip)

        for a in range(r):
            ce = ce_arr[a]
            if len(ce) == 0:
                continue
            t  = np.tanh(V2C[ce] / 2.0)
            la = np.log(np.abs(t) + 1e-300)
            sg = np.sign(t)
            sp = sigma_sign[a] * np.prod(sg)
            ls = float(np.sum(la))
            part = np.clip(sp * sg * np.exp(np.clip(ls - la, -700.0, 0.0)),
                           -1 + 1e-12, 1 - 1e-12)
            C2V[ce] = 2.0 * np.arctanh(part)

        post = np.full(n, lam, dtype=np.float64)
        np.add.at(post, ev, C2V)
        e_hat = (post < 0.0).astype(np.uint8)
        synd = np.zeros(r, dtype=np.int64)
        np.add.at(synd, ec, e_hat[ev].astype(np.int64))
        if np.array_equal(synd % 2, sigma):
            return e_hat, True, it + 1

    post = np.full(n, lam, dtype=np.float64)
    np.add.at(post, ev, C2V)
    e_hat = (post < 0.0).astype(np.uint8)
    return e_hat, False, max_iter


def _fast_bp_trial(n: int, Q: float, H: np.ndarray,
                   var_adj, chk_adj, r: int,
                   matrix_seed: int, trial_seed: int) -> dict:
    """Run one LDPC reconciliation trial using the vectorized BP decoder."""
    rng = np.random.default_rng(trial_seed)
    x_A = rng.integers(0, 2, size=n, dtype=np.uint8)
    e   = (rng.random(n) < Q).astype(np.uint8)
    x_B = x_A ^ e
    s_A = (H @ x_A.astype(np.int64)) % 2
    s_B = (H @ x_B.astype(np.int64)) % 2
    sigma = (s_A ^ s_B).astype(np.uint8)

    ev, ec, ce_arr = _build_edges(var_adj, chk_adj, n, r)
    e_hat, converged, iters = _fast_bp_decode(ev, ec, ce_arr, sigma, n, r, Q)
    success = bool(np.array_equal(x_B ^ e_hat, x_A))
    return {"success": success, "iterations": iters}

SELECTED_FIELDS = [
    "n", "Q", "beta", "selected_r", "selected_dv", "selected_seed", "rank_H",
    "leakage_bits", "design_trials", "design_failure_rate", "eval_trials",
    "eval_failure_rate", "mean_iterations", "p95_iterations", "max_iterations",
    "construction_method", "status", "r_shannon_min", "efficiency_r_over_shannon",
]
LEAKAGE_FIELDS = [
    "protocol", "n", "qber", "trials", "mean_leakage", "p95_leakage",
    "p99_leakage", "max_leakage", "failure_rate", "selected_r", "rank_H",
    "r_shannon_min", "efficiency_r_over_shannon", "mean_iterations",
    "p95_iterations", "max_iterations", "beta",
]


def _write_csv(path: Path, rows: list, fields: list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def _trial_failure_rate(n, Q, r, matrix_seed, n_trials, base_seed):
    """Build matrix once, run n_trials, return failure rate."""
    H, va, ca, _ = build_ldpc_matrix(n, r, DV, seed=matrix_seed)
    ev, ec, ce_arr = _build_edges(va, ca, n, r)
    n_ok = 0
    for t in range(n_trials):
        rng = np.random.default_rng(base_seed + t)
        x_A = rng.integers(0, 2, size=n, dtype=np.uint8)
        e   = (rng.random(n) < Q).astype(np.uint8)
        x_B = x_A ^ e
        sigma = ((H @ (x_A ^ x_B).astype(np.int64)) % 2).astype(np.uint8)
        e_hat, _, _ = _fast_bp_decode(ev, ec, ce_arr, sigma, n, r, Q)
        if np.array_equal(x_B ^ e_hat, x_A):
            n_ok += 1
    return 1.0 - n_ok / n_trials


def _select_code(n: int, Q: float, beta: float) -> dict:
    r_min = max(1, math.ceil(n * h2(Q)))
    r_max = min(n, max(r_min + 1, math.ceil(MAX_R_MULT * r_min)))
    coarse_step = max(1, math.ceil(COARSE_STEP_FRAC * r_min))
    base_seed = 10_000_000 + n * 10_000 + int(Q * 1_000_000)

    # ── coarse scan ──
    coarse_pass = None
    r_c = r_min
    while r_c <= r_max:
        best = min(
            _trial_failure_rate(n, Q, r_c, ms, DESIGN_TRIALS, base_seed + ms * 100_000)
            for ms in CANDIDATE_SEEDS
        )
        print(f"    coarse r={r_c:5d}  best_fail={best:.3f}  (beta={beta:.2f})", flush=True)
        if best < beta:
            coarse_pass = r_c
            break
        r_c += coarse_step

    if coarse_pass is None:
        return {
            "n": n, "Q": Q, "beta": beta, "status": "not_found",
            "selected_r": None, "r_shannon_min": r_min,
            "design_trials": DESIGN_TRIALS, "eval_trials": EVAL_TRIALS,
        }

    # ── fine scan ──
    fine_start = max(r_min, coarse_pass - coarse_step + 1)
    best_r, best_seed_v, best_fail = coarse_pass, CANDIDATE_SEEDS[0], 1.0
    for r_f in range(fine_start, coarse_pass + 1):
        for ms in CANDIDATE_SEEDS:
            fail = _trial_failure_rate(n, Q, r_f, ms, DESIGN_TRIALS,
                                       base_seed + ms * 100_000)
            if fail < beta and (r_f < best_r or (r_f == best_r and fail < best_fail)):
                best_r, best_seed_v, best_fail = r_f, ms, fail

    # ── evaluate ──
    H, va, ca, meta = build_ldpc_matrix(n, best_r, DV, seed=best_seed_v)
    rank = matrix_rank_gf2(H)
    eval_base = base_seed + 50_000_000
    ev_e, ec_e, ce_e = _build_edges(va, ca, n, best_r)
    n_ok, iters = 0, []
    for t in range(EVAL_TRIALS):
        rng = np.random.default_rng(eval_base + t)
        x_A = rng.integers(0, 2, size=n, dtype=np.uint8)
        e_v = (rng.random(n) < Q).astype(np.uint8)
        x_B = x_A ^ e_v
        sigma = ((H @ (x_A ^ x_B).astype(np.int64)) % 2).astype(np.uint8)
        e_hat, _, itr = _fast_bp_decode(ev_e, ec_e, ce_e, sigma, n, best_r, Q)
        n_ok += int(np.array_equal(x_B ^ e_hat, x_A))
        iters.append(itr)
    eval_fail = 1.0 - n_ok / EVAL_TRIALS

    print(f"    SELECTED: r={best_r}  eval_fail={eval_fail:.4f}", flush=True)
    return {
        "n": n, "Q": Q, "beta": beta,
        "selected_r": best_r, "selected_dv": DV,
        "selected_seed": best_seed_v, "rank_H": rank,
        "leakage_bits": best_r,
        "design_trials": DESIGN_TRIALS, "design_failure_rate": round(best_fail, 6),
        "eval_trials": EVAL_TRIALS, "eval_failure_rate": round(eval_fail, 6),
        "mean_iterations": round(float(np.mean(iters)), 3),
        "p95_iterations": round(float(np.percentile(iters, 95)), 3),
        "max_iterations": int(np.max(iters)),
        "construction_method": "peg", "status": "ok",
        "r_shannon_min": r_min,
        "efficiency_r_over_shannon": round(best_r / max(r_min, 1), 4),
    }


def _build_leakage_rows(selected: list) -> list:
    out = []
    for c in selected:
        if c["status"] != "ok" or c.get("selected_r") is None:
            continue
        label = f"ldpc_beta{int(c['beta'] * 100):02d}"
        r, r_sh = c["selected_r"], c["r_shannon_min"]
        out.append({
            "protocol": label, "n": c["n"], "qber": c["Q"],
            "trials": c["eval_trials"],
            "mean_leakage": r, "p95_leakage": r, "p99_leakage": r, "max_leakage": r,
            "failure_rate": c["eval_failure_rate"],
            "selected_r": r, "rank_H": c.get("rank_H"),
            "r_shannon_min": r_sh,
            "efficiency_r_over_shannon": c.get("efficiency_r_over_shannon"),
            "mean_iterations": c.get("mean_iterations"),
            "p95_iterations": c.get("p95_iterations"),
            "max_iterations": c.get("max_iterations"),
            "beta": c["beta"],
        })
    return out


def run_simulation() -> pd.DataFrame:
    """
    Deprecated compatibility stub.

    Simulations are intentionally centralized in run_ldpc_simulation.py so this
    plotting script cannot overwrite publication tables with quick parameters.
    """
    raise RuntimeError(
        "generate_ldpc_figures.py no longer runs LDPC simulations. "
        "Use run_ldpc_simulation.py first, then rerun the plotting script."
    )
    sel_path = TABLES_DIR / "ldpc_selected_codes.csv"
    leak_path = TABLES_DIR / "ldpc_leakage_table.csv"

    # Load existing progress
    done_keys: set = set()
    all_selected: list = []
    if sel_path.exists():
        try:
            df_ex = pd.read_csv(sel_path)
            for _, row in df_ex.iterrows():
                n_v = int(row["n"])
                q_v = float(row["Q"])
                b_v = float(row["beta"])
                key = (n_v, q_v, b_v)
                done_keys.add(key)
                d = row.to_dict()
                d["status"] = str(d.get("status", "unknown"))
                if d["status"] == "not_found":
                    d["selected_r"] = None
                elif pd.notna(d.get("selected_r")):
                    d["selected_r"] = int(d["selected_r"])
                all_selected.append(d)
            print(f"Loaded {len(done_keys)} already-computed grid points.")
        except Exception as exc:
            print(f"Warning: could not load existing codes: {exc}")

    total = len(N_VALUES) * len(Q_VALUES) * len(BETA_VALUES)
    job = 0
    t0 = time.time()

    for n, Q, beta in itertools.product(N_VALUES, Q_VALUES, BETA_VALUES):
        job += 1
        key = (n, Q, beta)
        if key in done_keys:
            print(f"[{job}/{total}] n={n}, Q={Q}, beta={beta} — skip (done)", flush=True)
            continue
        print(f"\n[{job}/{total}] n={n}, Q={Q:.3f}, beta={beta:.2f}"
              f"  (elapsed {time.time() - t0:.0f}s)", flush=True)
        result = _select_code(n, Q, beta)
        all_selected.append(result)
        done_keys.add(key)

        # Checkpoint
        _write_csv(sel_path, all_selected, SELECTED_FIELDS)
        leak_rows = _build_leakage_rows(all_selected)
        _write_csv(leak_path, leak_rows, LEAKAGE_FIELDS)

    leak_rows = _build_leakage_rows(all_selected)
    _write_csv(leak_path, leak_rows, LEAKAGE_FIELDS)
    print(f"\nSimulation done in {time.time() - t0:.1f}s", flush=True)
    return pd.DataFrame(leak_rows)


# ═════════════════════════════════════════════════════════════
# Section 4: Load existing Cascade data
# ═════════════════════════════════════════════════════════════

def load_cascade_nmin() -> pd.DataFrame:
    """Load locally-verified Nmin table from publication notebook."""
    df = pd.read_csv(PUB_NMIN_CSV)
    df.columns = [c.strip().lower() for c in df.columns]
    return df


def load_cascade_leakage() -> pd.DataFrame:
    df = pd.read_csv(CASCADE_LEAKAGE_CSV)
    df.columns = [c.strip().lower() for c in df.columns]
    return df


def load_ldpc_leakage() -> pd.DataFrame:
    """Load the LDPC leakage table produced by run_ldpc_simulation.py."""
    path = TABLES_DIR / "ldpc_leakage_table.csv"
    if not path.exists():
        raise FileNotFoundError(
            f"Missing {path}. Run run_ldpc_simulation.py before plotting."
        )
    df = pd.read_csv(path)
    df.columns = [c.strip().lower() for c in df.columns]
    return df


def cascade_nmin_for_model(df: pd.DataFrame, model_key: str) -> dict:
    """Return {q_tol: N_min} for one leakage model from the Nmin table."""
    sub = df[df["leakage_model"].astype(str).str.lower().str.contains(model_key, na=False)]
    # Take the smallest N_min per q_tol (locally verified minimum)
    out = {}
    for q_tol, g in sub.groupby("q_tol"):
        n_min_col = "n_min" if "n_min" in g.columns else "reported_n_min"
        if n_min_col in g.columns:
            out[float(q_tol)] = int(g[n_min_col].min())
    return out


# ═════════════════════════════════════════════════════════════
# Section 5: Figure generation
# ═════════════════════════════════════════════════════════════

def fig_efficiency_heatmap(leakage_df: pd.DataFrame) -> None:
    """
    Figure 1: LDPC leakage efficiency heatmap for beta=5%.
    ldpc_efficiency_heatmap_ldpc_beta05.pdf
    """
    label = "ldpc_beta05"
    sub = leakage_df[leakage_df["protocol"] == label].copy()

    # Build 2-D grid
    ns = sorted(sub["n"].dropna().unique().astype(int))
    qs = sorted(sub["qber"].dropna().unique().astype(float))
    grid = np.full((len(ns), len(qs)), np.nan)
    for _, row in sub.iterrows():
        i = ns.index(int(row["n"]))
        j = qs.index(float(row["qber"]))
        r = float(row["selected_r"])
        shannon = int(row["n"]) * h2(float(row["qber"]))
        if shannon > 0:
            grid[i, j] = r / shannon

    fig, ax = plt.subplots(figsize=(8.0, 4.8))
    im = ax.imshow(grid, aspect="auto", origin="lower",
                   cmap="YlOrRd", vmin=1.0, vmax=max(3.0, np.nanmax(grid)))
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label(r"$r\,/\,[n\,h_2(Q)]$")

    ax.set_xticks(range(len(qs)))
    ax.set_xticklabels([f"{q*100:.1f}%" for q in qs], rotation=30)
    ax.set_yticks(range(len(ns)))
    ax.set_yticklabels([str(n) for n in ns])
    ax.set_xlabel("QBER $Q$")
    ax.set_ylabel("Block length $n$")
    ax.set_title(r"LDPC leakage efficiency $r\,/\,[n\,h_2(Q)]$   ($\beta = 5\%$)")

    # Annotate cells
    for i in range(len(ns)):
        for j in range(len(qs)):
            v = grid[i, j]
            if not np.isnan(v):
                ax.text(j, i, f"{v:.2f}", ha="center", va="center",
                        fontsize=7, color="black" if v < 2.5 else "white")

    fig.tight_layout()
    out = FIGURES_OUT_DIR / "ldpc_efficiency_heatmap_ldpc_beta05.pdf"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {out}")


def fig_failure_rate_comparison(leakage_df: pd.DataFrame,
                                cascade_df: pd.DataFrame) -> None:
    """
    Figure 2: Failure rate comparison — Cascade vs LDPC (both betas).
    ldpc_failure_rate_comparison.pdf
    """
    fig, axes = plt.subplots(1, 2, figsize=(12.0, 5.0), sharey=False)
    markers = {"cascade": "o", "ldpc_beta05": "s", "ldpc_beta01": "^"}
    colors  = {"cascade": "#1f77b4", "ldpc_beta05": "#ff7f0e", "ldpc_beta01": "#2ca02c"}
    labels  = {"cascade": "Cascade", "ldpc_beta05": r"LDPC $\beta{=}5\%$",
               "ldpc_beta01": r"LDPC $\beta{=}1\%$"}

    # Left panel: failure rate vs n for a representative Q
    rep_qs = [0.03, 0.05]
    for ax, rep_q in zip(axes, rep_qs):
        # Cascade
        sub_c = cascade_df[np.isclose(cascade_df["qber"].astype(float), rep_q, atol=1e-4)].copy()
        sub_c = sub_c.sort_values("n")
        if not sub_c.empty:
            ax.plot(sub_c["n"].astype(int), sub_c["failure_rate"].astype(float),
                    marker=markers["cascade"], color=colors["cascade"],
                    label=labels["cascade"], linewidth=1.5)

        # LDPC (both betas)
        for bkey in ["ldpc_beta05", "ldpc_beta01"]:
            sub_l = leakage_df[
                (leakage_df["protocol"] == bkey) &
                np.isclose(leakage_df["qber"].astype(float), rep_q, atol=1e-4)
            ].copy()
            sub_l = sub_l.sort_values("n")
            if not sub_l.empty:
                ax.plot(sub_l["n"].astype(int), sub_l["failure_rate"].astype(float),
                        marker=markers[bkey], color=colors[bkey],
                        label=labels[bkey], linewidth=1.5)

        ax.set_xlabel("Block length $n$")
        ax.set_ylabel("Reconciliation failure rate")
        ax.set_title(f"$Q = {rep_q*100:.0f}\\%$")
        ax.legend()
        ax.set_yscale("log" if ax.get_ylim()[1] > 0.3 else "linear")
        try:
            ax.set_yscale("log")
        except Exception:
            pass

    fig.suptitle("Reconciliation failure rate: Cascade vs LDPC")
    fig.tight_layout()
    out = FIGURES_OUT_DIR / "ldpc_failure_rate_comparison.pdf"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {out}")


def fig_nmin_comparison(cascade_nmin_df: pd.DataFrame,
                        ldpc_nmin: dict) -> None:
    """
    Figure 3: Nmin comparison across models.
    ldpc_nmin_comparison.pdf
    """
    fig, ax = plt.subplots(figsize=(8.0, 5.0))

    qtol_pct = [q * 100 for q in QTOL_GRID]

    # ── Cascade lines ──
    for model_key, label, style in [
        ("ideal",       "Ideal",          dict(color="#1f77b4", ls="--", lw=1.5)),
        ("cascade_p95", "Cascade p95",    dict(color="#ff7f0e", ls="-",  lw=1.5)),
        ("cascade_p99", "Cascade p99",    dict(color="#2ca02c", ls="-",  lw=1.5)),
    ]:
        vals = cascade_nmin_for_model(cascade_nmin_df, model_key)
        ys = [vals.get(q) for q in QTOL_GRID]
        valid = [(x, y) for x, y in zip(qtol_pct, ys) if y is not None]
        if valid:
            xs, ys2 = zip(*valid)
            ax.plot(xs, ys2, marker="o", label=label, **style)

    # ── LDPC lines ──
    for bkey, label, style in [
        ("ldpc_beta05", r"LDPC $\beta{=}5\%$",
         dict(color="#d62728", ls="-", lw=1.5, marker="s")),
        ("ldpc_beta01", r"LDPC $\beta{=}1\%$",
         dict(color="#9467bd", ls="-", lw=1.5, marker="^")),
    ]:
        vals = ldpc_nmin.get(bkey, {})
        ys = [vals.get(q) for q in QTOL_GRID]
        valid = [(x, y) for x, y in zip(qtol_pct, ys) if y is not None]
        if valid:
            xs, ys2 = zip(*valid)
            ax.plot(xs, ys2, label=label, **style)

    ax.set_xlabel(r"Tolerated QBER $Q_{\rm tol}$ (%)")
    ax.set_ylabel(r"$N_{\min}$ (transmitted signals)")
    ax.set_title(r"$N_{\min}$ comparison: Cascade and LDPC vs ideal baseline")
    ax.legend()
    ax.set_yscale("log")
    fig.tight_layout()
    out = FIGURES_OUT_DIR / "ldpc_nmin_comparison.pdf"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {out}")


def fig_percent_increase(cascade_nmin_df: pd.DataFrame,
                         ldpc_nmin: dict) -> None:
    """
    Figure 4: Percentage increase over ideal baseline.
    ldpc_percent_increase_comparison.pdf
    """
    ideal_vals = cascade_nmin_for_model(cascade_nmin_df, "ideal")

    fig, ax = plt.subplots(figsize=(8.0, 5.0))
    qtol_pct = [q * 100 for q in QTOL_GRID]

    for model_key, label, style in [
        ("cascade_p95", "Cascade p95",    dict(color="#ff7f0e", ls="-",  lw=1.5, marker="o")),
        ("cascade_p99", "Cascade p99",    dict(color="#2ca02c", ls="-",  lw=1.5, marker="o")),
    ]:
        vals = cascade_nmin_for_model(cascade_nmin_df, model_key)
        ys, xs = [], []
        for q, pct in zip(QTOL_GRID, qtol_pct):
            ideal = ideal_vals.get(q)
            v = vals.get(q)
            if ideal and v:
                ys.append(100.0 * (v - ideal) / ideal)
                xs.append(pct)
        if xs:
            ax.plot(xs, ys, label=label, **style)

    for bkey, label, style in [
        ("ldpc_beta05", r"LDPC $\beta{=}5\%$",
         dict(color="#d62728", ls="-", lw=1.5, marker="s")),
        ("ldpc_beta01", r"LDPC $\beta{=}1\%$",
         dict(color="#9467bd", ls="-", lw=1.5, marker="^")),
    ]:
        vals = ldpc_nmin.get(bkey, {})
        ys, xs = [], []
        for q, pct in zip(QTOL_GRID, qtol_pct):
            ideal = ideal_vals.get(q)
            v = vals.get(q)
            if ideal and v:
                ys.append(100.0 * (v - ideal) / ideal)
                xs.append(pct)
        if xs:
            ax.plot(xs, ys, label=label, **style)

    ax.axhline(0, color="black", lw=0.8, ls=":")
    ax.set_xlabel(r"Tolerated QBER $Q_{\rm tol}$ (%)")
    ax.set_ylabel(r"$N_{\min}$ increase over ideal (\%)")
    ax.set_title("Percentage increase in $N_{\\min}$ over ideal baseline")
    ax.legend()
    fig.tight_layout()
    out = FIGURES_OUT_DIR / "ldpc_percent_increase_comparison.pdf"
    fig.savefig(out, bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {out}")


# ═════════════════════════════════════════════════════════════
# Main
# ═════════════════════════════════════════════════════════════

def main() -> None:
    parser = argparse.ArgumentParser(description="Generate LDPC diagnostic figures")
    parser.add_argument(
        "--run-simulation",
        action="store_true",
        help="Deprecated. Use run_ldpc_simulation.py to create LDPC tables.",
    )
    parser.add_argument(
        "--include-nmin-diagnostic",
        action="store_true",
        help="Also generate exploratory LDPC Nmin comparison figures.",
    )
    args = parser.parse_args()

    if args.run_simulation:
        raise SystemExit(
            "Simulation is handled by run_ldpc_simulation.py. "
            "Run that first, then run generate_ldpc_figures.py without "
            "--run-simulation."
        )

    print("=" * 60)
    print("Step 0: sanity checks")
    print("=" * 60)
    checks = run_sanity_checks()
    all_ok = all(c["passed"] for c in checks)
    for c in checks:
        print(f"  [{'PASS' if c['passed'] else 'FAIL'}] {c['name']}: {c['detail']}")
    if not all_ok:
        print("ERROR: sanity checks failed. Aborting.")
        sys.exit(1)
    print()

    print("=" * 60)
    print("Step 1: Load LDPC leakage table")
    print("=" * 60)
    leakage_df = load_ldpc_leakage()
    print(f"  LDPC leakage rows: {len(leakage_df)}")

    if leakage_df.empty:
        print("WARNING: leakage table is empty — "
              "all grid points returned not_found. Figures will be sparse.")

    print()
    print("=" * 60)
    print("Step 2: Load Cascade reference data")
    print("=" * 60)
    cascade_nmin_df  = load_cascade_nmin()
    cascade_leak_df  = load_cascade_leakage()
    print(f"  Cascade Nmin rows: {len(cascade_nmin_df)}")
    print(f"  Cascade leakage rows: {len(cascade_leak_df)}")

    print()
    print("=" * 60)
    print("Step 3: Compute LDPC Nmin")
    print("=" * 60)
    nmin_beta_jobs = (
        [(0.05, "ldpc_beta05"), (0.01, "ldpc_beta01")]
        if args.include_nmin_diagnostic else []
    )
    if not args.include_nmin_diagnostic:
        print("  Skipped. Pass --include-nmin-diagnostic for exploratory Nmin plots.")
    eps = split_budget_balanced(EPS_TOTAL)
    ldpc_nmin: dict[str, dict] = {}  # bkey -> {q_tol: N_min}

    for beta, bkey in nmin_beta_jobs:
        lookup = build_ldpc_lookup(leakage_df, beta)
        if not lookup:
            print(f"  No valid codes for {bkey}, skipping Nmin.")
            ldpc_nmin[bkey] = {}
            continue
        print(f"\n  {bkey}  ({len(lookup)} lookup entries)")
        nmin_map: dict = {}
        for q_tol in QTOL_GRID:
            nm = find_nmin(q_tol, lookup, eps)
            nmin_map[q_tol] = nm
            status = f"{nm}" if nm else "not_found"
            print(f"    Q_tol={q_tol*100:.1f}%  →  N_min = {status}", flush=True)
        ldpc_nmin[bkey] = nmin_map

    print()
    print("=" * 60)
    print("Step 4: Generate figures")
    print("=" * 60)

    print("  Figure 1: LDPC efficiency heatmap (beta=5%)")
    fig_efficiency_heatmap(leakage_df)

    print("  Figure 2: Failure rate comparison")
    fig_failure_rate_comparison(leakage_df, cascade_leak_df)

    if args.include_nmin_diagnostic:
        print("  Figure 3: Nmin comparison")
        fig_nmin_comparison(cascade_nmin_df, ldpc_nmin)

        print("  Figure 4: Percentage increase over ideal")
        fig_percent_increase(cascade_nmin_df, ldpc_nmin)

    print()
    print("Done. Figures saved to:", FIGURES_OUT_DIR)


if __name__ == "__main__":
    main()
