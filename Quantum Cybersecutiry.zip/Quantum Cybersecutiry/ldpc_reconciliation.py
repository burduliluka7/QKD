"""
LDPC information reconciliation for BB84 finite-key QKD.

This module implements:
  - PEG LDPC parity-check matrix construction (deterministic, seeded).
  - Syndrome belief-propagation (BP) decoding for the binary symmetric channel.
  - Per-trial runner that records every required field for the leakage study.

This is CLASSICAL LDPC syndrome reconciliation, not quantum LDPC / qLDPC.
Alice publishes the syndrome Hx_A; Bob corrects his string using belief propagation.
The transmitted syndrome has exactly r bits.  Its alphabet has size at most
2^rank(H), so r is a conservative entropy-leakage upper bound.
"""

from __future__ import annotations

import math
from typing import Dict, List, Optional, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# PEG LDPC matrix construction
# ---------------------------------------------------------------------------

def _reachable_checks_from_variable(
    var_adj: List[List[int]],
    chk_adj: List[List[int]],
    start_var: int,
) -> set[int]:
    """
    Return all check nodes reachable from start_var in the current Tanner graph.

    PEG uses this frontier expansion before adding each new edge: if a check is
    not reachable, connecting to it maximizes the local cycle length.
    """
    visited_var = {start_var}
    visited_chk: set[int] = set()
    frontier_var = {start_var}

    while frontier_var:
        next_chk: set[int] = set()
        for v in frontier_var:
            for c in var_adj[v]:
                if c not in visited_chk:
                    next_chk.add(c)
        if not next_chk:
            break

        visited_chk.update(next_chk)

        next_var: set[int] = set()
        for c in next_chk:
            for v in chk_adj[c]:
                if v not in visited_var:
                    visited_var.add(v)
                    next_var.add(v)
        frontier_var = next_var

    return visited_chk


def _peg_build(n: int, r: int, dv: int, seed: int) -> Tuple[List[List[int]], List[List[int]]]:
    """
    Progressive Edge Growth (PEG) construction of a regular (dv, dc) LDPC code.

    For each variable i in order, and for each of its dv edges:
      - Perform a BFS in the current Tanner graph starting from variable i.
      - Among check nodes NOT reached by the BFS, choose the one with minimum degree.
      - If all check nodes are reachable, choose the minimum-degree reachable check
        not already adjacent to i (maximises girth as much as possible).
      - Ties are broken randomly with the seeded RNG.

    Returns (var_adj, chk_adj) as lists of lists.
    """
    rng = np.random.default_rng(seed)

    if r < dv:
        raise ValueError(f"Need r >= dv to avoid parallel edges; got r={r}, dv={dv}")

    var_adj: List[List[int]] = [[] for _ in range(n)]
    chk_adj: List[List[int]] = [[] for _ in range(r)]
    chk_deg = np.zeros(r, dtype=np.int64)

    for i in range(n):
        for _edge_num in range(dv):
            connected = set(var_adj[i])

            visited_chk = _reachable_checks_from_variable(var_adj, chk_adj, i)

            # Candidates: checks NOT in visited_chk (prefer those to maximise girth)
            unreachable = [
                c for c in range(r)
                if c not in visited_chk and c not in connected
            ]
            if unreachable:
                candidates = unreachable
            else:
                # All checks reachable; fall back to any not yet adjacent to i
                candidates = [c for c in range(r) if c not in connected]
                if not candidates:
                    # Duplicate edges are invalid for the Tanner graph used by BP.
                    raise RuntimeError(
                        f"No valid check candidate for variable {i}; r={r}, dv={dv}"
                    )

            # Among candidates, pick those with minimum degree; break ties randomly
            cand_arr = np.array(candidates, dtype=np.int64)
            degs = chk_deg[cand_arr]
            min_deg = int(degs.min())
            min_cands = cand_arr[degs == min_deg]
            chosen = int(rng.choice(min_cands))

            var_adj[i].append(chosen)
            chk_adj[chosen].append(i)
            chk_deg[chosen] += 1

    return var_adj, chk_adj


def build_ldpc_matrix(
    n: int,
    r: int,
    dv: int = 3,
    seed: int = 42,
) -> Tuple[np.ndarray, List[List[int]], List[List[int]], dict]:
    """
    Build a binary LDPC parity-check matrix H of shape (r, n).

    Construction: PEG with variable degree dv and deterministic seed.
    All variable nodes get exactly dv edges; check degrees are as even as possible.

    Returns
    -------
    H          : (r, n) uint8 numpy array
    var_adj    : list of lists  var_adj[i] = check-node neighbors of variable i
    chk_adj    : list of lists  chk_adj[a] = variable-node neighbors of check a
    metadata   : dict with construction info
    """
    n = int(n)
    r = int(r)
    dv = int(dv)
    seed = int(seed)

    if r <= 0 or n <= 0 or dv <= 0:
        raise ValueError(f"n, r, dv must be positive; got n={n}, r={r}, dv={dv}")
    if dv * n < r:
        raise ValueError(f"Not enough edges ({dv}*{n}={dv*n}) to cover {r} check nodes.")

    var_adj, chk_adj = _peg_build(n, r, dv, seed)

    # Validate: no zero columns
    for i in range(n):
        assert len(var_adj[i]) == dv, f"Variable {i} has {len(var_adj[i])} edges, expected {dv}"
        if len(set(var_adj[i])) != dv:
            raise RuntimeError(f"Variable {i} has duplicate check edges: {var_adj[i]}")

    # Check for zero rows
    zero_rows = [a for a in range(r) if len(chk_adj[a]) == 0]
    if zero_rows:
        raise RuntimeError(f"LDPC construction left {len(zero_rows)} zero rows")

    # Build dense matrix
    H = np.zeros((r, n), dtype=np.uint8)
    for i in range(n):
        for a in var_adj[i]:
            H[a, i] = 1

    chk_degrees = [len(chk_adj[a]) for a in range(r)]
    row_patterns = [tuple(sorted(chk_adj[a])) for a in range(r)]
    duplicate_rows = len(row_patterns) - len(set(row_patterns))
    metadata = {
        "n": n,
        "r": r,
        "rank_H": matrix_rank_gf2(H),
        "dv": dv,
        "seed": seed,
        "construction_method": "peg",
        "mean_check_degree": float(np.mean(chk_degrees)),
        "min_check_degree": int(np.min(chk_degrees)),
        "max_check_degree": int(np.max(chk_degrees)),
        "zero_rows": len(zero_rows),
        "duplicate_rows": int(duplicate_rows),
        "total_edges": int(dv * n),
    }
    return H, var_adj, chk_adj, metadata


def matrix_rank_gf2(H: np.ndarray) -> int:
    """Compute the rank of a binary matrix over GF(2)."""
    # Convert to float for scipy; then recover rank via row reduction mod 2
    H = np.array(H, dtype=np.uint8).copy()
    r, n = H.shape
    rank = 0
    pivot_row = 0
    for col in range(n):
        # Find pivot
        found = -1
        for row in range(pivot_row, r):
            if H[row, col] == 1:
                found = row
                break
        if found == -1:
            continue
        # Swap rows
        H[[pivot_row, found]] = H[[found, pivot_row]]
        # Eliminate column
        for row in range(r):
            if row != pivot_row and H[row, col] == 1:
                H[row] ^= H[pivot_row]
        pivot_row += 1
        rank += 1
    return rank


# ---------------------------------------------------------------------------
# Syndrome belief-propagation decoder
# ---------------------------------------------------------------------------

def _build_edge_index(
    var_adj: List[List[int]],
    chk_adj: List[List[int]],
    n: int,
    r: int,
) -> Tuple[np.ndarray, np.ndarray, List[List[int]], List[List[int]]]:
    """
    Build edge index arrays for fast BP message passing.

    Returns
    -------
    edge_var   : E-length array, edge_var[k] = variable-node index
    edge_chk   : E-length array, edge_chk[k] = check-node index
    var_edges  : list of lists, var_edges[i] = list of edge indices incident to variable i
    chk_edges  : list of lists, chk_edges[a] = list of edge indices incident to check a
    """
    edge_var_list = []
    edge_chk_list = []
    var_edges: List[List[int]] = [[] for _ in range(n)]
    chk_edges: List[List[int]] = [[] for _ in range(r)]

    k = 0
    for i in range(n):
        for a in var_adj[i]:
            edge_var_list.append(i)
            edge_chk_list.append(a)
            var_edges[i].append(k)
            chk_edges[a].append(k)
            k += 1

    return (
        np.array(edge_var_list, dtype=np.int64),
        np.array(edge_chk_list, dtype=np.int64),
        var_edges,
        chk_edges,
    )


def syndrome_bp_decode(
    var_adj: List[List[int]],
    chk_adj: List[List[int]],
    sigma: np.ndarray,
    n: int,
    r: int,
    Q_dec: float,
    max_iter: int = 100,
    clip: float = 20.0,
) -> dict:
    """
    Syndrome belief-propagation decoder for a binary symmetric channel.

    Alice sends syndrome s_A = H x_A.  Bob computes sigma = s_A XOR s_B = H e
    where e is the unknown error vector.  This function decodes e from sigma.

    Parameters
    ----------
    var_adj   : variable-node adjacency lists (output of build_ldpc_matrix)
    chk_adj   : check-node adjacency lists
    sigma     : r-length uint8 syndrome vector
    n, r      : block length and number of parity-check rows
    Q_dec     : design crossover probability (QBER used for LLR initialisation)
    max_iter  : maximum number of BP iterations
    clip      : LLR clipping threshold

    Returns
    -------
    dict with keys:
      e_hat             : decoded error estimate (uint8 array, length n)
      syndrome_satisfied: bool (H @ e_hat == sigma mod 2)
      converged         : bool (stopped because syndrome was satisfied)
      iterations        : int
    """
    sigma = np.asarray(sigma, dtype=np.uint8)
    Q_dec = float(Q_dec)
    Q_dec = max(1e-12, min(1.0 - 1e-12, Q_dec))

    # Build edge index (cached per-call; fast for small codes)
    edge_var, edge_chk, var_edges, chk_edges = _build_edge_index(var_adj, chk_adj, n, r)
    E = len(edge_var)

    # Initial variable LLR: lambda_i = log((1-Q)/Q) for all i
    lam = math.log((1.0 - Q_dec) / Q_dec)

    # Messages
    V2C = np.full(E, lam, dtype=np.float64)   # variable-to-check
    C2V = np.zeros(E, dtype=np.float64)        # check-to-variable (init 0)

    # Syndrome sign: (-1)^sigma_a
    sigma_sign = np.where(sigma == 0, 1.0, -1.0).astype(np.float64)  # shape (r,)

    # Pre-flatten edge lists for efficient indexing
    var_edge_arr = [np.array(ve, dtype=np.int64) for ve in var_edges]
    chk_edge_arr = [np.array(ce, dtype=np.int64) for ce in chk_edges]

    e_hat = np.zeros(n, dtype=np.uint8)
    syndrome_satisfied = False

    for iteration in range(max_iter):
        # ------------------------------------------------------------------
        # Update V2C messages
        # V2C[k] = clip(lambda + sum_{b in N(i)\a} C2V[b->i])
        # ------------------------------------------------------------------
        var_sum = np.zeros(n, dtype=np.float64)
        np.add.at(var_sum, edge_var, C2V)

        for k in range(E):
            i = edge_var[k]
            V2C[k] = np.clip(lam + var_sum[i] - C2V[k], -clip, clip)

        # ------------------------------------------------------------------
        # Update C2V messages (log-domain product-of-tanh)
        # C2V[k] = 2 atanh( sigma_sign[a] * prod_{j in N(a)\i} tanh(V2C[j->a]/2) )
        # ------------------------------------------------------------------
        for a in range(r):
            ce = chk_edge_arr[a]
            if len(ce) == 0:
                continue
            t_vals = np.tanh(np.clip(V2C[ce], -clip, clip) / 2.0)
            # Log-absolute product for numerical stability
            log_abs_t = np.log(np.abs(t_vals) + 1e-300)
            signs_t = np.sign(t_vals)
            sign_product = sigma_sign[a] * float(np.prod(signs_t))
            log_abs_product = float(np.sum(log_abs_t))
            for j, k in enumerate(ce):
                log_abs_partial = log_abs_product - log_abs_t[j]
                sign_partial = sign_product * float(signs_t[j])  # /sign[j] = *sign[j]
                abs_partial = math.exp(max(-700.0, min(0.0, log_abs_partial)))
                partial = np.clip(sign_partial * abs_partial, -1.0 + 1e-12, 1.0 - 1e-12)
                C2V[k] = 2.0 * math.atanh(partial)

        # ------------------------------------------------------------------
        # Posterior LLR and hard decision
        # ------------------------------------------------------------------
        posterior = np.full(n, lam, dtype=np.float64)
        np.add.at(posterior, edge_var, C2V)
        e_hat = (posterior < 0.0).astype(np.uint8)

        # Check syndrome
        synd_check = np.zeros(r, dtype=np.uint8)
        for k in range(E):
            synd_check[edge_chk[k]] ^= e_hat[edge_var[k]]
        syndrome_satisfied = bool(np.array_equal(synd_check, sigma))

        if syndrome_satisfied:
            return {
                "e_hat": e_hat,
                "syndrome_satisfied": True,
                "converged": True,
                "iterations": iteration + 1,
            }

    # Max iterations reached
    synd_check = np.zeros(r, dtype=np.uint8)
    for k in range(E):
        synd_check[edge_chk[k]] ^= e_hat[edge_var[k]]
    syndrome_satisfied = bool(np.array_equal(synd_check, sigma))

    return {
        "e_hat": e_hat,
        "syndrome_satisfied": syndrome_satisfied,
        "converged": False,
        "iterations": max_iter,
    }


# ---------------------------------------------------------------------------
# Per-trial runner
# ---------------------------------------------------------------------------

def ldpc_trial(
    n: int,
    Q: float,
    H: np.ndarray,
    var_adj: List[List[int]],
    chk_adj: List[List[int]],
    r: int,
    dv: int,
    matrix_seed: int,
    trial_seed: int,
    construction_method: str = "peg",
    Q_dec: Optional[float] = None,
    max_iter: int = 100,
    clip: float = 20.0,
) -> dict:
    """
    Run one LDPC reconciliation trial and return all required CSV fields.

    Alice has x_A in F_2^n.  Bob has x_B = x_A XOR e, e_i ~ Bernoulli(Q).
    Alice sends s_A = H x_A.  Bob computes sigma = s_A XOR s_B = H e.
    Bob decodes e_hat from (H, sigma) and computes x_hat_A = x_B XOR e_hat.
    Success iff x_hat_A == x_A  (equivalently, e_hat == e).

    leakage_bits = r  (fixed for this H; the number of syndrome bits sent).
    """
    if Q_dec is None:
        Q_dec = Q

    rng = np.random.default_rng(trial_seed)
    n = int(n)
    r = int(r)
    Q = float(Q)
    Q_dec = float(Q_dec)

    # Generate Alice's key and error vector
    x_A = rng.integers(0, 2, size=n, dtype=np.uint8)
    e = (rng.random(n) < Q).astype(np.uint8)
    x_B = x_A ^ e

    # Alice computes and publishes syndrome
    s_A = (H @ x_A.astype(np.int64)) % 2
    s_B = (H @ x_B.astype(np.int64)) % 2
    sigma = (s_A ^ s_B).astype(np.uint8)

    # Sanity: sigma should equal H @ e mod 2
    He = (H @ e.astype(np.int64)) % 2
    assert np.array_equal(sigma, He), "Syndrome mismatch: sigma != He"

    # Decode
    result = syndrome_bp_decode(
        var_adj, chk_adj, sigma, n, r, Q_dec,
        max_iter=max_iter, clip=clip,
    )

    e_hat = result["e_hat"]
    x_hat_A = x_B ^ e_hat

    # Success requires x_hat_A == x_A, i.e., e_hat == e
    success = bool(np.array_equal(x_hat_A, x_A))
    residual_errors = int(np.sum(x_hat_A != x_A))

    initial_errors = int(np.sum(e))
    syndrome_weight = int(np.sum(sigma))

    return {
        "n": n,
        "Q": Q,
        "r": r,
        "dv": dv,
        "construction_method": construction_method,
        "matrix_seed": matrix_seed,
        "trial_seed": trial_seed,
        "initial_errors": initial_errors,
        "syndrome_weight": syndrome_weight,
        "decoder_converged": bool(result["converged"]),
        "syndrome_satisfied": bool(result["syndrome_satisfied"]),
        "residual_errors": residual_errors,
        "success": success,
        "iterations": int(result["iterations"]),
        "leakage_bits": r,  # fixed: number of syndrome bits transmitted
    }


# ---------------------------------------------------------------------------
# Utility: binary entropy
# ---------------------------------------------------------------------------

def binary_entropy(q: float) -> float:
    """Return h2(q) in bits."""
    q = float(q)
    if q <= 0.0 or q >= 1.0:
        return 0.0
    return -q * math.log2(q) - (1.0 - q) * math.log2(1.0 - q)


# ---------------------------------------------------------------------------
# Sanity checks (callable externally)
# ---------------------------------------------------------------------------

def run_sanity_checks() -> List[dict]:
    """
    Run basic sanity checks for the LDPC implementation.

    Returns a list of dicts with keys: name, passed, detail.
    """
    checks = []

    # 1. Syndrome identity: sigma = H e mod 2
    n, r, dv, seed = 64, 24, 3, 1
    H, var_adj, chk_adj, _ = build_ldpc_matrix(n, r, dv, seed)
    rng = np.random.default_rng(99)
    e = rng.integers(0, 2, size=n, dtype=np.uint8)
    x_A = rng.integers(0, 2, size=n, dtype=np.uint8)
    x_B = x_A ^ e
    s_A = (H @ x_A.astype(np.int64)) % 2
    s_B = (H @ x_B.astype(np.int64)) % 2
    sigma = (s_A ^ s_B).astype(np.uint8)
    He = (H @ e.astype(np.int64)) % 2
    checks.append({
        "name": "sigma == He",
        "passed": bool(np.array_equal(sigma, He)),
        "detail": f"max|sigma - He| = {int(np.max(np.abs(sigma.astype(int) - He.astype(int))))}",
    })

    # 2. Zero-error case: decoder should return e_hat = 0
    e_zero = np.zeros(n, dtype=np.uint8)
    sigma_zero = np.zeros(r, dtype=np.uint8)
    res_zero = syndrome_bp_decode(var_adj, chk_adj, sigma_zero, n, r, Q_dec=0.05)
    checks.append({
        "name": "zero-error decodes correctly",
        "passed": bool(np.all(res_zero["e_hat"] == 0)),
        "detail": f"e_hat sum = {int(np.sum(res_zero['e_hat']))}",
    })

    # 3. Trial success requires e_hat == e: run a zero-error trial to verify
    # A zero-error trial must succeed (sigma=0, BP returns e_hat=0, success=True)
    import types
    zero_H = H.copy()
    # Build a mock zero-error environment: pass H but force Q=0 in the trial
    # Simplest: directly check that zero-error trial succeeds
    rng2 = np.random.default_rng(77)
    x_A_z = rng2.integers(0, 2, size=n, dtype=np.uint8)
    e_z = np.zeros(n, dtype=np.uint8)
    x_B_z = x_A_z.copy()
    s_A_z = (H @ x_A_z.astype(np.int64)) % 2
    s_B_z = (H @ x_B_z.astype(np.int64)) % 2
    sigma_z = (s_A_z ^ s_B_z).astype(np.uint8)
    assert np.all(sigma_z == 0), "Zero-error should give zero syndrome"
    res_z = syndrome_bp_decode(var_adj, chk_adj, sigma_z, n, r, Q_dec=0.05)
    zero_ok = bool(np.all(res_z["e_hat"] == 0) and res_z["syndrome_satisfied"])
    checks.append({
        "name": "success implies e_hat == e",
        "passed": zero_ok,
        "detail": (f"zero-error: e_hat_sum={int(np.sum(res_z['e_hat']))}, "
                   f"syndrome_satisfied={res_z['syndrome_satisfied']}"),
    })

    # 4. leakage_bits == r (use a new trial at low Q so it is more likely to decode)
    trial4 = ldpc_trial(n, 0.01, H, var_adj, chk_adj, r, dv,
                        matrix_seed=seed, trial_seed=43)
    checks.append({
        "name": "leakage_bits == r",
        "passed": trial4["leakage_bits"] == r,
        "detail": f"leakage_bits={trial4['leakage_bits']}, r={r}",
    })

    # 5. Variable degrees all equal dv
    var_degrees = [len(var_adj[i]) for i in range(n)]
    checks.append({
        "name": "all variable degrees == dv",
        "passed": all(d == dv for d in var_degrees),
        "detail": f"min={min(var_degrees)}, max={max(var_degrees)}, dv={dv}",
    })

    return checks


if __name__ == "__main__":
    print("Running LDPC sanity checks...")
    results = run_sanity_checks()
    all_passed = True
    for r in results:
        status = "PASS" if r["passed"] else "FAIL"
        print(f"  [{status}] {r['name']}: {r['detail']}")
        if not r["passed"]:
            all_passed = False
    if all_passed:
        print("All sanity checks passed.")
    else:
        print("Some checks failed.")
