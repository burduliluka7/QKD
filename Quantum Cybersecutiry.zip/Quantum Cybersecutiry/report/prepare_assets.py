"""Prepare report figures, tables, inventories, and corrected result exports.

This script is intentionally provenance-preserving: source outputs are copied,
never modified.  The corrected table is recomputed from the locally verified
N_min values with the exact functions embedded in the publication-ready
notebook, so ancillary fields correspond to the reported minimum.
"""

from __future__ import annotations

import ast
import csv
import itertools
import json
import math
import shutil
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
import numpy as np
import pandas as pd
import scipy


ROOT = Path(__file__).resolve().parent.parent
REPORT = ROOT / "report"
FIGURES = REPORT / "figures"
TABLES = REPORT / "tables"
FIGURES.mkdir(parents=True, exist_ok=True)
TABLES.mkdir(parents=True, exist_ok=True)


STAGES = {
    "01": ROOT / "results_01_finite-key",
    "02": ROOT / "results_02_rigorous",
    "03": ROOT / "results_03_reconciliation",
    "04": ROOT / "results_04_theorem-wrapper",
    "05": ROOT / "results_05_publication-ready",
}


CAPTIONS = {
    "baseline_key_length_vs_N": "Preliminary key length versus transmitted signals under a fixed test fraction. It established the threshold-crossing shape that motivates minimizing N, but uses the early planning model rather than the final theorem.",
    "baseline_Nmin_vs_QBER": "Preliminary minimum signal count versus QBER. It was plotted to reveal the rapid finite-size cost of noise and motivated the later theorem-level N_min objective.",
    "ec_models_Nmin": "Preliminary N_min comparison for stylized error-correction leakage models. The separation between curves showed why reconciliation leakage required direct empirical study before theorem-level conclusions were drawn.",
    "epsilon_allocation_comparison": "Preliminary comparison of security-budget allocations. It tests how reallocating failure probability changes N_min and motivated the final balanced split plus sensitivity analysis.",
    "ml_surrogate_results": "Exploratory surrogate-model diagnostics for optimizer outputs. The plot was used only to study sensitivity and search acceleration; no security conclusion or final N_min value relies on the surrogate.",
    "optimize_m_example": "Example optimization of the parameter-estimation sample size. The interior maximum illustrates the trade-off between tighter sampling bounds and retaining more raw-key bits.",
    "pareto_front_exploration": "Exploratory Pareto front for signal count, key margin, and protocol overheads. It shows that the absolute N_min point can be operationally fragile and motivated retaining margin diagnostics.",
    "search_efficiency": "Comparison of exploratory parameter-search methods. It was plotted to assess computational cost; the final reported minima use deterministic grid optimization and local verification.",
    "sensitivity_analysis": "Preliminary sensitivity sweeps over QBER, leakage efficiency, security level, and sifting. The dominant dependence on QBER and leakage motivated the final focused analysis.",
    "statistical_bounds_grouped_bar": "Preliminary N_min comparison across concentration bounds. It demonstrates that finite-sample parameter estimation can move the 256-bit threshold substantially and motivates exact finite-population inversion.",
    "bit_budget_decomposition": "Planning-model bit-budget decomposition. It identifies entropy loss and reconciliation leakage as the main deductions, anticipating the subtraction structure of the final theorem.",
    "ec_models_comparison": "Rigorous-bound-stage comparison of ideal and stress-test reconciliation models. The plot motivated replacing stylized leakage with measured Cascade transcripts.",
    "full_matrix_qber_010": "Full parameter-estimation and leakage-model matrix at 1% QBER. It separates statistical-bound effects from reconciliation assumptions and connects both to N_min.",
    "full_matrix_qber_030": "Full parameter-estimation and leakage-model matrix at 3% QBER. It shows growing sensitivity of N_min to the leakage model at moderate noise.",
    "full_matrix_qber_050": "Full parameter-estimation and leakage-model matrix at 5% QBER. The large spread motivated treating reconciliation leakage as a theorem input rather than a small correction.",
    "optimal_m_fraction": "Historical planning-stage parameter-estimation-fraction diagnostic across probability bounds and leakage stress tests; it predates the theorem-level 21-point p_Z search.",
    "pe_bounds_ideal_ec": "N_min under Hoeffding, Serfling, Clopper--Pearson, and hypergeometric parameter-estimation bounds with ideal leakage. It isolates the statistical model's finite-size cost.",
    "bit_budget_empirical_ec": "Planning-model bit budgets using measured reconciliation leakage. It shows how empirical Cascade caps consume raw entropy and push the 256-bit crossing to larger N.",
    "cascade_f_eff_vs_n": "Measured Cascade efficiency f_eff versus block length for several QBER values. It diagnoses short-block overhead relative to n h2(Q), the ideal leakage baseline used in the theorem comparison.",
    "cascade_failure_rate_vs_n": "Residual reconciliation failure rate versus block length. It was plotted to distinguish operational abort probability from secrecy leakage; verification converts residual disagreement into abort except with epsilon_cor.",
    "cascade_mean_leakage_vs_n": "Mean Cascade parity leakage versus block length and QBER. It quantifies transcript growth but is not itself a security cap, which is why the final theorem enforces p95, p99, or maximum caps.",
    "cascade_p95_f_eff_heatmap": "Heat map of empirical p95 Cascade efficiency over block length and QBER. It identifies where short-block interaction costs are largest and therefore where N_min is most leakage-sensitive.",
    "leakage_models_comparison_empirical": "Empirical comparison of ideal, Cascade, and Hamming-family leakage. It motivates Cascade as the operational main model while exposing the limitations of leakage-only comparisons.",
    "nmin_empirical_reconciliation": "Planning-model N_min values with empirical reconciliation statistics. It is a predecessor to the exact Hamming-ball theorem calculation and records the evolution from stylized to measured leakage.",
    "notebook02_vs_notebook03_ec_models": "Comparison of stress-test leakage models with empirical reconciliation results. It checks whether earlier assumptions bracketed observed Cascade behavior before the theorem wrapper was introduced.",
    "operational_success_adjusted_N": "Signal requirements adjusted by measured reconciliation success probability. It illustrates operational throughput costs, which remain separate from the composable key-length theorem.",
    "percent_increase_over_ideal": "Planning-model percentage increase in N_min over ideal leakage. It previews the final resource-cost metric, later recomputed with the exact Hamming-ball theorem.",
    "bit_budget_theorem_locked": "Theorem-wrapper bit-budget decomposition. It shows the direct subtraction of deterministic leakage, verification, smoothing placeholder, and privacy-amplification terms before the cleaned proof removed the placeholder.",
    "nmin_theorem_locked_leakage_caps": "Theorem-wrapper N_min under ideal and empirical leakage caps. It records the transition to enforced transcript caps but predates the final exact cleaned theorem.",
    "notebook03_vs_theorem_locked": "Comparison between empirical planning-model and theorem-wrapper minima. It isolates the effect of moving from a rate-style entropy approximation to explicit security bookkeeping.",
    "operational_acceptance_with_caps": "Estimated operational acceptance under mean, p95, p99, and maximum leakage caps. It shows that tighter caps trade lower theorem leakage for more aborts rather than secrecy failures.",
    "percent_increase_theorem_locked": "Theorem-wrapper percentage increase over ideal leakage. It connects enforced Cascade caps to the N_min objective before the final local-verification pass.",
    "security_budget_allocation": "Theorem-wrapper sensitivity to security-budget allocation. It demonstrates that the balanced split is a convention rather than a globally optimal allocation.",
    "smoothing_penalty_sensitivity": "Sensitivity to an earlier placeholder smoothing penalty. The cleaned theorem removes this separate subtraction; the plot remains as a diagnostic history of the proof refinement.",
    "01_entropy_exact_vs_binary": "Exact Hamming-ball raw entropy and the binary-entropy lower bound versus phase-error fraction. It was plotted to quantify the finite-size combinatorial correction; the exact curve is used in the theorem and yields slightly more extractable entropy.",
    "02_phase_error_upper_vs_N": "Phase-error upper rate versus signal count using a fixed test fraction of m/s=0.2. The final calculation separately searches the full p_Z grid.",
    "03_key_length_vs_N_qber_1pct": "Theorem key length versus N on the symmetric planning slice Q_X,tol=Q_Z,design=1%, optimized over the declared 21-point p_Z grid.",
    "03_key_length_vs_N_qber_3pct": "Theorem key length versus N on the symmetric planning slice Q_X,tol=Q_Z,design=3%, optimized over the declared 21-point p_Z grid.",
    "03_key_length_vs_N_qber_5pct": "Theorem key length versus N on the symmetric planning slice Q_X,tol=Q_Z,design=5%, optimized over the declared 21-point p_Z grid.",
    "04_Nmin_vs_QBER": "Accepted-run N_min on the symmetric planning slice Q=Q_X,tol=Q_Z,design for ideal, p95, p99, and maximum leakage caps.",
    "05_percent_increase_over_ideal": "Percentage increase in locally verified N_min when ideal leakage is replaced by enforced Cascade caps. It expresses the practical reconciliation penalty in the paper's central resource metric.",
    "06_bit_budget_qber_1pct": "Original exported bit budget at 1% QBER. It was generated before every ancillary field was refreshed after local N_min correction and is retained only as a superseded diagnostic.",
    "06_bit_budget_qber_3pct": "Original exported bit budget at 3% QBER. It is retained for reproducibility but superseded by the corrected main figure recomputed at the locally verified minima.",
    "06_bit_budget_qber_5pct": "Original exported bit budget at 5% QBER. It is retained as provenance; the corrected version is authoritative for theorem bookkeeping.",
    "07_optimal_parameter_estimation_fraction": "Original exported optimized m/s curve. Several ancillary rows were stale after local N_min correction, so this export is retained as a superseded diagnostic.",
    "08_security_budget_sensitivity": "N_min at 3% QBER with a p95 Cascade cap versus total security parameter and allocation rule. Stricter security generally requires more signals; PE-heavy splits are often favorable in this grid.",
    "09_exact_vs_binary_entropy_Nmin": "N_min obtained from the exact Hamming-ball entropy and the binary-entropy lower bound. The comparison confirms that the exact finite-size expression is modestly less conservative and is the appropriate main theorem term.",
    "10_leakage_caps_visualization": "Empirical Cascade transcript distribution and cap levels at a representative block. It shows how mean, p95, p99, and maximum statistics become candidate protocol caps rather than security statements by themselves.",
    "11_cap_abort_probability": "Empirical probability that a Cascade transcript exceeds p95, p99, or maximum caps. Exceedance produces an operational abort, separating robustness cost from secrecy failure in the theorem.",
    "12_hamming_cautionary_baseline": "Hamming-family and Cascade reconciliation failure rates. The plot warns that a low-leakage code can still be operationally unusable, so leakage-only N_min comparisons need failure-rate context.",
}


def copy_file(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def prepare_figures() -> list[dict[str, str]]:
    inventory: list[dict[str, str]] = []
    for stage, base in STAGES.items():
        fig_dir = base / "figures"
        if not fig_dir.exists():
            continue
        for source in sorted(fig_dir.iterdir()):
            if source.suffix.lower() not in {".png", ".pdf"}:
                continue
            stem = source.stem
            caption = CAPTIONS.get(stem, f"Diagnostic plot {stem.replace('_', ' ')}.")
            if stage == "05" and source.suffix.lower() == ".png":
                inventory.append({
                    "original_path": source.relative_to(ROOT).as_posix(),
                    "copied_path": "",
                    "placement": "duplicate rendering omitted",
                    "caption_draft": caption,
                })
                continue
            sanitized_history = stem in {
                "notebook02_vs_notebook03_ec_models",
                "notebook03_vs_theorem_locked",
            }
            if sanitized_history:
                stale_target = FIGURES / f"diag{stage}_{stem}{source.suffix.lower()}"
                if stale_target.exists():
                    stale_target.unlink()
                inventory.append({
                    "original_path": source.relative_to(ROOT).as_posix(),
                    "copied_path": "",
                    "placement": "semantic duplicate sanitized for appendix",
                    "caption_draft": caption,
                })
                continue
            if stage == "05":
                superseded = stem.startswith("06_bit_budget") or stem.startswith("07_optimal")
                prefix = "diag05_export" if superseded else "main"
                placement = "appendix (superseded export)" if superseded else "main text"
                target = FIGURES / f"{prefix}_{stem}{source.suffix.lower()}"
            else:
                target = FIGURES / f"diag{stage}_{stem}{source.suffix.lower()}"
                placement = "appendix"
            copy_file(source, target)
            inventory.append({
                "original_path": source.relative_to(ROOT).as_posix(),
                "copied_path": target.relative_to(ROOT).as_posix(),
                "placement": placement,
                "caption_draft": caption,
            })
    return inventory


def regenerate_neutral_history_figures(inventory: list[dict[str, str]]) -> None:
    """Re-render two historical comparisons without workflow-stage terminology."""
    artificial = pd.read_csv(STAGES["02"] / "tables" / "ec_models_comparison.csv")
    empirical = pd.read_csv(STAGES["03"] / "tables" / "nmin_empirical_reconciliation.csv")
    fig, ax = plt.subplots(figsize=(10.5, 5.8))
    for model in ["ideal", "short_block_penalty", "pessimistic_short_block"]:
        sub = artificial[artificial["ec_model"] == model].sort_values("qber")
        ax.plot(100 * sub["qber"], sub["N_min"], marker="o", linestyle="--", label=f"stress test: {model}")
    for model in ["ideal_fec_1_1", "cascade_p95", "cascade_p99"]:
        sub = empirical[empirical["ec_model"] == model].sort_values("qber")
        ax.plot(100 * sub["qber"], sub["N_min"], marker="s", label=f"empirical: {model}")
    ax.set_yscale("log")
    ax.set_xlabel("QBER (%)")
    ax.set_ylabel(r"$N_{\min}$")
    ax.set_title("Artificial leakage stress tests versus empirical reconciliation")
    ax.legend(fontsize=8)
    fig.tight_layout()
    target = FIGURES / "diag03_artificial_vs_empirical_ec_models.png"
    fig.savefig(target, dpi=180)
    plt.close(fig)
    inventory.append({
        "original_path": "semantic re-render of results_03_reconciliation/figures/notebook02_vs_notebook03_ec_models.png",
        "copied_path": target.relative_to(ROOT).as_posix(),
        "placement": "appendix",
        "caption_draft": "Artificial leakage stress tests and empirical Cascade N_min values. The comparison checks whether preliminary leakage assumptions bracketed measured behavior; it motivated using measured caps in the theorem-level objective.",
    })

    comparison = pd.read_csv(STAGES["04"] / "tables" / "notebook03_vs_theorem_locked.csv")
    fig, ax = plt.subplots(figsize=(9, 5.5))
    for model, sub in comparison.groupby("ec_cap_model"):
        sub = sub.sort_values("qber")
        ax.plot(100 * sub["qber"], sub["planning_model_N_min"], marker="o", linestyle="--", alpha=0.7, label=f"planning, {model}")
        ax.plot(100 * sub["qber"], sub["theorem_locked_N_min"], marker="s", label=f"theorem wrapper, {model}")
    ax.set_yscale("log")
    ax.set_xlabel("QBER (%)")
    ax.set_ylabel(r"$N_{\min}$")
    ax.set_title("Planning-model and theorem-wrapper resource estimates")
    ax.legend(fontsize=7, ncol=2)
    fig.tight_layout()
    target = FIGURES / "diag04_planning_vs_theorem_wrapper.png"
    fig.savefig(target, dpi=180)
    plt.close(fig)
    inventory.append({
        "original_path": "semantic re-render of results_04_theorem-wrapper/figures/notebook03_vs_theorem_locked.png",
        "copied_path": target.relative_to(ROOT).as_posix(),
        "placement": "appendix",
        "caption_draft": "Planning-model and theorem-wrapper N_min estimates. Differences isolate the effect of explicit security bookkeeping and motivated replacing the wrapper with the cleaned exact Hamming-ball theorem.",
    })


def _log2_hamming_ball(n: int, t: int) -> float:
    """Evaluate log2(sum_{i=0}^t binom(n, i)) without forming huge integers."""
    n = int(n)
    t = int(np.clip(t, 0, n))
    i = np.arange(t + 1, dtype=float)
    log_terms = scipy.special.gammaln(n + 1.0)
    log_terms -= scipy.special.gammaln(i + 1.0)
    log_terms -= scipy.special.gammaln(n - i + 1.0)
    return float(scipy.special.logsumexp(log_terms) / math.log(2.0))


def _binary_entropy(q: float) -> float:
    q = float(np.clip(q, 0.0, 1.0))
    if q in {0.0, 1.0}:
        return 0.0
    return float(-q * math.log2(q) - (1.0 - q) * math.log2(1.0 - q))


def _hypergeom_K_upper(e: int, s: int, m: int, eps_pe: float) -> int:
    """Largest population error count K whose lower tail is at least eps_pe."""
    low, high, best = int(e), int(s), int(e)
    while low <= high:
        mid = (low + high) // 2
        cdf = float(scipy.stats.hypergeom.cdf(e, s, mid, m))
        if np.isfinite(cdf) and cdf >= eps_pe:
            best = mid
            low = mid + 1
        else:
            high = mid - 1
    return best


def regenerate_pedagogical_figures(inventory: list[dict[str, str]]) -> None:
    """Create the method figures added for the pedagogical report revision."""
    plt.rcParams.update({
        "axes.grid": True,
        "grid.alpha": 0.24,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "font.size": 10,
        "legend.frameon": False,
        "savefig.bbox": "tight",
    })
    colors = ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00"]

    entropy = pd.read_csv(STAGES["05"] / "data" / "entropy_exact_vs_binary_grid.csv")
    fig, ax = plt.subplots(figsize=(8.2, 5.2))
    for color, n in zip(colors, sorted(entropy["n"].unique())):
        sub = entropy[entropy["n"] == n].sort_values("q")
        ax.plot(sub["q"], sub["entropy_exact"], color=color, label=fr"exact, $n={int(n)}$")
        ax.plot(sub["q"], sub["entropy_binary"], color=color, linestyle="--", alpha=0.72,
                label=fr"binary bound, $n={int(n)}$")
    ax.set_xlabel(r"Phase-error fraction $q=t/n$")
    ax.set_ylabel(r"Raw-key entropy lower bound (bits)")
    ax.set_title("Exact Hamming-ball entropy and binary-entropy bound")
    ax.legend(ncol=2, fontsize=8)
    fig.tight_layout()
    target = FIGURES / "main_01_entropy_exact_vs_binary.pdf"
    fig.savefig(target)
    plt.close(fig)

    n = 256
    t_values = np.arange(0, 65, dtype=int)
    q_values = t_values / n
    exact_values = np.array([n - _log2_hamming_ball(n, int(t)) for t in t_values])
    binary_values = np.array([n * (1.0 - _binary_entropy(float(q))) for q in q_values])
    fig, ax = plt.subplots(figsize=(7.8, 4.8))
    ax.step(q_values, exact_values, where="post", color=colors[0], linewidth=1.8,
            label=r"exact $256-\log_2 B(256,t)$")
    ax.plot(q_values, binary_values, color=colors[1], linestyle="--", linewidth=1.7,
            label=r"binary bound $256[1-h_2(t/256)]$")
    ax.set_xlabel(r"Phase-error fraction $t/256$")
    ax.set_ylabel(r"Raw-key entropy lower bound (bits)")
    ax.set_title(r"Zoomed Hamming-ball comparison at $n=256$")
    ax.legend(fontsize=9)
    fig.tight_layout()
    target_zoom = FIGURES / "main_hamming_n256_zoom.pdf"
    fig.savefig(target_zoom)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.8, 4.8))
    line_styles = ["-", "--", "-.", ":", (0, (5, 2, 1, 2))]
    for color, line_style, n in zip(colors, line_styles, [256, 512, 1024, 2048, 4096]):
        t_values = np.arange(0, int(math.floor(0.2 * n)) + 1)
        q_values = t_values / n
        absolute_gain = np.array([
            n * _binary_entropy(float(q)) - _log2_hamming_ball(n, int(t))
            for q, t in zip(q_values, t_values)
        ])
        relative_gain_percent = 100.0 * absolute_gain / n
        ax.plot(
            q_values,
            relative_gain_percent,
            color=color,
            linestyle=line_style,
            label=fr"$n={n}$",
        )
    ax.set_xlabel(r"Phase-error fraction $q=t/n$")
    ax.set_ylabel(r"Relative finite-size gain $\Delta(n,q)/n$ [%]")
    ax.set_title("Relative finite-size gain from the exact Hamming ball")
    ax.set_ylim(bottom=0.0)
    ax.legend(ncol=2)
    fig.tight_layout()
    target_gain = FIGURES / "main_hamming_finite_gain.pdf"
    fig.savefig(target_gain)
    plt.close(fig)

    phase = pd.read_csv(STAGES["05"] / "data" / "phase_error_upper_vs_N.csv")
    fig, ax = plt.subplots(figsize=(8.0, 5.0))
    for color, q_tol in zip(colors, sorted(phase["q_tol"].unique())):
        sub = phase[np.isclose(phase["q_tol"], q_tol)].sort_values("N")
        ax.plot(sub["N"], sub["q_ph_upper"], color=color, marker="o", markersize=3,
                label=fr"$Q_X^{{\mathrm{{tol}}}}={100*q_tol:g}\%$")
    ax.set_xscale("log")
    ax.set_xlabel(r"Transmitted signals $N$")
    ax.set_ylabel(r"Phase-error upper rate $Q_{\mathrm{ph}}^{U}$")
    ax.set_title(r"Phase-error bound with fixed test fraction $m/s=0.2$")
    ax.legend()
    fig.tight_layout()
    target_phase = FIGURES / "main_02_phase_error_upper_vs_N.pdf"
    fig.savefig(target_phase)
    plt.close(fig)

    # Figure 14 is assembled from three panels in LaTeX.  Regenerate the
    # individual PDFs with deliberately large typography so their labels remain
    # readable after each panel is reduced to roughly half the text width.
    key_grid = pd.read_csv(STAGES["05"] / "data" / "key_length_vs_N_grid.csv")
    key_styles = {
        "ideal_fec_1_1": ("#0077BB", "o", "-", r"Ideal $1.1n h_2(Q)$"),
        "cascade_p95": ("#EE7733", "s", "--", "Cascade p95"),
        "cascade_p99": ("#009988", "^", "-.", "Cascade p99"),
        "cascade_max": ("#CC3311", "D", ":", "Cascade maximum"),
    }
    for q_tol in [0.01, 0.03, 0.05]:
        fig, ax = plt.subplots(figsize=(8.0, 5.0))
        q_rows = key_grid[np.isclose(key_grid["grid_q_tol"], q_tol)]
        for model, (color, marker, line_style, label) in key_styles.items():
            sub = q_rows[q_rows["leakage_model"] == model].sort_values("N")
            ax.plot(
                sub["N"],
                sub["ell"],
                color=color,
                marker=marker,
                linestyle=line_style,
                linewidth=2.4,
                markersize=5.5,
                label=label,
            )
        ax.axhline(
            256,
            color="black",
            linewidth=1.6,
            linestyle="--",
            label="256-bit target",
        )
        ax.set_xlabel(r"Transmitted signals $N$", fontsize=20)
        ax.set_ylabel(r"Optimized key length $\ell$ (bits)", fontsize=20)
        ax.set_title(
            fr"Historical fixed-sifting diagnostic: $Q={100*q_tol:.0f}\%$",
            fontsize=22,
            fontweight="semibold",
            pad=10,
        )
        ax.tick_params(axis="both", labelsize=17)
        ax.xaxis.set_major_locator(MaxNLocator(nbins=5, integer=True))
        ax.ticklabel_format(style="plain", axis="x")
        ax.legend(
            fontsize=16,
            loc="upper left",
            frameon=True,
            facecolor="white",
            edgecolor="0.8",
            framealpha=0.92,
            borderpad=0.35,
            labelspacing=0.25,
            handlelength=2.0,
        )
        ax.margins(x=0.02)
        fig.tight_layout(pad=0.8)
        target_key = FIGURES / f"main_03_key_length_vs_N_qber_{int(100*q_tol)}pct.pdf"
        fig.savefig(target_key)
        plt.close(fig)

    q_tol = 0.03
    eps_pe = 2e-10
    s_values = np.unique(np.round(np.logspace(math.log10(800), math.log10(30_000), 34)).astype(int))
    pe_rows: list[dict[str, float]] = []
    for s in s_values:
        m = max(1, int(math.floor(0.2 * s)))
        n = s - m
        e_tol = int(math.floor(q_tol * m))
        q_hat = e_tol / m
        hoeffding = min(0.5, q_hat + math.sqrt(math.log(1.0 / eps_pe) / (2.0 * m)))
        serfling = min(0.5, q_hat + math.sqrt((s - m + 1.0) * math.log(1.0 / eps_pe) / (2.0 * m * s)))
        clopper = float(np.clip(scipy.stats.beta.ppf(1.0 - eps_pe, e_tol + 1, m - e_tol), 0.0, 0.5))
        K_upper = _hypergeom_K_upper(e_tol, s, m, eps_pe)
        hypergeom = float(np.clip((K_upper - e_tol) / n, 0.0, 0.5))
        pe_rows.append({
            "s": s,
            "Hoeffding": hoeffding,
            "Serfling": serfling,
            "Clopper--Pearson": clopper,
            "Hypergeometric": hypergeom,
        })
    pe = pd.DataFrame(pe_rows)
    fig, ax = plt.subplots(figsize=(8.0, 5.0))
    for color, method in zip(colors, ["Hoeffding", "Serfling", "Clopper--Pearson", "Hypergeometric"]):
        ax.plot(pe["s"], pe[method], color=color, marker="o", markersize=2.8, label=method)
    ax.set_xscale("log")
    ax.set_xlabel(r"Sifted block size $s$")
    ax.set_ylabel(r"Upper phase-error rate $Q_{\mathrm{ph}}^{U}$")
    ax.set_title(r"Comparison using the same test fraction: $Q_X^{\mathrm{tol}}=3\%$, $m/s\simeq0.2$")
    ax.legend()
    fig.tight_layout()
    target_pe = FIGURES / "main_parameter_estimation_comparison.pdf"
    fig.savefig(target_pe)
    plt.close(fig)

    trials = pd.read_csv(STAGES["03"] / "tables" / "reconciliation_trials.csv")
    group = trials[
        trials["protocol"].astype(str).str.contains("cascade", case=False, na=False)
        & (trials["n"] == 2048)
        & np.isclose(trials["qber"], 0.03)
    ]
    leakage = group["leakage_bits"].to_numpy(dtype=float)
    statistics = {
        "mean": float(np.mean(leakage)),
        "p95": float(np.quantile(leakage, 0.95)),
        "p99": float(np.quantile(leakage, 0.99)),
        "max": float(np.max(leakage)),
    }
    fig, ax = plt.subplots(figsize=(8.0, 5.0))
    ax.hist(leakage, bins=22, color="#56B4E9", edgecolor="white", alpha=0.9)
    line_styles = ["-", "--", "-.", ":"]
    for color, style, (name, value) in zip(colors, line_styles, statistics.items()):
        ax.axvline(value, color=color, linestyle=style, linewidth=1.8,
                   label=fr"{name}: ${value:.1f}$ bits")
    ax.set_xlabel(r"Cascade parity leakage $L$ (bits)")
    ax.set_ylabel("Number of simulated runs")
    ax.set_title(r"Cascade leakage histogram: $n=2048$, $Q=3\%$")
    ax.legend()
    fig.tight_layout()
    target_leakage = FIGURES / "main_10_leakage_caps_visualization.pdf"
    fig.savefig(target_leakage)
    plt.close(fig)

    for target, caption in [
        (target_zoom, "Zoomed exact and binary-entropy Hamming-ball comparison at n=256."),
        (target_gain, "Relative finite-size entropy gain from using the exact Hamming-ball volume, expressed as a percentage of the raw-key block."),
        (target_pe, "Hoeffding, Serfling, Clopper--Pearson, and hypergeometric PE comparison."),
    ]:
        inventory.append({
            "original_path": "generated by report/prepare_assets.py",
            "copied_path": target.relative_to(ROOT).as_posix(),
            "placement": "main text",
            "caption_draft": caption,
        })


def _load_notebook_functions() -> dict[str, object]:
    notebook = json.loads((ROOT / "05_publication_ready_analysis.ipynb").read_text(encoding="utf-8"))
    namespace: dict[str, object] = {
        "ast": ast,
        "itertools": itertools,
        "json": json,
        "math": math,
        "Path": Path,
        "np": np,
        "pd": pd,
        "scipy": scipy,
        "TARGET_KEY_LENGTH": 256,
        "DEFAULT_EPS_TOTAL": 1e-9,
        "DEFAULT_P_SIFT": 0.5,
        "DEFAULT_F_EC": 1.1,
        "DEFAULT_QTOL_GRID": [0.005, 0.01, 0.02, 0.03, 0.05],
        "EXACT_S_LIMIT": 200_000,
        "MAIN_M_FRACTION_GRID": np.linspace(0.06, 0.44, 20),
        "DIAGNOSTIC_M_FRACTION_GRID": np.linspace(0.08, 0.40, 13),
    }
    retained_assignments = {"_HAMMING_CACHE", "_PE_CACHE", "_KEY_CACHE", "SEARCH_TRACE_ROWS"}
    for cell_index in [6, 10, 21, 23, 25]:
        tree = ast.parse("".join(notebook["cells"][cell_index]["source"]))
        body: list[ast.stmt] = []
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.Import, ast.ImportFrom)):
                body.append(node)
            elif isinstance(node, ast.Assign):
                names = {target.id for target in node.targets if isinstance(target, ast.Name)}
                if names & retained_assignments:
                    body.append(node)
        module = ast.Module(body=body, type_ignores=[])
        exec(compile(module, f"notebook_cell_{cell_index}", "exec"), namespace)
    leakage = pd.read_csv(STAGES["03"] / "tables" / "empirical_leakage_table.csv")
    leakage.columns = [str(col).strip().lower().replace(" ", "_").replace("-", "_") for col in leakage.columns]
    leakage["protocol"] = leakage["protocol"].astype(str).str.lower().str.strip()
    namespace["cascade_leakage_table"] = leakage[leakage["protocol"].str.contains("cascade", na=False)].copy()
    return namespace


def corrected_results() -> pd.DataFrame:
    namespace = _load_notebook_functions()
    verified = pd.read_csv(STAGES["05"] / "tables" / "Nmin_local_verification.csv")
    rows: list[dict[str, object]] = []
    optimize = namespace["optimize_m_fraction_for_N"]
    for row in verified.itertuples(index=False):
        best, _ = optimize(
            int(row.reported_N_min),
            float(row.q_tol),
            m_fraction_grid=namespace["MAIN_M_FRACTION_GRID"],
            ec_model=str(row.leakage_model),
            eps_total=1e-9,
            p_sift=0.5,
            pe_method="hypergeom",
            leakage_table=namespace["cascade_leakage_table"],
            exact_hamming=True,
        )
        best["N_min"] = int(row.reported_N_min)
        best["binary_search_N_min"] = int(row.binary_search_N_min)
        best["locally_verified_minimal"] = bool(row.locally_verified_minimal)
        rows.append(best)
    result = pd.DataFrame(rows).sort_values(["q_tol", "leakage_model"]).reset_index(drop=True)
    result.to_csv(TABLES / "corrected_main_Nmin_table.csv", index=False)

    budget = result[
        result["q_tol"].isin([0.01, 0.03, 0.05])
        & result["leakage_model"].isin(["ideal_fec_1_1", "cascade_p95", "cascade_p99"])
    ][["q_tol", "leakage_model", "N_min", "entropy_used", "L_max", "t_ver", "pa_penalty", "ell"]].copy()
    budget["ell_ec"] = budget["entropy_used"] - budget["L_max"]
    budget["ell_ver"] = budget["ell_ec"] - budget["t_ver"]
    budget["ell_pa"] = budget["ell_ver"] - budget["pa_penalty"]
    budget = budget[[
        "q_tol", "leakage_model", "N_min", "entropy_used", "L_max",
        "ell_ec", "t_ver", "ell_ver", "pa_penalty", "ell_pa", "ell",
    ]]
    if not np.array_equal(np.floor(budget["ell_pa"]).astype(int), budget["ell"].astype(int)):
        raise ValueError("Progressive key-length stages do not reproduce the final integer key length.")
    budget.to_csv(TABLES / "corrected_bit_budget_table.csv", index=False)

    fractions = result[["q_tol", "leakage_model", "N_min", "s", "m", "m_fraction"]].copy()
    fractions["m_over_s"] = fractions["m"] / fractions["s"]
    fractions.to_csv(TABLES / "corrected_optimal_m_fraction_table.csv", index=False)

    wide_n = result.pivot(index="q_tol", columns="leakage_model", values="N_min").reset_index()
    for model in ["cascade_p95", "cascade_p99", "cascade_max"]:
        wide_n[f"{model}_percent_increase"] = 100.0 * (
            wide_n[model] / wide_n["ideal_fec_1_1"] - 1.0
        )
    wide_n.to_csv(TABLES / "main_result_wide.csv", index=False)
    return result


def regenerate_corrected_figures(result: pd.DataFrame, inventory: list[dict[str, str]]) -> None:
    plt.rcParams.update({
        "axes.grid": True,
        "grid.alpha": 0.25,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "font.size": 10,
        "legend.frameon": False,
    })
    budget = pd.read_csv(TABLES / "corrected_bit_budget_table.csv")
    for q_tol in [0.01, 0.03, 0.05]:
        sub = budget[np.isclose(budget["q_tol"], q_tol)].copy()
        order = ["ideal_fec_1_1", "cascade_p95", "cascade_p99"]
        sub["order"] = sub["leakage_model"].map({name: i for i, name in enumerate(order)})
        sub = sub.sort_values("order")
        stage_columns = ["ell_ec", "ell_ver", "ell_pa", "ell"]
        stage_labels = [
            r"$\ell_{\mathrm{EC}}$",
            r"$\ell_{\mathrm{ver}}$",
            r"$\ell_{\mathrm{PA}}$",
            r"final $\ell$",
        ]
        x = np.arange(len(stage_columns))
        fig, ax = plt.subplots(figsize=(8, 4.8))
        styles = {
            "ideal_fec_1_1": ("#0077BB", "o", "-", "ideal $1.1n h_2(Q)$"),
            "cascade_p95": ("#EE7733", "s", "--", "Cascade p95"),
            "cascade_p99": ("#009988", "^", "-.", "Cascade p99"),
        }
        for row in sub.itertuples(index=False):
            color, marker, line_style, label = styles[row.leakage_model]
            values = np.array([getattr(row, column) for column in stage_columns], dtype=float)
            ax.plot(
                x,
                values,
                color=color,
                marker=marker,
                linestyle=line_style,
                linewidth=1.8,
                markersize=6,
                label=label,
            )
        ax.axhline(256, color="black", linewidth=0.8, linestyle="--", label="256-bit target")
        ax.set_xticks(x)
        ax.set_xticklabels(stage_labels)
        ax.set_ylim(250, float(sub["ell_ec"].max()) + 8)
        ax.set_ylabel("Remaining key-length budget (bits)", fontsize=13)
        ax.set_title(
            fr"Symmetric planning slice: $Q={100*q_tol:.0f}\%$",
            fontsize=14,
        )
        ax.tick_params(axis="both", labelsize=11)
        ax.legend(fontsize=10)
        fig.tight_layout()
        target = FIGURES / f"main_corrected_bit_budget_qber_{int(100*q_tol)}pct.pdf"
        fig.savefig(target)
        plt.close(fig)
        inventory.append({
            "original_path": "generated from report/tables/corrected_main_Nmin_table.csv",
            "copied_path": target.relative_to(ROOT).as_posix(),
            "placement": "main text",
            "caption_draft": f"Historical fixed-sifting bit-budget diagnostic at common planning error Q={int(100*q_tol)}%; superseded by the basis-resolved export.",
        })

    fractions = pd.read_csv(TABLES / "corrected_optimal_m_fraction_table.csv")
    fig, ax = plt.subplots(figsize=(8, 5))
    for model in ["ideal_fec_1_1", "cascade_p95", "cascade_p99", "cascade_max"]:
        sub = fractions[fractions["leakage_model"] == model].sort_values("q_tol")
        ax.plot(sub["q_tol"], sub["m_over_s"], marker="o", label=model)
    ax.set_xlabel(r"Historical planning error rate $Q$ (symmetric assumption)")
    ax.set_ylabel(r"Optimized parameter-estimation fraction $m/s$")
    ax.set_title("Historical planning-stage fraction diagnostic")
    ax.legend(fontsize=8)
    fig.tight_layout()
    target = FIGURES / "main_corrected_optimal_parameter_estimation_fraction.pdf"
    fig.savefig(target)
    plt.close(fig)
    inventory.append({
        "original_path": "generated from report/tables/corrected_main_Nmin_table.csv",
        "copied_path": target.relative_to(ROOT).as_posix(),
        "placement": "main text",
        "caption_draft": "Historical planning-stage m/s diagnostic retained for provenance; it does not generate the theorem-level minima on the 21-point p_Z grid.",
    })


def regenerate_basis_resolved_headline_figures(inventory: list[dict[str, str]]) -> None:
    """Redraw headline plots from stored minima without rerunning the search."""
    minima = pd.read_csv(ROOT / "results" / "ideal_basis" / "minima.csv")
    q_column = "q_x_tol" if "q_x_tol" in minima.columns else "q_tol"
    styles = {
        "ideal_fec_1_1": ("#0077BB", "o", "ideal"),
        "cascade_p95": ("#EE7733", "s", "Cascade p95"),
        "cascade_p99": ("#009988", "^", "Cascade p99"),
        "cascade_max": ("#CC3311", "D", "Cascade maximum"),
    }

    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    for model, (color, marker, label) in styles.items():
        group = minima[minima["leakage_model"] == model].sort_values(q_column)
        ax.plot(100 * group[q_column], group["N_min"], color=color, marker=marker, label=label)
    ax.set_xlabel(r"Symmetric planning error rate $Q$ (\%)")
    ax.set_ylabel("Transmitted pulses")
    ax.set_title(r"Accepted-run minima: $Q=Q_X^{\rm tol}=Q_Z^{\rm design}$")
    ax.legend()
    fig.tight_layout()
    target = FIGURES / "ideal_basis_minima.pdf"
    fig.savefig(target)
    plt.close(fig)

    wide = minima.pivot(index=q_column, columns="leakage_model", values="N_min").sort_index()
    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    for model in ["cascade_p95", "cascade_p99", "cascade_max"]:
        color, marker, label = styles[model]
        increase = 100.0 * (wide[model] / wide["ideal_fec_1_1"] - 1.0)
        ax.plot(100 * wide.index, increase, color=color, marker=marker, label=label)
    ax.set_xlabel(r"Symmetric planning error rate $Q$ (\%)")
    ax.set_ylabel(r"Increase in $N_{\min}$ over ideal (\%)")
    ax.set_title(r"Enforced-cap cost: $Q=Q_X^{\rm tol}=Q_Z^{\rm design}$")
    ax.legend()
    fig.tight_layout()
    target = FIGURES / "main_05_percent_increase_over_ideal.pdf"
    fig.savefig(target)
    plt.close(fig)

    for target, caption in [
        ("ideal_basis_minima.pdf", "Accepted-run minima on the symmetric planning slice."),
        ("main_05_percent_increase_over_ideal.pdf", "Relative cap cost on the symmetric planning slice."),
    ]:
        inventory.append({
            "original_path": "generated from results/ideal_basis/minima.csv",
            "copied_path": (FIGURES / target).relative_to(ROOT).as_posix(),
            "placement": "main text",
            "caption_draft": caption,
        })


def prepare_tables() -> list[dict[str, str]]:
    inventory: list[dict[str, str]] = []
    for stage, base in STAGES.items():
        for source in sorted(base.rglob("*.csv")):
            subkind = "data" if source.parent.name == "data" else "table"
            target = TABLES / f"s{stage}_{subkind}_{source.name}"
            copy_file(source, target)
            lower = source.name.lower()
            if any(token in lower for token in ["paper_table_2", "percent_increase", "local_verification", "security_budget_sensitivity", "cap_abort_probability", "exact_vs_binary", "reconciliation_summary"]):
                use = "main or appendix evidence"
            elif any(token in lower for token in ["trials", "scan_details", "search_traces", "grid", "checks", "diagnostics"]):
                use = "source data / reproducibility"
            else:
                use = "appendix or supporting analysis"
            inventory.append({
                "original_path": source.relative_to(ROOT).as_posix(),
                "copied_path": target.relative_to(ROOT).as_posix(),
                "use_in_report": use,
                "caption_draft": f"Project data export: {source.stem.replace('_', ' ')}. It records the numerical inputs or outputs used to trace the finite-key and reconciliation analysis.",
            })
    for name, use, caption in [
        ("corrected_main_Nmin_table.csv", "main result", "Locally verified N_min rows with every theorem and block-size field recomputed at the reported minimum."),
        ("main_result_wide.csv", "main result", "Wide comparison of ideal, p95, p99, and maximum leakage-cap N_min values and percentage increases."),
        ("corrected_bit_budget_table.csv", "main result", "Progressive exact-Hamming key-length budgets after the error-correction cap, verification tag, privacy-amplification margin, and final integer floor."),
        ("corrected_optimal_m_fraction_table.csv", "historical diagnostic", "Historical planning-stage parameter-estimation fractions retained for provenance; not used by the basis-resolved theorem search."),
    ]:
        inventory.append({
            "original_path": "generated from locally verified source rows",
            "copied_path": (TABLES / name).relative_to(ROOT).as_posix(),
            "use_in_report": use,
            "caption_draft": caption,
        })
    return inventory


def write_inventory(path: Path, rows: list[dict[str, str]], fieldnames: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    figure_inventory = prepare_figures()
    regenerate_neutral_history_figures(figure_inventory)
    regenerate_pedagogical_figures(figure_inventory)
    corrected = corrected_results()
    regenerate_corrected_figures(corrected, figure_inventory)
    regenerate_basis_resolved_headline_figures(figure_inventory)
    table_inventory = prepare_tables()
    write_inventory(
        REPORT / "figure_inventory.csv",
        figure_inventory,
        ["original_path", "copied_path", "placement", "caption_draft"],
    )
    write_inventory(
        REPORT / "table_inventory.csv",
        table_inventory,
        ["original_path", "copied_path", "use_in_report", "caption_draft"],
    )
    print(f"Prepared {len(figure_inventory)} figure-inventory rows.")
    print(f"Prepared {len(table_inventory)} table-inventory rows.")


if __name__ == "__main__":
    main()
