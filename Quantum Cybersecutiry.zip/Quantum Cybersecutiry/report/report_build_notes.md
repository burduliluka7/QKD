# Report build notes

## Build outcome

- `main.tex` compiles successfully to a 48-page `main.pdf`.
- The final direct build sequence was `pdflatex`, `bibtex`, `pdflatex`, `pdflatex`.
- The final LaTeX log contains no warnings, undefined citations, undefined references, overfull boxes, or underfull boxes.
- Section order was revised so the main result appears sooner: theory -> Cascade reconciliation (Sec. 10) -> ideal-source results (Sec. 11) -> finite decoy-state extension (Sec. 12) -> further work: LDPC (Sec. 13) -> discussion/conclusion. The LDPC "further work" block previously sat between Cascade and the ideal-source results; it now follows the decoy extension. The ideal-source results table therefore reaches the reader around page 20 instead of page 34.
- The compiled manuscript includes 23 external figure files plus two TikZ diagrams and 9 numbered tables. Section 13 ("Further work: LDPC syndrome reconciliation") carries the LDPC mechanism, code-search, held-out validation, quick-grid diagnostics, and the Hamming-family cautionary baseline. The LDPC code-search subsection now states explicitly that the failure-probability gate is evaluated on the held-out sample and therefore constitutes an evaluation-gated search (post-selection endpoints), not a freeze-then-validate certification. The ideal-source results section also carries a "Capacity-only sensitivity diagnostics" subsection with the three previously development-record-only plots (`main_04_Nmin_vs_QBER.pdf`, `main_08_security_budget_sensitivity.pdf`, `main_09_exact_vs_binary_entropy_Nmin.pdf`), framed as security-only capacity thresholds that are not `N_90` or `Ncount_99`. The remaining `\iffalse` block (Appendix "Complete supporting figure record") still holds the superseded exploratory diagnostic plots.
- LDPC-vs-Cascade wording was tightened in the abstract, the further-work section, and the conclusion: the claim is now "the tested LDPC implementation does not yet provide a validated operational schedule competitive with Cascade" (a selected syndrome can be shorter in leakage alone, but only at unbounded decoding-failure rates), replacing the broader "does not improve on Cascade".
- `figure_inventory.csv` and `table_inventory.csv` still record the full historical set (including the omitted PNG duplicates and the superseded diagnostic plots); only the entries referenced from the non-`\iffalse` body of `main.tex` appear in the PDF.

## Materials used

The report uses the following project materials:

- `01_finite_key_short_key_qkd_study.ipynb`
- `02_rigorous_bounds_and_ec_leakage.ipynb`
- `03_empirical_reconciliation_leakage.ipynb`
- `04_theorem_level_finite_key_wrapper.ipynb`
- `05_publication_ready_analysis.ipynb`
- `cleaned_security_proof_theory.txt`
- `Notes.pdf` and `Notes.tex`
- `0806.0120v1.pdf`
- `2405.16578v3.pdf`
- `ncomms1631.pdf`
- all CSV and figure outputs under `results_01_finite-key/`, `results_02_rigorous/`, `results_03_reconciliation/`, `results_04_theorem-wrapper/`, and `results_05_publication-ready/`

The cleaned proof is the authority for the final key-length expression. The publication-ready local verification file is the authority for reported minima. Empirical reconciliation summaries and trial-level records supply the Cascade cap candidates and operational failure diagnostics.

## Requested names that were not present

Several names in the task description refer to an older directory layout. They were not found verbatim:

- `finite_key_short_key_qkd_study.ipynb` (available as `01_finite_key_short_key_qkd_study.ipynb`)
- `03_empirical_reconciliation_leakage(1).ipynb`
- `04_theorem_level_finite_key_wrapper(1).ipynb`
- `05_publication_ready_analysis(1).ipynb`
- `Notes(2).pdf` (available as `Notes.pdf`)
- `results_reconciliation/` (available as `results_03_reconciliation/`)
- `results_theorem_wrapper/` (available as `results_04_theorem-wrapper/`)
- `results_publication_ready/`, `tables_publication_ready/`, and `figures_publication_ready/` (available under `results_05_publication-ready/`)

No result was invented for an absent file. Equivalent available materials were used where the mapping was unambiguous.

## Integrity correction applied during the build

The publication-ready local scan lowered five binary-search candidates. The headline `N_min` values were correctly updated, but several ancillary fields in the same exported rows retained values from the earlier candidates because the cached checkpoint stored only a subset of columns. This affected some `s`, `m`, `n`, phase-error, entropy, and derived fraction fields, and therefore affected four exported diagnostic plots.

The report-preparation script reloads the exact numerical functions from the publication-ready analysis, evaluates every locally verified `N_min` with the declared 21-point `p_Z` grid, and rebuilds all ancillary fields. The authoritative corrected files are:

- `tables/corrected_main_Nmin_table.csv`
- `tables/main_result_wide.csv`
- `tables/corrected_bit_budget_table.csv`
- `tables/corrected_optimal_m_fraction_table.csv`

Corrected progressive key-length-budget and parameter-estimation-fraction plots are used in the main text. The original four exports remain in the appendix and are explicitly labeled as superseded diagnostics.

## Pedagogical revision

The report-preparation script now also generates a dedicated $n=256$ Hamming-ball zoom, a relative finite-size-gain plot normalized per raw-key bit, a four-method parameter-estimation comparison, a math-typeset phase-error plot, and an explicit Cascade leakage histogram. The main text defines each security-budget term and each phase-estimation variable at first use, traces the computation from transmitted signals to the Hamming-ball radius, and states the accepted-transcript alphabet condition needed to subtract the reconciliation cap.

## Bibliography checks

Core journal metadata and DOIs for the finite-key, uncertainty-relation, leftover-hashing, BB84-security, Hoeffding, Serfling, and Clopper--Pearson references were checked against Crossref where network access was available. Local primary PDFs supplied the finite-key paper metadata and the latest consolidated proof version. Entries without a reliably resolved DOI use stable arXiv or proceedings metadata rather than a guessed identifier.

`BertaEtAl2010` (superseded by `TomamichelRenner2011` in the text and cited nowhere) was removed from `references.bib`. `HuEtAl2005` was re-added and is now cited from the LDPC further-work section for the PEG matrix construction. `Gallager1962` is likewise cited from that section. `BennettBrassard1984`, `LimEtAl2014`, and `WiesemannCode2025` are retained: they are cited by `decoy.tex` or the `decoy_notes.tex` manual bibliography, or are reserved for a planned finite-key benchmark comparison.

## Interpretation limits retained in the report

- The protocol model is ideal single-photon BB84 with trusted devices and fixed effective sifting.
- The simplified Cascade simulation counts disclosed block and binary-search parity bits. A deployment proof must cap a canonical encoding of every key-dependent transcript feature, including control flow.
- There are 200 reconciliation trials per block-size/QBER point; p99 and maximum caps are sensitivity evidence, not stable extreme-tail estimates.
- The reported values are locally verified minima under a discrete `m/s` grid, not a formal global optimum over continuous protocol parameters.
- Authentication-key consumption, decoy-state source statistics, detector imperfections, and side channels are outside scope.

## Remaining polish for submission

- Add affiliation and target-venue metadata.
- Select a journal style and adapt the document class and bibliography style.
- Validate the simplified Cascade implementation against a reference implementation or published test vectors.
- Increase reconciliation trials and attach uncertainty intervals to cap estimates.
- Replace the discrete parameter-estimation grid with an adaptive or exhaustive optimizer.

## Rebuild

From the project root:

```powershell
python .\report\prepare_assets.py
Set-Location .\report
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

For the standalone decoy report, keep SyncTeX enabled so PDF backward search can jump from `decoy.pdf` to `decoy.tex`:

```powershell
Set-Location .\report
pdflatex -synctex=1 -interaction=nonstopmode -halt-on-error decoy.tex
```

`latexmk` was not used for the final build because the local executable resolves its runtime incorrectly. The direct build sequence succeeds.
