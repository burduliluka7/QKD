"""
LDPC code-selection search and evaluation for BB84 finite-key reconciliation.

For each (n, Q) grid point and each target failure threshold beta, this script:
  1. Uses Shannon entropy as a lower bound to seed the r-scan.
  2. Scans r upward (coarse then fine) using design trials.
  3. Selects the smallest r with empirical failure rate < beta.
  4. Evaluates the selected code with more trials.
  5. Saves:
     - ldpc_trial_results.csv      (per-trial data for all evaluated codes)
     - ldpc_selected_codes.csv     (one row per (n, Q, beta))
     - ldpc_leakage_table.csv      (leakage lookup table for publication notebook)

Usage:
    python run_ldpc_simulation.py [--mode quick|full] [--output-dir DIR]
                                  [--design-trials N] [--eval-trials N]
                                  [--max-iter N] [--dv N] [--betas 0.01 0.05]

Modes:
    quick  default): n in {256, 512, 1024, 2048}, design_trials=100, eval_trials=200
    full            n in {256..8192},              design_trials=200, eval_trials=1000
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
from scipy.stats import beta as beta_dist

# Import LDPC core
from ldpc_reconciliation import (
    binary_entropy,
    build_ldpc_matrix,
    ldpc_trial,
    matrix_rank_gf2,
    run_sanity_checks,
)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

QUICK_N_VALUES = [256, 512, 1024, 2048]
FULL_N_VALUES = [256, 512, 1024, 2048, 4096, 8192]
Q_VALUES = [0.005, 0.01, 0.02, 0.03, 0.05, 0.08]
BETA_VALUES = [0.01, 0.05]

CANDIDATE_SEEDS = [0, 1, 2]      # seeds for candidate matrix generation
COARSE_STEP_FRACTION = 0.15      # coarse scan step as fraction of r_min_shannon
FINE_STEP = 1                    # fine scan step (single-bit increment)
FINE_WINDOW = 5                  # fine-scan range around first coarse success
MAX_R_MULTIPLIER = 3.0           # give up if r > MAX_R_MULTIPLIER * r_min_shannon
MIN_R_FLOOR = 1                  # absolute minimum r to try

# DV=3 is the default variable degree
DEFAULT_DV = 3
DEFAULT_MAX_ITER = 100
DEFAULT_CLIP = 20.0
DEFAULT_CONFIDENCE_LEVEL = 0.95

# Output paths
DEFAULT_OUTPUT_DIR = "results_ldpc"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def r_shannon_min(n: int, Q: float) -> int:
    """Return ceil(n * h2(Q)) as the Shannon lower bound for r."""
    h = binary_entropy(Q)
    if h <= 0.0:
        return 1
    return max(1, math.ceil(n * h))


def build_edge_index(
    var_adj: list[list[int]],
    chk_adj: list[list[int]],
    n: int,
    r: int,
) -> tuple[np.ndarray, np.ndarray, list[np.ndarray]]:
    """Build edge-index arrays for vectorized BP updates."""
    ev_list: list[int] = []
    ec_list: list[int] = []
    check_edges: list[list[int]] = [[] for _ in range(r)]
    k = 0
    for i in range(n):
        for a in var_adj[i]:
            ev_list.append(i)
            ec_list.append(a)
            check_edges[a].append(k)
            k += 1
    ev = np.array(ev_list, dtype=np.int64)
    ec = np.array(ec_list, dtype=np.int64)
    ce_arr = [np.array(edges, dtype=np.int64) for edges in check_edges]
    return ev, ec, ce_arr


def fast_syndrome_from_error(
    ev: np.ndarray,
    ec: np.ndarray,
    e: np.ndarray,
    r: int,
) -> np.ndarray:
    """Compute H e over GF(2) using the sparse edge index."""
    sigma = np.zeros(r, dtype=np.int64)
    np.add.at(sigma, ec, e[ev].astype(np.int64))
    return (sigma % 2).astype(np.uint8)


def fast_bp_decode(
    ev: np.ndarray,
    ec: np.ndarray,
    ce_arr: list[np.ndarray],
    sigma: np.ndarray,
    n: int,
    r: int,
    Q: float,
    max_iter: int = DEFAULT_MAX_ITER,
    clip: float = DEFAULT_CLIP,
) -> tuple[np.ndarray, bool, int]:
    """Vectorized sum-product BP decoder for syndrome decoding on a BSC."""
    Q = max(1e-12, min(1.0 - 1e-12, float(Q)))
    lam = math.log((1.0 - Q) / Q)
    sigma_sign = np.where(sigma == 0, 1.0, -1.0)
    V2C = np.full(len(ev), lam, dtype=np.float64)
    C2V = np.zeros(len(ev), dtype=np.float64)

    for it in range(max_iter):
        vsum = np.zeros(n, dtype=np.float64)
        np.add.at(vsum, ev, C2V)
        V2C = np.clip(lam + vsum[ev] - C2V, -clip, clip)

        for a in range(r):
            ce = ce_arr[a]
            if len(ce) == 0:
                continue
            tanh_vals = np.tanh(V2C[ce] / 2.0)
            log_abs = np.log(np.abs(tanh_vals) + 1e-300)
            signs = np.sign(tanh_vals)
            sign_product = sigma_sign[a] * np.prod(signs)
            log_sum = float(np.sum(log_abs))
            messages = np.clip(
                sign_product * signs * np.exp(np.clip(log_sum - log_abs, -700.0, 0.0)),
                -1.0 + 1e-12,
                1.0 - 1e-12,
            )
            C2V[ce] = 2.0 * np.arctanh(messages)

        post = np.full(n, lam, dtype=np.float64)
        np.add.at(post, ev, C2V)
        e_hat = (post < 0.0).astype(np.uint8)
        if np.array_equal(fast_syndrome_from_error(ev, ec, e_hat, r), sigma):
            return e_hat, True, it + 1

    post = np.full(n, lam, dtype=np.float64)
    np.add.at(post, ev, C2V)
    e_hat = (post < 0.0).astype(np.uint8)
    return e_hat, False, max_iter


def fast_ldpc_trial(
    n: int,
    Q: float,
    ev: np.ndarray,
    ec: np.ndarray,
    ce_arr: list[np.ndarray],
    r: int,
    dv: int,
    matrix_seed: int,
    trial_seed: int,
    construction_method: str,
    max_iter: int,
    collect_row: bool,
) -> dict:
    """Run one reconciliation trial using sparse syndrome and vectorized BP."""
    rng = np.random.default_rng(trial_seed)
    _x_a = rng.integers(0, 2, size=n, dtype=np.uint8)
    e = (rng.random(n) < Q).astype(np.uint8)
    sigma = fast_syndrome_from_error(ev, ec, e, r)
    e_hat, converged, iterations = fast_bp_decode(
        ev, ec, ce_arr, sigma, n, r, Q, max_iter=max_iter
    )
    residual = int(np.sum(e_hat ^ e))
    success = residual == 0

    if not collect_row:
        return {"success": success, "iterations": iterations}

    return {
        "n": n,
        "Q": Q,
        "r": r,
        "dv": dv,
        "construction_method": construction_method,
        "matrix_seed": matrix_seed,
        "trial_seed": trial_seed,
        "initial_errors": int(np.sum(e)),
        "syndrome_weight": int(np.sum(sigma)),
        "decoder_converged": bool(converged),
        "syndrome_satisfied": bool(converged),
        "residual_errors": residual,
        "success": bool(success),
        "iterations": int(iterations),
        "leakage_bits": int(r),
    }


def run_design_trials(
    n: int,
    Q: float,
    r: int,
    dv: int,
    matrix_seed: int,
    n_trials: int,
    max_iter: int,
    base_trial_seed: int,
) -> tuple[float, list[dict]]:
    """
    Build one LDPC matrix (n, r, dv, matrix_seed) and run n_trials design trials.

    Returns (failure_rate, list_of_trial_dicts).
    """
    H, var_adj, chk_adj, meta = build_ldpc_matrix(n, r, dv, seed=matrix_seed)
    _ = H
    ev, ec, ce_arr = build_edge_index(var_adj, chk_adj, n, r)
    trials = []
    for t in range(n_trials):
        trial_seed = base_trial_seed + t
        row = fast_ldpc_trial(
            n, Q, ev, ec, ce_arr, r, dv,
            matrix_seed=matrix_seed,
            trial_seed=trial_seed,
            construction_method=meta["construction_method"],
            max_iter=max_iter,
            collect_row=False,
        )
        trials.append(row)
    successes = sum(1 for row in trials if row["success"])
    failure_rate = 1.0 - successes / max(n_trials, 1)
    return failure_rate, trials


def clopper_pearson_upper(
    failures: int,
    trials: int,
    confidence: float = DEFAULT_CONFIDENCE_LEVEL,
) -> float:
    """One-sided exact binomial upper confidence bound for the failure rate."""
    failures = int(failures)
    trials = int(trials)
    confidence = float(confidence)
    if trials <= 0:
        return 1.0
    if confidence <= 0.0:
        return failures / trials
    if failures <= 0:
        return float(beta_dist.ppf(confidence, 1, trials))
    if failures >= trials:
        return 1.0
    return float(beta_dist.ppf(confidence, failures + 1, trials - failures))


def evaluate_candidate_code(
    n: int,
    Q: float,
    r: int,
    dv: int,
    matrix_seed: int,
    eval_trials: int,
    max_iter: int,
    eval_base_seed: int,
    confidence_level: float,
    compute_rank: bool = False,
) -> dict:
    """Run the held-out evaluation for one candidate code."""
    H, var_adj, chk_adj, meta = build_ldpc_matrix(n, r, dv, seed=matrix_seed)
    rank = matrix_rank_gf2(H) if compute_rank else None
    ev, ec, ce_arr = build_edge_index(var_adj, chk_adj, n, r)

    eval_trial_rows = []
    for t in range(eval_trials):
        row = fast_ldpc_trial(
            n, Q, ev, ec, ce_arr, r, dv,
            matrix_seed=matrix_seed,
            trial_seed=eval_base_seed + t,
            construction_method=meta["construction_method"],
            max_iter=max_iter,
            collect_row=True,
        )
        eval_trial_rows.append(row)

    eval_failures = sum(1 for row in eval_trial_rows if not row["success"])
    eval_fail_rate = eval_failures / max(eval_trials, 1)
    eval_fail_upper = clopper_pearson_upper(
        eval_failures, eval_trials, confidence_level
    )
    iters = [row["iterations"] for row in eval_trial_rows] or [0]

    return {
        "rank_H": rank,
        "eval_failures": eval_failures,
        "eval_failure_rate": round(eval_fail_rate, 6),
        "eval_failure_upper": round(eval_fail_upper, 6),
        "mean_iterations": round(float(np.mean(iters)), 3),
        "p95_iterations": round(float(np.percentile(iters, 95)), 3),
        "max_iterations": int(np.max(iters)),
        "construction_method": meta["construction_method"],
        "eval_trial_rows": eval_trial_rows,
    }


def _select_code_for_point_legacy(
    n: int,
    Q: float,
    beta: float,
    dv: int,
    design_trials: int,
    eval_trials: int,
    candidate_seeds: list[int],
    max_iter: int,
    verbose: bool = True,
) -> dict:
    """
    Select the smallest r (and best matrix seed) for (n, Q) with failure < beta.

    Search strategy:
      1. Coarse upward scan starting at r_shannon_min, step = max(1, ceil(coarse_frac * r_min))
      2. Once coarse finds a passing r, fine-scan FINE_WINDOW steps downward to verify
         and find the actual minimum.

    Returns a dict with selected code metadata and evaluated statistics.
    """
    r_min = r_shannon_min(n, Q)
    r_max = max(r_min + 1, math.ceil(MAX_R_MULTIPLIER * r_min))
    r_max = min(r_max, n)  # can't have more checks than bits

    coarse_step = max(1, math.ceil(COARSE_STEP_FRACTION * r_min))
    base_trial_seed = 10_000_000 + n * 10_000 + int(Q * 1_000_000)

    if verbose:
        print(f"  Searching n={n}, Q={Q:.3f}, beta={beta:.2f}: "
              f"r_min_shannon={r_min}, r_max={r_max}, coarse_step={coarse_step}")

    # Coarse scan
    coarse_first_pass_r = None
    r_coarse = r_min
    while r_coarse <= r_max:
        best_fail = 1.0
        for mseed in candidate_seeds:
            fail, _ = run_design_trials(
                n, Q, r_coarse, dv, mseed, design_trials, max_iter,
                base_trial_seed=base_trial_seed + mseed * 100_000,
            )
            if fail < best_fail:
                best_fail = fail
        if verbose:
            print(f"    coarse r={r_coarse}: best_fail={best_fail:.4f} (beta={beta:.2f})")
        if best_fail < beta:
            coarse_first_pass_r = r_coarse
            break
        r_coarse += coarse_step

    if coarse_first_pass_r is None:
        # Could not find a passing code
        return {
            "n": n, "Q": Q, "beta": beta, "selected_r": None,
            "selected_dv": dv, "selected_seed": None, "rank_H": None,
            "leakage_bits": None, "design_trials": design_trials,
            "design_failure_rate": None, "eval_trials": eval_trials,
            "eval_failure_rate": None, "mean_iterations": None,
            "p95_iterations": None, "max_iterations": None,
            "construction_method": "peg", "status": "not_found",
            "r_shannon_min": r_min,
        }

    # Fine scan: go back up to FINE_WINDOW steps before coarse_first_pass_r
    fine_start = max(r_min, coarse_first_pass_r - coarse_step + 1)
    fine_end = coarse_first_pass_r

    best_r = coarse_first_pass_r
    best_seed = candidate_seeds[0]
    best_fail = 1.0

    if verbose:
        print(f"    fine scan r in [{fine_start}, {fine_end}]")

    for r_fine in range(fine_start, fine_end + 1):
        for mseed in candidate_seeds:
            fail, _ = run_design_trials(
                n, Q, r_fine, dv, mseed, design_trials, max_iter,
                base_trial_seed=base_trial_seed + mseed * 100_000,
            )
            if verbose:
                print(f"      fine r={r_fine}, seed={mseed}: fail={fail:.4f}")
            if fail < beta and r_fine <= best_r:
                if r_fine < best_r or fail < best_fail:
                    best_r = r_fine
                    best_seed = mseed
                    best_fail = fail

    # Evaluate selected code with eval_trials
    H, var_adj, chk_adj, meta = build_ldpc_matrix(n, best_r, dv, seed=best_seed)
    rank = matrix_rank_gf2(H)

    eval_trial_rows = []
    eval_base_seed = base_trial_seed + 50_000_000
    for t in range(eval_trials):
        row = ldpc_trial(
            n, Q, H, var_adj, chk_adj, best_r, dv,
            matrix_seed=best_seed,
            trial_seed=eval_base_seed + t,
            construction_method=meta["construction_method"],
            max_iter=max_iter,
        )
        eval_trial_rows.append(row)

    eval_failures = sum(1 for row in eval_trial_rows if not row["success"])
    eval_fail_rate = eval_failures / max(eval_trials, 1)
    iters = [row["iterations"] for row in eval_trial_rows]
    mean_iters = float(np.mean(iters))
    p95_iters = float(np.percentile(iters, 95))
    max_iters = int(np.max(iters))

    if verbose:
        print(f"    SELECTED: r={best_r}, seed={best_seed}, rank={rank}, "
              f"eval_fail={eval_fail_rate:.4f}")

    return {
        "n": n,
        "Q": Q,
        "beta": beta,
        "selected_r": best_r,
        "selected_dv": dv,
        "selected_seed": best_seed,
        "rank_H": rank,
        "leakage_bits": best_r,
        "design_trials": design_trials,
        "design_failure_rate": round(best_fail, 6),
        "eval_trials": eval_trials,
        "eval_failure_rate": round(eval_fail_rate, 6),
        "mean_iterations": round(mean_iters, 3),
        "p95_iterations": round(p95_iters, 3),
        "max_iterations": max_iters,
        "construction_method": meta["construction_method"],
        "status": "ok",
        "r_shannon_min": r_min,
        "efficiency_r_over_shannon": round(best_r / max(r_min, 1), 4),
        "eval_trial_rows": eval_trial_rows,
    }


def select_code_for_point(
    n: int,
    Q: float,
    beta: float,
    dv: int,
    design_trials: int,
    eval_trials: int,
    candidate_seeds: list[int],
    max_iter: int,
    confidence_level: float = DEFAULT_CONFIDENCE_LEVEL,
    verbose: bool = True,
) -> dict:
    """
    Select the smallest r whose held-out evaluation passes the target beta.

    The design scan is still used as a cheap filter, but a code is marked "ok"
    only when the one-sided binomial upper confidence bound for the evaluation
    failure probability is <= beta.
    """
    r_min = r_shannon_min(n, Q)
    r_max = max(r_min + 1, math.ceil(MAX_R_MULTIPLIER * r_min))
    r_max = min(r_max, n)

    coarse_step = max(1, math.ceil(COARSE_STEP_FRACTION * r_min))
    base_trial_seed = 10_000_000 + n * 10_000 + int(Q * 1_000_000)
    eval_rows_all: list[dict] = []
    rejected_eval_count = 0

    if verbose:
        print(f"  Searching n={n}, Q={Q:.3f}, beta={beta:.2f}: "
              f"r_min_shannon={r_min}, r_max={r_max}, coarse_step={coarse_step}, "
              f"confidence={confidence_level:.2f}")

    search_start = r_min
    while search_start <= r_max:
        coarse_first_pass_r = None
        r_coarse = search_start

        while r_coarse <= r_max:
            best_fail = 1.0
            for mseed in candidate_seeds:
                fail, _ = run_design_trials(
                    n, Q, r_coarse, dv, mseed, design_trials, max_iter,
                    base_trial_seed=base_trial_seed + mseed * 100_000,
                )
                best_fail = min(best_fail, fail)
            if verbose:
                print(f"    coarse r={r_coarse}: best_fail={best_fail:.4f} "
                      f"(beta={beta:.2f})")
            if best_fail < beta:
                coarse_first_pass_r = r_coarse
                break
            r_coarse += coarse_step

        if coarse_first_pass_r is None:
            return {
                "n": n, "Q": Q, "beta": beta, "selected_r": None,
                "selected_dv": dv, "selected_seed": None, "rank_H": None,
                "leakage_bits": None, "design_trials": design_trials,
                "design_failure_rate": None, "eval_trials": eval_trials,
                "eval_failures": None, "eval_failure_rate": None,
                "eval_failure_upper": None, "confidence_level": confidence_level,
                "selection_passed_eval": False,
                "rejected_eval_count": rejected_eval_count,
                "mean_iterations": None, "p95_iterations": None,
                "max_iterations": None, "construction_method": "peg",
                "status": "not_found_eval" if rejected_eval_count else "not_found",
                "r_shannon_min": r_min, "eval_trial_rows": eval_rows_all,
            }

        fine_start = max(search_start, coarse_first_pass_r - coarse_step + 1)
        fine_end = coarse_first_pass_r
        candidates: list[tuple[int, float, int]] = []

        if verbose:
            print(f"    fine scan r in [{fine_start}, {fine_end}]")

        for r_fine in range(fine_start, fine_end + 1):
            for mseed in candidate_seeds:
                fail, _ = run_design_trials(
                    n, Q, r_fine, dv, mseed, design_trials, max_iter,
                    base_trial_seed=base_trial_seed + mseed * 100_000,
                )
                if verbose:
                    print(f"      fine r={r_fine}, seed={mseed}: fail={fail:.4f}")
                if fail < beta:
                    candidates.append((r_fine, fail, mseed))

        if not candidates:
            search_start = coarse_first_pass_r + 1
            continue

        candidates.sort(key=lambda item: (item[0], item[1], item[2]))
        max_candidate_r = max(item[0] for item in candidates)

        for cand_r, design_fail, mseed in candidates:
            eval_base_seed = base_trial_seed + 50_000_000 + cand_r * 10_000 + mseed * 1_000
            eval_stats = evaluate_candidate_code(
                n, Q, cand_r, dv, mseed, eval_trials, max_iter,
                eval_base_seed, confidence_level,
            )
            eval_rows_all.extend(eval_stats.pop("eval_trial_rows", []))
            selection_passed = eval_stats["eval_failure_upper"] <= beta

            if verbose:
                print(f"      eval r={cand_r}, seed={mseed}: "
                      f"fail={eval_stats['eval_failure_rate']:.4f}, "
                      f"upper={eval_stats['eval_failure_upper']:.4f}, "
                      f"passed={selection_passed}")

            if selection_passed:
                H_pass, _, _, _ = build_ldpc_matrix(n, cand_r, dv, seed=mseed)
                accepted_rank = matrix_rank_gf2(H_pass)
                if verbose:
                    print(f"    SELECTED: r={cand_r}, seed={mseed}, "
                          f"rank={accepted_rank}, "
                          f"eval_fail={eval_stats['eval_failure_rate']:.4f}, "
                          f"upper={eval_stats['eval_failure_upper']:.4f}")
                return {
                    "n": n,
                    "Q": Q,
                    "beta": beta,
                    "selected_r": cand_r,
                    "selected_dv": dv,
                    "selected_seed": mseed,
                    "rank_H": accepted_rank,
                    "leakage_bits": cand_r,
                    "design_trials": design_trials,
                    "design_failure_rate": round(design_fail, 6),
                    "eval_trials": eval_trials,
                    "eval_failures": eval_stats["eval_failures"],
                    "eval_failure_rate": eval_stats["eval_failure_rate"],
                    "eval_failure_upper": eval_stats["eval_failure_upper"],
                    "confidence_level": confidence_level,
                    "selection_passed_eval": True,
                    "rejected_eval_count": rejected_eval_count,
                    "mean_iterations": eval_stats["mean_iterations"],
                    "p95_iterations": eval_stats["p95_iterations"],
                    "max_iterations": eval_stats["max_iterations"],
                    "construction_method": eval_stats["construction_method"],
                    "status": "ok",
                    "r_shannon_min": r_min,
                    "efficiency_r_over_shannon": round(cand_r / max(r_min, 1), 4),
                    "eval_trial_rows": eval_rows_all,
                }

            rejected_eval_count += 1

        search_start = max_candidate_r + 1

    return {
        "n": n, "Q": Q, "beta": beta, "selected_r": None,
        "selected_dv": dv, "selected_seed": None, "rank_H": None,
        "leakage_bits": None, "design_trials": design_trials,
        "design_failure_rate": None, "eval_trials": eval_trials,
        "eval_failures": None, "eval_failure_rate": None,
        "eval_failure_upper": None, "confidence_level": confidence_level,
        "selection_passed_eval": False,
        "rejected_eval_count": rejected_eval_count,
        "mean_iterations": None, "p95_iterations": None,
        "max_iterations": None, "construction_method": "peg",
        "status": "not_found_eval" if rejected_eval_count else "not_found",
        "r_shannon_min": r_min, "eval_trial_rows": eval_rows_all,
    }


# ---------------------------------------------------------------------------
# Leakage table builder (analog to Cascade empirical_leakage_table.csv)
# ---------------------------------------------------------------------------

def build_leakage_table(selected_codes: list[dict]) -> list[dict]:
    """
    Build per-beta leakage tables for the publication notebook.

    For LDPC, leakage_bits = selected_r (fixed, not a distribution).
    We produce mean/p95/p99/max all equal to selected_r, and failure_rate
    from the evaluation.
    """
    rows = []
    for code in selected_codes:
        if (
            code["status"] != "ok"
            or code["selected_r"] is None
            or not code.get("selection_passed_eval", False)
        ):
            continue
        beta_label = f"ldpc_beta{int(code['beta'] * 100):02d}"
        r = code["selected_r"]
        rows.append({
            "protocol": beta_label,
            "n": code["n"],
            "qber": code["Q"],
            "trials": code["eval_trials"],
            "mean_leakage": r,
            "p95_leakage": r,
            "p99_leakage": r,
            "max_leakage": r,
            "failure_rate": code["eval_failure_rate"],
            "failure_rate_upper": code["eval_failure_upper"],
            "selected_r": r,
            "rank_H": code["rank_H"],
            "r_shannon_min": code["r_shannon_min"],
            "efficiency_r_over_shannon": code["efficiency_r_over_shannon"],
            "mean_iterations": code["mean_iterations"],
            "p95_iterations": code["p95_iterations"],
            "max_iterations": code["max_iterations"],
            "confidence_level": code["confidence_level"],
            "beta": code["beta"],
        })
    return rows


# ---------------------------------------------------------------------------
# CSV I/O helpers
# ---------------------------------------------------------------------------

TRIAL_FIELDS = [
    "n", "Q", "r", "dv", "construction_method", "matrix_seed", "trial_seed",
    "initial_errors", "syndrome_weight", "decoder_converged",
    "syndrome_satisfied", "residual_errors", "success", "iterations",
    "leakage_bits",
]

SELECTED_FIELDS = [
    "n", "Q", "beta", "selected_r", "selected_dv", "selected_seed", "rank_H",
    "leakage_bits", "design_trials", "design_failure_rate", "eval_trials",
    "eval_failures", "eval_failure_rate", "eval_failure_upper",
    "confidence_level", "selection_passed_eval", "rejected_eval_count",
    "mean_iterations", "p95_iterations", "max_iterations", "construction_method",
    "status", "r_shannon_min", "efficiency_r_over_shannon",
]

LEAKAGE_FIELDS = [
    "protocol", "n", "qber", "trials", "mean_leakage", "p95_leakage",
    "p99_leakage", "max_leakage", "failure_rate", "failure_rate_upper",
    "selected_r", "rank_H", "r_shannon_min", "efficiency_r_over_shannon",
    "mean_iterations", "p95_iterations", "max_iterations", "confidence_level",
    "beta",
]


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    global MAX_R_MULTIPLIER
    parser = argparse.ArgumentParser(description="LDPC reconciliation simulation")
    parser.add_argument("--mode", choices=["quick", "full"], default="quick")
    parser.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--design-trials", type=int, default=None)
    parser.add_argument("--eval-trials", type=int, default=None)
    parser.add_argument("--max-iter", type=int, default=DEFAULT_MAX_ITER)
    parser.add_argument("--dv", type=int, default=DEFAULT_DV)
    parser.add_argument("--betas", type=float, nargs="+", default=BETA_VALUES)
    parser.add_argument("--confidence-level", type=float, default=DEFAULT_CONFIDENCE_LEVEL)
    parser.add_argument(
        "--max-r-multiplier", type=float, default=MAX_R_MULTIPLIER,
        help="maximum searched r as a multiple of ceil(n*h2(Q))",
    )
    parser.add_argument("--skip-sanity", action="store_true")
    parser.add_argument("--n-values", type=int, nargs="+", default=None)
    parser.add_argument("--q-values", type=float, nargs="+", default=None)
    args = parser.parse_args()

    # Mode defaults
    if args.mode == "quick":
        n_values = args.n_values or QUICK_N_VALUES
        design_trials = args.design_trials or 100
        eval_trials = args.eval_trials or 200
    else:
        n_values = args.n_values or FULL_N_VALUES
        design_trials = args.design_trials or 200
        eval_trials = args.eval_trials or 1000

    q_values = args.q_values or Q_VALUES
    betas = args.betas
    dv = args.dv
    max_iter = args.max_iter
    confidence_level = args.confidence_level
    MAX_R_MULTIPLIER = args.max_r_multiplier
    output_dir = Path(args.output_dir)
    tables_dir = output_dir / "tables"
    tables_dir.mkdir(parents=True, exist_ok=True)

    print(f"LDPC simulation: mode={args.mode}, n={n_values}, Q={q_values}")
    print(f"  design_trials={design_trials}, eval_trials={eval_trials}")
    print(f"  dv={dv}, max_iter={max_iter}, betas={betas}")
    print(f"  evaluation confidence level={confidence_level}")

    # Sanity checks
    if not args.skip_sanity:
        print("\nRunning sanity checks...")
        checks = run_sanity_checks()
        all_ok = True
        for c in checks:
            status = "PASS" if c["passed"] else "FAIL"
            print(f"  [{status}] {c['name']}: {c['detail']}")
            if not c["passed"]:
                all_ok = False
        if not all_ok:
            print("ERROR: Sanity checks failed. Aborting.")
            sys.exit(1)
        print("Sanity checks passed.\n")

    # Save config
    config = {
        "mode": args.mode,
        "n_values": n_values,
        "q_values": q_values,
        "betas": betas,
        "dv": dv,
        "design_trials": design_trials,
        "eval_trials": eval_trials,
        "max_iter": max_iter,
        "confidence_level": confidence_level,
        "candidate_seeds": CANDIDATE_SEEDS,
        "coarse_step_fraction": COARSE_STEP_FRACTION,
        "fine_step": FINE_STEP,
        "max_r_multiplier": MAX_R_MULTIPLIER,
    }
    (output_dir / "ldpc_config.json").write_text(
        json.dumps(config, indent=2), encoding="utf-8"
    )

    # Main loop
    all_selected = []
    all_eval_trials = []

    total = len(n_values) * len(q_values) * len(betas)
    job = 0
    t0 = time.time()

    for n, Q, beta in itertools.product(n_values, q_values, betas):
        job += 1
        elapsed = time.time() - t0
        print(f"\n[{job}/{total}] n={n}, Q={Q:.3f}, beta={beta:.2f}  "
              f"(elapsed {elapsed:.0f}s)")
        result = select_code_for_point(
            n, Q, beta,
            dv=dv,
            design_trials=design_trials,
            eval_trials=eval_trials,
            candidate_seeds=CANDIDATE_SEEDS,
            max_iter=max_iter,
            confidence_level=confidence_level,
            verbose=True,
        )

        # Collect eval trial rows
        eval_rows = result.pop("eval_trial_rows", [])
        all_eval_trials.extend(eval_rows)
        all_selected.append(result)

        # Checkpoint after each (n, Q, beta)
        write_csv(
            tables_dir / "ldpc_selected_codes.csv",
            all_selected,
            SELECTED_FIELDS,
        )
        write_csv(
            tables_dir / "ldpc_trial_results.csv",
            all_eval_trials,
            TRIAL_FIELDS,
        )
        # Build and save leakage table
        leakage_rows = build_leakage_table(all_selected)
        write_csv(
            tables_dir / "ldpc_leakage_table.csv",
            leakage_rows,
            LEAKAGE_FIELDS,
        )

    # Final summary
    print(f"\n{'='*60}")
    print(f"Done. Total time: {time.time() - t0:.1f}s")
    print(f"\nSelected codes ({len(all_selected)}):")
    for row in all_selected:
        if row["status"] == "ok":
            h2 = binary_entropy(row["Q"])
            r_shannon = row["r_shannon_min"]
            print(f"  n={row['n']:5d} Q={row['Q']:.3f} beta={row['beta']:.2f}  "
                  f"r={row['selected_r']:5d} (r_shannon={r_shannon:5d}, "
                  f"eff={row['efficiency_r_over_shannon']:.3f})  "
                  f"eval_fail={row['eval_failure_rate']:.4f}  "
                  f"upper={row['eval_failure_upper']:.4f}")
        else:
            print(f"  n={row['n']:5d} Q={row['Q']:.3f} beta={row['beta']:.2f}  "
                  f"{row['status'].upper()}")

    print(f"\nOutputs saved to {output_dir.resolve()}")
    print(f"  {tables_dir / 'ldpc_selected_codes.csv'}")
    print(f"  {tables_dir / 'ldpc_trial_results.csv'}")
    print(f"  {tables_dir / 'ldpc_leakage_table.csv'}")


if __name__ == "__main__":
    main()
