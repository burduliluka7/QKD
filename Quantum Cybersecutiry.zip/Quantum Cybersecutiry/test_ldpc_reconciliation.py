"""Focused validation checks for the LDPC reconciliation code."""

from __future__ import annotations

import numpy as np

from ldpc_reconciliation import (
    build_ldpc_matrix,
    run_sanity_checks,
    syndrome_bp_decode,
)
from run_ldpc_simulation import clopper_pearson_upper
from run_ldpc_simulation import build_edge_index, fast_ldpc_trial, fast_syndrome_from_error


def test_existing_sanity_checks() -> None:
    checks = run_sanity_checks()
    failures = [c for c in checks if not c["passed"]]
    assert not failures, failures


def test_peg_matrix_has_valid_edges_and_rows() -> None:
    cases = [(64, 24, 3), (256, 91, 3), (512, 165, 3)]
    for n, r, dv in cases:
        H, var_adj, chk_adj, meta = build_ldpc_matrix(n, r, dv=dv, seed=0)
        assert H.shape == (r, n)
        assert all(len(v) == dv and len(set(v)) == dv for v in var_adj)
        assert min(len(c) for c in chk_adj) > 0
        assert meta["zero_rows"] == 0
        assert 0 <= meta["rank_H"] <= r


def test_syndrome_match_is_not_success_by_itself() -> None:
    n = 2
    r = 1
    var_adj = [[0], [0]]
    chk_adj = [[0, 1]]
    sigma = np.array([0], dtype=np.uint8)

    result = syndrome_bp_decode(
        var_adj, chk_adj, sigma, n, r, Q_dec=0.1, max_iter=5
    )
    x_a = np.array([0, 0], dtype=np.uint8)
    x_b = np.array([1, 1], dtype=np.uint8)
    x_hat_a = x_b ^ result["e_hat"]

    assert result["syndrome_satisfied"]
    assert not np.array_equal(x_hat_a, x_a)


def test_clopper_pearson_upper_bound_scale() -> None:
    assert clopper_pearson_upper(0, 50, 0.95) > 0.05
    assert clopper_pearson_upper(0, 200, 0.95) < 0.05
    assert clopper_pearson_upper(1, 200, 0.0) == 0.005


def test_fast_sparse_syndrome_path() -> None:
    n, r, dv = 64, 24, 3
    H, var_adj, chk_adj, meta = build_ldpc_matrix(n, r, dv=dv, seed=7)
    ev, ec, ce_arr = build_edge_index(var_adj, chk_adj, n, r)
    rng = np.random.default_rng(123)
    e = (rng.random(n) < 0.05).astype(np.uint8)
    dense_sigma = (H @ e.astype(np.int64)) % 2

    assert np.array_equal(fast_syndrome_from_error(ev, ec, e, r), dense_sigma)

    row = fast_ldpc_trial(
        n, 0.0, ev, ec, ce_arr, r, dv,
        matrix_seed=7,
        trial_seed=456,
        construction_method=meta["construction_method"],
        max_iter=20,
        collect_row=True,
    )
    assert row["success"]
    assert row["residual_errors"] == 0


def main() -> None:
    tests = [
        test_existing_sanity_checks,
        test_peg_matrix_has_valid_edges_and_rows,
        test_syndrome_match_is_not_success_by_itself,
        test_clopper_pearson_upper_bound_scale,
        test_fast_sparse_syndrome_path,
    ]
    for test in tests:
        test()
        print(f"PASS {test.__name__}")


if __name__ == "__main__":
    main()
