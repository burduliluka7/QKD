from __future__ import annotations

import math
from pathlib import Path
import sys
import unittest
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "code"))

from qkd.channel_model import ChannelParams
from qkd.decoy_asymptotic import vacuum_weak_bounds
from qkd.decoy_finite import (
    COUNT_CONCENTRATION_EVENTS,
    FiniteDecoyConfig,
    SecurityBudget,
    TWO_DECOY_COMMON_SECURITY_BRANCHES,
    allocate_sent_pulses,
    evaluate_finite_decoy,
)
from qkd.decoy_operating import (
    DecoyOperatingPoint,
    DecoySourceProbabilities,
    build_nominal_decoy_counts,
    evaluate_decoy_key_length_from_counts,
    find_first_decoy_crossing,
    load_operating_points,
)
from qkd.fixed_output import AcceptancePolicy
from qkd.hamming import finite_entropy, finite_gain, hamming_sandwich, log2_hamming_ball
from qkd.ideal_basis import (
    accepted_phase_error_upper,
    allocate_basis_counts,
    basis_count_policy,
    hypergeom_total_error_upper,
    ideal_key_length,
    phase_error_upper_for_observation,
    split_security_budget,
    truncated_binary_entropy,
)
from qkd.optimization import find_minimum_N
from qkd.operational import (
    binomial_lower_target,
    binomial_upper_acceptance_count,
    evaluate_operational_ideal,
    load_cascade_validation,
)


class HammingTests(unittest.TestCase):
    def test_monotonicity(self) -> None:
        for n in range(4, 40):
            for t in range(0, n - 1):
                self.assertLessEqual(finite_entropy(n, t + 1), finite_entropy(n, t) + 1e-10)
            for t in range(0, n // 2):
                self.assertGreaterEqual(finite_entropy(n + 1, t), finite_entropy(n, t) - 1e-10)

    def test_sandwich_bounds(self) -> None:
        for n in range(6, 60):
            for t in range(0, n // 2):
                log_low, log_high, _f_low, _f_high = hamming_sandwich(n, t)
                exact = log2_hamming_ball(n, t)
                self.assertLessEqual(log_low - 1e-10, exact)
                self.assertLessEqual(exact, log_high + 1e-10)

    def test_direct_integer_sum_small_n(self) -> None:
        for n in range(2, 20):
            for t in range(0, n + 1):
                direct = sum(math.comb(n, j) for j in range(t + 1))
                self.assertAlmostEqual(log2_hamming_ball(n, t), math.log2(direct), places=10)

    def test_finite_gain_nonnegative(self) -> None:
        for n in [64, 128, 256, 512]:
            for q in [0.01, 0.03, 0.1, 0.2]:
                t = int(math.floor(n * q))
                self.assertGreaterEqual(finite_gain(n, t), -1e-9)

    def test_truncated_binary_entropy_points(self) -> None:
        for x, expected in [(0.0, 0.0), (0.1, 0.4689955935892812), (0.5, 1.0), (0.6, 1.0), (1.0, 1.0)]:
            self.assertAlmostEqual(truncated_binary_entropy(x), expected)


class IdealBasisTests(unittest.TestCase):
    def test_purified_distance_budget_and_squared_sampling_tail(self) -> None:
        budget = split_security_budget(1e-9)
        self.assertAlmostEqual(
            budget["eps_cor"]
            + 2 * budget["eps_pe"]
            + 2 * budget["eps_smooth"]
            + budget["eps_pa"],
            1e-9,
        )
        e_x, n_z, m_x = 2, 120, 80
        epsilon = 1e-3
        upper = hypergeom_total_error_upper(e_x, n_z, m_x, epsilon)
        from scipy.stats import hypergeom as scipy_hypergeom
        self.assertGreaterEqual(
            float(scipy_hypergeom.cdf(e_x, n_z + m_x, upper, m_x)),
            epsilon**2,
        )
        if upper < n_z + m_x:
            self.assertLess(
                float(scipy_hypergeom.cdf(e_x, n_z + m_x, upper + 1, m_x)),
                epsilon**2,
            )

    def test_unbiased_and_biased_accounting(self) -> None:
        unbiased = allocate_basis_counts(101, 0.5)
        self.assertEqual((unbiased.n_z, unbiased.m_x), (25, 25))
        self.assertEqual(unbiased.n_z + unbiased.m_x + unbiased.remainder, 101)
        biased = allocate_basis_counts(1000, 0.9)
        self.assertAlmostEqual(biased.matched / 1000, 0.82, delta=0.002)
        self.assertNotAlmostEqual(biased.matched / 1000, 0.5, delta=0.1)

    def test_x_endpoint_maximization_and_clipping(self) -> None:
        n_z, m_x, eps = 31, 17, 1e-5
        e_tol, endpoint = accepted_phase_error_upper(0.2, n_z, m_x, eps)
        brute = max(phase_error_upper_for_observation(e, n_z, m_x, eps) for e in range(e_tol + 1))
        self.assertEqual(endpoint, brute)
        self.assertGreaterEqual(endpoint, 0)
        self.assertLessEqual(endpoint, n_z)

    def test_realized_basis_count_policy_and_subsampling(self) -> None:
        targets = allocate_basis_counts(1000, 0.7)
        self.assertFalse(basis_count_policy(1000, 0.7, targets.n_z - 1, targets.m_x).accepted_count_condition)
        self.assertFalse(basis_count_policy(1000, 0.7, targets.n_z, targets.m_x - 1).accepted_count_condition)
        exact = basis_count_policy(1000, 0.7, targets.n_z, targets.m_x)
        self.assertTrue(exact.accepted_count_condition)
        extra = basis_count_policy(1000, 0.7, targets.n_z + 11, targets.m_x + 7)
        self.assertEqual(extra.selected_block_sizes(), (targets.n_z, targets.m_x))

    def test_x_and_z_error_parameters_are_separated(self) -> None:
        base = ideal_key_length(3000, 0.66, 0.01, 0.02)
        changed_x = ideal_key_length(3000, 0.66, 0.03, 0.02)
        self.assertEqual(base["L_max"], changed_x["L_max"])
        self.assertNotEqual((base["e_X_tol"], base["t_ph_upper"]), (changed_x["e_X_tol"], changed_x["t_ph_upper"]))
        changed_z = ideal_key_length(3000, 0.66, 0.01, 0.05)
        self.assertNotEqual(base["L_max"], changed_z["L_max"])
        self.assertEqual((base["e_X_tol"], base["t_ph_upper"]), (changed_z["e_X_tol"], changed_z["t_ph_upper"]))

    def test_completeness_targets_use_distribution_tails(self) -> None:
        N, p = 10_000, 0.49
        target = binomial_lower_target(N, p, 0.005)
        self.assertLess(target, math.floor(N * p))
        accepted_errors = binomial_upper_acceptance_count(1000, 0.03, 0.01)
        self.assertGreater(accepted_errors, math.floor(1000 * 0.03))

    def test_cascade_cap_uses_separate_design_and_validation_halves(self) -> None:
        records = load_cascade_validation(ROOT / "results_03_reconciliation" / "tables" / "reconciliation_trials.csv")
        point = records[(4096, 0.005)]
        self.assertEqual(point.design_trials, 100)
        self.assertEqual(point.validation_trials, 100)
        self.assertEqual(point.transcript_cap, 2 * point.parity_query_cap)
        self.assertGreaterEqual(point.design_accepted_runs, 0)
        self.assertLessEqual(point.design_accepted_runs, point.design_trials)
        self.assertEqual(point.selection_family_size, 6)
        self.assertLessEqual(
            point.selection_adjusted_success_lower_95,
            point.success_lower_95,
        )
        result = evaluate_operational_ideal(
            6234,
            0.82,
            0.005,
            "cascade_four_pass",
            cascade_records=records,
            cascade_block_size=4096,
        )
        self.assertIsNotNone(result)
        assert result is not None
        self.assertGreaterEqual(result.honest_success_lower_95, 0.90)


class DecoyFormulaTests(unittest.TestCase):
    def test_two_decoy_security_budget_bookkeeping(self) -> None:
        budget = SecurityBudget.wiesemann_equal_split(1e-9)
        self.assertEqual(len(COUNT_CONCENTRATION_EVENTS), 12)
        self.assertEqual(TWO_DECOY_COMMON_SECURITY_BRANCHES, 17)
        self.assertAlmostEqual(budget.total_secrecy_failure(), budget.epsilon_sec_prime)
        self.assertAlmostEqual(budget.common_auxiliary_value(), budget.epsilon_sec_prime / 17.0)

    def test_security_budget_rejects_invalid_allocations(self) -> None:
        budget = SecurityBudget.wiesemann_equal_split(1e-9)
        missing = dict(budget.concentration_epsilons)
        missing.pop(COUNT_CONCENTRATION_EVENTS[0])
        bad = SecurityBudget(
            epsilon_cor=budget.epsilon_cor,
            epsilon_sec_prime=budget.epsilon_sec_prime,
            epsilon_serfling=budget.epsilon_serfling,
            epsilon_smoothing=budget.epsilon_smoothing,
            epsilon_pa=budget.epsilon_pa,
            concentration_epsilons=missing,
        )
        with self.assertRaises(ValueError):
            bad.validate()

        over = SecurityBudget(
            epsilon_cor=budget.epsilon_cor,
            epsilon_sec_prime=budget.epsilon_sec_prime,
            epsilon_serfling=budget.epsilon_sec_prime,
            epsilon_smoothing=budget.epsilon_smoothing,
            epsilon_pa=budget.epsilon_pa,
            concentration_epsilons=budget.concentration_epsilons,
        )
        with self.assertRaises(ValueError):
            over.validate()

    def test_security_overheads_match_simplified_expression(self) -> None:
        budget = SecurityBudget.wiesemann_equal_split(1e-9)
        eps0 = budget.epsilon_sec_prime / TWO_DECOY_COMMON_SECURITY_BRANCHES
        self.assertAlmostEqual(budget.verification_overhead_bits(), math.log2(2.0 / budget.epsilon_cor))
        self.assertAlmostEqual(
            budget.secrecy_overhead_bits(),
            4.0 * math.log2(1.0 / ((2.0 ** 0.25) * eps0)),
        )

    def test_fixed_output_policy_certifies_exact_output_length(self) -> None:
        budget = SecurityBudget.wiesemann_equal_split(1e-9)
        policy = AcceptancePolicy(
            output_bits=256,
            min_z_detections=1000,
            min_x_detections=1000,
            min_s_z0=0.0,
            min_s_z1=20_000.0,
            min_s_x1=8_000.0,
            max_lambda_x=0.04,
            max_leak_ec=3_000,
            security_budget=budget,
            completeness_beta=1e-2,
            margin_z=10.0,
        )
        self.assertTrue(policy.is_certifying())
        self.assertGreaterEqual(policy.certified_key_length(), policy.output_bits)
        observed = SimpleNamespace(
            z_detection_count=2000,
            x_counts=SimpleNamespace(total_detections=2000),
            s_z0_lower=0.0,
            s_z1_lower=25_000.0,
            s_x1_lower=10_000.0,
            lambda_x_upper=0.03,
            leak_ec=2_500,
        )
        self.assertEqual(policy.protocol_output(observed), 256)
        observed.leak_ec = 3_001
        self.assertIsNone(policy.protocol_output(observed))

    def test_asymptotic_rate_includes_signal_probability(self) -> None:
        params = ChannelParams(eta=0.1, y0=1e-5, e_d=0.01)
        full = vacuum_weak_bounds(0.5, 0.1, params, p_z=0.8, p_mu=1.0)
        half = vacuum_weak_bounds(0.5, 0.1, params, p_z=0.8, p_mu=0.5)
        self.assertAlmostEqual(half.rate_gllp, 0.5 * full.rate_gllp)

    def test_vacuum_weak_worked_example(self) -> None:
        result = vacuum_weak_bounds(
            0.5,
            0.1,
            ChannelParams(eta=0.1, y0=1e-5, e_d=0.01),
            p_z=1.0,
        )
        self.assertAlmostEqual(result.true_y1, 0.100, delta=0.001)
        self.assertAlmostEqual(result.y1_lower, 0.096, delta=0.004)
        self.assertAlmostEqual(result.true_e1, 0.0101, delta=0.001)
        self.assertAlmostEqual(result.e1_upper, 0.0112, delta=0.002)

    def test_finite_decoy_physical_ranges(self) -> None:
        cfg = FiniteDecoyConfig()
        result = evaluate_finite_decoy(1_000_000, 10.0, cfg)
        self.assertGreaterEqual(result.s_z0_lower, 0.0)
        self.assertGreaterEqual(result.s_z1_lower, 0.0)
        self.assertGreaterEqual(result.s_x1_lower, 0.0)
        self.assertGreaterEqual(result.lambda_x_upper, 0.0)
        self.assertLessEqual(result.lambda_x_upper, 1.0)
        self.assertGreaterEqual(result.phase_error_upper, 0.0)
        self.assertLessEqual(result.phase_error_upper, 1.0)

    def test_expected_count_integer_allocation(self) -> None:
        cfg = FiniteDecoyConfig()
        previous_zz_mu = -1
        previous_xx_nu = -1
        for N in range(1, 500):
            sent = allocate_sent_pulses(N, cfg)
            total = sum(sum(children.values()) for children in sent.values())
            self.assertEqual(total, N)
            self.assertGreaterEqual(sent["remainder"]["all"], 0)
            self.assertGreaterEqual(sent["ZZ"]["mu"], previous_zz_mu)
            self.assertGreaterEqual(sent["XX"]["nu"], previous_xx_nu)
            previous_zz_mu = sent["ZZ"]["mu"]
            previous_xx_nu = sent["XX"]["nu"]

    def test_zero_error_and_near_degenerate_parameters(self) -> None:
        clean = evaluate_finite_decoy(500_000, 0.0, FiniteDecoyConfig(), y0=0.0, e_d=0.0)
        self.assertEqual(clean.z_counts.total_errors, 0)
        self.assertGreaterEqual(clean.leak_ec, 0)
        tight = evaluate_finite_decoy(
            2_000_000,
            5.0,
            FiniteDecoyConfig(mu=0.31, nu=0.30, p_mu=0.5, p_nu=0.25, p_omega=0.25, p_z=0.7),
        )
        self.assertTrue(math.isfinite(tight.real_key_length))

    def test_error_monotonicity(self) -> None:
        cfg = FiniteDecoyConfig()
        clean = evaluate_finite_decoy(1_000_000, 10.0, cfg, e_d=0.005)
        noisy = evaluate_finite_decoy(1_000_000, 10.0, cfg, e_d=0.03)
        self.assertGreaterEqual(noisy.leak_ec, clean.leak_ec)
        self.assertLessEqual(noisy.final_key_length, clean.final_key_length)

    def test_end_to_end_minimum_local_check(self) -> None:
        cfg = FiniteDecoyConfig(mu=0.5, nu=0.1, p_mu=0.8, p_nu=0.15, p_omega=0.05)
        result = find_minimum_N(0.0, cfg, local_window=20)
        self.assertTrue(result.feasible)
        previous = evaluate_finite_decoy(result.N - 1, 0.0, cfg)
        self.assertFalse(previous.feasible)
        self.assertEqual(previous.final_key_length, result.ell_previous)
        self.assertEqual(previous.failure_reason, result.previous_failure_reason)

    def test_search_reproducibility(self) -> None:
        cfg = FiniteDecoyConfig(mu=0.6, nu=0.25, p_mu=0.5, p_nu=0.275, p_omega=0.225, p_z=0.6)
        a = find_minimum_N(10.0, cfg, local_window=64)
        b = find_minimum_N(10.0, cfg, local_window=64)
        self.assertEqual(a.N, b.N)
        self.assertEqual(a.final_key_length, b.final_key_length)


class DecoyOperatingPointTests(unittest.TestCase):
    def test_parse_and_validate_external_operating_points(self) -> None:
        points = load_operating_points(ROOT / "config" / "decoy_operating_points.csv")
        self.assertGreaterEqual(len(points), 1)
        for point in points:
            point.validate()
            self.assertLess(point.nu, point.mu)
            self.assertLessEqual(point.e_mu, 0.5)

    def test_gain_to_count_conversion_is_conservative(self) -> None:
        point = DecoyOperatingPoint(
            operating_point_id="rounding-test",
            mu=0.5,
            nu=0.1,
            q_mu=0.1234,
            q_nu=0.0345,
            q_0=0.001,
            e_mu=0.02,
            e_nu=0.03,
            e_0=0.5,
        )
        probs = DecoySourceProbabilities(p_mu=0.5, p_nu=0.25, p_0=0.25, p_z=0.6)
        counts = build_nominal_decoy_counts(12_345, point, probs)
        sent = counts.sent_counts["ZZ"]["mu"]
        self.assertEqual(counts.z_counts.detections["mu"], math.floor(sent * point.q_mu))
        self.assertEqual(
            counts.z_counts.errors["mu"],
            min(counts.z_counts.detections["mu"], math.ceil(sent * point.q_mu * point.e_mu)),
        )
        for basis_counts in (counts.z_counts, counts.x_counts):
            for name in ("mu", "nu", "omega"):
                self.assertLessEqual(basis_counts.errors[name], basis_counts.detections[name])

    def test_count_based_estimator_accepts_observed_style_counts(self) -> None:
        point = DecoyOperatingPoint(
            operating_point_id="direct-count-test",
            mu=0.5,
            nu=0.1,
            q_mu=0.35,
            q_nu=0.09,
            q_0=1e-5,
            e_mu=0.01,
            e_nu=0.011,
            e_0=0.5,
        )
        probs = DecoySourceProbabilities(p_mu=0.5, p_nu=0.25, p_0=0.25, p_z=0.6)
        result = evaluate_decoy_key_length_from_counts(500_000, point, probs)
        self.assertTrue(math.isfinite(result.real_key_length))
        self.assertGreaterEqual(result.z_counts.total_detections, 0)

    def test_invalid_operating_points_are_rejected(self) -> None:
        with self.assertRaises(ValueError):
            DecoyOperatingPoint(
                operating_point_id="bad-intensity",
                mu=0.1,
                nu=0.5,
                q_mu=0.1,
                q_nu=0.1,
                q_0=0.0,
                e_mu=0.01,
                e_nu=0.01,
                e_0=0.5,
            ).validate()
        with self.assertRaises(ValueError):
            DecoyOperatingPoint(
                operating_point_id="bad-gain",
                mu=0.5,
                nu=0.1,
                q_mu=1.2,
                q_nu=0.1,
                q_0=0.0,
                e_mu=0.01,
                e_nu=0.01,
                e_0=0.5,
            ).validate()
        with self.assertRaises(ValueError):
            DecoyOperatingPoint(
                operating_point_id="bad-error",
                mu=0.5,
                nu=0.1,
                q_mu=0.2,
                q_nu=0.1,
                q_0=0.0,
                e_mu=0.8,
                e_nu=0.01,
                e_0=0.5,
            ).validate()

    def test_first_crossing_minimality(self) -> None:
        point = DecoyOperatingPoint(
            operating_point_id="crossing-test",
            mu=0.5,
            nu=0.1,
            q_mu=0.65,
            q_nu=0.22,
            q_0=1e-4,
            e_mu=0.002,
            e_nu=0.002,
            e_0=0.5,
        )
        probs = DecoySourceProbabilities(p_mu=0.5, p_nu=0.25, p_0=0.25, p_z=0.6)
        crossing = find_first_decoy_crossing(point, probs, start=1024, max_N=5_000_000, exact_scan_limit=256)
        self.assertGreaterEqual(crossing.result.final_key_length, 256)
        self.assertIsNotNone(crossing.previous_result)
        assert crossing.previous_result is not None
        self.assertFalse(
            crossing.previous_result.estimation_feasible
            and crossing.previous_result.final_key_length >= crossing.result.config.target_bits
        )

    def test_exported_legacy_operating_point_regression(self) -> None:
        points = {p.operating_point_id: p for p in load_operating_points(ROOT / "config" / "decoy_operating_points.csv")}
        point = points["syn-loss-10dB"]
        probs = DecoySourceProbabilities()
        cfg = FiniteDecoyConfig(mu=0.5, nu=0.1, p_mu=0.8, p_nu=0.15, p_omega=0.05, p_z=0.9)
        legacy = evaluate_finite_decoy(1_000_000, 10.0, cfg)
        new = evaluate_decoy_key_length_from_counts(1_000_000, point, probs)
        self.assertEqual(new.z_counts.detections, legacy.z_counts.detections)
        self.assertEqual(new.x_counts.detections, legacy.x_counts.detections)
        self.assertEqual(new.z_counts.errors, legacy.z_counts.errors)
        self.assertEqual(new.x_counts.errors, legacy.x_counts.errors)
        self.assertEqual(new.final_key_length, legacy.final_key_length)

    def test_main_decoy_script_exports_fixed_output_policy(self) -> None:
        script = (ROOT / "code" / "run_main_decoy_results.py").read_text(encoding="utf-8")
        self.assertIn("qkd.fixed_output", script)
        self.assertIn("acceptance_policies.json", script)
        self.assertIn("estimate_operating_point_success", script)
        self.assertIn("count_acceptance_lower_95", script)

    def test_policy_rejects_each_adverse_threshold(self) -> None:
        budget = SecurityBudget.wiesemann_equal_split(1e-9)
        policy = AcceptancePolicy(256, 0, 0, 0.0, 20_000.0, 8_000.0, 0.04, 3_000, budget, 0.0, 0.0)
        base = dict(z_detection_count=1, x_counts=SimpleNamespace(total_detections=1),
                    s_z0_lower=0.0, s_z1_lower=21_000.0, s_x1_lower=9_000.0,
                    lambda_x_upper=0.03, leak_ec=2_999)
        self.assertEqual(policy.protocol_output(SimpleNamespace(**base)), 256)
        for field, value in [("s_z0_lower", -1.0), ("s_z1_lower", 19_999.0),
                             ("s_x1_lower", 7_999.0), ("lambda_x_upper", 0.041),
                             ("leak_ec", 3_001)]:
            changed = dict(base)
            changed[field] = value
            self.assertIsNone(policy.protocol_output(SimpleNamespace(**changed)))

    def test_operational_scope_is_declared(self) -> None:
        manuscript = (ROOT / "report" / "main.tex").read_text(encoding="utf-8")
        generator = (ROOT / "build_publication_ready_notebook.py").read_text(encoding="utf-8")
        self.assertIn("resource calculation includes basis-count and X-test abort probabilities", manuscript)
        self.assertIn("count acceptance rather than complete protocol success", manuscript)
        self.assertIn("Symmetric planning error rate", generator)
        self.assertNotIn(r"$N_{\min}$ at $Q_{\mathrm{tol}}=3\%$ (Cascade p95)", generator)


class GeneratedArtifactTests(unittest.TestCase):
    def test_generated_artifacts_when_pipeline_has_run(self) -> None:
        expected = [
            ROOT / "results" / "decoy" / "asymptotic_validation.csv",
            ROOT / "results" / "decoy" / "fixed_parameters.csv",
            ROOT / "results" / "decoy" / "selected_parameters.csv",
            ROOT / "results" / "decoy" / "epsilon_allocation.csv",
            ROOT / "results" / "decoy" / "honest_success.csv",
            ROOT / "results" / "decoy" / "source_benchmark.csv",
            ROOT / "report" / "figures" / "decoy_n256_search_comparison.pdf",
            ROOT / "report" / "figures" / "decoy_threshold_diagnostic.pdf",
            ROOT / "report" / "generated_tables" / "decoy_fixed_parameters.tex",
            ROOT / "report" / "generated_tables" / "decoy_epsilon_allocation.tex",
            ROOT / "report" / "generated_tables" / "decoy_honest_success.tex",
        ]
        missing = [str(p) for p in expected if not p.exists()]
        if missing:
            self.skipTest("Decoy pipeline artifacts not generated yet: " + ", ".join(missing))

    def test_generated_epsilon_table_agrees_with_code_values(self) -> None:
        table = ROOT / "report" / "generated_tables" / "decoy_epsilon_allocation.tex"
        if not table.exists():
            self.skipTest("Decoy epsilon table has not been generated yet")
        text = table.read_text(encoding="utf-8")
        budget = SecurityBudget.wiesemann_equal_split(1e-9)
        mantissa, exponent = f"{budget.common_auxiliary_value():.3e}".split("e")
        expected_tex = f"{float(mantissa):.3f}\\times10^{{{int(exponent)}}}"
        self.assertIn("$12+2+2+1=17$", text)
        self.assertIn(expected_tex, text)


if __name__ == "__main__":
    unittest.main()
